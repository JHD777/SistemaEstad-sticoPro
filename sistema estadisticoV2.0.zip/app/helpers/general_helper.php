<?php
/**
 * Función para obtener la URL de assets
 */
function asset_url($path = '') {
    return base_url('assets/' . ltrim($path, '/'));
}
?>