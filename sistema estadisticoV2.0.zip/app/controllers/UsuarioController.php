<?php
/**
 * Sistema Estadístico Pro - Controlador de Usuarios
 * Maneja la gestión de usuarios (solo para usuarios supremos)
 */

class UsuarioController extends Controller {
    private $usuarioModel;

    public function __construct() {
        parent::__construct();
        $this->usuarioModel = new Usuario();
    }

    /**
     * Verificar permisos (sobrescribir método padre)
     */
    protected function checkAuthentication() {
        $this->requireAuth();
        $this->requirePermission('users.view');
    }

    /**
     * Listar usuarios
     */
    public function listar($pagina = 1) {
        $filtros = [];

        // Aplicar filtros si se enviaron
        if (isset($_GET['rol']) && !empty($_GET['rol'])) {
            $filtros['rol'] = $this->sanitize($_GET['rol']);
        }

        if (isset($_GET['activo']) && $_GET['activo'] !== '') {
            $filtros['activo'] = $_GET['activo'] === '1';
        }

        // Buscar si hay término de búsqueda
        if (isset($_GET['buscar']) && !empty($_GET['buscar'])) {
            $termino = $this->sanitize($_GET['buscar']);
            $resultado = $this->usuarioModel->buscar($termino, $pagina);
        } else {
            $resultado = $this->usuarioModel->listar($pagina, ITEMS_PER_PAGE, $filtros);
        }

        $data = [
            'usuarios' => $resultado['usuarios'],
            'paginacion' => [
                'pagina_actual' => $resultado['pagina'],
                'total_paginas' => $resultado['total_paginas'],
                'total_registros' => $resultado['total'],
                'registros_por_pagina' => $resultado['limite']
            ],
            'filtros' => $filtros,
            'estadisticas' => $this->usuarioModel->obtenerEstadisticas(),
            'roles' => USER_ROLES
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('usuarios/listar', $data);
    }

    /**
     * Mostrar formulario para crear usuario
     */
    public function crear() {
        $this->requirePermission('users.create');

        $data = [
            'roles' => USER_ROLES,
            'roles_disponibles' => $this->getRolesDisponibles()
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('usuarios/crear', $data);
    }

    /**
     * Procesar creación de usuario
     */
    public function procesarCreacion() {
        $this->requirePermission('users.create');

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('usuarios/crear'), 'Método no permitido', 'error');
            return;
        }

        $nombre = $this->sanitize($_POST['nombre'] ?? '');
        $email = $this->sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $rol = $this->sanitize($_POST['rol'] ?? 'basico');

        // Validar datos
        $datosUsuario = [
            'nombre' => $nombre,
            'email' => $email,
            'password' => $password,
            'rol' => $rol
        ];

        $errores = $this->usuarioModel->validarDatos($datosUsuario);

        if (!empty($errores)) {
            $mensaje = implode('<br>', $errores);
            $this->redirectWithMessage(base_url('usuarios/crear'), $mensaje, 'error');
            return;
        }

        // Crear usuario
        $datosInsertar = [
            'nombre' => $nombre,
            'email' => $email,
            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
            'rol' => $rol,
            'activo' => true
        ];

        $usuarioId = $this->usuarioModel->crear($datosInsertar);

        if (!$usuarioId) {
            $this->redirectWithMessage(base_url('usuarios/crear'), 'Error al crear usuario', 'error');
            return;
        }

        // Log de creación de usuario
        error_log("Usuario creado: {$email} ({$rol}) por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('usuarios/listar'), 'Usuario creado exitosamente', 'success');
    }

    /**
     * Mostrar formulario para editar usuario
     */
    public function editar($id) {
        $this->requirePermission('users.edit');

        $usuario = $this->usuarioModel->obtenerPorId($id);

        if (!$usuario) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'Usuario no encontrado', 'error');
            return;
        }

        // Los usuarios supremos no pueden ser editados por otros usuarios supremos
        if ($usuario['rol'] === 'supremo' && $_SESSION['user_role'] !== 'supremo') {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'No tienes permisos para editar este usuario', 'error');
            return;
        }

        $data = [
            'usuario' => $usuario,
            'roles' => USER_ROLES,
            'roles_disponibles' => $this->getRolesDisponibles()
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('usuarios/editar', $data);
    }

    /**
     * Procesar edición de usuario
     */
    public function procesarEdicion($id) {
        $this->requirePermission('users.edit');

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url("usuarios/editar/{$id}"), 'Método no permitido', 'error');
            return;
        }

        $usuario = $this->usuarioModel->obtenerPorId($id);

        if (!$usuario) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'Usuario no encontrado', 'error');
            return;
        }

        // Los usuarios supremos no pueden ser editados por otros usuarios supremos
        if ($usuario['rol'] === 'supremo' && $_SESSION['user_role'] !== 'supremo') {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'No tienes permisos para editar este usuario', 'error');
            return;
        }

        $nombre = $this->sanitize($_POST['nombre'] ?? '');
        $email = $this->sanitize($_POST['email'] ?? '');
        $rol = $this->sanitize($_POST['rol'] ?? 'basico');
        $activo = isset($_POST['activo']) ? ($_POST['activo'] === '1') : true;

        // Validar datos
        $datosUsuario = [
            'id' => $id,
            'nombre' => $nombre,
            'email' => $email,
            'rol' => $rol
        ];

        $errores = $this->usuarioModel->validarDatos($datosUsuario, true);

        if (!empty($errores)) {
            $mensaje = implode('<br>', $errores);
            $this->redirectWithMessage(base_url("usuarios/editar/{$id}"), $mensaje, 'error');
            return;
        }

        // Actualizar usuario
        $datosActualizar = [
            'nombre' => $nombre,
            'email' => $email,
            'rol' => $rol,
            'activo' => $activo
        ];

        $resultado = $this->usuarioModel->actualizar($id, $datosActualizar);

        if (!$resultado) {
            $this->redirectWithMessage(base_url("usuarios/editar/{$id}"), 'Error al actualizar usuario', 'error');
            return;
        }

        // Log de actualización de usuario
        error_log("Usuario actualizado: {$email} ({$rol}) por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('usuarios/listar'), 'Usuario actualizado exitosamente', 'success');
    }

    /**
     * Desactivar usuario
     */
    public function desactivar($id) {
        $this->requirePermission('users.edit');

        $usuario = $this->usuarioModel->obtenerPorId($id);

        if (!$usuario) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'Usuario no encontrado', 'error');
            return;
        }

        // Los usuarios supremos no pueden ser desactivados por otros usuarios supremos
        if ($usuario['rol'] === 'supremo' && $_SESSION['user_role'] !== 'supremo') {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'No tienes permisos para desactivar este usuario', 'error');
            return;
        }

        // No permitir desactivar al propio usuario
        if ($usuario['id'] == $_SESSION['user_id']) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'No puedes desactivar tu propio usuario', 'error');
            return;
        }

        $resultado = $this->usuarioModel->desactivar($id);

        if (!$resultado) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'Error al desactivar usuario', 'error');
            return;
        }

        // Log de desactivación de usuario
        error_log("Usuario desactivado: {$usuario['email']} por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('usuarios/listar'), 'Usuario desactivado exitosamente', 'success');
    }

    /**
     * Activar usuario
     */
    public function activar($id) {
        $this->requirePermission('users.edit');

        $usuario = $this->usuarioModel->obtenerPorId($id);

        if (!$usuario) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'Usuario no encontrado', 'error');
            return;
        }

        $resultado = $this->usuarioModel->activar($id);

        if (!$resultado) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'Error al activar usuario', 'error');
            return;
        }

        // Log de activación de usuario
        error_log("Usuario activado: {$usuario['email']} por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('usuarios/listar'), 'Usuario activado exitosamente', 'success');
    }

    /**
     * Cambiar contraseña de usuario
     */
    public function cambiarPassword($id) {
        $this->requirePermission('users.edit');

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'Método no permitido', 'error');
            return;
        }

        $usuario = $this->usuarioModel->obtenerPorId($id);

        if (!$usuario) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'Usuario no encontrado', 'error');
            return;
        }

        $newPassword = $_POST['new_password'] ?? '';

        if (empty($newPassword)) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'La contraseña es requerida', 'error');
            return;
        }

        if (!$this->validarPassword($newPassword)) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'La contraseña debe tener al menos ' . PASSWORD_MIN_LENGTH . ' caracteres', 'error');
            return;
        }

        $resultado = $this->usuarioModel->cambiarPassword($id, $newPassword);

        if (!$resultado) {
            $this->redirectWithMessage(base_url('usuarios/listar'), 'Error al cambiar contraseña', 'error');
            return;
        }

        // Log de cambio de contraseña
        error_log("Contraseña cambiada para usuario: {$usuario['email']} por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('usuarios/listar'), 'Contraseña cambiada exitosamente', 'success');
    }

    /**
     * Obtener roles disponibles según permisos del usuario actual
     */
    private function getRolesDisponibles() {
        $usuarioActual = $_SESSION['user_role'];
        $rolesDisponibles = [];

        foreach (USER_ROLES as $rol => $config) {
            // Usuarios supremos pueden asignar cualquier rol
            if ($usuarioActual === 'supremo') {
                $rolesDisponibles[$rol] = $config['name'];
            }
            // Otros usuarios solo pueden asignar roles inferiores
            elseif ($usuarioActual === 'admin' && !in_array($rol, ['supremo'])) {
                $rolesDisponibles[$rol] = $config['name'];
            }
            // Usuarios básicos y registrados no pueden asignar roles
            elseif (!in_array($usuarioActual, ['basico', 'registrado'])) {
                $rolesDisponibles[$rol] = $config['name'];
            }
        }

        return $rolesDisponibles;
    }

    /**
     * Validar contraseña según reglas del sistema
     */
    private function validarPassword($password) {
        return strlen($password) >= PASSWORD_MIN_LENGTH;
    }

    /**
     * Ver perfil de usuario (AJAX)
     */
    public function verPerfil($id) {
        $usuario = $this->usuarioModel->obtenerPorId($id);

        if (!$usuario) {
            $this->jsonError('Usuario no encontrado', 404);
            return;
        }

        // Verificar permisos
        if (!$this->hasPermission('users.view')) {
            $this->jsonError('No tienes permisos para ver este usuario', 403);
            return;
        }

        $this->jsonSuccess([
            'id' => $usuario['id'],
            'nombre' => $usuario['nombre'],
            'email' => $usuario['email'],
            'rol' => $usuario['rol'],
            'rol_nombre' => getRoleName($usuario['rol']),
            'fecha_creacion' => $usuario['fecha_creacion'],
            'activo' => $usuario['activo']
        ]);
    }

    /**
     * Obtener estadísticas de usuarios (AJAX)
     */
    public function obtenerEstadisticas() {
        if (!$this->hasPermission('users.view')) {
            $this->jsonError('No tienes permisos para ver estadísticas', 403);
            return;
        }

        $estadisticas = $this->usuarioModel->obtenerEstadisticas();
        $this->jsonSuccess($estadisticas);
    }
}