<?php
/**
 * Sistema Estadístico Pro - Controlador del Centro Estadístico
 * Implementa el algoritmo de visualización de datos según especificaciones
 */

class EstadisticaController extends Controller {
    private $especieModel;
    private $formularioModel;
    private $preguntaModel;
    private $respuestaModel;

    public function __construct() {
        parent::__construct();
        $this->especieModel = new Especie();
        $this->formularioModel = new Formulario();
        $this->preguntaModel = new Pregunta();
        $this->respuestaModel = new Respuesta();
    }

    /**
     * Verificar permisos
     */
    protected function checkAuthentication() {
        // El centro estadístico es accesible para usuarios básicos sin login
        // pero con funcionalidades limitadas
        return true;
    }

    /**
     * Centro Estadístico principal con filtros
     */
    public function index() {
        // Crear preguntas base de ejemplo si no existen (inicialización del sistema)
        $this->crearPreguntasBaseEjemplo();

        $data = [
            'reinos' => $this->especieModel->obtenerReinos(),
            'modulos' => [],
            'especies' => [],
            'estadisticas' => null,
            'filtros' => [
                'reino' => $_GET['reino'] ?? null,
                'modulo' => $_GET['modulo'] ?? null,
                'especie' => $_GET['especie'] ?? null
            ]
        ];

        // Si hay filtros aplicados, obtener estadísticas
        if (!empty($data['filtros']['reino']) || !empty($data['filtros']['modulo']) || !empty($data['filtros']['especie'])) {
            $data['estadisticas'] = $this->obtenerEstadisticasFiltradas($data['filtros']);
        }

        // Cargar opciones de módulos y especies según filtros
        if (!empty($data['filtros']['reino'])) {
            $data['modulos'] = $this->especieModel->obtenerModulos($data['filtros']['reino']);
        }

        if (!empty($data['filtros']['modulo'])) {
            $data['especies'] = $this->especieModel->obtenerEspecies($data['filtros']['modulo']);
        }

        $this->render('estadistica/index', $data);
    }

    /**
     * Obtener estadísticas según filtros aplicados
     * Implementa el algoritmo de intersección de preguntas según especificaciones
     */
    private function obtenerEstadisticasFiltradas($filtros) {
        $estadisticas = [];

        // Determinar el nivel de filtro aplicado
        if (!empty($filtros['especie'])) {
            // Vista Específica: Mostrar TODAS las preguntas del formulario de la especie
            $especieId = $filtros['especie'];
            error_log("DEBUG Centro Estadístico: Obteniendo estadísticas para especie ID: {$especieId}");
            $estadisticas = $this->obtenerEstadisticasEspecie($especieId);
            $estadisticas['nivel'] = 'especie';
            $estadisticas['titulo'] = 'Estadísticas de Especie';
            error_log("DEBUG Centro Estadístico: Especie - Preguntas encontradas: " . count($estadisticas['preguntas'] ?? []));

        } elseif (!empty($filtros['modulo'])) {
            // Vista Medio: Encontrar intersección de preguntas comunes a todas las especies del módulo
            $moduloId = $filtros['modulo'];
            error_log("DEBUG Centro Estadístico: Obteniendo estadísticas para módulo ID: {$moduloId}");
            $estadisticas = $this->obtenerEstadisticasModulo($moduloId);
            $estadisticas['nivel'] = 'modulo';
            $estadisticas['titulo'] = 'Estadísticas de Módulo';
            error_log("DEBUG Centro Estadístico: Módulo - Preguntas encontradas: " . count($estadisticas['preguntas'] ?? []));

        } elseif (!empty($filtros['reino'])) {
            // Vista General: Encontrar intersección de preguntas comunes a todas las especies del reino
            $reinoId = $filtros['reino'];
            error_log("DEBUG Centro Estadístico: Obteniendo estadísticas para reino ID: {$reinoId}");
            $estadisticas = $this->obtenerEstadisticasReino($reinoId);
            $estadisticas['nivel'] = 'reino';
            $estadisticas['titulo'] = 'Estadísticas de Reino';
            error_log("DEBUG Centro Estadístico: Reino - Preguntas encontradas: " . count($estadisticas['preguntas'] ?? []));
        }

        return $estadisticas;
    }

    /**
     * Vista Específica: Estadísticas de una especie específica
     * Muestra TODAS las preguntas del formulario de la especie
     */
    private function obtenerEstadisticasEspecie($especieId) {
        // Obtener formulario aprobado de la especie
        $formulario = $this->formularioModel->obtenerAprobadoPorEspecie($especieId);

        if (!$formulario) {
            return ['error' => 'No hay formulario aprobado para esta especie'];
        }

        // Obtener todas las preguntas del formulario
        $preguntas = $this->preguntaModel->obtenerPorFormulario($formulario['id']);

        $estadisticas = [
            'preguntas' => []
        ];

        foreach ($preguntas as $pregunta) {
            $datosPregunta = $this->respuestaModel->obtenerEstadisticasPorPregunta($pregunta['id']);
            if ($datosPregunta) {
                $estadisticas['preguntas'][] = [
                    'pregunta' => $pregunta,
                    'datos' => $datosPregunta
                ];
            }
        }

        return $estadisticas;
    }

    /**
     * Vista Medio: Estadísticas de un módulo
     * Según especificaciones: encuentra la intersección de preguntas comunes a TODOS los formularios de especies del módulo
     */
    private function obtenerEstadisticasModulo($moduloId) {
        error_log("DEBUG obtenerEstadisticasModulo: Procesando módulo ID: {$moduloId}");

        // Obtener todas las especies del módulo
        $especies = $this->especieModel->obtenerEspecies($moduloId);
        $especiesIds = array_column($especies, 'id');

        error_log("DEBUG obtenerEstadisticasModulo: Especies encontradas: " . count($especiesIds) . " - IDs: " . implode(',', $especiesIds));

        if (empty($especiesIds)) {
            return ['error' => 'No hay especies en este módulo'];
        }

        // Obtener formularios aprobados para todas las especies del módulo
        $formulariosIds = [];
        foreach ($especiesIds as $especieId) {
            $formulario = $this->formularioModel->obtenerAprobadoPorEspecie($especieId);
            if ($formulario) {
                $formulariosIds[] = $formulario['id'];
                error_log("DEBUG obtenerEstadisticasModulo: Formulario aprobado encontrado para especie {$especieId}: {$formulario['id']}");
            } else {
                error_log("DEBUG obtenerEstadisticasModulo: No hay formulario aprobado para especie {$especieId}");
            }
        }

        if (count($formulariosIds) < 2) {
            return ['error' => 'Se necesitan al menos 2 formularios aprobados para calcular intersección'];
        }

        error_log("DEBUG obtenerEstadisticasModulo: Formularios para intersección: " . implode(',', $formulariosIds));

        // Encontrar preguntas comunes a TODOS los formularios (INTERSECCIÓN)
        $preguntasComunes = $this->encontrarPreguntasComunes($formulariosIds);
        error_log("DEBUG obtenerEstadisticasModulo: Preguntas comunes encontradas: " . count($preguntasComunes));

        $estadisticas = [
            'preguntas' => []
        ];

        foreach ($preguntasComunes as $pregunta) {
            error_log("DEBUG obtenerEstadisticasModulo: Procesando pregunta común: {$pregunta['texto_pregunta']} (ID: {$pregunta['id']})");

            // Obtener estadísticas de la pregunta
            $datosPregunta = $this->respuestaModel->obtenerEstadisticasPorPregunta($pregunta['id']);

            if ($datosPregunta) {
                error_log("DEBUG obtenerEstadisticasModulo: Datos encontrados para pregunta {$pregunta['id']}");
                $estadisticas['preguntas'][] = [
                    'pregunta' => $pregunta,
                    'datos' => $datosPregunta
                ];
            } else {
                error_log("DEBUG obtenerEstadisticasModulo: No hay datos para pregunta {$pregunta['id']}");
            }
        }

        error_log("DEBUG obtenerEstadisticasModulo: Total preguntas con datos: " . count($estadisticas['preguntas']));
        return $estadisticas;
    }

    /**
     * Vista General: Estadísticas de un reino
     * Según especificaciones: encuentra la intersección de preguntas comunes a TODOS los formularios de especies del reino
     */
    private function obtenerEstadisticasReino($reinoId) {
        error_log("DEBUG obtenerEstadisticasReino: Procesando reino ID: {$reinoId}");

        // Obtener todas las especies del reino (de todos los módulos)
        $modulos = $this->especieModel->obtenerModulos($reinoId);
        $especiesIds = [];
        foreach ($modulos as $modulo) {
            $especies = $this->especieModel->obtenerEspecies($modulo['id']);
            $especiesIds = array_merge($especiesIds, array_column($especies, 'id'));
        }

        error_log("DEBUG obtenerEstadisticasReino: Especies encontradas: " . count($especiesIds) . " - IDs: " . implode(',', $especiesIds));

        if (empty($especiesIds)) {
            return ['error' => 'No hay especies en los módulos de este reino'];
        }

        // Obtener formularios aprobados para todas las especies del reino
        $formulariosIds = [];
        foreach ($especiesIds as $especieId) {
            $formulario = $this->formularioModel->obtenerAprobadoPorEspecie($especieId);
            if ($formulario) {
                $formulariosIds[] = $formulario['id'];
                error_log("DEBUG obtenerEstadisticasReino: Formulario aprobado encontrado para especie {$especieId}: {$formulario['id']}");
            } else {
                error_log("DEBUG obtenerEstadisticasReino: No hay formulario aprobado para especie {$especieId}");
            }
        }

        if (count($formulariosIds) < 2) {
            return ['error' => 'Se necesitan al menos 2 formularios aprobados para calcular intersección'];
        }

        error_log("DEBUG obtenerEstadisticasReino: Formularios para intersección: " . implode(',', $formulariosIds));

        // Encontrar preguntas comunes a TODOS los formularios (INTERSECCIÓN)
        $preguntasComunes = $this->encontrarPreguntasComunes($formulariosIds);
        error_log("DEBUG obtenerEstadisticasReino: Preguntas comunes encontradas: " . count($preguntasComunes));

        $estadisticas = [
            'preguntas' => []
        ];

        foreach ($preguntasComunes as $pregunta) {
            error_log("DEBUG obtenerEstadisticasReino: Procesando pregunta común: {$pregunta['texto_pregunta']} (ID: {$pregunta['id']})");

            // Obtener estadísticas agregadas de todas las especies del reino
            $datosPregunta = $this->respuestaModel->obtenerEstadisticasPorPregunta($pregunta['id']);

            if ($datosPregunta) {
                error_log("DEBUG obtenerEstadisticasReino: Datos encontrados para pregunta {$pregunta['id']}");
                $estadisticas['preguntas'][] = [
                    'pregunta' => $pregunta,
                    'datos' => $datosPregunta
                ];
            } else {
                error_log("DEBUG obtenerEstadisticasReino: No hay datos para pregunta {$pregunta['id']}");
            }
        }

        error_log("DEBUG obtenerEstadisticasReino: Total preguntas con datos: " . count($estadisticas['preguntas']));
        return $estadisticas;
    }

    /**
     * Encontrar preguntas comunes a TODOS los formularios (INTERSECCIÓN)
     * Algoritmo clave según especificaciones - usado para especies específicas
     */
    private function encontrarPreguntasComunes($formulariosIds) {
        if (empty($formulariosIds)) {
            return [];
        }

        // Obtener todas las preguntas de cada formulario
        $preguntasPorFormulario = [];
        foreach ($formulariosIds as $formularioId) {
            $preguntas = $this->preguntaModel->obtenerPorFormulario($formularioId);
            $preguntasPorFormulario[$formularioId] = $preguntas;
        }

        if (empty($preguntasPorFormulario)) {
            return [];
        }

        // Encontrar intersección: preguntas que existen en TODOS los formularios
        // con el mismo texto_pregunta, tipo_pregunta y opciones
        $primero = array_shift($preguntasPorFormulario);
        $comunes = $primero;

        foreach ($preguntasPorFormulario as $preguntas) {
            $comunes = $this->interseccionPreguntas($comunes, $preguntas);
        }

        return $comunes;
    }

    /**
     * Calcular intersección de preguntas entre dos arrays
     */
    private function interseccionPreguntas($preguntas1, $preguntas2) {
        $comunes = [];

        foreach ($preguntas1 as $p1) {
            foreach ($preguntas2 as $p2) {
                // Comparar por texto, tipo y opciones (ignorando IDs y orden)
                if ($p1['texto_pregunta'] === $p2['texto_pregunta'] &&
                    $p1['tipo_pregunta'] === $p2['tipo_pregunta'] &&
                    $p1['opciones'] === $p2['opciones']) {
                    $comunes[] = $p1; // Usar la primera ocurrencia
                    break;
                }
            }
        }

        return $comunes;
    }

    /**
     * Crear preguntas base de ejemplo si no existen
     * Método temporal para inicializar el sistema
     */
    private function crearPreguntasBaseEjemplo() {
        try {
            // Primero asegurar que existan las especies base necesarias
            $especiesIds = $this->crearEspeciesBase();

            // Verificar si ya existen preguntas base para Flora
            $preguntasReino = $this->preguntaModel->obtenerPreguntasBase('reino', $especiesIds['flora']);
            if (empty($preguntasReino)) {
                // Crear preguntas base para Flora
                $preguntasFlora = [
                    [
                        'formulario_id' => null, // NULL para preguntas base
                        'texto_pregunta' => '¿El organismo realiza fotosíntesis?',
                        'tipo_pregunta' => 'booleano',
                        'orden' => 1,
                        'obligatoria' => true,
                        'depende_de' => null,
                        'respuesta_requerida' => null,
                        'ambito_aplicacion' => 'reino',
                        'ambito_id' => $especiesIds['flora']
                    ],
                    [
                        'formulario_id' => null, // NULL para preguntas base
                        'texto_pregunta' => '¿Presencia de clorofila?',
                        'tipo_pregunta' => 'booleano',
                        'orden' => 2,
                        'obligatoria' => true,
                        'depende_de' => null,
                        'respuesta_requerida' => null,
                        'ambito_aplicacion' => 'reino',
                        'ambito_id' => $especiesIds['flora']
                    ],
                    [
                        'formulario_id' => null, // NULL para preguntas base
                        'texto_pregunta' => '¿Tipo de estructura principal?',
                        'tipo_pregunta' => 'opcion_multiple',
                        'opciones' => 'Leñosa,Herbácea,Fungus',
                        'orden' => 3,
                        'obligatoria' => true,
                        'depende_de' => null,
                        'respuesta_requerida' => null,
                        'ambito_aplicacion' => 'reino',
                        'ambito_id' => $especiesIds['flora']
                    ]
                ];

                foreach ($preguntasFlora as $pregunta) {
                    $this->preguntaModel->crear($pregunta);
                }
            }

            // Verificar preguntas base para Cítricos
            $preguntasCitricos = $this->preguntaModel->obtenerPreguntasBase('modulo', $especiesIds['citricos']);
            if (empty($preguntasCitricos)) {
                $preguntasCitricosData = [
                    [
                        'formulario_id' => null, // NULL para preguntas base
                        'texto_pregunta' => '¿Presencia de aceites esenciales en la piel?',
                        'tipo_pregunta' => 'booleano',
                        'orden' => 1,
                        'obligatoria' => false,
                        'depende_de' => null,
                        'respuesta_requerida' => null,
                        'ambito_aplicacion' => 'modulo',
                        'ambito_id' => $especiesIds['citricos']
                    ],
                    [
                        'formulario_id' => null, // NULL para preguntas base
                        'texto_pregunta' => '¿Estructura del fruto?',
                        'tipo_pregunta' => 'opcion_multiple',
                        'opciones' => 'Hesperidio,Baya,Drupa',
                        'orden' => 2,
                        'obligatoria' => true,
                        'depende_de' => null,
                        'respuesta_requerida' => null,
                        'ambito_aplicacion' => 'modulo',
                        'ambito_id' => $especiesIds['citricos']
                    ]
                ];

                foreach ($preguntasCitricosData as $pregunta) {
                    $this->preguntaModel->crear($pregunta);
                }
            }
        } catch (Exception $e) {
            error_log("Error creando preguntas base: " . $e->getMessage());
            // Continue without failing the whole page load
        }
    }

    /**
     * Crear especies base necesarias para las preguntas base
     * Retorna array con los IDs de las especies creadas
     */
    private function crearEspeciesBase() {
        $ids = [];

        // Verificar y crear reinos
        $reinos = $this->especieModel->obtenerReinos();
        if (empty($reinos)) {
            // Crear reinos base
            $floraId = $this->especieModel->crear([
                'nombre' => 'Flora',
                'tipo' => 'reino',
                'parent_id' => null,
                'descripcion' => 'Reino vegetal - Plantas y organismos fotosintéticos'
            ]);

            $faunaId = $this->especieModel->crear([
                'nombre' => 'Fauna',
                'tipo' => 'reino',
                'parent_id' => null,
                'descripcion' => 'Reino animal - Animales y organismos heterótrofos'
            ]);

            $ids['flora'] = $floraId;
            $ids['fauna'] = $faunaId;
        } else {
            // Encontrar IDs existentes
            foreach ($reinos as $reino) {
                if ($reino['nombre'] === 'Flora') {
                    $ids['flora'] = $reino['id'];
                } elseif ($reino['nombre'] === 'Fauna') {
                    $ids['fauna'] = $reino['id'];
                }
            }
        }

        // Verificar y crear módulos base
        if (isset($ids['flora'])) {
            $modulosFlora = $this->especieModel->obtenerModulos($ids['flora']);
            if (empty($modulosFlora)) {
                $citricosId = $this->especieModel->crear([
                    'nombre' => 'Cítricos',
                    'tipo' => 'modulo',
                    'parent_id' => $ids['flora'],
                    'descripcion' => 'Árboles y plantas cítricas'
                ]);
                $ids['citricos'] = $citricosId;
            } else {
                // Buscar Cítricos existente
                foreach ($modulosFlora as $modulo) {
                    if ($modulo['nombre'] === 'Cítricos') {
                        $ids['citricos'] = $modulo['id'];
                        break;
                    }
                }
            }
        }

        if (isset($ids['fauna'])) {
            $modulosFauna = $this->especieModel->obtenerModulos($ids['fauna']);
            if (empty($modulosFauna)) {
                $bovinosId = $this->especieModel->crear([
                    'nombre' => 'Bovinos',
                    'tipo' => 'modulo',
                    'parent_id' => $ids['fauna'],
                    'descripcion' => 'Ganado bovino y especies relacionadas'
                ]);
                $ids['bovinos'] = $bovinosId;
            } else {
                // Buscar Bovinos existente
                foreach ($modulosFauna as $modulo) {
                    if ($modulo['nombre'] === 'Bovinos') {
                        $ids['bovinos'] = $modulo['id'];
                        break;
                    }
                }
            }
        }

        return $ids;
    }

    /**
     * API para obtener módulos de un reino (AJAX)
     */
    public function obtenerModulos($reinoId) {
        $modulos = $this->especieModel->obtenerModulos($reinoId);
        $this->jsonSuccess($modulos);
    }

    /**
     * API para obtener especies de un módulo (AJAX)
     */
    public function obtenerEspecies($moduloId) {
        $especies = $this->especieModel->obtenerEspecies($moduloId);
        $this->jsonSuccess($especies);
    }

    /**
     * API pública para obtener módulos de un reino (para Centro Estadístico)
     * No requiere autenticación
     */
    public function apiObtenerModulos() {
        $reinoId = isset($_GET['reino']) ? (int)$_GET['reino'] : null;

        if (!$reinoId) {
            $this->jsonError('ID de reino requerido', 400);
            return;
        }

        $modulos = $this->especieModel->obtenerModulos($reinoId);

        // Agregar información adicional por módulo
        foreach ($modulos as &$modulo) {
            $especies = $this->especieModel->obtenerEspecies($modulo['id']);
            $modulo['especies_count'] = count($especies);
        }

        $this->jsonSuccess($modulos);
    }

    /**
     * API pública para obtener especies de un módulo (para Centro Estadístico)
     * No requiere autenticación
     */
    public function apiObtenerEspecies() {
        $moduloId = isset($_GET['modulo']) ? (int)$_GET['modulo'] : null;

        if ($moduloId) {
            // Obtener especies de un módulo específico
            $especies = $this->especieModel->obtenerEspecies($moduloId);
            $this->jsonSuccess($especies);
        } else {
            // Obtener todas las especies de todos los módulos
            $todosModulos = [];

            // Obtener módulos de Flora
            $modulosFlora = $this->especieModel->obtenerModulos(1);
            foreach ($modulosFlora as $modulo) {
                $especies = $this->especieModel->obtenerEspecies($modulo['id']);
                $todosModulos = array_merge($todosModulos, $especies);
            }

            // Obtener módulos de Fauna
            $modulosFauna = $this->especieModel->obtenerModulos(2);
            foreach ($modulosFauna as $modulo) {
                $especies = $this->especieModel->obtenerEspecies($modulo['id']);
                $todosModulos = array_merge($todosModulos, $especies);
            }

            $this->jsonSuccess($todosModulos);
        }
    }
}
?>