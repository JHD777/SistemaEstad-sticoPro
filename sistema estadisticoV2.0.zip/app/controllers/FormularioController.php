<?php
/**
 * Sistema Estadístico Pro - Controlador de Formularios
 * Maneja la gestión de formularios dinámicos y realización de censos
 */

class FormularioController extends Controller {
    private $formularioModel;
    private $especieModel;
    private $preguntaModel;
    private $registroModel;
    private $respuestaModel;

    public function __construct() {
        parent::__construct();
        $this->formularioModel = new Formulario();
        $this->especieModel = new Especie();
        $this->preguntaModel = new Pregunta();
        $this->registroModel = new RegistroCenso();
        $this->respuestaModel = new Respuesta();
    }

    /**
     * Verificar permisos (sobrescribir método padre)
     */
    protected function checkAuthentication() {
        $this->requireAuth();
        // Los permisos específicos se verifican en cada método según sea necesario
    }

    /**
     * Listar formularios
     */
    public function listar($pagina = 1) {
        $filtros = [];

        // Aplicar filtros si se enviaron
        if (isset($_GET['especie_id']) && !empty($_GET['especie_id'])) {
            $filtros['especie_id'] = (int)$_GET['especie_id'];
        }

        if (isset($_GET['estado']) && !empty($_GET['estado'])) {
            $filtros['estado'] = $this->sanitize($_GET['estado']);
        }

        // Buscar si hay término de búsqueda
        if (isset($_GET['buscar']) && !empty($_GET['buscar'])) {
            $termino = $this->sanitize($_GET['buscar']);
            $resultado = $this->formularioModel->buscar($termino, $pagina);
        } else {
            $resultado = $this->formularioModel->listar($pagina, ITEMS_PER_PAGE, $filtros);
        }

        $data = [
            'formularios' => $resultado['formularios'],
            'paginacion' => [
                'pagina_actual' => $resultado['pagina'],
                'total_paginas' => $resultado['total_paginas'],
                'total_registros' => $resultado['total'],
                'registros_por_pagina' => $resultado['limite']
            ],
            'filtros' => $filtros,
            'estadisticas' => $this->formularioModel->obtenerEstadisticas(),
            'especies' => $this->especieModel->obtenerParaFormularios(),
            'estados' => FORM_STATES
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('formularios/listar', $data);
    }

    /**
     * Mostrar formulario para crear formulario
     */
    public function crear() {
        $this->requirePermission('forms.create');

        $data = [
            'especies' => $this->especieModel->obtenerEspeciesHoja(),
            'tipos_pregunta' => QUESTION_TYPES,
            'reinos' => $this->especieModel->obtenerReinos(),
            'modulos' => $this->especieModel->obtenerTodas() // Obtener todos para filtrar módulos después
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('formularios/crear', $data);
    }

    /**
     * Procesar creación de formulario con herencia automática
     */
    public function procesarCreacion() {
        $this->requirePermission('forms.create');

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('formularios/crear'), 'Método no permitido', 'error');
            return;
        }

        $especie_id = (int)($_POST['especie_id'] ?? 0);
        $tipo_formulario = $this->sanitize($_POST['tipo_formulario'] ?? '');
        $nombre = $this->sanitize($_POST['nombre'] ?? '');
        $descripcion = $this->sanitize($_POST['descripcion'] ?? '');

        // Para admin, el estado por defecto es 'pendiente', para supremo puede ser 'borrador'
        $estado_default = $this->hasPermission('forms.approve') ? 'borrador' : 'pendiente';
        $estado = $this->sanitize($_POST['estado'] ?? $estado_default);

        // Validar datos básicos
        $datosFormulario = [
            'especie_id' => $especie_id,
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'estado' => $estado,
            'creador_id' => $_SESSION['user_id']
        ];

        // Validar que especie_id sea válido
        if ($especie_id <= 0) {
            $this->redirectWithMessage(base_url('formularios/crear'), 'Debes seleccionar una especie válida para el formulario.', 'error');
            return;
        }

        $errores = $this->formularioModel->validarDatos($datosFormulario);

        if (!empty($errores)) {
            $mensaje = implode('<br>', $errores);
            $this->redirectWithMessage(base_url('formularios/crear'), $mensaje, 'error');
            return;
        }

        // Crear formulario
        $formularioId = $this->formularioModel->crear($datosFormulario);

        if (!$formularioId) {
            $this->redirectWithMessage(base_url('formularios/crear'), 'Error al crear formulario', 'error');
            return;
        }

        // Con la nueva arquitectura, las preguntas heredadas se cargan dinámicamente
        // Solo procesar preguntas específicas del formulario si se enviaron
        if (isset($_POST['preguntas']) && is_array($_POST['preguntas'])) {
            $this->procesarPreguntas($formularioId, $_POST['preguntas']);
        }

        // Log de creación de formulario
        error_log("Formulario creado: {$nombre} por {$_SESSION['user_email']}", 0);

        $mensaje = 'Formulario creado exitosamente';
        if ($estado === 'pendiente') {
            $mensaje .= '. Se ha enviado para aprobación.';
        }

        $this->redirectWithMessage(base_url('formularios/listar'), $mensaje, 'success');
    }

    /**
     * Procesar preguntas del formulario
     */
    private function procesarPreguntas($formularioId, $preguntasData) {
        $orden = 1; // Reiniciar orden desde 1
        $preguntasCreadas = []; // Array para mapear índices de formulario a IDs de BD
        $preguntasConDependencias = []; // Preguntas que necesitan actualizar dependencias

        // Primera pasada: crear todas las preguntas SIN dependencias
        $ordenActual = 1;
        foreach ($preguntasData as $index => $preguntaData) {
            if (empty($preguntaData['texto_pregunta'])) {
                continue; // Saltar preguntas vacías
            }

            // Limpiar valores vacíos para opciones
            $opciones = isset($preguntaData['opciones']) && !empty(trim($preguntaData['opciones'])) ? $this->sanitize($preguntaData['opciones']) : null;

            // Para preguntas que NO son de opción múltiple, opciones debe ser NULL
            if ($preguntaData['tipo_pregunta'] !== 'opcion_multiple') {
                $opciones = null;
            }

            $datosPregunta = [
                'formulario_id' => $formularioId,
                'texto_pregunta' => $this->sanitize($preguntaData['texto_pregunta']),
                'tipo_pregunta' => $this->sanitize($preguntaData['tipo_pregunta']),
                'opciones' => $opciones,
                'orden' => $ordenActual,
                'obligatoria' => isset($preguntaData['obligatoria']) ? 1 : 0,
                'depende_de' => null, // Crear SIN dependencias primero
                'respuesta_requerida' => null
            ];

            $errores = $this->preguntaModel->validarDatos($datosPregunta);

            if (empty($errores)) {
                $preguntaId = $this->preguntaModel->crear($datosPregunta);
                if ($preguntaId) {
                    // Mapear el número de pregunta (orden visual) al ID de la BD
                    // El JavaScript envía dependencias como números de pregunta (1, 2, 3...)
                    $numeroPregunta = $ordenActual; // Este es el número visual de la pregunta (1, 2, 3...)
                    $preguntasCreadas[$numeroPregunta] = $preguntaId;

                    // Si esta pregunta tiene dependencias, guardarla para actualizar después
                    if (!empty($preguntaData['depende_de'])) {
                        $respuestaRequerida = isset($preguntaData['respuesta_requerida']) && !empty(trim($preguntaData['respuesta_requerida'])) ? $this->sanitize($preguntaData['respuesta_requerida']) : null;

                        $preguntasConDependencias[] = [
                            'id' => $preguntaId,
                            'depende_de_numero' => (int)$preguntaData['depende_de'],
                            'respuesta_requerida' => $respuestaRequerida
                        ];
                    }

                    error_log("Pregunta creada exitosamente: ID {$preguntaId}, orden {$ordenActual}, numero_pregunta {$numeroPregunta}");
                    $ordenActual++;
                } else {
                    error_log("Error creando pregunta: " . json_encode($datosPregunta));
                }
            } else {
                error_log("Errores en pregunta: " . json_encode($errores));
            }
        }

        // Segunda pasada: actualizar dependencias con los IDs correctos
        foreach ($preguntasConDependencias as $preguntaDep) {
            $dependeDeId = $preguntasCreadas[$preguntaDep['depende_de_numero']] ?? null;

            if ($dependeDeId) {
                $datosActualizar = [
                    'depende_de' => $dependeDeId,
                    'respuesta_requerida' => $preguntaDep['respuesta_requerida']
                ];

                $this->preguntaModel->actualizar($preguntaDep['id'], $datosActualizar);
                error_log("Dependencia actualizada para pregunta {$preguntaDep['id']}: depende_de = {$dependeDeId} (numero {$preguntaDep['depende_de_numero']})");
            } else {
                error_log("Error: No se encontró ID para dependencia numero {$preguntaDep['depende_de_numero']} en pregunta {$preguntaDep['id']}");
            }
        }
    }

    /**
     * Mostrar formulario para editar formulario
     */
    public function editar($id) {
        $this->requirePermission('forms.edit');

        $formulario = $this->formularioModel->obtenerPorId($id);

        if (!$formulario) {
            $this->redirectWithMessage(base_url('formularios/listar'), 'Formulario no encontrado', 'error');
            return;
        }

        // Verificar permisos de edición
        if ($formulario['creador_id'] != $_SESSION['user_id'] && !$this->hasPermission('forms.edit_all')) {
            $this->redirectWithMessage(base_url('formularios/listar'), 'No tienes permisos para editar este formulario', 'error');
            return;
        }

        $preguntas = $this->preguntaModel->obtenerPorFormulario($id);

        // Obtener preguntas padre disponibles para lógica condicional
        $preguntasPadre = $this->preguntaModel->obtenerPreguntasPadre($formulario['id']);

        $data = [
            'formulario' => $formulario,
            'preguntas' => $preguntas,
            'preguntas_padre' => $preguntasPadre,
            'especies' => $this->especieModel->obtenerEspeciesHoja(),
            'tipos_pregunta' => QUESTION_TYPES,
            'estados' => FORM_STATES
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('formularios/editar', $data);
    }

    /**
     * Procesar edición de formulario
     */
    public function procesarEdicion($id) {
        $this->requirePermission('forms.edit');

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url("formularios/editar/{$id}"), 'Método no permitido', 'error');
            return;
        }

        $formulario = $this->formularioModel->obtenerPorId($id);

        if (!$formulario) {
            $this->redirectWithMessage(base_url('formularios/listar'), 'Formulario no encontrado', 'error');
            return;
        }

        // Verificar permisos de edición
        if ($formulario['creador_id'] != $_SESSION['user_id'] && !$this->hasPermission('forms.edit_all')) {
            $this->redirectWithMessage(base_url('formularios/listar'), 'No tienes permisos para editar este formulario', 'error');
            return;
        }

        $nombre = $this->sanitize($_POST['nombre'] ?? '');
        $descripcion = $this->sanitize($_POST['descripcion'] ?? '');
        $estado = $this->sanitize($_POST['estado'] ?? 'borrador');

        // Validar datos básicos
        $datosFormulario = [
            'especie_id' => $formulario['especie_id'], // Mantener la especie existente
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'estado' => $estado
        ];

        $errores = $this->formularioModel->validarDatos($datosFormulario, true);

        if (!empty($errores)) {
            $mensaje = implode('<br>', $errores);
            $this->redirectWithMessage(base_url("formularios/editar/{$id}"), $mensaje, 'error');
            return;
        }

        // Actualizar formulario (solo campos editables)
        $datosActualizar = [
            'nombre' => $nombre,
            'descripcion' => $descripcion,
            'estado' => $estado
        ];

        $resultado = $this->formularioModel->actualizar($id, $datosActualizar);

        if (!$resultado) {
            error_log("Error al actualizar formulario {$id}: " . json_encode($datosActualizar));
            $this->redirectWithMessage(base_url("formularios/editar/{$id}"), 'Error al actualizar formulario', 'error');
            return;
        }

        // Procesar preguntas existentes (actualizar) DESPUÉS de actualizar el formulario
        try {
            if (isset($_POST['preguntas']) && is_array($_POST['preguntas'])) {
                $this->procesarActualizacionPreguntas($id, $_POST['preguntas']);
            }
        } catch (Exception $e) {
            error_log("Error procesando preguntas del formulario {$id}: " . $e->getMessage());
            $this->redirectWithMessage(base_url("formularios/editar/{$id}"), 'Error al actualizar preguntas del formulario', 'error');
            return;
        }

        // Log de actualización de formulario
        error_log("Formulario actualizado: {$nombre} por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('formularios/listar'), 'Formulario actualizado exitosamente', 'success');
    }

    /**
     * Procesar actualización de preguntas existentes
     */
    private function procesarActualizacionPreguntas($formularioId, $preguntasData) {
        foreach ($preguntasData as $preguntaId => $preguntaData) {
            // Verificar si la pregunta es heredada
            $preguntaExistente = $this->preguntaModel->obtenerPorId($preguntaId);
            if (!$preguntaExistente) {
                continue; // Pregunta no existe, saltar
            }

            // Si la pregunta es heredada, no permitir modificaciones
            // Solo verificar si la columna existe
            if (isset($preguntaExistente['es_heredada']) && $preguntaExistente['es_heredada']) {
                continue; // Saltar preguntas heredadas
            }

            if (empty($preguntaData['texto_pregunta'])) {
                // Si la pregunta está vacía, eliminarla
                $this->preguntaModel->eliminar($preguntaId);
                continue;
            }

            // Limpiar valores vacíos para opciones y respuesta_requerida
            $opciones = isset($preguntaData['opciones']) && !empty(trim($preguntaData['opciones'])) ? $this->sanitize($preguntaData['opciones']) : null;
            $respuestaRequerida = isset($preguntaData['respuesta_requerida']) && !empty(trim($preguntaData['respuesta_requerida'])) ? $this->sanitize($preguntaData['respuesta_requerida']) : null;

            // Para preguntas que NO son de opción múltiple, opciones debe ser NULL
            if ($preguntaData['tipo_pregunta'] !== 'opcion_multiple') {
                $opciones = null;
            }

            // Para preguntas que NO dependen de otra, respuesta_requerida debe ser NULL
            if (empty($preguntaData['depende_de'])) {
                $respuestaRequerida = null;
            }

            $datosPregunta = [
                'texto_pregunta' => $this->sanitize($preguntaData['texto_pregunta']),
                'tipo_pregunta' => $this->sanitize($preguntaData['tipo_pregunta']),
                'opciones' => $opciones,
                'obligatoria' => isset($preguntaData['obligatoria']) ? 1 : 0,
                'depende_de' => !empty($preguntaData['depende_de']) ? (int)$preguntaData['depende_de'] : null,
                'respuesta_requerida' => $respuestaRequerida
            ];

            $errores = $this->preguntaModel->validarDatos($datosPregunta);

            if (empty($errores)) {
                $this->preguntaModel->actualizar($preguntaId, $datosPregunta);
            }
        }
    }

    /**
     * Responder formulario (realizar censo)
     */
    public function responder($id) {
        $this->requirePermission('census.create');

        $formulario = $this->formularioModel->obtenerPorId($id);

        if (!$formulario) {
            $this->redirectWithMessage(base_url('dashboard/general'), 'Formulario no encontrado', 'error');
            return;
        }

        if ($formulario['estado'] !== 'aprobado') {
            $this->redirectWithMessage(base_url('dashboard/general'), 'El formulario debe estar aprobado para realizar censos', 'error');
            return;
        }

        $preguntas = $this->preguntaModel->obtenerPorFormulario($id);

        // Agregar información de especie para el formulario
        $especie = $this->especieModel->obtenerPorId($formulario['especie_id']);
        $formulario['especie_nombre'] = $especie ? $especie['nombre'] : 'Desconocida';

        $data = [
            'formulario' => $formulario,
            'preguntas' => $preguntas
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('formularios/responder', $data);
    }

    /**
     * Procesar respuestas del formulario
     */
    public function procesarRespuestas($id) {
        $this->requirePermission('census.create');

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url("formularios/responder/{$id}"), 'Método no permitido', 'error');
            return;
        }

        $formulario = $this->formularioModel->obtenerPorId($id);

        if (!$formulario) {
            $this->redirectWithMessage(base_url('dashboard/general'), 'Formulario no encontrado', 'error');
            return;
        }

        if ($formulario['estado'] !== 'aprobado') {
            $this->redirectWithMessage(base_url("formularios/responder/{$id}"), 'El formulario debe estar aprobado', 'error');
            return;
        }

        // Crear registro de censo
        $datosRegistro = [
            'formulario_id' => $id,
            'usuario_admin_id' => $_SESSION['user_id'],
            'fecha_censo' => date('Y-m-d H:i:s'),
            'ubicacion_geo' => $this->sanitize($_POST['ubicacion_geo'] ?? ''),
            'observaciones' => $this->sanitize($_POST['observaciones'] ?? '')
        ];

        $registroId = $this->registroModel->crear($datosRegistro);

        if (!$registroId) {
            $this->redirectWithMessage(base_url("formularios/responder/{$id}"), 'Error al guardar el censo', 'error');
            return;
        }

        // Procesar respuestas
        $preguntas = $this->preguntaModel->obtenerPorFormulario($id);
        $respuestas = [];

        foreach ($preguntas as $pregunta) {
            $campoNombre = 'pregunta_' . $pregunta['id'];
            $valor = $_POST[$campoNombre] ?? '';

            // Validar respuesta
            if (!$this->preguntaModel->validarRespuesta($pregunta, $valor)) {
                continue; // Saltar respuestas inválidas
            }

            $respuestas[$pregunta['id']] = $valor;
        }

        // Guardar respuestas
        $resultado = $this->respuestaModel->crearMultiples($registroId, $respuestas);

        if (!$resultado) {
            // Si hay error guardando respuestas, eliminar el registro de censo
            $this->registroModel->eliminar($registroId);
            $this->redirectWithMessage(base_url("formularios/responder/{$id}"), 'Error al guardar las respuestas', 'error');
            return;
        }

        // Log de censo completado
        error_log("Censo completado: Formulario {$formulario['nombre']} por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('dashboard/general'), 'Censo guardado exitosamente', 'success');
    }

    /**
     * Ver detalles de formulario (AJAX)
     */
    public function verAjax($id) {
        $formulario = $this->formularioModel->obtenerPorId($id);

        if (!$formulario) {
            $this->jsonError('Formulario no encontrado', 404);
            return;
        }

        // Verificar permisos
        if (!$this->hasPermission('forms.view')) {
            $this->jsonError('No tienes permisos para ver este formulario', 403);
            return;
        }

        $preguntas = $this->preguntaModel->obtenerPorFormulario($id);

        $this->jsonSuccess([
            'formulario' => $formulario,
            'preguntas' => $preguntas
        ]);
    }

    /**
     * Eliminar formulario
     */
    public function eliminar($id) {
        $this->requirePermission('forms.delete');

        $formulario = $this->formularioModel->obtenerPorId($id);

        if (!$formulario) {
            $this->redirectWithMessage(base_url('formularios/listar'), 'Formulario no encontrado', 'error');
            return;
        }

        // Verificar permisos de eliminación
        if ($formulario['creador_id'] != $_SESSION['user_id'] && !$this->hasPermission('forms.delete_all')) {
            $this->redirectWithMessage(base_url('formularios/listar'), 'No tienes permisos para eliminar este formulario', 'error');
            return;
        }

        $resultado = $this->formularioModel->eliminar($id);

        if (!$resultado) {
            $this->redirectWithMessage(base_url('formularios/listar'), 'Error al eliminar formulario', 'error');
            return;
        }

        // Log de eliminación de formulario
        error_log("Formulario eliminado: {$formulario['nombre']} por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('formularios/listar'), 'Formulario eliminado exitosamente', 'success');
    }

    /**
     * Aprobar formulario (solo para usuarios supremos)
     */
    public function aprobar($id) {
        $this->requirePermission('forms.approve');

        $formulario = $this->formularioModel->obtenerPorId($id);

        if (!$formulario) {
            $this->redirectWithMessage(base_url('formularios/pendientes'), 'Formulario no encontrado', 'error');
            return;
        }

        if ($formulario['estado'] !== 'pendiente') {
            $this->redirectWithMessage(base_url('formularios/pendientes'), 'Solo se pueden aprobar formularios pendientes', 'error');
            return;
        }

        $resultado = $this->formularioModel->aprobar($id, $_SESSION['user_id']);

        if (!$resultado) {
            $this->redirectWithMessage(base_url('formularios/pendientes'), 'Error al aprobar formulario', 'error');
            return;
        }

        // Log de aprobación de formulario
        error_log("Formulario aprobado: {$formulario['nombre']} por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('formularios/pendientes'), 'Formulario aprobado exitosamente', 'success');
    }

    /**
     * Rechazar formulario (solo para usuarios supremos)
     */
    public function rechazar($id) {
        $this->requirePermission('forms.approve');

        $formulario = $this->formularioModel->obtenerPorId($id);

        if (!$formulario) {
            $this->redirectWithMessage(base_url('formularios/pendientes'), 'Formulario no encontrado', 'error');
            return;
        }

        if ($formulario['estado'] !== 'pendiente') {
            $this->redirectWithMessage(base_url('formularios/pendientes'), 'Solo se pueden rechazar formularios pendientes', 'error');
            return;
        }

        $resultado = $this->formularioModel->rechazar($id);

        if (!$resultado) {
            $this->redirectWithMessage(base_url('formularios/pendientes'), 'Error al rechazar formulario', 'error');
            return;
        }

        // Log de rechazo de formulario
        error_log("Formulario rechazado: {$formulario['nombre']} por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('formularios/pendientes'), 'Formulario rechazado', 'success');
    }

    /**
     * Ver formularios pendientes de aprobación
     */
    public function pendientes() {
        $this->requirePermission('forms.approve');

        $pendientes = $this->formularioModel->obtenerPendientes();

        $data = [
            'formularios_pendientes' => $pendientes
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('formularios/pendientes', $data);
    }

    /**
     * Obtener preguntas de formulario (AJAX)
     */
    public function obtenerPreguntas($id) {
        $preguntas = $this->preguntaModel->obtenerPorFormulario($id);

        if (empty($preguntas)) {
            $this->jsonError('No se encontraron preguntas para este formulario', 404);
            return;
        }

        $this->jsonSuccess($preguntas);
    }

    /**
     * Ver detalles de un formulario
     */
    public function ver($id) {
        $this->requireAuth();

        $formulario = $this->formularioModel->obtenerPorId($id);

        if (!$formulario) {
            $this->redirectWithMessage(base_url('formularios/listar'), 'Formulario no encontrado', 'error');
            return;
        }

        // Obtener preguntas del formulario
        $preguntas = $this->preguntaModel->obtenerPorFormulario($id);

        // Obtener estadísticas del formulario
        $estadisticas = [
            'total_preguntas' => count($preguntas),
            'preguntas_obligatorias' => count(array_filter($preguntas, fn($p) => $p['obligatoria'])),
            'preguntas_condicionales' => count(array_filter($preguntas, fn($p) => !empty($p['depende_de']))),
            'censos_realizados' => 0 // TODO: Implementar método contarPorFormulario en RegistroCenso
        ];

        $data = [
            'formulario' => $formulario,
            'preguntas' => $preguntas,
            'estadisticas' => $estadisticas
        ];

        $this->render('formularios/ver', $data);
    }

    /**
     * Duplicar formulario
     */
    public function duplicar($id) {
        $this->requirePermission('forms.create');

        $formulario = $this->formularioModel->obtenerPorId($id);

        if (!$formulario) {
            $this->redirectWithMessage(base_url('formularios/listar'), 'Formulario no encontrado', 'error');
            return;
        }

        // Crear nuevo formulario basado en el existente
        $datosNuevo = [
            'especie_id' => $formulario['especie_id'],
            'nombre' => $formulario['nombre'] . ' (Copia)',
            'descripcion' => $formulario['descripcion'],
            'estado' => 'borrador',
            'creador_id' => $_SESSION['user_id']
        ];

        $nuevoFormularioId = $this->formularioModel->crear($datosNuevo);

        if (!$nuevoFormularioId) {
            $this->redirectWithMessage(base_url('formularios/listar'), 'Error al duplicar formulario', 'error');
            return;
        }

        // Duplicar preguntas
        $preguntas = $this->preguntaModel->obtenerPorFormulario($id);

        foreach ($preguntas as $pregunta) {
            $datosPregunta = [
                'formulario_id' => $nuevoFormularioId,
                'texto_pregunta' => $pregunta['texto_pregunta'],
                'tipo_pregunta' => $pregunta['tipo_pregunta'],
                'opciones' => $pregunta['opciones'],
                'orden' => $pregunta['orden'],
                'obligatoria' => $pregunta['obligatoria'],
                'depende_de' => $pregunta['depende_de'],
                'respuesta_requerida' => $pregunta['respuesta_requerida']
            ];

            $this->preguntaModel->crear($datosPregunta);
        }

        // Log de duplicación de formulario
        error_log("Formulario duplicado: {$formulario['nombre']} -> Nuevo formulario creado por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('formularios/listar'), 'Formulario duplicado exitosamente', 'success');
    }
}