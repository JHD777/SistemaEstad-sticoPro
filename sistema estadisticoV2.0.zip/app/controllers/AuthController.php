<?php
/**
 * Sistema Estadístico Pro - Controlador de Autenticación
 * Maneja login, registro y gestión de sesiones
 */

class AuthController extends Controller {
    private $usuarioModel;

    public function __construct() {
        parent::__construct();
        $this->usuarioModel = new Usuario();
    }

    /**
     * Mostrar formulario de login
     */
    public function login() {
        // Si ya está logueado, redirigir al dashboard
        if (isset($_SESSION['user_id'])) {
            header('Location: ' . base_url('dashboard/general'));
            exit;
        }
        
        $data = [];

        // Verificar si hay mensaje de error en sesión
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage['message'];
            $data['flash_type'] = $flashMessage['type'];
        }

        // Renderizar vista directamente
        extract($data);
        $this->view('auth/login', $data);
    }

    /**
     * Procesar login
     */
    public function procesarLogin() {
        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('login'), 'Método no permitido', 'error');
            return;
        }

        $email = $this->sanitize($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        // Validar datos
        if (empty($email) || empty($password)) {
            $this->redirectWithMessage(base_url('login'), 'Email y contraseña son requeridos', 'error');
            return;
        }

        // Intentar verificar credenciales con la base de datos
        try {
            $usuario = $this->usuarioModel->obtenerPorEmail($email);

            if ($usuario && password_verify($password, $usuario['password_hash'])) {
                // Verificar que el usuario esté activo
                if (!$usuario['activo']) {
                    $this->redirectWithMessage(base_url('login'), 'Usuario inactivo. Contacte al administrador.', 'error');
                    return;
                }

                // Crear sesión
                $_SESSION['user_id'] = $usuario['id'];
                $_SESSION['user_name'] = $usuario['nombre'];
                $_SESSION['user_email'] = $usuario['email'];
                $_SESSION['user_role'] = $usuario['rol'];
                $_SESSION['login_time'] = time();

                // Log de login exitoso
                error_log("Login exitoso: {$usuario['email']} ({$usuario['rol']})", 0);

                header('Location: ' . base_url('dashboard/general'));
                exit;
                return;
            }
        } catch (Exception $e) {
            // Si hay error de base de datos, intentar con credenciales de respaldo
            error_log("Error de base de datos en login: " . $e->getMessage());
        }

        // Credenciales incorrectas
        $this->redirectWithMessage(base_url('login'), 'Credenciales incorrectas', 'error');
        return;
    }

    /**
      * Mostrar formulario de registro público
      */
     public function register() {
         // Si ya está logueado, redirigir al dashboard
         if (isset($_SESSION['user_id'])) {
             header('Location: ' . base_url('dashboard/general'));
             exit;
         }

         $data = [];

         // Verificar si hay mensaje de error en sesión
         $flashMessage = $this->getFlashMessage();
         if ($flashMessage) {
             $data['flash_message'] = $flashMessage['message'];
             $data['flash_type'] = $flashMessage['type'];
         }

         // Renderizar vista directamente
         extract($data);
         $this->view('auth/register', $data);
     }

    /**
      * Procesar registro público (cualquier usuario puede registrarse)
      */
     public function procesarRegistro() {
         // Si ya está logueado, redirigir al dashboard
         if (isset($_SESSION['user_id'])) {
             header('Location: ' . base_url('dashboard/general'));
             exit;
         }

         if (!$this->is_post()) {
             $this->redirectWithMessage(base_url('register'), 'Método no permitido', 'error');
             return;
         }

         $nombre = $this->sanitize($_POST['nombre'] ?? '');
         $email = $this->sanitize($_POST['email'] ?? '');
         $password = $_POST['password'] ?? '';
         $confirmPassword = $_POST['confirmPassword'] ?? '';
         $aceptarTerminos = isset($_POST['aceptarTerminos']);

         // Validar datos básicos
         if (empty($nombre) || empty($email) || empty($password) || empty($confirmPassword)) {
             $this->redirectWithMessage(base_url('register'), 'Todos los campos requeridos deben ser completados.', 'error');
             return;
         }

         // Verificar que las contraseñas coincidan
         if ($password !== $confirmPassword) {
             $this->redirectWithMessage(base_url('register'), 'Las contraseñas no coinciden.', 'error');
             return;
         }

         // Verificar longitud mínima de contraseña
         if (strlen($password) < 6) {
             $this->redirectWithMessage(base_url('register'), 'La contraseña debe tener al menos 6 caracteres.', 'error');
             return;
         }

         // Verificar aceptación de términos
         if (!$aceptarTerminos) {
             $this->redirectWithMessage(base_url('register'), 'Debes aceptar los términos y condiciones para continuar.', 'error');
             return;
         }

         // Verificar que el email no esté en uso
         try {
             $usuarioExistente = $this->usuarioModel->obtenerPorEmail($email);
             if ($usuarioExistente) {
                 $this->redirectWithMessage(base_url('register'), 'El correo electrónico ya está en uso. Por favor, intente con otro.', 'error');
                 return;
             }
         } catch (Exception $e) {
             // Si hay error de BD, intentar con respaldo
             error_log("Error verificando email existente: " . $e->getMessage());
         }

         // Crear usuario con rol 'registrado' por defecto
         $datosInsertar = [
             'nombre' => $nombre,
             'email' => $email,
             'password_hash' => password_hash($password, PASSWORD_DEFAULT),
             'rol' => 'registrado',
             'activo' => true
         ];

         try {
             $usuarioId = $this->usuarioModel->crear($datosInsertar);

             if (!$usuarioId) {
                 $this->redirectWithMessage(base_url('register'), 'Hubo un error al crear la cuenta. Por favor, intente nuevamente.', 'error');
                 return;
             }

             // Log de creación de usuario
             error_log("Usuario registrado públicamente: {$email} (registrado)", 0);

             // Redirigir al login con mensaje de éxito
             $this->redirectWithMessage(base_url('login'), '¡Cuenta creada con éxito! Ahora puedes iniciar sesión.', 'success');

         } catch (Exception $e) {
             error_log("Error creando usuario público: " . $e->getMessage());
             $this->redirectWithMessage(base_url('register'), 'Hubo un error al crear la cuenta. Por favor, intente nuevamente.', 'error');
         }
     }

    /**
     * Cerrar sesión
     */
    public function logout() {
        // Log de logout
        if (isset($_SESSION['user_email'])) {
            error_log("Logout: {$_SESSION['user_email']}", 0);
        }

        // Destruir sesión
        session_unset();
        session_destroy();

        $this->redirectWithMessage(base_url('login'), 'Sesión cerrada exitosamente', 'success');
    }

    /**
     * Verificar autenticación (sobrescribir método padre)
     */
    protected function checkAuthentication() {
        $currentRoute = $_SERVER['REQUEST_URI'] ?? '';

        // Remover parámetros de query
        if (($pos = strpos($currentRoute, '?')) !== false) {
            $currentRoute = substr($currentRoute, 0, $pos);
        }

        // Rutas públicas que no requieren autenticación
        $publicRoutes = [
            '/login',
            '/procesarLogin',
            '/logout',
            '/register'
        ];

        // Si es una ruta pública, no requerir autenticación
        foreach ($publicRoutes as $route) {
            if (strpos($currentRoute, $route) !== false) {
                return;
            }
        }

        // Para otras rutas, requerir autenticación
        if (!isset($_SESSION['user_id'])) {
            header('Location: ' . base_url('login'));
            exit;
        }
    }

    public function cambiarPassword() {
        $this->requireAuth();

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('dashboard/general'), 'Método no permitido', 'error');
            return;
        }

        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        // Validar datos
        if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
            $this->redirectWithMessage(base_url('dashboard/general'), 'Todos los campos son requeridos', 'error');
            return;
        }

        if ($newPassword !== $confirmPassword) {
            $this->redirectWithMessage(base_url('dashboard/general'), 'Las contraseñas no coinciden', 'error');
            return;
        }

        if (!$this->validatePassword($newPassword)) {
            $this->redirectWithMessage(base_url('dashboard/general'), 'La contraseña debe tener al menos ' . PASSWORD_MIN_LENGTH . ' caracteres', 'error');
            return;
        }

        // Verificar contraseña actual
        $usuario = $this->usuarioModel->verificarCredenciales($_SESSION['user_email'], $currentPassword);

        if (!$usuario) {
            $this->redirectWithMessage(base_url('dashboard/general'), 'La contraseña actual es incorrecta.', 'error');
            return;
        }

        // Cambiar contraseña
        $resultado = $this->usuarioModel->cambiarPassword($usuario['id'], $newPassword);

        if (!$resultado) {
            $this->redirectWithMessage(base_url('dashboard/general'), 'Error al cambiar contraseña', 'error');
            return;
        }

        // Log de cambio de contraseña
        error_log("Contraseña cambiada: {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('dashboard/general'), 'Contraseña cambiada exitosamente', 'success');
    }

    /**
     * Validar contraseña según reglas del sistema
     */
    private function validarPassword($password) {
        return strlen($password) >= PASSWORD_MIN_LENGTH;
    }

    /**
     * Recuperar contraseña (funcionalidad futura)
     */
    public function recuperarPassword() {
        // Esta funcionalidad se puede implementar en el futuro
        $this->redirectWithMessage(base_url('login'), 'Funcionalidad no disponible aún', 'info');
    }

    /**
     * Verificar estado de sesión (para AJAX)
     */
    public function verificarSesion() {
        if (isset($_SESSION['user_id'])) {
            echo json_encode([
                'success' => true,
                'logged_in' => true,
                'user' => [
                    'id' => $_SESSION['user_id'],
                    'name' => $_SESSION['user_name'],
                    'email' => $_SESSION['user_email'],
                    'role' => $_SESSION['user_role']
                ]
            ]);
        } else {
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'error' => 'Sesión no activa'
            ]);
        }
    }

    /**
     * Obtener información del usuario actual (para AJAX)
     */
    public function obtenerUsuarioActual() {
        if (!isset($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode([
                'success' => false,
                'error' => 'No autenticado'
            ]);
            return;
        }

        try {
            $usuario = $this->usuarioModel->obtenerPorId($_SESSION['user_id']);

            if (!$usuario) {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'error' => 'Usuario no encontrado'
                ]);
                return;
            }

            echo json_encode([
                'success' => true,
                'data' => [
                    'id' => $usuario['id'],
                    'nombre' => $usuario['nombre'],
                    'email' => $usuario['email'],
                    'rol' => $usuario['rol'],
                    'fecha_creacion' => $usuario['fecha_creacion'],
                    'activo' => $usuario['activo']
                ]
            ]);
        } catch (Exception $e) {
            // Si hay error de base de datos, devolver datos de sesión
            echo json_encode([
                'success' => true,
                'data' => [
                    'id' => $_SESSION['user_id'],
                    'nombre' => $_SESSION['user_name'],
                    'email' => $_SESSION['user_email'],
                    'rol' => $_SESSION['user_role'],
                    'fecha_creacion' => date('Y-m-d H:i:s'),
                    'activo' => true
                ]
            ]);
        }
    }

    /**
     * Función auxiliar para redirigir con mensaje (sobrescribe el del padre para mantener la estructura de array)
     */
    protected function redirectWithMessage($url, $message, $type = 'info') {
        $_SESSION['flash_message'] = $message;
        $_SESSION['flash_type'] = $type;
        header('Location: ' . $url);
        exit;
    }
}