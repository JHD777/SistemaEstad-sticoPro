<?php
/**
 * Sistema Estadístico Pro - Controlador Dashboard
 * Maneja las vistas del dashboard administrativo
 */

class DashboardController extends Controller {
    private $usuarioModel;
    private $especieModel;
    private $formularioModel;
    private $registroModel;
    private $respuestaModel;

    public function __construct() {
        parent::__construct();
        $this->usuarioModel = new Usuario();
        $this->especieModel = new Especie();
        $this->formularioModel = new Formulario();
        $this->registroModel = new RegistroCenso();
        $this->respuestaModel = new Respuesta();
    }

    /**
     * Página de estadísticas jerárquicas - Centro Estadístico
     */
    public function estadisticas() {
        // Verificar si el usuario está autenticado
        if (!isset($_SESSION['user_id'])) {
            header('Location: ' . base_url('login'));
            exit();
        }

        try {
            // Obtener información del usuario actual
            $usuario = $this->usuarioModel->obtenerPorId($_SESSION['user_id']);

            if (!$usuario) {
                // Si no se encuentra el usuario en la base de datos, usar datos de sesión como respaldo
                $usuario = [
                    'id' => $_SESSION['user_id'],
                    'nombre' => $_SESSION['user_name'] ?? 'Usuario',
                    'email' => $_SESSION['user_email'] ?? 'usuario@sistema.com',
                    'rol' => $_SESSION['user_role'] ?? 'basico'
                ];
            }

            // Obtener reinos para la navegación jerárquica
            $reinos = $this->especieModel->obtenerReinos() ?? [];

            // Renderizar la vista de estadísticas jerárquicas
            $this->render('dashboard/estadisticas', [
                'usuario' => $usuario,
                'reinos' => $reinos,
                'rol_usuario' => $_SESSION['user_role'] ?? 'basico',
                'especieModel' => $this->especieModel,
                'registroModel' => $this->registroModel
            ]);

        } catch (Exception $e) {
            error_log('Error en DashboardController::estadisticas: ' . $e->getMessage());

            // Si es un error de base de datos, mostrar mensaje específico
            if (strpos($e->getMessage(), 'SQLSTATE') !== false || strpos($e->getMessage(), 'PDO') !== false) {
                $this->render('errors/error500', [
                    'message' => 'Error de conexión con la base de datos. Asegúrese de que la base de datos esté inicializada correctamente ejecutando: php app/core/InitData.php'
                ]);
            } else {
                $this->render('errors/error500', [
                    'message' => 'Ocurrió un error al cargar las estadísticas. Por favor, intente nuevamente.'
                ]);
            }
        }
    }

    /**
     * Dashboard público para usuarios básicos (sin login requerido)
     */
    public function publico() {
        try {
            // Obtener estadísticas básicas para usuarios públicos
            $estadisticas = $this->obtenerEstadisticasBasicas();

            // Obtener reinos para navegación jerárquica
            $reinos = $this->especieModel->obtenerReinos() ?? [];

            // Renderizar vista pública
            $this->render('dashboard/publico', [
                'estadisticas' => $estadisticas,
                'reinos' => $reinos,
                'rol_usuario' => 'basico' // Usuario básico público
            ]);

        } catch (Exception $e) {
            error_log('Error en DashboardController::publico: ' . $e->getMessage());

            // Vista de error simplificada para usuarios públicos
            $this->render('errors/error500', [
                'message' => 'Ocurrió un error al cargar los datos estadísticos. Por favor, intente nuevamente.'
            ]);
        }
    }

    /**
     * Página principal y dashboard general - Única vista según estructura
     */
    public function general() {
        // Verificar si el usuario está autenticado
        if (!isset($_SESSION['user_id'])) {
            header('Location: ' . base_url('login'));
            exit();
        }

        try {
            // Obtener información del usuario actual
            $usuario = $this->usuarioModel->obtenerPorId($_SESSION['user_id']);

            if (!$usuario) {
                // Si no se encuentra el usuario en la base de datos, usar datos de sesión como respaldo
                $usuario = [
                    'id' => $_SESSION['user_id'],
                    'nombre' => $_SESSION['user_name'] ?? 'Usuario',
                    'email' => $_SESSION['user_email'] ?? 'usuario@sistema.com',
                    'rol' => $_SESSION['user_role'] ?? 'basico'
                ];
            }

            // Obtener estadísticas generales del sistema
            $estadisticas = $this->obtenerEstadisticasGenerales();

            // Obtener reinos para la navegación jerárquica
            $reinos = $this->especieModel->obtenerReinos() ?? [];

            // Pasar modelos a la vista
            $especieModel = $this->especieModel;
            $registroModel = $this->registroModel;

            // Datos adicionales según el rol del usuario
            $datosAdicionales = [];

            switch ($_SESSION['user_role'] ?? 'basico') {
                case 'supremo':
                    $datosAdicionales['formularios_pendientes'] = $this->formularioModel->obtenerPendientes() ?? [];
                    $datosAdicionales['usuarios'] = $this->usuarioModel->listar(1, 10)['usuarios'] ?? [];
                    break;
                case 'admin':
                    $datosAdicionales['formularios_aprobados'] = $this->formularioModel->obtenerAprobadosPorEspecie(null) ?? [];
                    $datosAdicionales['mis_registros'] = $this->registroModel->obtenerPorAdmin($usuario['id']) ?? [];
                    break;
                case 'registrado':
                    // Usuario registrado tiene acceso a reportes adicionales
                    break;
                case 'basico':
                default:
                    // Usuario básico tiene acceso básico
                    break;
            }

            // Renderizar la vista general con todos los datos
            $this->render('dashboard/general', array_merge([
                'usuario' => $usuario,
                'estadisticas' => $estadisticas,
                'reinos' => $reinos,
                'rol_usuario' => $_SESSION['user_role'] ?? 'basico'
            ], $datosAdicionales));

        } catch (Exception $e) {
            error_log('Error en DashboardController: ' . $e->getMessage());

            // Si es un error de base de datos, mostrar mensaje específico
            if (strpos($e->getMessage(), 'SQLSTATE') !== false || strpos($e->getMessage(), 'PDO') !== false) {
                $this->render('errors/error500', [
                    'message' => 'Error de conexión con la base de datos. Asegúrese de que la base de datos esté inicializada correctamente ejecutando: php app/core/InitData.php'
                ]);
            } else {
                $this->render('errors/error500', [
                    'message' => 'Ocurrió un error al cargar el dashboard. Por favor, intente nuevamente.'
                ]);
            }
        }
    }

    /**
     * Página acerca de - Información del Sistema Estadístico Pro
     */
    public function acerca() {
        $this->setLayout('static');
        $this->render('dashboard/acerca', [
            'titulo' => 'Acerca del Sistema Estadístico Pro',
            'descripcion' => 'Sistema avanzado para la gestión y análisis de datos estadísticos de especies.',
            'version' => '1.0.0',
            'desarrollador' => 'Sistema Estadístico Pro'
        ]);
    }

    /**
     * Página de contacto
     */
    public function contacto() {
        $this->setLayout('static');
        $this->render('dashboard/contacto', [
            'titulo' => 'Contacto - Sistema Estadístico Pro',
            'email' => 'contacto@sistema-estadistico-pro.com',
            'telefono' => '+591 123 4567',
            'direccion' => 'La Paz, Bolivia'
        ]);
    }

    /**
     * Página de términos y condiciones
     */
    public function terminos() {
        $this->setLayout('static');
        $this->render('dashboard/terminos', [
            'titulo' => 'Términos y Condiciones - Sistema Estadístico Pro',
            'ultima_actualizacion' => date('d/m/Y')
        ]);
    }

    /**
     * Página de política de privacidad
     */
    public function privacidad() {
        $this->setLayout('static');
        $this->render('dashboard/privacidad', [
            'titulo' => 'Política de Privacidad - Sistema Estadístico Pro',
            'ultima_actualizacion' => date('d/m/Y')
        ]);
    }


    /**
     * Muestra la vista de un reino específico
     */
    public function reino($id) {
        $reino = $this->especieModel->obtenerPorId($id);

        if (!$reino || $reino['tipo'] !== 'reino') {
            $this->show404();
            return;
        }

        // Obtener estadísticas agregadas del reino
        $respuestaModel = new Respuesta();
        $estadisticasReino = $respuestaModel->obtenerEstadisticasAgregadas($id, 'reino');

        $data = [
            'reino' => $reino,
            'modulos' => $this->especieModel->obtenerModulos($id),
            'datos_modulos' => $this->obtenerDatosModulos($id),
            'estadisticas_reino' => $estadisticasReino,
            'especieModel' => $this->especieModel,
            'registroModel' => $this->registroModel,
            'formularioModel' => $this->formularioModel,
            'respuestaModel' => $respuestaModel
        ];

        $this->render('dashboard/reino', $data);
    }

    /**
     * Vista específica de un módulo (especies)
     */
    public function modulo($id) {
        $modulo = $this->especieModel->obtenerPorId($id);

        if (!$modulo || $modulo['tipo'] !== 'modulo') {
            $this->show404();
            return;
        }

        // Obtener estadísticas agregadas del módulo
        $respuestaModel = new Respuesta();
        $estadisticasModulo = $respuestaModel->obtenerEstadisticasAgregadas($id, 'modulo');

        $data = [
            'modulo' => $modulo,
            'especies' => $this->especieModel->obtenerEspecies($id),
            'datos_especies' => $this->obtenerDatosEspecies($id),
            'estadisticas_modulo' => $estadisticasModulo,
            'especieModel' => $this->especieModel,
            'registroModel' => $this->registroModel,
            'formularioModel' => $this->formularioModel,
            'respuestaModel' => $respuestaModel
        ];

        $this->render('dashboard/modulo', $data);
    }

    /**
     * Vista específica de una especie (datos detallados)
     */
    public function especie($id) {
        $especie = $this->especieModel->obtenerPorId($id);

        if (!$especie || $especie['tipo'] !== 'especie') {
            $this->show404();
            return;
        }

        $data = [
            'especie' => $especie,
            'formularios' => $this->formularioModel->obtenerAprobadosPorEspecie($id),
            'datos_especie' => $this->obtenerDatosEspecie($id),
            'estadisticas' => $this->registroModel->obtenerPorEspecie($id),
            'especieModel' => $this->especieModel,
            'registroModel' => $this->registroModel,
            'formularioModel' => $this->formularioModel
        ];

        $this->render('dashboard/especie', $data);
    }

    /**
     * Obtener datos para gráficos de módulos
     */
    private function obtenerDatosModulos($reinoId) {
        $modulos = $this->especieModel->obtenerModulos($reinoId);
        $datosModulos = [];

        foreach ($modulos as $modulo) {
            $especiesIds = array_column($this->especieModel->obtenerEspecies($modulo['id']), 'id');

            if (!empty($especiesIds)) {
                // Obtener preguntas comunes a todas las especies del módulo
                $preguntasComunes = $this->obtenerPreguntasComunes($especiesIds);

                if (!empty($preguntasComunes)) {
                    $respuestas = $this->respuestaModel->obtenerParaAnalisis($especiesIds, array_keys($preguntasComunes));

                    $datosModulos[] = [
                        'modulo' => $modulo,
                        'preguntas_comunes' => $preguntasComunes,
                        'respuestas' => $respuestas,
                        'estadisticas' => $this->procesarEstadisticasRespuestas($respuestas, $preguntasComunes)
                    ];
                }
            }
        }

        return $datosModulos;
    }

    /**
     * Obtener datos para gráficos de especies
     */
    private function obtenerDatosEspecies($moduloId) {
        $especies = $this->especieModel->obtenerEspecies($moduloId);
        $datosEspecies = [];

        foreach ($especies as $especie) {
            $datosEspecie = $this->obtenerDatosEspecie($especie['id']);
            if ($datosEspecie) {
                $datosEspecies[] = [
                    'especie' => $especie,
                    'datos' => $datosEspecie
                ];
            }
        }

        return $datosEspecies;
    }

    /**
     * Obtener datos detallados de una especie
     */
    private function obtenerDatosEspecie($especieId) {
        // Obtener formularios aprobados para la especie
        $formularios = $this->formularioModel->obtenerAprobadosPorEspecie($especieId);

        if (empty($formularios)) {
            return null;
        }

        // Obtener todas las preguntas del primer formulario (como referencia)
        $preguntaModel = new Pregunta();
        $preguntas = $preguntaModel->obtenerPorFormulario($formularios[0]['id']);

        if (empty($preguntas)) {
            return null;
        }

        // Obtener respuestas para análisis
        $respuestas = $this->respuestaModel->obtenerParaAnalisis([$especieId]);

        $datos = [
            'preguntas' => $preguntas,
            'respuestas' => $respuestas,
            'estadisticas' => $this->procesarEstadisticasRespuestas($respuestas, $preguntas),
            'total_registros' => count($this->registroModel->obtenerPorEspecie($especieId))
        ];

        return $datos;
    }

    /**
     * Obtener preguntas comunes entre especies
     */
    private function obtenerPreguntasComunes($especiesIds) {
        if (empty($especiesIds)) {
            return [];
        }

        // Esta consulta encuentra preguntas que existen en TODOS los formularios de las especies
        $sql = "SELECT p.id, p.texto_pregunta, p.tipo_pregunta, COUNT(DISTINCT f.id) as formularios_con_pregunta
                FROM preguntas p
                INNER JOIN formularios f ON p.formulario_id = f.id
                WHERE f.especie_id IN (" . str_repeat('?,', count($especiesIds) - 1) . "?)
                AND f.estado = 'aprobado'
                GROUP BY p.id, p.texto_pregunta, p.tipo_pregunta
                HAVING formularios_con_pregunta = ?
                ORDER BY p.orden ASC";

        $params = array_merge($especiesIds, [count($especiesIds)]);
        $preguntas = $this->respuestaModel->obtenerParaAnalisis($especiesIds);

        // Crear un array asociativo para facilitar el acceso
        $preguntasComunes = [];
        foreach ($preguntas as $pregunta) {
            $preguntasComunes[$pregunta['pregunta_id']] = [
                'texto' => $pregunta['texto_pregunta'] ?? 'Pregunta sin texto',
                'tipo' => $pregunta['tipo_pregunta'] ?? 'texto'
            ];
        }

        return $preguntasComunes;
    }

    /**
     * Procesar estadísticas de respuestas para gráficos
     */
    private function procesarEstadisticasRespuestas($respuestas, $preguntas) {
        $estadisticas = [];

        foreach ($preguntas as $preguntaId => $pregunta) {
            $respuestasPregunta = array_filter($respuestas, function($r) use ($preguntaId) {
                return $r['pregunta_id'] == $preguntaId;
            });

            if (empty($respuestasPregunta)) {
                continue;
            }

            switch ($pregunta['tipo'] ?? $pregunta['tipo_pregunta']) {
                case 'numero':
                    $estadisticas[$preguntaId] = $this->procesarEstadisticasNumericas($respuestasPregunta);
                    break;
                case 'booleano':
                    $estadisticas[$preguntaId] = $this->procesarEstadisticasBooleanas($respuestasPregunta);
                    break;
                case 'opcion_multiple':
                    $estadisticas[$preguntaId] = $this->procesarEstadisticasOpciones($respuestasPregunta, $pregunta);
                    break;
                case 'texto':
                    $estadisticas[$preguntaId] = $this->procesarEstadisticasTexto($respuestasPregunta);
                    break;
                case 'fecha':
                    $estadisticas[$preguntaId] = $this->procesarEstadisticasFecha($respuestasPregunta);
                    break;
            }
        }

        return $estadisticas;
    }

    /**
     * Procesar estadísticas numéricas
     */
    private function procesarEstadisticasNumericas($respuestas) {
        $valores = array_column($respuestas, 'valor_respuesta');
        $valoresNumericos = array_filter($valores, 'is_numeric');

        if (empty($valoresNumericos)) {
            return ['tipo' => 'numerico', 'datos' => [], 'total' => 0];
        }

        return [
            'tipo' => 'numerico',
            'datos' => [
                'promedio' => array_sum($valoresNumericos) / count($valoresNumericos),
                'minimo' => min($valoresNumericos),
                'maximo' => max($valoresNumericos),
                'total' => count($valoresNumericos)
            ],
            'total' => count($valoresNumericos)
        ];
    }

    /**
     * Procesar estadísticas booleanas
     */
    private function procesarEstadisticasBooleanas($respuestas) {
        $positivas = 0;
        $negativas = 0;
        $total = count($respuestas);

        foreach ($respuestas as $respuesta) {
            $valor = $respuesta['valor_respuesta'];
            if (in_array($valor, ['1', 'true', 'Si', 'Sí', 1, true])) {
                $positivas++;
            } elseif (in_array($valor, ['0', 'false', 'No', 0, false])) {
                $negativas++;
            }
        }

        return [
            'tipo' => 'booleano',
            'datos' => [
                'positivas' => $positivas,
                'negativas' => $negativas,
                'porcentaje_positivo' => $total > 0 ? ($positivas / $total) * 100 : 0,
                'porcentaje_negativo' => $total > 0 ? ($negativas / $total) * 100 : 0
            ],
            'total' => $total
        ];
    }

    /**
     * Procesar estadísticas de opciones múltiples
     */
    private function procesarEstadisticasOpciones($respuestas, $pregunta) {
        $conteos = [];
        $total = count($respuestas);

        // Si la pregunta tiene opciones definidas, usarlas
        if (!empty($pregunta['opciones'])) {
            $opciones = array_map('trim', explode(',', $pregunta['opciones']));
            foreach ($opciones as $opcion) {
                $conteos[$opcion] = 0;
            }
        }

        // Contar respuestas
        foreach ($respuestas as $respuesta) {
            $valor = $respuesta['valor_respuesta'];
            if (isset($conteos[$valor])) {
                $conteos[$valor]++;
            } else {
                $conteos[$valor] = 1;
            }
        }

        return [
            'tipo' => 'opcion_multiple',
            'datos' => $conteos,
            'total' => $total
        ];
    }

    /**
     * Procesar estadísticas de texto
     */
    private function procesarEstadisticasTexto($respuestas) {
        $textos = array_column($respuestas, 'valor_respuesta');
        $textosFiltrados = array_filter($textos, function($texto) {
            return !empty(trim($texto));
        });

        return [
            'tipo' => 'texto',
            'datos' => [
                'total_respuestas' => count($textosFiltrados),
                'respuestas_unicas' => count(array_unique($textosFiltrados))
            ],
            'total' => count($textosFiltrados)
        ];
    }

    /**
     * Procesar estadísticas de fecha
     */
    private function procesarEstadisticasFecha($respuestas) {
        $fechas = array_column($respuestas, 'valor_respuesta');
        $fechasFiltradas = array_filter($fechas, function($fecha) {
            return !empty(trim($fecha)) && strtotime($fecha) !== false;
        });

        if (empty($fechasFiltradas)) {
            return ['tipo' => 'fecha', 'datos' => [], 'total' => 0];
        }

        $fechasTimestamp = array_map('strtotime', $fechasFiltradas);

        return [
            'tipo' => 'fecha',
            'datos' => [
                'fecha_mas_antigua' => min($fechasFiltradas),
                'fecha_mas_reciente' => max($fechasFiltradas),
                'total_respuestas' => count($fechasFiltradas)
            ],
            'total' => count($fechasFiltradas)
        ];
    }

    /**
     * Obtener estadísticas básicas para usuarios básicos
     */
    private function obtenerEstadisticasBasicas() {
        try {
            $estadisticas = [
                'reinos' => $this->especieModel->obtenerReinos() ?? [],
                'totalEspecies' => 0,
                'totalFormularios' => 0,
                'totalRegistros' => 0
            ];

            // Contar especies
            if (!empty($estadisticas['reinos'])) {
                foreach ($estadisticas['reinos'] as $reino) {
                    $modulos = $this->especieModel->obtenerModulos($reino['id']) ?? [];
                    foreach ($modulos as $modulo) {
                        $especies = $this->especieModel->obtenerEspecies($modulo['id']) ?? [];
                        $estadisticas['totalEspecies'] += count($especies);
                    }
                }
            }

            // Contar formularios aprobados
            $formularios = $this->formularioModel->obtenerEstadisticas();
            $estadisticas['totalFormularios'] = $formularios['aprobados'] ?? 0;

            // Contar registros
            $registros = $this->registroModel->obtenerEstadisticas();
            $estadisticas['totalRegistros'] = $registros['total'] ?? 0;

            return $estadisticas;

        } catch (Exception $e) {
            error_log('Error obteniendo estadísticas básicas: ' . $e->getMessage());
            return [
                'reinos' => [],
                'totalEspecies' => 0,
                'totalFormularios' => 0,
                'totalRegistros' => 0
            ];
        }
    }

    /**
     * Obtener estadísticas generales del sistema
     */
    private function obtenerEstadisticasGenerales() {
        return [
            'usuarios' => $this->usuarioModel->obtenerEstadisticas(),
            'especies' => $this->especieModel->obtenerEstadisticas(),
            'formularios' => $this->formularioModel->obtenerEstadisticas(),
            'registros' => $this->registroModel->obtenerEstadisticas(),
            'respuestas' => $this->respuestaModel->contarTotal()
        ];
    }

    /**
     * API para obtener datos de dashboard (AJAX)
     */
    public function obtenerDatos($tipo, $id) {
        switch ($tipo) {
            case 'reino':
                $datos = $this->obtenerDatosModulos($id);
                break;
            case 'modulo':
                $datos = $this->obtenerDatosEspecies($id);
                break;
            case 'especie':
                $datos = $this->obtenerDatosEspecie($id);
                break;
            default:
                $this->jsonError('Tipo no válido', 400);
                return;
        }

        $this->jsonSuccess($datos);
    }

    /**
     * API para obtener módulos de un reino
     */
    public function apiModulos($id) {
        try {
            $modulos = $this->especieModel->obtenerModulos($id);

            // Agregar estadísticas a cada módulo
            foreach ($modulos as &$modulo) {
                $especies = $this->especieModel->obtenerEspecies($modulo['id']);
                $modulo['especies_count'] = count($especies);
                $modulo['censos_count'] = 0; // TODO: Calcular censos por módulo
            }

            $this->jsonSuccess($modulos);
        } catch (Exception $e) {
            error_log('Error en apiModulos: ' . $e->getMessage());
            $this->jsonError('Error al obtener módulos', 500);
        }
    }

    /**
     * API para obtener datos de un módulo (preguntas comunes)
     */
    public function apiDatosModulo($id) {
        try {
            $modulo = $this->especieModel->obtenerPorId($id);

            if (!$modulo || $modulo['tipo'] !== 'modulo') {
                $this->jsonError('Módulo no encontrado', 404);
                return;
            }

            // Obtener especies del módulo
            $especies = $this->especieModel->obtenerEspecies($id);
            $especiesIds = array_column($especies, 'id');

            if (empty($especiesIds)) {
                $this->jsonSuccess([
                    'especies' => [],
                    'preguntas_comunes' => []
                ]);
                return;
            }

            // Obtener preguntas comunes
            $preguntasComunes = $this->obtenerPreguntasComunes($especiesIds);

            // Procesar datos para gráficos
            $preguntasProcesadas = [];
            foreach ($preguntasComunes as $preguntaId => $pregunta) {
                $respuestas = $this->respuestaModel->obtenerParaAnalisis($especiesIds, [$preguntaId]);

                $preguntasProcesadas[] = [
                    'id' => $preguntaId,
                    'texto_pregunta' => $pregunta['texto'],
                    'tipo_pregunta' => $pregunta['tipo'],
                    'datos' => $respuestas
                ];
            }

            $this->jsonSuccess([
                'especies' => $especies,
                'preguntas_comunes' => $preguntasProcesadas
            ]);
        } catch (Exception $e) {
            error_log('Error en apiDatosModulo: ' . $e->getMessage());
            $this->jsonError('Error al obtener datos del módulo', 500);
        }
    }

    /**
     * API para obtener datos específicos de una especie
     */
    public function apiDatosEspecie($id) {
        try {
            $especie = $this->especieModel->obtenerPorId($id);

            if (!$especie || $especie['tipo'] !== 'especie') {
                $this->jsonError('Especie no encontrada', 404);
                return;
            }

            // Obtener datos de la especie
            $datosEspecie = $this->obtenerDatosEspecie($id);

            if (!$datosEspecie) {
                $this->jsonSuccess([
                    'especie' => $especie,
                    'preguntas' => []
                ]);
                return;
            }

            // Procesar datos para gráficos
            $preguntasProcesadas = [];
            foreach ($datosEspecie['preguntas'] as $pregunta) {
                $preguntasProcesadas[] = [
                    'id' => $pregunta['id'],
                    'texto_pregunta' => $pregunta['texto_pregunta'],
                    'tipo_pregunta' => $pregunta['tipo_pregunta'],
                    'opciones' => $pregunta['opciones'],
                    'datos' => $datosEspecie['respuestas']
                ];
            }

            $this->jsonSuccess([
                'especie' => $especie,
                'preguntas' => $preguntasProcesadas
            ]);
        } catch (Exception $e) {
            error_log('Error en apiDatosEspecie: ' . $e->getMessage());
            $this->jsonError('Error al obtener datos de la especie', 500);
        }
    }

    /**
     * Exportar datos (funcionalidad futura)
     */
    public function exportar($tipo, $id, $formato = 'json') {
        // Esta funcionalidad se puede implementar en el futuro
        $this->jsonError('Funcionalidad no disponible aún', 501);
    }
}