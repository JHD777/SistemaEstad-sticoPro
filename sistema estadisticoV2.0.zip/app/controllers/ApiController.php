<?php
/**
 * Sistema Estadístico Pro - Controlador de API
 * Maneja las rutas de API delegando a los archivos específicos
 */

class ApiController extends Controller {
    /**
     * Redirigir a los endpoints de API específicos
     */

    public function especies() {
        require_once PUBLIC_PATH . '/api/v1/especies.php';
    }

    public function especie($id) {
        $_GET['id'] = $id;
        require_once PUBLIC_PATH . '/api/v1/especies.php';
    }

    public function crearEspecie() {
        require_once PUBLIC_PATH . '/api/v1/especies.php';
    }

    public function actualizarEspecie($id) {
        $_GET['id'] = $id;
        require_once PUBLIC_PATH . '/api/v1/especies.php';
    }

    public function eliminarEspecie($id) {
        $_GET['id'] = $id;
        require_once PUBLIC_PATH . '/api/v1/especies.php';
    }

    public function formularios() {
        require_once PUBLIC_PATH . '/api/v1/formularios.php';
    }

    public function formulario($id) {
        $_GET['id'] = $id;
        require_once PUBLIC_PATH . '/api/v1/formularios.php';
    }

    public function crearFormulario() {
        require_once PUBLIC_PATH . '/api/v1/formularios.php';
    }

    public function actualizarFormulario($id) {
        $_GET['id'] = $id;
        require_once PUBLIC_PATH . '/api/v1/formularios.php';
    }

    public function eliminarFormulario($id) {
        $_GET['id'] = $id;
        require_once PUBLIC_PATH . '/api/v1/formularios.php';
    }

    public function registros() {
        require_once PUBLIC_PATH . '/api/v1/registros.php';
    }

    public function registro($id) {
        $_GET['id'] = $id;
        require_once PUBLIC_PATH . '/api/v1/registros.php';
    }

    public function crearRegistro() {
        require_once PUBLIC_PATH . '/api/v1/registros.php';
    }

    public function actualizarRegistro($id) {
        $_GET['id'] = $id;
        require_once PUBLIC_PATH . '/api/v1/registros.php';
    }

    public function eliminarRegistro($id) {
        $_GET['id'] = $id;
        require_once PUBLIC_PATH . '/api/v1/registros.php';
    }
}
