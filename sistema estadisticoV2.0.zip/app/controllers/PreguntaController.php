<?php
/**
 * Sistema Estadístico Pro - Controlador de Preguntas Base
 * Maneja la gestión de preguntas base para herencia
 */

class PreguntaController extends Controller {
    private $preguntaModel;
    private $especieModel;

    public function __construct() {
        parent::__construct();
        $this->preguntaModel = new Pregunta();
        $this->especieModel = new Especie();
    }

    /**
     * Verificar permisos (sobrescribir método padre)
     */
    protected function checkAuthentication() {
        $this->requireAuth();

        // Solo requerir permisos especiales para métodos de gestión de preguntas base
        $method = debug_backtrace()[1]['function'] ?? '';
        $restrictedMethods = ['listar', 'crear', 'procesarCreacion', 'editar', 'procesarEdicion', 'eliminar'];

        if (in_array($method, $restrictedMethods)) {
            $this->requirePermission('questions.manage'); // Solo supremo puede gestionar preguntas base
        }
    }

    /**
     * Listar preguntas base
     */
    public function listar() {
        $data = [
            'preguntas_base' => $this->obtenerPreguntasBase(),
            'reinos' => $this->especieModel->obtenerReinos(),
            'modulos' => $this->especieModel->obtenerTodas(),
            'tipos_pregunta' => QUESTION_TYPES
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('preguntas/listar', $data);
    }

    /**
     * Mostrar formulario para crear pregunta base
     */
    public function crear() {
        // Obtener solo módulos para el ámbito de aplicación
        $todasEspecies = $this->especieModel->obtenerTodas();
        $modulos = array_filter($todasEspecies, function($especie) {
            return $especie['tipo'] === 'modulo';
        });

        $data = [
            'reinos' => $this->especieModel->obtenerReinos(),
            'modulos' => array_values($modulos), // Reindexar array
            'tipos_pregunta' => QUESTION_TYPES
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('preguntas/crear', $data);
    }

    /**
     * Procesar creación de pregunta base
     */
    public function procesarCreacion() {
        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('preguntas/crear'), 'Método no permitido', 'error');
            return;
        }

        $ambito_aplicacion = $this->sanitize($_POST['ambito_aplicacion'] ?? '');
        $ambito_id = (int)($_POST['ambito_id'] ?? 0);
        $texto_pregunta = $this->sanitize($_POST['texto_pregunta'] ?? '');
        $tipo_pregunta = $this->sanitize($_POST['tipo_pregunta'] ?? '');
        $opciones = $this->sanitize($_POST['opciones'] ?? '');
        $orden = (int)($_POST['orden'] ?? 1);
        $obligatoria = isset($_POST['obligatoria']) ? 1 : 0;

        // Debug: Log received values
        error_log("DEBUG PreguntaController POST: " . json_encode($_POST));
        error_log("DEBUG PreguntaController: ambito_aplicacion='$ambito_aplicacion', ambito_id=$ambito_id, texto='$texto_pregunta'");

        // Validar datos
        $errores = [];
        if (empty($ambito_aplicacion) || !in_array($ambito_aplicacion, ['reino', 'modulo', 'especie'])) {
            $errores[] = 'Debe seleccionar un ámbito de aplicación válido';
        }
        if ($ambito_id <= 0) {
            $errores[] = 'Debe seleccionar un ámbito específico';
        }
        if (empty($texto_pregunta)) {
            $errores[] = 'El texto de la pregunta es requerido';
        }
        if (empty($tipo_pregunta) || !array_key_exists($tipo_pregunta, QUESTION_TYPES)) {
            $errores[] = 'Debe seleccionar un tipo de pregunta válido';
        }
        if ($tipo_pregunta === 'opcion_multiple' && empty($opciones)) {
            $errores[] = 'Las opciones son requeridas para preguntas de opción múltiple';
        }

        if (!empty($errores)) {
            $mensaje = implode('<br>', $errores);
            $this->redirectWithMessage(base_url('preguntas/crear'), $mensaje, 'error');
            return;
        }

        // Crear pregunta base (formulario_id = NULL)
        $datosPregunta = [
            'formulario_id' => null, // Pregunta base
            'texto_pregunta' => $texto_pregunta,
            'tipo_pregunta' => $tipo_pregunta,
            'opciones' => $opciones,
            'orden' => $orden,
            'obligatoria' => $obligatoria,
            'ambito_aplicacion' => $ambito_aplicacion,
            'ambito_id' => $ambito_id
        ];

        $preguntaId = $this->preguntaModel->crear($datosPregunta);

        if (!$preguntaId) {
            $this->redirectWithMessage(base_url('preguntas/crear'), 'Error al crear pregunta base', 'error');
            return;
        }

        // Log de creación
        error_log("Pregunta base creada: {$texto_pregunta} ({$ambito_aplicacion}) por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('preguntas/listar'), 'Pregunta base creada exitosamente', 'success');
    }

    /**
     * Mostrar formulario para editar pregunta base
     */
    public function editar($id) {
        $pregunta = $this->preguntaModel->obtenerPorId($id);

        if (!$pregunta) {
            $this->redirectWithMessage(base_url('preguntas/listar'), 'Pregunta no encontrada', 'error');
            return;
        }

        // Solo permitir editar preguntas base (formulario_id = NULL)
        if ($pregunta['formulario_id'] !== null) {
            $this->redirectWithMessage(base_url('preguntas/listar'), 'Solo se pueden editar preguntas base', 'error');
            return;
        }

        // Obtener solo módulos para el ámbito de aplicación
        $todasEspecies = $this->especieModel->obtenerTodas();
        $modulos = array_filter($todasEspecies, function($especie) {
            return $especie['tipo'] === 'modulo';
        });

        $data = [
            'pregunta' => $pregunta,
            'reinos' => $this->especieModel->obtenerReinos(),
            'modulos' => array_values($modulos), // Reindexar array
            'tipos_pregunta' => QUESTION_TYPES
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('preguntas/editar', $data);
    }

    /**
     * Procesar edición de pregunta base
     */
    public function procesarEdicion($id) {
        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('preguntas/listar'), 'Método no permitido', 'error');
            return;
        }

        $pregunta = $this->preguntaModel->obtenerPorId($id);

        if (!$pregunta) {
            $this->redirectWithMessage(base_url('preguntas/listar'), 'Pregunta no encontrada', 'error');
            return;
        }

        // Solo permitir editar preguntas base (formulario_id = NULL)
        if ($pregunta['formulario_id'] !== null) {
            $this->redirectWithMessage(base_url('preguntas/listar'), 'Solo se pueden editar preguntas base', 'error');
            return;
        }

        $ambito_aplicacion = $this->sanitize($_POST['ambito_aplicacion'] ?? '');
        $ambito_id = (int)($_POST['ambito_id'] ?? 0);
        $texto_pregunta = $this->sanitize($_POST['texto_pregunta'] ?? '');
        $tipo_pregunta = $this->sanitize($_POST['tipo_pregunta'] ?? '');
        $opciones = $this->sanitize($_POST['opciones'] ?? '');
        $orden = (int)($_POST['orden'] ?? 1);
        $obligatoria = isset($_POST['obligatoria']) ? 1 : 0;

        // Validar datos
        $errores = [];
        if (empty($ambito_aplicacion) || !in_array($ambito_aplicacion, ['reino', 'modulo', 'especie'])) {
            $errores[] = 'Debe seleccionar un ámbito de aplicación válido';
        }
        if ($ambito_id <= 0) {
            $errores[] = 'Debe seleccionar un ámbito específico';
        }
        if (empty($texto_pregunta)) {
            $errores[] = 'El texto de la pregunta es requerido';
        }
        if (empty($tipo_pregunta) || !array_key_exists($tipo_pregunta, QUESTION_TYPES)) {
            $errores[] = 'Debe seleccionar un tipo de pregunta válido';
        }
        if ($tipo_pregunta === 'opcion_multiple' && empty($opciones)) {
            $errores[] = 'Las opciones son requeridas para preguntas de opción múltiple';
        }

        if (!empty($errores)) {
            $mensaje = implode('<br>', $errores);
            $this->redirectWithMessage(base_url("preguntas/editar/{$id}"), $mensaje, 'error');
            return;
        }

        // Actualizar pregunta base
        $datosActualizar = [
            'texto_pregunta' => $texto_pregunta,
            'tipo_pregunta' => $tipo_pregunta,
            'opciones' => $opciones,
            'orden' => $orden,
            'obligatoria' => $obligatoria,
            'ambito_aplicacion' => $ambito_aplicacion,
            'ambito_id' => $ambito_id
        ];

        $resultado = $this->preguntaModel->actualizar($id, $datosActualizar);

        if (!$resultado) {
            $this->redirectWithMessage(base_url("preguntas/editar/{$id}"), 'Error al actualizar pregunta base', 'error');
            return;
        }

        // Log de edición
        error_log("Pregunta base actualizada: {$texto_pregunta} ({$ambito_aplicacion}) por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('preguntas/listar'), 'Pregunta base actualizada exitosamente', 'success');
    }

    /**
     * Eliminar pregunta base
     */
    public function eliminar($id) {
        $pregunta = $this->preguntaModel->obtenerPorId($id);

        if (!$pregunta) {
            $this->redirectWithMessage(base_url('preguntas/listar'), 'Pregunta no encontrada', 'error');
            return;
        }

        // Solo permitir eliminar preguntas base (formulario_id = NULL)
        if ($pregunta['formulario_id'] !== null) {
            $this->redirectWithMessage(base_url('preguntas/listar'), 'Solo se pueden eliminar preguntas base', 'error');
            return;
        }

        $resultado = $this->preguntaModel->eliminar($id);

        if (!$resultado) {
            $this->redirectWithMessage(base_url('preguntas/listar'), 'Error al eliminar pregunta base', 'error');
            return;
        }

        // Log de eliminación
        error_log("Pregunta base eliminada: {$pregunta['texto_pregunta']} por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('preguntas/listar'), 'Pregunta base eliminada exitosamente', 'success');
    }

    /**
     * Obtener preguntas base agrupadas por ámbito
     */
    private function obtenerPreguntasBase() {
        try {
            // Check if ambito columns exist
            $columns = Database::getInstance()->select("DESCRIBE preguntas");
            $hasAmbito = false;

            foreach ($columns as $column) {
                if ($column['Field'] === 'ambito_aplicacion') {
                    $hasAmbito = true;
                    break;
                }
            }

            if (!$hasAmbito) {
                return []; // No base questions if columns don't exist
            }

            $sql = "SELECT
                        p.id,
                        p.texto_pregunta,
                        p.tipo_pregunta,
                        p.opciones,
                        p.orden,
                        p.obligatoria,
                        p.ambito_aplicacion,
                        p.ambito_id,
                        s.nombre as ambito_nombre,
                        s.tipo as ambito_tipo
                    FROM preguntas p
                    INNER JOIN especies s ON p.ambito_id = s.id
                    WHERE p.formulario_id IS NULL
                    ORDER BY p.ambito_aplicacion, s.nombre, p.orden";

            $preguntas = Database::getInstance()->select($sql);

            // Agrupar por ámbito
            $agrupadas = [];
            foreach ($preguntas as $pregunta) {
                $ambito = $pregunta['ambito_aplicacion'] . '_' . $pregunta['ambito_id'];
                if (!isset($agrupadas[$ambito])) {
                    $agrupadas[$ambito] = [
                        'ambito_aplicacion' => $pregunta['ambito_aplicacion'],
                        'ambito_nombre' => $pregunta['ambito_nombre'],
                        'ambito_tipo' => $pregunta['ambito_tipo'],
                        'preguntas' => []
                    ];
                }
                $agrupadas[$ambito]['preguntas'][] = $pregunta;
            }

            return $agrupadas;
        } catch (Exception $e) {
            error_log("Error obteniendo preguntas base: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Obtener módulos de un reino (AJAX)
     */
    public function obtenerModulos($reinoId) {
        $modulos = $this->especieModel->obtenerModulos($reinoId);
        $this->jsonSuccess($modulos);
    }

    /**
     * Obtener especies de un módulo (AJAX)
     */
    public function obtenerEspecies($moduloId) {
        $especies = $this->especieModel->obtenerEspecies($moduloId);
        $this->jsonSuccess($especies);
    }

    /**
     * Obtener preguntas heredadas para una especie (API)
     */
    public function obtenerPreguntasHeredadas($especieId) {
        $preguntas = $this->preguntaModel->obtenerPreguntasHeredadas($especieId);
        $this->jsonSuccess($preguntas);
    }
}