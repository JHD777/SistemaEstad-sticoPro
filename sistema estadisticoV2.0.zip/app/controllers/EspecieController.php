<?php
/**
 * Sistema Estadístico Pro - Controlador de Especies
 * Maneja la gestión de la jerarquía taxonómica
 */

class EspecieController extends Controller {
    private $especieModel;

    public function __construct() {
        parent::__construct();
        $this->especieModel = new Especie();
    }

    /**
     * Verificar permisos (sobrescribir método padre)
     */
    protected function checkAuthentication() {
        // Para métodos API públicos, no requerir autenticación
        $method = debug_backtrace()[1]['function'] ?? '';
        $publicMethods = ['apiEspecies', 'obtenerModulos', 'obtenerEspecies'];

        if (!in_array($method, $publicMethods)) {
            $this->requireAuth();
            $this->requirePermission('species.view');
        }
    }

    /**
     * Listar especies con jerarquía
     */
    public function listar() {
        $reinos = $this->especieModel->obtenerReinos();

        $data = [
            'arbol_especies' => $this->especieModel->obtenerArbol(),
            'estadisticas' => $this->especieModel->obtenerEstadisticas(),
            'reinos' => $reinos
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('especies/listar', $data);
    }

    /**
     * Mostrar formulario para crear especie
     */
    public function crear() {
        $this->requirePermission('species.create');

        $data = [
            'tipos' => SPECIES_TYPES,
            'reinos' => $this->especieModel->obtenerReinos(),
            'modulos' => []
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('especies/crear', $data);
    }

    /**
     * Procesar creación de especie
     */
    public function procesarCreacion() {
        $this->requirePermission('species.create');

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('especies/crear'), 'Método no permitido', 'error');
            return;
        }

        // Debug: Mostrar datos POST
        error_log("POST data: " . json_encode($_POST));

        $nombre = $this->sanitize($_POST['nombre'] ?? '');
        $tipo = $this->sanitize($_POST['tipo'] ?? '');
        $descripcion = $this->sanitize($_POST['descripcion'] ?? '');
        $parent_id = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;

        // Debug: Mostrar datos procesados
        error_log("Datos procesados - nombre: $nombre, tipo: $tipo, parent_id: $parent_id");

        // Validar datos
        $datosEspecie = [
            'nombre' => $nombre,
            'tipo' => $tipo,
            'descripcion' => $descripcion,
            'parent_id' => $parent_id
        ];

        $errores = $this->especieModel->validarDatos($datosEspecie);

        if (!empty($errores)) {
            $mensaje = implode('<br>', $errores);
            error_log("Errores de validación: $mensaje");
            $this->redirectWithMessage(base_url('especies/crear'), $mensaje, 'error');
            return;
        }

        // Crear especie
        $especieId = $this->especieModel->crear($datosEspecie);

        if (!$especieId) {
            error_log("Error al crear especie - modelo retornó false");
            $this->redirectWithMessage(base_url('especies/crear'), 'Error al crear especie', 'error');
            return;
        }

        // Log de creación de especie
        error_log("Especie creada exitosamente: {$nombre} ({$tipo}) ID: {$especieId} por {$_SESSION['user_email']}");

        $this->redirectWithMessage(base_url('especies/listar'), 'Especie creada exitosamente', 'success');
    }

    /**
     * Mostrar formulario para editar especie
     */
    public function editar($id) {
        $this->requirePermission('species.edit');

        $especie = $this->especieModel->obtenerPorId($id);

        if (!$especie) {
            $this->redirectWithMessage(base_url('especies/listar'), 'Especie no encontrada', 'error');
            return;
        }

        // Obtener opciones de padre según el tipo
        $reinos = $this->especieModel->obtenerReinos();
        $modulos = $especie['tipo'] === 'especie' ? $this->especieModel->obtenerModulos($especie['parent_id'] ?? 0) : [];

        $data = [
            'especie' => $especie,
            'tipos' => SPECIES_TYPES,
            'reinos' => $reinos,
            'modulos' => $modulos
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('especies/editar', $data);
    }

    /**
     * Procesar edición de especie
     */
    public function procesarEdicion($id) {
        $this->requirePermission('species.edit');

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url("especies/editar/{$id}"), 'Método no permitido', 'error');
            return;
        }

        $especie = $this->especieModel->obtenerPorId($id);

        if (!$especie) {
            $this->redirectWithMessage(base_url('especies/listar'), 'Especie no encontrada', 'error');
            return;
        }

        $nombre = $this->sanitize($_POST['nombre'] ?? '');
        $tipo = $this->sanitize($_POST['tipo'] ?? '');
        $descripcion = $this->sanitize($_POST['descripcion'] ?? '');
        $parent_id = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;

        // Validar datos
        $datosEspecie = [
            'id' => $id,
            'nombre' => $nombre,
            'tipo' => $tipo,
            'descripcion' => $descripcion,
            'parent_id' => $parent_id
        ];

        $errores = $this->especieModel->validarDatos($datosEspecie, true);

        if (!empty($errores)) {
            $mensaje = implode('<br>', $errores);
            $this->redirectWithMessage(base_url("especies/editar/{$id}"), $mensaje, 'error');
            return;
        }

        // Actualizar especie
        $datosActualizar = [
            'nombre' => $nombre,
            'tipo' => $tipo,
            'descripcion' => $descripcion,
            'parent_id' => $parent_id
        ];

        $resultado = $this->especieModel->actualizar($id, $datosActualizar);

        if (!$resultado) {
            $this->redirectWithMessage(base_url("especies/editar/{$id}"), 'Error al actualizar especie', 'error');
            return;
        }

        // Log de actualización de especie
        error_log("Especie actualizada: {$nombre} ({$tipo}) por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('especies/listar'), 'Especie actualizada exitosamente', 'success');
    }

    /**
     * Eliminar especie
     */
    public function eliminar() {
        $this->requirePermission('species.delete');

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('especies/listar'), 'Método no permitido', 'error');
            return;
        }

        $id = (int)($_POST['especie_id'] ?? 0);
        $codigoConfirmacion = $_POST['codigo_confirmacion'] ?? '';

        if (!$id) {
            $this->redirectWithMessage(base_url('especies/listar'), 'ID de especie requerido', 'error');
            return;
        }

        // Verificar código de confirmación (por seguridad)
        if (empty($codigoConfirmacion)) {
            $this->redirectWithMessage(base_url('especies/listar'), 'Código de confirmación requerido', 'error');
            return;
        }

        $especie = $this->especieModel->obtenerPorId($id);

        if (!$especie) {
            $this->redirectWithMessage(base_url('especies/listar'), 'Especie no encontrada', 'error');
            return;
        }

        // Verificar si tiene hijos
        $hijos = $this->especieModel->obtenerHijos($id);
        if (!empty($hijos)) {
            $this->redirectWithMessage(base_url('especies/listar'), 'No se puede eliminar una especie que tiene hijos', 'error');
            return;
        }

        // Verificar si tiene formularios asociados
        if ($this->especieModel->tieneFormularios($id)) {
            $this->redirectWithMessage(base_url('especies/listar'), 'No se puede eliminar una especie que tiene formularios asociados', 'error');
            return;
        }

        $resultado = $this->especieModel->eliminar($id);

        if (!$resultado) {
            $this->redirectWithMessage(base_url('especies/listar'), 'Error al eliminar especie', 'error');
            return;
        }

        // Log de eliminación de especie
        error_log("Especie eliminada: {$especie['nombre']} ({$especie['tipo']}) por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('especies/listar'), 'Especie eliminada exitosamente', 'success');
    }

    /**
     * Obtener módulos de un reino (AJAX)
     */
    public function obtenerModulos($reinoId) {
        $modulos = $this->especieModel->obtenerModulos($reinoId);

        // Agregar conteo de especies por módulo
        foreach ($modulos as &$modulo) {
            $especies = $this->especieModel->obtenerEspecies($modulo['id']);
            $modulo['especies_count'] = count($especies);
        }

        $this->jsonSuccess($modulos);
    }

    /**
     * Obtener especies de un módulo (AJAX)
     */
    public function obtenerEspecies($moduloId) {
        $especies = $this->especieModel->obtenerEspecies($moduloId);
        $this->jsonSuccess($especies);
    }

    /**
     * Buscar especies (AJAX)
     */
    public function buscar() {
        $termino = $this->sanitize($_GET['q'] ?? '');
        $tipo = $this->sanitize($_GET['tipo'] ?? '');

        if (empty($termino)) {
            $this->jsonError('Término de búsqueda requerido', 400);
            return;
        }

        $resultados = $this->especieModel->buscar($termino, $tipo);
        $this->jsonSuccess($resultados);
    }

    /**
     * Ver detalles de especie (AJAX)
     */
    public function ver($id) {
        $especie = $this->especieModel->obtenerPorId($id);

        if (!$especie) {
            $this->jsonError('Especie no encontrada', 404);
            return;
        }

        // Obtener información adicional
        $jerarquia = $this->especieModel->obtenerJerarquia($id);
        $hijos = $this->especieModel->obtenerHijos($id);

        $this->jsonSuccess([
            'especie' => $especie,
            'jerarquia' => $jerarquia,
            'hijos' => $hijos,
            'tiene_formularios' => $this->especieModel->tieneFormularios($id)
        ]);
    }

    /**
     * API para especies con filtros (Centro Estadístico)
     */
    public function apiEspecies() {
        // Obtener parámetros de la URL
        $reinoId = isset($_GET['reino']) ? (int)$_GET['reino'] : null;
        $moduloId = isset($_GET['modulo']) ? (int)$_GET['modulo'] : null;

        if ($reinoId) {
            // Obtener módulos de un reino específico
            $modulos = $this->especieModel->obtenerModulos($reinoId);

            // Agregar información adicional por módulo
            foreach ($modulos as &$modulo) {
                $especies = $this->especieModel->obtenerEspecies($modulo['id']);
                $modulo['especies_count'] = count($especies);
                $modulo['censos_count'] = 0; // TODO: Calcular censos reales
                $modulo['reino'] = $reinoId == 1 ? 'Flora' : 'Fauna';
            }

            $this->jsonSuccess($modulos);
        } elseif ($moduloId) {
            // Obtener especies de un módulo específico
            $especies = $this->especieModel->obtenerEspecies($moduloId);

            // Agregar información adicional por especie
            foreach ($especies as &$especie) {
                $especie['censos_count'] = 0; // TODO: Calcular censos reales
            }

            $this->jsonSuccess($especies);
        } else {
            // Sin parámetros, devolver todos los módulos con información de reino
            $todosModulos = [];

            // Obtener módulos de Flora
            $modulosFlora = $this->especieModel->obtenerModulos(1);
            foreach ($modulosFlora as &$modulo) {
                $modulo['reino'] = 'Flora';
                $modulo['especies_count'] = count($this->especieModel->obtenerEspecies($modulo['id']));
                $todosModulos[] = $modulo;
            }

            // Obtener módulos de Fauna
            $modulosFauna = $this->especieModel->obtenerModulos(2);
            foreach ($modulosFauna as &$modulo) {
                $modulo['reino'] = 'Fauna';
                $modulo['especies_count'] = count($this->especieModel->obtenerEspecies($modulo['id']));
                $todosModulos[] = $modulo;
            }

            $this->jsonSuccess($todosModulos);
        }
    }

    /**
     * Crear módulo (método específico)
     */
    public function crearModulo() {
        $this->requirePermission('species.create');

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('especies/crear-modulo'), 'Método no permitido', 'error');
            return;
        }

        $nombre = $this->sanitize($_POST['nombre'] ?? '');
        $reino_id = (int)($_POST['reino_id'] ?? 0);
        $descripcion = $this->sanitize($_POST['descripcion'] ?? '');

        // Validar datos
        if (empty($nombre)) {
            $this->redirectWithMessage(base_url('especies/crear-modulo'), 'El nombre es requerido', 'error');
            return;
        }

        if (!$reino_id) {
            $this->redirectWithMessage(base_url('especies/crear-modulo'), 'El reino es requerido', 'error');
            return;
        }

        $datosModulo = [
            'nombre' => $nombre,
            'tipo' => 'modulo',
            'descripcion' => $descripcion,
            'parent_id' => $reino_id
        ];

        $errores = $this->especieModel->validarDatos($datosModulo);

        if (!empty($errores)) {
            $mensaje = implode('<br>', $errores);
            $this->redirectWithMessage(base_url('especies/crear-modulo'), $mensaje, 'error');
            return;
        }

        $moduloId = $this->especieModel->crear($datosModulo);

        if (!$moduloId) {
            $this->redirectWithMessage(base_url('especies/crear-modulo'), 'Error al crear módulo', 'error');
            return;
        }

        // Log de creación de módulo
        error_log("Módulo creado: {$nombre} por {$_SESSION['user_email']}", 0);

        $this->redirectWithMessage(base_url('especies/listar'), 'Módulo creado exitosamente', 'success');
    }

    /**
     * Mostrar formulario para crear módulo
     */
    public function crearModuloForm() {
        $this->requirePermission('species.create');

        $data = [
            'reinos' => $this->especieModel->obtenerReinos()
        ];

        // Verificar si hay mensaje flash
        $flashMessage = $this->getFlashMessage();
        if ($flashMessage) {
            $data['flash_message'] = $flashMessage;
        }

        $this->render('especies/crear_modulo', $data);
    }

    /**
     * Eliminar módulo (solo Admin Supremo)
     */
    public function eliminarModulo() {
        // Solo Admin Supremo puede eliminar módulos
        $this->verificarRol(['supremo']);

        if (!$this->is_post()) {
            $this->redirectWithMessage(base_url('especies'), 'Método no permitido', 'error');
            return;
        }

        $moduloId = (int)($_POST['modulo_id'] ?? 0);
        $codigoConfirmacion = $_POST['codigo_confirmacion'] ?? '';

        error_log("DEBUG eliminarModulo: Iniciando eliminación de módulo ID: $moduloId");

        if (!$moduloId) {
            error_log("DEBUG eliminarModulo: Error - ID de módulo requerido");
            $this->redirectWithMessage(base_url('especies'), 'ID de módulo requerido', 'error');
            return;
        }

        // Verificar código de confirmación
        if (empty($codigoConfirmacion)) {
            error_log("DEBUG eliminarModulo: Error - Código de confirmación requerido");
            $this->redirectWithMessage(base_url('especies'), 'Código de confirmación requerido', 'error');
            return;
        }

        // Obtener información del módulo
        $modulo = $this->especieModel->obtenerPorId($moduloId);
        error_log("DEBUG eliminarModulo: Módulo obtenido: " . json_encode($modulo));

        if (!$modulo || $modulo['tipo'] !== 'modulo') {
            error_log("DEBUG eliminarModulo: Error - Módulo no encontrado o no es módulo");
            $this->redirectWithMessage(base_url('especies'), 'Módulo no encontrado', 'error');
            return;
        }

        // Verificar que no tenga especies hijas
        $especies = $this->especieModel->obtenerEspecies($moduloId);
        error_log("DEBUG eliminarModulo: Especies del módulo: " . count($especies));

        if (!empty($especies)) {
            error_log("DEBUG eliminarModulo: ¡El módulo tiene especies hijas! No se puede eliminar.");
            $this->redirectWithMessage(base_url('especies'), 'No se puede eliminar el módulo porque tiene especies asociadas. Elimine primero las especies.', 'error');
            return;
        }

        // Verificar que no tenga censos realizados (aunque no debería tener especies, por seguridad)
        $tieneCensos = false;

        foreach ($especies as $especie) {
            error_log("DEBUG eliminarModulo: Verificando censos para especie: {$especie['id']} - {$especie['nombre']}");
            $registroModel = new RegistroCenso();
            $censos = $registroModel->obtenerPorEspecie($especie['id']);
            error_log("DEBUG eliminarModulo: Censos encontrados para especie {$especie['id']}: " . count($censos));

            if (!empty($censos)) {
                $tieneCensos = true;
                error_log("DEBUG eliminarModulo: ¡Se encontraron censos! No se puede eliminar.");
                break;
            }
        }

        if ($tieneCensos) {
            error_log("DEBUG eliminarModulo: Bloqueado por censos existentes");
            $this->redirectWithMessage(base_url('especies'), 'No se puede eliminar el módulo porque tiene censos realizados', 'error');
            return;
        }

        // Intentar eliminar el módulo
        error_log("DEBUG eliminarModulo: Intentando eliminar módulo...");
        $resultado = $this->especieModel->eliminar($moduloId);

        if ($resultado) {
            // Log de eliminación
            error_log("Módulo eliminado exitosamente: {$modulo['nombre']} por {$_SESSION['user_email']}", 0);
            $this->redirectWithMessage(base_url('especies'), 'Módulo eliminado exitosamente', 'success');
        } else {
            error_log("DEBUG eliminarModulo: Error al eliminar módulo en BD");
            $this->redirectWithMessage(base_url('especies'), 'Error al eliminar el módulo', 'error');
        }
    }
}