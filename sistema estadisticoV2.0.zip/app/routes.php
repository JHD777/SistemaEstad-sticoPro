<?php
/**
 * Sistema Estadístico Pro - Sistema de Rutas
 * Define todas las rutas de la aplicación
 */

// Verificar si el router está definido
if (!isset($router)) {
    throw new Exception('Router no está definido');
}

// =============================================
// RUTAS PÚBLICAS (no requieren autenticación)
// =============================================

// Página de inicio - Centro Estadístico para todos los usuarios
$router->get('/', function() {
    if (isset($_SESSION['user_id'])) {
        // Usuario autenticado - mostrar dashboard completo
        $controller = new DashboardController();
        $controller->general();
    } else {
        // Usuario no autenticado - mostrar centro estadístico público
        $controller = new DashboardController();
        $controller->publico();
    }
});
$router->get('/home', function() {
    if (isset($_SESSION['user_id'])) {
        $controller = new DashboardController();
        $controller->general();
    } else {
        include __DIR__ . '/../app/views/principal.php';
    }
});

// Dashboard público para usuarios básicos
$router->get('/dashboard/publico', function() {
    $controller = new DashboardController();
    $controller->publico();
});

// Autenticación
$router->get('/login', 'AuthController@login');
$router->post('/login', 'AuthController@procesarLogin');
$router->get('/logout', 'AuthController@logout');

// Registro de usuarios
$router->get('/register', 'AuthController@register');
$router->post('/register', 'AuthController@procesarRegistro');

// Recuperación de contraseña
$router->get('/recuperar-password', 'AuthController@recuperarPassword');
$router->post('/cambiar-password', 'AuthController@cambiarPassword');

// Páginas estáticas
$router->get('/acerca', 'DashboardController@acerca');
$router->get('/contacto', 'DashboardController@contacto');
$router->get('/terminos', 'DashboardController@terminos');
$router->get('/privacidad', 'DashboardController@privacidad');

// API para verificar sesión (AJAX)
$router->get('/api/auth/verificar-sesion', 'AuthController@verificarSesion');
$router->get('/api/auth/usuario-actual', 'AuthController@obtenerUsuarioActual');

// API de la aplicación
$router->get('/api/estadisticas/generales', 'ApiController@estadisticasGenerales');

// =============================================
// RUTAS DEL DASHBOARD
// =============================================

$router->get('/dashboard', 'DashboardController@general');
$router->get('/dashboard/general', 'DashboardController@general');
$router->get('/dashboard/estadisticas', 'DashboardController@estadisticas');

// Rutas jerárquicas del dashboard
$router->get('/dashboard/reino/{id}', 'DashboardController@reino');
$router->get('/dashboard/modulo/{id}', 'DashboardController@modulo');
$router->get('/dashboard/especie/{id}', 'DashboardController@especie');

// API del dashboard
$router->get('/api/dashboard/datos/{tipo}/{id}', 'DashboardController@obtenerDatos');
$router->get('/api/dashboard/modulos/{id}', 'DashboardController@apiModulos');
$router->get('/api/dashboard/datos/modulo/{id}', 'DashboardController@apiDatosModulo');
$router->get('/api/dashboard/datos/especie/{id}', 'DashboardController@apiDatosEspecie');
$router->get('/api/dashboard/exportar/{tipo}/{id}', 'DashboardController@exportar');

// =============================================
// RUTAS DEL CENTRO ESTADÍSTICO
// =============================================

$router->get('/estadistica', 'EstadisticaController@index');
$router->get('/estadistica/index', 'EstadisticaController@index');

// API del Centro Estadístico
$router->get('/estadistica/obtenerModulos/{id}', 'EstadisticaController@obtenerModulos');
$router->get('/estadistica/obtenerEspecies/{id}', 'EstadisticaController@obtenerEspecies');

// API pública del Centro Estadístico (sin autenticación requerida)
$router->get('/api/estadistica/modulos', 'EstadisticaController@apiObtenerModulos');
$router->get('/api/estadistica/especies', 'EstadisticaController@apiObtenerEspecies');

// =============================================
// RUTAS DE GESTIÓN DE USUARIOS (Solo usuarios supremos)
// =============================================

$router->get('/usuarios', 'UsuarioController@listar');
$router->get('/usuarios/listar/{pagina}', 'UsuarioController@listar');
$router->get('/usuarios/crear', 'UsuarioController@crear');
$router->post('/usuarios/crear', 'UsuarioController@procesarCreacion');
$router->get('/usuarios/editar/{id}', 'UsuarioController@editar');
$router->post('/usuarios/editar/{id}', 'UsuarioController@procesarEdicion');
$router->get('/usuarios/activar/{id}', 'UsuarioController@activar');
$router->get('/usuarios/desactivar/{id}', 'UsuarioController@desactivar');
$router->post('/usuarios/cambiar-password/{id}', 'UsuarioController@cambiarPassword');

// API de usuarios
$router->get('/api/usuarios/ver/{id}', 'UsuarioController@verPerfil');
$router->get('/api/usuarios/estadisticas', 'UsuarioController@obtenerEstadisticas');

// =============================================
// RUTAS DE GESTIÓN DE ESPECIES
// =============================================

$router->get('/especies', 'EspecieController@listar');
$router->get('/especies/listar', 'EspecieController@listar');
$router->get('/especies/crear', 'EspecieController@crear');
$router->post('/especies/procesarCreacion', 'EspecieController@procesarCreacion');
$router->get('/especies/crear-modulo', 'EspecieController@crearModuloForm');
$router->post('/especies/crear-modulo', 'EspecieController@crearModulo');
$router->get('/especies/editar/{id}', 'EspecieController@editar');
$router->post('/especies/editar/{id}', 'EspecieController@procesarEdicion');
$router->post('/especies/eliminar', 'EspecieController@eliminar');
$router->post('/especies/eliminar-modulo', 'EspecieController@eliminarModulo');

// API de especies
$router->get('/api/especies/ver/{id}', 'EspecieController@ver');
$router->get('/api/especies/buscar', 'EspecieController@buscar');
$router->get('/api/especies/reino/{id}/modulos', 'EspecieController@obtenerModulos');
$router->get('/api/especies/modulo/{id}/especies', 'EspecieController@obtenerEspecies');
$router->get('/api/especies', 'EspecieController@apiEspecies');

// =============================================
// RUTAS DE GESTIÓN DE FORMULARIOS
// =============================================

$router->get('/formularios', 'FormularioController@listar');
$router->get('/formularios/listar', 'FormularioController@listar');
$router->get('/formularios/listar/{pagina}', 'FormularioController@listar');
$router->get('/formularios/crear', 'FormularioController@crear');
$router->post('/formularios/crear', 'FormularioController@procesarCreacion');
$router->post('/formularios/procesarCreacion', 'FormularioController@procesarCreacion');
$router->get('/formularios/editar/{id}', 'FormularioController@editar');
$router->post('/formularios/editar/{id}', 'FormularioController@procesarEdicion');
$router->get('/formularios/eliminar/{id}', 'FormularioController@eliminar');
$router->get('/formularios/duplicar/{id}', 'FormularioController@duplicar');

// Rutas para realización de censos
$router->get('/formularios/responder/{id}', 'FormularioController@responder');
$router->post('/formularios/responder/{id}', 'FormularioController@procesarRespuestas');

// Rutas para aprobación de formularios (usuarios supremos)
$router->get('/formularios/pendientes', 'FormularioController@pendientes');
$router->get('/formularios/aprobar/{id}', 'FormularioController@aprobar');
$router->get('/formularios/rechazar/{id}', 'FormularioController@rechazar');

// Ver detalles de formulario
$router->get('/formularios/ver/{id}', 'FormularioController@ver');

// API de formularios
$router->get('/api/formularios/ver/{id}', 'FormularioController@verAjax');
$router->get('/api/formularios/preguntas/{id}', 'FormularioController@obtenerPreguntas');

// =============================================
// RUTAS DE GESTIÓN DE PREGUNTAS BASE (Solo usuarios supremos)
// =============================================

$router->get('/preguntas', 'PreguntaController@listar');
$router->get('/preguntas/listar', 'PreguntaController@listar');
$router->get('/preguntas/crear', 'PreguntaController@crear');
$router->post('/preguntas/crear', 'PreguntaController@procesarCreacion');
$router->get('/preguntas/editar/{id}', 'PreguntaController@editar');
$router->post('/preguntas/editar/{id}', 'PreguntaController@procesarEdicion');
$router->get('/preguntas/eliminar/{id}', 'PreguntaController@eliminar');

// API de preguntas base
$router->get('/api/preguntas/modulos/{reinoId}', 'PreguntaController@obtenerModulos');
$router->get('/api/preguntas/especies/{moduloId}', 'PreguntaController@obtenerEspecies');
$router->get('/api/preguntas/heredadas/{especieId}', 'PreguntaController@obtenerPreguntasHeredadas');

// =============================================
// RUTAS DE REPORTES Y EXPORTACIÓN (Futuro)
// =============================================

$router->get('/reportes', function() {
    // Esta funcionalidad se implementará en el futuro
    echo "Reportes - Funcionalidad futura";
});

$router->get('/exportar/{tipo}/{id}', function($tipo, $id) {
    // Esta funcionalidad se implementará en el futuro
    echo "Exportar - Funcionalidad futura";
});

// =============================================
// RUTAS DE API REST (public/api/v1/)
// =============================================

$router->get('/api/v1/especies', 'ApiController@especies');
$router->get('/api/v1/especies/{id}', 'ApiController@especie');
$router->post('/api/v1/especies', 'ApiController@crearEspecie');
$router->put('/api/v1/especies/{id}', 'ApiController@actualizarEspecie');
$router->delete('/api/v1/especies/{id}', 'ApiController@eliminarEspecie');

$router->get('/api/v1/formularios', 'ApiController@formularios');
$router->get('/api/v1/formularios/{id}', 'ApiController@formulario');
$router->post('/api/v1/formularios', 'ApiController@crearFormulario');
$router->put('/api/v1/formularios/{id}', 'ApiController@actualizarFormulario');
$router->delete('/api/v1/formularios/{id}', 'ApiController@eliminarFormulario');

$router->get('/api/v1/registros', 'ApiController@registros');
$router->get('/api/v1/registros/{id}', 'ApiController@registro');
$router->post('/api/v1/registros', 'ApiController@crearRegistro');
$router->put('/api/v1/registros/{id}', 'ApiController@actualizarRegistro');
$router->delete('/api/v1/registros/{id}', 'ApiController@eliminarRegistro');

// =============================================
// RUTAS DE CONFIGURACIÓN DEL SISTEMA (Solo usuarios supremos)
// =============================================

$router->get('/configuracion', function() {
    // Esta funcionalidad se implementará en el futuro
    echo "Configuración - Funcionalidad futura";
});

// =============================================
// RUTAS DE AYUDA Y DOCUMENTACIÓN
// =============================================

$router->get('/ayuda', function() {
    // Esta funcionalidad se implementará en el futuro
    echo "Ayuda - Funcionalidad futura";
});

$router->get('/documentacion', function() {
    // Esta funcionalidad se implementará en el futuro
    echo "Documentación - Funcionalidad futura";
});

// =============================================
// RUTA POR DEFECTO (404)
// =============================================

$router->any('/404', function() {
    http_response_code(404);
    include __DIR__ . '/../app/views/errors/404.php';
});

// =============================================
// RUTAS DE DESARROLLO Y DEBUG (Solo en modo desarrollo)
// =============================================

if (isDebugMode()) {
    $router->get('/debug/phpinfo', function() {
        phpinfo();
    });

    $router->get('/debug/routes', function() use ($router) {
        echo "<h1>Rutas Definidas</h1>";
        echo "<pre>";
        print_r($router);
        echo "</pre>";
    });

    $router->get('/debug/session', function() {
        echo "<h1>Datos de Sesión</h1>";
        echo "<pre>";
        print_r($_SESSION);
        echo "</pre>";
    });
}