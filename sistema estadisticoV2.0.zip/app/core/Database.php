<?php
/**
 * Sistema Estadístico Pro - Clase de Base de Datos
 * Maneja la conexión PDO y consultas preparadas de forma segura
 */

class Database {
    private static $instance = null;
    private $connection;
    private $transactionStarted = false;

    private function __construct() {
        $this->connect();
    }

    /**
     * Patrón Singleton para obtener instancia única
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Conectar a la base de datos
     */
    private function connect() {
        try {
            $dsn = sprintf(
                "mysql:host=%s;dbname=%s;charset=%s",
                DB_HOST,
                DB_NAME,
                DB_CHARSET
            );

            $this->connection = new PDO($dsn, DB_USER, DB_PASS, DB_OPTIONS);

            // Configurar atributos adicionales de PDO
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->connection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

        } catch (PDOException $e) {
            $this->handleConnectionError($e);
        }
    }

    /**
     * Manejar errores de conexión
     */
    private function handleConnectionError(PDOException $e) {
        $error = [
            'type' => 'database_connection',
            'message' => $e->getMessage(),
            'code' => $e->getCode(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'timestamp' => date('Y-m-d H:i:s')
        ];

        // Log del error sin mostrar información sensible
        error_log('Error de conexión a la base de datos: ' . date('Y-m-d H:i:s'), 3, __DIR__ . '/../../logs/database.log');

        // En producción, nunca mostrar detalles del error
        die('Error interno del servidor. Por favor, inténtelo más tarde.');
    }

    /**
     * Obtener la conexión PDO
     */
    public function getConnection() {
        return $this->connection;
    }

    /**
     * Ejecutar consulta preparada SELECT
     */
    public function select($sql, $params = [], $fetchMode = PDO::FETCH_ASSOC) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll($fetchMode);
        } catch (PDOException $e) {
            $this->handleQueryError($e, $sql, $params);
            return false;
        }
    }

    /**
     * Ejecutar consulta preparada SELECT que devuelve una sola fila
     */
    public function selectOne($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetch();
        } catch (PDOException $e) {
            $this->handleQueryError($e, $sql, $params);
            return false;
        }
    }

    /**
     * Ejecutar consulta preparada INSERT
     */
    public function insert($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $this->connection->lastInsertId();
        } catch (PDOException $e) {
            $this->handleQueryError($e, $sql, $params);
            return false;
        }
    }

    /**
     * Ejecutar consulta preparada UPDATE
     */
    public function update($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt->rowCount();
        } catch (PDOException $e) {
            $this->handleQueryError($e, $sql, $params);
            return false;
        }
    }

    /**
     * Ejecutar consulta preparada DELETE
     */
    public function delete($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt->rowCount();
        } catch (PDOException $e) {
            $this->handleQueryError($e, $sql, $params);
            return false;
        }
    }

    /**
     * Ejecutar consulta preparada genérica
     */
    public function query($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            $this->handleQueryError($e, $sql, $params);
            return false;
        }
    }

    /**
     * Iniciar transacción
     */
    public function beginTransaction() {
        if (!$this->transactionStarted) {
            $this->connection->beginTransaction();
            $this->transactionStarted = true;
        }
    }

    /**
     * Confirmar transacción
     */
    public function commit() {
        if ($this->transactionStarted) {
            $this->connection->commit();
            $this->transactionStarted = false;
        }
    }

    /**
     * Revertir transacción
     */
    public function rollback() {
        if ($this->transactionStarted) {
            $this->connection->rollBack();
            $this->transactionStarted = false;
        }
    }

    /**
     * Verificar si hay una transacción activa
     */
    public function inTransaction() {
        return $this->transactionStarted;
    }

    /**
     * Manejar errores de consulta
     */
    private function handleQueryError(PDOException $e, $sql, $params) {
        $error = [
            'type' => 'database_query',
            'message' => $e->getMessage(),
            'sql' => $sql,
            'params' => $params,
            'code' => $e->getCode(),
            'file' => $e->getFile(),
            'line' => $e->getLine(),
            'timestamp' => date('Y-m-d H:i:s')
        ];

        // Log del error
        error_log(json_encode($error) . PHP_EOL, 3, LOG_PATH . 'database.log');

        if (isDebugMode()) {
            die('Error en consulta SQL: ' . $e->getMessage());
        } else {
            die('Error interno del servidor. Por favor, inténtelo más tarde.');
        }
    }

    /**
     * Obtener el número de filas afectadas por la última consulta
     */
    public function getRowCount() {
        return $this->connection->query('SELECT FOUND_ROWS()')->fetchColumn();
    }

    /**
     * Escapar valores para consultas SQL (uso limitado, preferir consultas preparadas)
     */
    public function quote($value) {
        return $this->connection->quote($value);
    }

    /**
     * Verificar si la conexión está activa
     */
    public function isConnected() {
        try {
            $this->connection->query('SELECT 1');
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    /**
     * Cerrar conexión (generalmente no necesario con PDO)
     */
    public function close() {
        $this->connection = null;
        self::$instance = null;
    }

    /**
     * Destructor para cerrar conexión
     */
    public function __destruct() {
        if ($this->transactionStarted) {
            $this->rollback();
        }
        $this->connection = null;
    }
}