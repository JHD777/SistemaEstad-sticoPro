<?php
/**
 * Sistema Estadístico Pro - Inicialización de Datos
 * Crea la base de datos y carga datos de ejemplo según las especificaciones
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = getDB();

    // Script de creación de base de datos
    $sql = "-- =================================================================
-- SCRIPT DE CREACIÓN DE BASE DE DATOS PARA SISTEMA ESTADÍSTICO PRO (Versión Optimizada)
-- =================================================================

-- Eliminar la base de datos si existe para una instalación limpia
DROP DATABASE IF EXISTS `sistema_estadistico_pro`;

-- Crear la base de datos con charset UTF8 para soporte completo de caracteres
CREATE DATABASE `sistema_estadistico_pro`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_spanish_ci;

-- Seleccionar la base de datos recién creada para usarla
USE `sistema_estadistico_pro`;

-- =================================================================
-- TABLA 1: usuarios
-- Almacena la información de los usuarios y sus roles de acceso.
-- =================================================================
CREATE TABLE `usuarios` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `rol` ENUM('basico', 'registrado', 'admin', 'supremo') NOT NULL DEFAULT 'basico',
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `activo` BOOLEAN DEFAULT TRUE,
    -- Índice para búsquedas rápidas por email (ya es único, pero es bueno recordarlo)
    INDEX `idx_email` (`email`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 2: especies
-- Define la jerarquía taxonómica: Reino -> Módulo -> Especie.
-- Es una tabla auto-referenciada para crear la estructura de árbol.
-- =================================================================
CREATE TABLE `especies` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(255) NOT NULL,
    `parent_id` INT NULL,
    `tipo` ENUM('reino', 'modulo', 'especie') NOT NULL,
    `descripcion` TEXT NULL,
    FOREIGN KEY (`parent_id`) REFERENCES `especies`(`id`) ON DELETE SET NULL,
    -- Índice para encontrar rápidamente los hijos de un padre
    INDEX `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 3: formularios
-- Cada formulario está asociado a una especie específica.
-- Contiene el flujo de aprobación (borrador, pendiente, aprobado).
-- =================================================================
CREATE TABLE `formularios` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `especie_id` INT NOT NULL,
    `nombre` VARCHAR(255) NOT NULL,
    `descripcion` TEXT NULL,
    `estado` ENUM('borrador', 'pendiente', 'aprobado', 'archivado') NOT NULL DEFAULT 'borrador',
    `creador_id` INT NOT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `fecha_aprobacion` TIMESTAMP NULL,
    `aprobador_id` INT NULL,
    FOREIGN KEY (`especie_id`) REFERENCES `especies`(`id`) ON DELETE CASCADE,
    -- ON DELETE RESTRICT: Protege la integridad. No se puede borrar un usuario que ha creado formularios.
    FOREIGN KEY (`creador_id`) REFERENCES `usuarios`(`id`) ON DELETE RESTRICT,
    -- ON DELETE SET NULL: Si el aprobador es borrado, el formulario sigue aprobado, pero pierde la referencia de quién lo aprobó.
    FOREIGN KEY (`aprobador_id`) REFERENCES `usuarios`(`id`) ON DELETE SET NULL,
    -- Índices para búsquedas comunes en el dashboard
    INDEX `idx_especie_estado` (`especie_id`, `estado`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 4: preguntas
-- Define cada pregunta de un formulario. Soporta lógica condicional.
-- =================================================================
CREATE TABLE `preguntas` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `formulario_id` INT NOT NULL,
    `texto_pregunta` TEXT NOT NULL,
    `tipo_pregunta` ENUM('texto', 'numero', 'booleano', 'opcion_multiple', 'fecha') NOT NULL,
    `opciones` TEXT NULL, -- Para 'opcion_multiple', ej: \"Sí,No,Tal vez\"
    `orden` INT NOT NULL,
    `obligatoria` BOOLEAN DEFAULT FALSE,
    `depende_de` INT NULL, -- ID de la pregunta \"padre\"
    `respuesta_requerida` TEXT NULL, -- Respuesta que activa esta pregunta
    FOREIGN KEY (`formulario_id`) REFERENCES `formularios`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`depende_de`) REFERENCES `preguntas`(`id`) ON DELETE SET NULL,
    -- Índice para obtener las preguntas de un formulario ordenadas
    INDEX `idx_formulario_orden` (`formulario_id`, `orden`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 5: registros_censo
-- Representa una instancia única de un censo completado para un individuo.
-- =================================================================
CREATE TABLE `registros_censo` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `formulario_id` INT NOT NULL,
    `usuario_admin_id` INT NOT NULL,
    `fecha_censo` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `ubicacion_geo` VARCHAR(100) NULL, -- Ej: \"-12.0464, -77.0428\"
    `observaciones` TEXT NULL,
    FOREIGN KEY (`formulario_id`) REFERENCES `formularios`(`id`) ON DELETE CASCADE,
    -- ON DELETE RESTRICT: Protege la integridad. No se puede borrar un usuario que ha realizado censos.
    FOREIGN KEY (`usuario_admin_id`) REFERENCES `usuarios`(`id`) ON DELETE RESTRICT,
    -- Índice para filtrar censos por formulario o admin
    INDEX `idx_formulario_admin` (`formulario_id`, `usuario_admin_id`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 6: respuestas
-- Almacena cada respuesta individual, conectando un registro de censo con una pregunta.
-- Esta es la tabla clave del modelo EAV (Entidad-Atributo-Valor).
-- =================================================================
CREATE TABLE `respuestas` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `registro_censo_id` INT NOT NULL,
    `pregunta_id` INT NOT NULL,
    `valor_respuesta` TEXT NOT NULL,
    FOREIGN KEY (`registro_censo_id`) REFERENCES `registros_censo`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`pregunta_id`) REFERENCES `preguntas`(`id`) ON DELETE CASCADE,
    -- Índices cruciales para el rendimiento al consultar datos del dashboard
    INDEX `idx_registro_censo` (`registro_censo_id`),
    INDEX `idx_pregunta` (`pregunta_id`)
) ENGINE=InnoDB;

-- =================================================================
-- INSERCIÓN DE DATOS DE EJEMPLO
-- =================================================================

-- NOTA: El hash de contraseña es para \"password123\". Generado con password_hash().
SET @password_hash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

-- Insertar usuarios de ejemplo para cada rol
INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password_hash`, `rol`) VALUES
(1, 'Admin Supremo', 'supremo@censo.com', @password_hash, 'supremo'),
(2, 'Administrador', 'admin@censo.com', @password_hash, 'admin'),
(3, 'Usuario Registrado', 'registrado@censo.com', @password_hash, 'registrado'),
(4, 'Usuario Básico', 'basico@censo.com', @password_hash, 'basico');

-- Insertar la jerarquía de especies
INSERT INTO `especies` (`id`, `nombre`, `parent_id`, `tipo`) VALUES
(1, 'Flora', NULL, 'reino'),
(2, 'Fauna', NULL, 'reino'),
(3, 'Cítricos', 1, 'modulo'),
(4, 'Bovinos', 2, 'modulo'),
(5, 'Limón', 3, 'especie'),
(6, 'Naranja', 3, 'especie'),
(7, 'Vaca', 4, 'especie'),
(8, 'Toro', 4, 'especie');

-- Insertar formularios de ejemplo
INSERT INTO `formularios` (`id`, `especie_id`, `nombre`, `estado`, `creador_id`) VALUES
(1, 5, 'Censo de Limón 2024', 'aprobado', 2), -- Creado por un admin, aprobado (simulado)
(2, 7, 'Censo de Vaca Lechera', 'borrador', 2); -- Creado por un admin, pendiente de aprobación

-- Insertar preguntas para el formulario de Limón (ID 1)
INSERT INTO `preguntas` (`id`, `formulario_id`, `texto_pregunta`, `tipo_pregunta`, `orden`, `obligatoria`) VALUES
(1, 1, '¿El árbol fue fumigado el último año?', 'booleano', 1, TRUE),
(2, 1, '¿Cuántos frutos estima que tiene?', 'numero', 2, TRUE),
(3, 1, '¿Presenta signos de alguna plaga?', 'opcion_multiple', 3, FALSE),
(4, 1, '¿Cuál plaga específica?', 'texto', 4, FALSE);

-- Configurar las opciones y la lógica condicional para las preguntas del Limón
UPDATE `preguntas` SET `opciones` = 'Sí,No' WHERE `id` = 3;
UPDATE `preguntas` SET `depende_de` = 3, `respuesta_requerida` = 'Sí' WHERE `id` = 4;

-- Insertar preguntas para el formulario de Vaca (ID 2)
INSERT INTO `preguntas` (`id`, `formulario_id`, `texto_pregunta`, `tipo_pregunta`, `orden`, `obligatoria`) VALUES
(5, 2, '¿Está en producción de leche?', 'booleano', 1, TRUE),
(6, 2, '¿Cuántos litros de leche produce al día?', 'numero', 2, FALSE),
(7, 2, '¿Está vacunada contra la fiebre aftosa?', 'booleano', 3, TRUE),
(8, 2, 'Número de partos', 'numero', 4, FALSE);

-- Configurar la lógica condicional para las preguntas de la Vaca
UPDATE `preguntas` SET `depende_de` = 5, `respuesta_requerida` = '1' WHERE `id` = 6; -- Solo muestra producción si está en producción (1 para 'Sí')

-- Insertar un registro de censo completado para un Limón
INSERT INTO `registros_censo` (`id`, `formulario_id`, `usuario_admin_id`, `ubicacion_geo`) VALUES (1, 1, 2, '-12.0464, -77.0428');

-- Insertar las respuestas para ese registro de censo del Limón
INSERT INTO `respuestas` (`registro_censo_id`, `pregunta_id`, `valor_respuesta`) VALUES
(1, 1, '1'), -- 'Sí' para fumigado
(1, 2, '250'), -- 250 frutos
(1, 3, 'Sí'), -- Sí tiene plaga
(1, 4, 'Minador de la hoja'); -- Plaga específica

-- Insertar un registro de censo completado para una Vaca
INSERT INTO `registros_censo` (`id`, `formulario_id`, `usuario_admin_id`, `ubicacion_geo`) VALUES (2, 2, 2, '-12.0500, -77.0400');

-- Insertar las respuestas para ese registro de censo de la Vaca
INSERT INTO `respuestas` (`registro_censo_id`, `pregunta_id`, `valor_respuesta`) VALUES
(2, 5, '1'), -- 'Sí' está en producción
(2, 6, '22'), -- 22 litros
(2, 7, '1'), -- 'Sí' está vacunada
(2, 8, '3'); -- 3 partos

-- =================================================================
-- FIN DEL SCRIPT
-- =================================================================";

    // Ejecutar el script SQL
    $db->exec($sql);

    echo "Base de datos inicializada correctamente con datos de ejemplo.\n";
    echo "Usuarios de prueba:\n";
    echo "- supremo@censo.com (password123) - Rol: supremo\n";
    echo "- admin@censo.com (password123) - Rol: admin\n";
    echo "- registrado@censo.com (password123) - Rol: registrado\n";
    echo "- basico@censo.com (password123) - Rol: basico\n";

} catch (PDOException $e) {
    echo "Error al inicializar la base de datos: " . $e->getMessage() . "\n";
    exit(1);
}
?>
