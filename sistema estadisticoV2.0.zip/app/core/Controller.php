<?php
/**
 * Sistema Estadístico Pro - Controlador Base
 * Clase padre para todos los controladores del sistema
 */

class Controller {
    protected $data = [];
    protected $layout = 'main';
    protected $view;
    protected $user;

    public function __construct() {
        // Inicializar datos comunes
        $this->data = [
            'app_name' => APP_NAME,
            'app_version' => APP_VERSION,
            'base_url' => base_url(),
            'current_time' => date('Y-m-d H:i:s'),
            'user' => $this->getCurrentUser(),
            'csrf_token' => generate_csrf_token()
        ];

        // Verificar autenticación si es necesario
        $this->checkAuthentication();
    }

    /**
     * Método para cargar y mostrar vistas
     */
    protected function view($view, $data = []) {
        // Combinar datos del controlador con datos adicionales
        $viewData = array_merge($this->data, $data);

        // Construir ruta completa de la vista
        $viewPath = $this->getViewPath($view);

        // Verificar que la vista existe
        if (!file_exists($viewPath)) {
            throw new Exception("Vista no encontrada: $viewPath");
        }

        // Extraer variables para la vista
        extract($viewData);

        // Incluir la vista
        include $viewPath;
    }

    /**
     * Método para obtener la ruta completa de una vista
     */
    private function getViewPath($view) {
        // Si la vista ya incluye extensión .php, usarla directamente
        if (substr($view, -4) === '.php') {
            return __DIR__ . '/../views/' . $view;
        }

        // De lo contrario, construir la ruta estándar
        return __DIR__ . '/../views/' . $view . '.php';
    }

    /**
     * Método para cargar vistas dentro de un layout
     */
    protected function render($view, $data = []) {
        $this->view = $view;
        $this->data = array_merge($this->data, $data);

        // Extraer variables para que estén disponibles en el layout y las vistas
        extract($this->data);

        // Incluir el layout principal
        include $this->getLayoutPath();
    }

    /**
     * Método para obtener la ruta del layout
     */
    private function getLayoutPath() {
        return __DIR__ . '/../views/layouts/' . $this->layout . '.php';
    }

    /**
     * Método para cambiar el layout
     */
    protected function setLayout($layout) {
        $this->layout = $layout;
    }

    /**
     * Método para obtener el usuario actual
     */
    protected function getCurrentUser() {
        if (isset($_SESSION['user_id'])) {
            return $this->getUserById($_SESSION['user_id']);
        }
        return null;
    }

    /**
     * Método para obtener usuario por ID
     */
    private function getUserById($userId) {
        // Esta implementación se completará cuando creemos el modelo Usuario
        return null;
    }

    /**
     * Método para verificar autenticación
     */
    protected function checkAuthentication() {
        // Por defecto, no requerir autenticación
        // Los controladores específicos pueden sobrescribir este método
    }

    /**
     * Método para verificar autenticación estricta
     */
    protected function verificarAutenticacion() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: ' . base_url('login'));
            exit();
        }
    }

    /**
     * Método para verificar roles específicos
     */
    protected function verificarRol($rolesPermitidos) {
        if (!isset($_SESSION['user_id'])) {
            header('Location: ' . base_url('login'));
            exit();
        }

        if (!isset($_SESSION['user_role'])) {
            header('Location: ' . base_url('login'));
            exit();
        }

        if (!in_array($_SESSION['user_role'], $rolesPermitidos)) {
            $this->show403();
        }
    }

    /**
     * Método para requerir autenticación
     */
    protected function requireAuth() {
        if (!$this->isLoggedIn()) {
            $this->redirectToLogin();
        }
    }

    /**
     * Método para requerir permisos específicos
     */
    protected function requirePermission($permission) {
        if (!$this->hasPermission($permission)) {
            $this->show403();
        }
    }

    /**
     * Método para verificar si la petición es GET
     */
    protected function is_get() {
        return request_method() === 'GET';
    }

    /**
     * Método para verificar si la petición es POST
     */
    protected function is_post() {
        return request_method() === 'POST';
    }

    /**
     * Método para verificar si el usuario está logueado
     */
    protected function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    /**
     * Método para verificar permisos
     */
    protected function hasPermission($permission) {
        if (!$this->isLoggedIn()) {
            return false;
        }

        $userRole = $_SESSION['user_role'] ?? 'basico';
        return hasPermission($userRole, $permission);
    }

    /**
     * Método para redirigir al login
     */
    protected function redirectToLogin() {
        redirect(base_url('auth/login'));
    }

    /**
     * Método para mostrar página 403
     */
    protected function show403() {
        http_response_code(403);
        include __DIR__ . '/../views/errors/403.php';
        exit;
    }

    /**
     * Método para mostrar página 404
     */
    protected function show404() {
        http_response_code(404);
        include __DIR__ . '/../views/errors/404.php';
        exit;
    }

    /**
     * Método para redirigir con mensaje
     */
    protected function redirectWithMessage($url, $message, $type = 'success') {
        $_SESSION['flash_message'] = $message;
        $_SESSION['flash_type'] = $type;
        redirect($url);
    }

    /**
     * Método para obtener mensaje flash
     */
    protected function getFlashMessage() {
        if (isset($_SESSION['flash_message'])) {
            $message = $_SESSION['flash_message'];
            $type = $_SESSION['flash_type'] ?? 'info';

            unset($_SESSION['flash_message']);
            unset($_SESSION['flash_type']);

            return [
                'message' => $message,
                'type' => $type
            ];
        }
        return null;
    }

    /**
     * Método para sanitizar entrada de usuario
     */
    protected function sanitize($data) {
        if (is_array($data)) {
            return array_map([$this, 'sanitize'], $data);
        }
        return sanitize($data);
    }

    /**
     * Método para validar datos requeridos
     */
    protected function validateRequired($data, $fields) {
        $errors = [];

        foreach ($fields as $field) {
            if (empty($data[$field])) {
                $errors[$field] = "El campo $field es requerido";
            }
        }

        return $errors;
    }

    /**
     * Método para validar email
     */
    protected function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    /**
     * Método para validar longitud de contraseña
     */
    protected function validatePassword($password) {
        return strlen($password) >= PASSWORD_MIN_LENGTH;
    }

    /**
     * Método para manejar respuestas JSON (para AJAX)
     */
    protected function jsonResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');

        echo json_encode($data);
        exit;
    }

    /**
     * Método para manejar errores JSON
     */
    protected function jsonError($message, $statusCode = 400) {
        $this->jsonResponse([
            'success' => false,
            'error' => $message
        ], $statusCode);
    }

    /**
     * Método para manejar éxito JSON
     */
    protected function jsonSuccess($data = null, $message = null) {
        $response = [
            'success' => true
        ];

        if ($message) {
            $response['message'] = $message;
        }

        if ($data) {
            $response['data'] = $data;
        }

        $this->jsonResponse($response);
    }
}