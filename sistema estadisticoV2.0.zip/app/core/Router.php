<?php
/**
 * Sistema Estadístico Pro - Router
 * Maneja el enrutamiento de URLs hacia controladores y métodos
 */

class Router {
    private $routes = [];
    private $params = [];
    private $requestMethod;

    public function __construct() {
        $this->requestMethod = $_SERVER['REQUEST_METHOD'];
    }

    /**
     * Agrega una ruta GET
     */
    public function get($route, $action) {
        $this->addRoute('GET', $route, $action);
    }

    /**
     * Agrega una ruta POST
     */
    public function post($route, $action) {
        $this->addRoute('POST', $route, $action);
    }

    /**
     * Agrega una ruta PUT
     */
    public function put($route, $action) {
        $this->addRoute('PUT', $route, $action);
    }

    /**
     * Agrega una ruta DELETE
     */
    public function delete($route, $action) {
        $this->addRoute('DELETE', $route, $action);
    }

    /**
     * Agrega una ruta para cualquier método HTTP
     */
    public function any($route, $action) {
        $this->addRoute('ANY', $route, $action);
    }

    /**
     * Agrega una ruta con método específico
     */
    private function addRoute($method, $route, $action) {
        // Asegurar que la ruta comienza con /
        $route = '/' . ltrim($route, '/');
        
        // Convertir la ruta en expresión regular
        $route = preg_replace('/\//', '\\/', $route);
        $route = preg_replace('/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/', '(?P<\1>[a-zA-Z0-9_]+)', $route);
        $route = '/^' . $route . '$/';

        $this->routes[$method][$route] = $action;
    }

    /**
     * Procesa la petición y ejecuta la acción correspondiente
     */
    public function dispatch($uri) {
        // Obtener el método HTTP
        $method = $this->requestMethod;
        
        // Asegurar que la URI comienza con /
        $uri = '/' . ltrim($uri, '/');

        // Buscar la ruta en las rutas definidas
        if (isset($this->routes[$method])) {
            $action = $this->matchRoute($this->routes[$method], $uri);
            if ($action) {
                return $this->executeAction($action, $this->params);
            }
        }

        // Buscar en rutas ANY si no se encontró en el método específico
        if (isset($this->routes['ANY'])) {
            $action = $this->matchRoute($this->routes['ANY'], $uri);
            if ($action) {
                return $this->executeAction($action, $this->params);
            }
        }

        // Si no se encontró ninguna ruta, lanzar excepción
        throw new Exception("No se encontró la ruta: $uri");
    }

    /**
     * Busca una coincidencia para la URI en las rutas definidas
     */
    private function matchRoute($routes, $uri) {
        foreach ($routes as $routePattern => $action) {
            if (preg_match($routePattern, $uri, $matches)) {
                // Extraer parámetros nombrados
                foreach ($matches as $key => $value) {
                    if (is_string($key)) {
                        $this->params[$key] = $value;
                    }
                }
                return $action;
            }
        }
        return false;
    }

    /**
     * Ejecuta la acción correspondiente (controlador@método)
     */
    private function executeAction($action, $params = []) {
        // Si la acción es un closure, ejecutarla directamente
        if (is_callable($action)) {
            return call_user_func_array($action, $params);
        }

        // Si la acción es un string en formato "Controller@method"
        if (is_string($action)) {
            list($controllerName, $methodName) = explode('@', $action);

            // Construir el nombre completo de la clase del controlador
            $controllerClass = $controllerName;

            // Verificar que el controlador existe
            if (!class_exists($controllerClass)) {
                throw new Exception("Controlador no encontrado: $controllerClass");
            }

            // Crear instancia del controlador
            $controller = new $controllerClass();

            // Verificar que el método existe
            if (!method_exists($controller, $methodName)) {
                throw new Exception("Método no encontrado: $methodName en $controllerClass");
            }

            // Convertir parámetros asociativos a posicionales según el orden esperado
            $methodParams = $this->getMethodParameters($controller, $methodName, $params);

            // Ejecutar el método con los parámetros en el orden correcto
            return call_user_func_array([$controller, $methodName], $methodParams);
        }

        throw new Exception("Tipo de acción no válido");
    }

    /**
     * Obtiene los parámetros del método en el orden correcto
     */
    private function getMethodParameters($controller, $methodName, $params) {
        // Usar reflexión para obtener la información del método
        $reflection = new ReflectionMethod($controller, $methodName);
        $methodParams = $reflection->getParameters();

        $orderedParams = [];

        // Para cada parámetro del método, buscar el valor correspondiente en $params
        foreach ($methodParams as $param) {
            $paramName = $param->getName();

            if (isset($params[$paramName])) {
                $orderedParams[] = $params[$paramName];
            } elseif ($param->isOptional()) {
                // Si el parámetro es opcional y no está definido, usar el valor por defecto
                $orderedParams[] = $param->getDefaultValue();
            } else {
                // Si el parámetro es requerido pero no está definido, lanzar error
                throw new Exception("Parámetro requerido '$paramName' no encontrado para el método $methodName");
            }
        }

        return $orderedParams;
    }

    /**
     * Obtiene los parámetros de la ruta actual
     */
    public function getParams() {
        return $this->params;
    }

    /**
     * Obtiene un parámetro específico de la ruta
     */
    public function getParam($key, $default = null) {
        return isset($this->params[$key]) ? $this->params[$key] : $default;
    }

    /**
     * Genera una URL basada en el nombre de la ruta
     */
    public function url($routeName, $params = []) {
        // Esta funcionalidad se puede implementar en el futuro
        // para generar URLs basadas en nombres de rutas
        return base_url($routeName);
    }
}