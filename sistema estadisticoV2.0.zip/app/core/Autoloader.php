<?php
/**
 * Autoloader para cargar automáticamente las clases
 */
class Autoloader {
    /**
     * Directorios donde buscar las clases
     */
    private static $directories = [
        'core',
        'controllers',
        'models',
        'helpers',
        'libraries'
    ];

    /**
     * Registrar el autoloader
     */
    public static function register() {
        spl_autoload_register([__CLASS__, 'load']);
    }

    /**
     * Cargar una clase
     */
    public static function load($class) {
        $class = str_replace('\\', DIRECTORY_SEPARATOR, $class);
        $classFile = $class . '.php';
        
        // Buscar en los directorios base
        foreach (self::$directories as $directory) {
            $path = APP_PATH . '/' . $directory . '/' . $classFile;
            if (file_exists($path)) {
                require_once $path;
                return true;
            }
        }
        
        // Si no se encontró, intentar cargar con el namespace completo
        $fullPath = APP_PATH . '/' . $classFile;
        if (file_exists($fullPath)) {
            require_once $fullPath;
            return true;
        }
        
        return false;
    }
}

// Registrar el autoloader
Autoloader::register();
