<?php
/**
 * Centro Estadístico - Dashboard Centralizado
 * Vista principal del Centro Estadístico con filtros jerárquicos
 */

// Verificar permisos básicos
if (!isset($_SESSION['user_role'])) {
    $_SESSION['user_role'] = 'basico'; // Usuario público
}

$page_title = 'Centro Estadístico';
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-chart-line me-2 text-primary"></i>
                    Centro Estadístico
                </h2>
                <p class="text-muted mt-1">Visualización inteligente de datos censales</p>
            </div>
            <div>
                <a href="<?php echo base_url('dashboard/general'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-home me-1"></i>Dashboard General
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Información del Sistema -->
<div class="row mb-4">
    <div class="col-12">
        <div class="alert alert-info">
            <h6><i class="fas fa-info-circle me-2"></i>¿Cómo funciona el Centro Estadístico?</h6>
            <p class="mb-2">Este sistema utiliza un algoritmo inteligente para mostrar estadísticas según el nivel seleccionado:</p>
            <ul class="mb-0">
                <li><strong>Reino:</strong> Muestra preguntas comunes a todas las especies del reino seleccionado</li>
                <li><strong>Módulo:</strong> Muestra preguntas comunes a todas las especies del módulo seleccionado</li>
                <li><strong>Especie:</strong> Muestra todas las preguntas específicas del formulario de esa especie</li>
            </ul>
            <hr>
            <p class="mb-0"><strong>💡 Tip:</strong> Selecciona primero un Reino, luego un Módulo y finalmente una Especie para ver estadísticas cada vez más específicas.</p>
        </div>
    </div>
</div>

<!-- Filtros de Búsqueda -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-filter me-2"></i>Filtros de Visualización
                </h6>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo base_url('estadistica/index'); ?>" id="filtrosForm">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="reino" class="form-label">
                                    <i class="fas fa-globe me-1"></i>Reino Biológico
                                </label>
                                <select class="form-select" id="reino" name="reino">
                                    <option value="">Seleccionar Reino...</option>
                                    <?php foreach ($reinos as $reino): ?>
                                        <option value="<?php echo $reino['id']; ?>"
                                                <?php echo ($filtros['reino'] == $reino['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($reino['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="modulo" class="form-label">
                                    <i class="fas fa-folder me-1"></i>Módulo
                                </label>
                                <select class="form-select" id="modulo" name="modulo" <?php echo empty($modulos) ? 'disabled' : ''; ?>>
                                    <option value="">Seleccionar Módulo...</option>
                                    <?php foreach ($modulos as $modulo): ?>
                                        <option value="<?php echo $modulo['id']; ?>"
                                                <?php echo ($filtros['modulo'] == $modulo['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($modulo['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="especie" class="form-label">
                                    <i class="fas fa-leaf me-1"></i>Especie
                                </label>
                                <select class="form-select" id="especie" name="especie" <?php echo empty($especies) ? 'disabled' : ''; ?>>
                                    <option value="">Seleccionar Especie...</option>
                                    <?php foreach ($especies as $especie): ?>
                                        <option value="<?php echo $especie['id']; ?>"
                                                <?php echo ($filtros['especie'] == $especie['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($especie['nombre']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary me-2" id="btnMostrar">
                                <i class="fas fa-chart-bar me-1"></i>Mostrar Estadísticas
                            </button>
                            <a href="<?php echo base_url('estadistica/index'); ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-times me-1"></i>Limpiar Filtros
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Resultados de Estadísticas -->
<?php if ($estadisticas): ?>
<div class="row">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-success">
                    <i class="fas fa-chart-line me-2"></i><?php echo htmlspecialchars($estadisticas['titulo']); ?>
                </h6>
                <span class="badge bg-primary"><?php echo count($estadisticas['preguntas'] ?? []); ?> preguntas analizadas</span>
            </div>
            <div class="card-body">
                <?php if (isset($estadisticas['error'])): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo htmlspecialchars($estadisticas['error']); ?>
                    </div>
                <?php elseif (!empty($estadisticas['preguntas'])): ?>
                    <div class="row">
                        <?php foreach ($estadisticas['preguntas'] as $index => $item): ?>
                            <div class="col-md-6 mb-4">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <h6 class="mb-0">
                                            <i class="fas fa-question-circle text-primary me-2"></i>
                                            <?php echo htmlspecialchars($item['pregunta']['texto_pregunta']); ?>
                                        </h6>
                                        <small class="text-muted">
                                            Tipo: <?php echo htmlspecialchars($item['pregunta']['tipo_pregunta']); ?>
                                            <?php if ($estadisticas['nivel'] !== 'especie'): ?>
                                                | Nivel: <?php echo ucfirst($estadisticas['nivel']); ?>
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="chart-estadistica-<?php echo $index; ?>" width="400" height="300"></canvas>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-chart-bar fa-3x text-gray-300 mb-3"></i>
                        <h5 class="text-gray-500">No hay datos estadísticos disponibles</h5>
                        <p class="text-gray-400">No se encontraron censos realizados para los filtros seleccionados.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Funcionalidad de filtros en cascada
document.addEventListener('DOMContentLoaded', function() {
    const reinoSelect = document.getElementById('reino');
    const moduloSelect = document.getElementById('modulo');
    const especieSelect = document.getElementById('especie');
    const btnMostrar = document.getElementById('btnMostrar');

    // Cuando cambia el reino, cargar módulos
    reinoSelect.addEventListener('change', function() {
        const reinoId = this.value;
        moduloSelect.innerHTML = '<option value="">Cargando...</option>';
        especieSelect.innerHTML = '<option value="">Seleccionar Especie...</option>';
        especieSelect.disabled = true;

        if (reinoId) {
            fetch(`<?php echo base_url('api/estadistica/modulos'); ?>?reino=${reinoId}`)
                .then(response => response.json())
                .then(responseData => {
                    if (responseData.success && responseData.data) {
                        moduloSelect.innerHTML = '<option value="">Seleccionar Módulo...</option>';
                        responseData.data.forEach(modulo => {
                            const option = document.createElement('option');
                            option.value = modulo.id;
                            option.textContent = modulo.nombre;
                            moduloSelect.appendChild(option);
                        });
                        moduloSelect.disabled = false;
                    } else {
                        console.error('Respuesta inválida de la API:', responseData);
                        moduloSelect.innerHTML = '<option value="">Error en respuesta</option>';
                    }
                })
                .catch(error => {
                    console.error('Error cargando módulos:', error);
                    moduloSelect.innerHTML = '<option value="">Error al cargar</option>';
                });
        } else {
            moduloSelect.innerHTML = '<option value="">Seleccionar Módulo...</option>';
            moduloSelect.disabled = true;
        }
    });

    // Cuando cambia el módulo, cargar especies
    moduloSelect.addEventListener('change', function() {
        const moduloId = this.value;
        especieSelect.innerHTML = '<option value="">Cargando...</option>';

        if (moduloId) {
            fetch(`<?php echo base_url('api/estadistica/especies'); ?>?modulo=${moduloId}`)
                .then(response => response.json())
                .then(responseData => {
                    if (responseData.success && responseData.data) {
                        especieSelect.innerHTML = '<option value="">Seleccionar Especie...</option>';
                        responseData.data.forEach(especie => {
                            const option = document.createElement('option');
                            option.value = especie.id;
                            option.textContent = especie.nombre;
                            especieSelect.appendChild(option);
                        });
                        especieSelect.disabled = false;
                    } else {
                        console.error('Respuesta inválida de la API:', responseData);
                        especieSelect.innerHTML = '<option value="">Error en respuesta</option>';
                    }
                })
                .catch(error => {
                    console.error('Error cargando especies:', error);
                    especieSelect.innerHTML = '<option value="">Error al cargar</option>';
                });
        } else {
            especieSelect.innerHTML = '<option value="">Seleccionar Especie...</option>';
            especieSelect.disabled = true;
        }
    });

    // Actualizar estado del botón
    function actualizarBoton() {
        const tieneFiltros = reinoSelect.value || moduloSelect.value || especieSelect.value;
        btnMostrar.disabled = !tieneFiltros;
        if (tieneFiltros) {
            btnMostrar.innerHTML = '<i class="fas fa-chart-bar me-1"></i>Mostrar Estadísticas';
        } else {
            btnMostrar.innerHTML = '<i class="fas fa-chart-bar me-1"></i>Selecciona al menos un filtro';
        }
    }

    reinoSelect.addEventListener('change', actualizarBoton);
    moduloSelect.addEventListener('change', actualizarBoton);
    especieSelect.addEventListener('change', actualizarBoton);

    // Estado inicial
    actualizarBoton();

    // Crear gráficos si hay estadísticas
    <?php if ($estadisticas && !empty($estadisticas['preguntas'])): ?>
        <?php foreach ($estadisticas['preguntas'] as $index => $item): ?>
            crearGraficoEstadistica(<?php echo $index; ?>, <?php echo json_encode($item['pregunta']); ?>, <?php echo json_encode($item['datos']); ?>);
        <?php endforeach; ?>
    <?php endif; ?>
});

function crearGraficoEstadistica(index, pregunta, estadisticas) {
    const canvas = document.getElementById('chart-estadistica-' + index);
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    // Configurar datos según el tipo de pregunta
    let chartData = {};
    let chartType = 'bar';

    switch (pregunta.tipo_pregunta) {
        case 'numero':
            chartData = {
                labels: ['Mínimo', 'Promedio', 'Máximo'],
                datasets: [{
                    label: 'Valores Numéricos',
                    data: [
                        estadisticas.minimo || 0,
                        estadisticas.promedio || 0,
                        estadisticas.maximo || 0
                    ],
                    backgroundColor: 'rgba(0, 123, 255, 0.5)',
                    borderColor: 'rgba(0, 123, 255, 1)',
                    borderWidth: 1
                }]
            };
            break;

        case 'booleano':
            chartType = 'pie';
            chartData = {
                labels: ['Sí', 'No'],
                datasets: [{
                    label: 'Respuestas',
                    data: [
                        estadisticas.respuestas_positivas || 0,
                        estadisticas.respuestas_negativas || 0
                    ],
                    backgroundColor: [
                        'rgba(40, 167, 69, 0.5)',
                        'rgba(220, 53, 69, 0.5)'
                    ],
                    borderColor: [
                        'rgba(40, 167, 69, 1)',
                        'rgba(220, 53, 69, 1)'
                    ],
                    borderWidth: 1
                }]
            };
            break;

        case 'opcion_multiple':
            chartData = {
                labels: estadisticas.map(item => item.opcion),
                datasets: [{
                    label: 'Frecuencia',
                    data: estadisticas.map(item => item.conteo),
                    backgroundColor: 'rgba(255, 193, 7, 0.5)',
                    borderColor: 'rgba(255, 193, 7, 1)',
                    borderWidth: 1
                }]
            };
            break;

        case 'fecha':
            chartData = {
                labels: ['Respuestas con fecha'],
                datasets: [{
                    label: 'Conteo',
                    data: [estadisticas.total || 0],
                    backgroundColor: 'rgba(23, 162, 184, 0.5)',
                    borderColor: 'rgba(23, 162, 184, 1)',
                    borderWidth: 1
                }]
            };
            break;

        case 'texto':
            chartData = {
                labels: ['Respuestas de texto'],
                datasets: [{
                    label: 'Conteo',
                    data: [estadisticas.total || 0],
                    backgroundColor: 'rgba(108, 117, 125, 0.5)',
                    borderColor: 'rgba(108, 117, 125, 1)',
                    borderWidth: 1
                }]
            };
            break;

        default:
            chartData = {
                labels: ['Sin datos'],
                datasets: [{
                    label: 'Sin información',
                    data: [0],
                    backgroundColor: 'rgba(108, 117, 125, 0.5)',
                    borderColor: 'rgba(108, 117, 125, 1)',
                    borderWidth: 1
                }]
            };
    }

    new Chart(ctx, {
        type: chartType,
        data: chartData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: pregunta.texto_pregunta || 'Estadística'
                }
            }
        }
    });
}
</script>