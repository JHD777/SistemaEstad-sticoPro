<?php
// Verificar si el usuario está autenticado
$usuarioAutenticado = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Estadístico Pro - Plataforma de Gestión de Datos Censales</title>
    <meta name="description" content="Sistema Estadístico Pro - Plataforma avanzada para la recolección, gestión y análisis inteligente de datos censales de flora y fauna con arquitectura EAV dinámica.">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/assets/images/logo.png">

    <!-- Fuentes -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Animate.css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">

    <!-- Estilos personalizados -->
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
            --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --gradient-secondary: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --gradient-success: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }

        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: #f8f9fa;
            color: var(--dark-color);
        }

        /* Navbar elegante */
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }

        .navbar.scrolled {
            background: rgba(255, 255, 255, 0.98);
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
        }

        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
            color: var(--primary-color) !important;
        }

        .navbar-nav .nav-link {
            font-weight: 500;
            color: var(--dark-color) !important;
            transition: color 0.3s ease;
        }

        .navbar-nav .nav-link:hover {
            color: var(--secondary-color) !important;
        }

        /* Hero Section sofisticado */
        .hero-section {
            background: var(--gradient-primary);
            min-height: 100vh;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><defs><pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse"><path d="M 50 0 L 0 0 0 50" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(%23grid)"/></svg>');
            opacity: 0.3;
        }

        .hero-content {
            position: relative;
            z-index: 2;
            color: white;
        }

        .hero-content h1 {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            line-height: 1.2;
        }

        .hero-content .lead {
            font-size: 1.25rem;
            opacity: 0.9;
            margin-bottom: 2rem;
        }

        /* Botones elegantes */
        .btn {
            border-radius: 50px;
            padding: 12px 30px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            border: none;
        }

        .btn-primary {
            background: var(--gradient-secondary);
            box-shadow: 0 4px 15px rgba(245, 87, 108, 0.4);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(245, 87, 108, 0.6);
        }

        .btn-outline-light {
            border: 2px solid rgba(255, 255, 255, 0.8);
            color: white;
        }

        .btn-outline-light:hover {
            background: white;
            color: var(--primary-color);
            border-color: white;
        }

        /* Secciones con diseño moderno */
        .section {
            padding: 100px 0;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Cards modernas */
        .feature-card {
            background: white;
            border-radius: 20px;
            padding: 40px 30px;
            text-align: center;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            border: none;
            height: 100%;
        }

        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
        }

        .feature-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            font-size: 2rem;
            color: white;
            position: relative;
        }

        .feature-icon::before {
            content: '';
            position: absolute;
            inset: -2px;
            border-radius: 50%;
            background: var(--gradient-primary);
            z-index: -1;
        }

        /* Información de la empresa */
        .company-info {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 20px;
            padding: 60px 40px;
            margin: 40px 0;
        }

        .company-logo {
            width: 120px;
            height: 120px;
            background: var(--gradient-primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 2rem;
            font-size: 3rem;
            color: white;
        }

        /* Estadísticas */
        .stat-item {
            text-align: center;
            padding: 30px 20px;
        }

        .stat-number {
            font-size: 3rem;
            font-weight: 700;
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1;
        }

        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Demo cards */
        .demo-card {
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .demo-card:hover {
            transform: translateY(-5px);
        }

        .demo-header {
            background: var(--gradient-primary);
            color: white;
            padding: 20px;
            text-align: center;
        }

        /* Animaciones */
        .animate-fade-in-up {
            animation: fadeInUp 0.8s ease-out;
        }

        .animate-fade-in-up.delay-1 {
            animation-delay: 0.2s;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .hero-content h1 {
                font-size: 2.5rem;
            }

            .section {
                padding: 60px 0;
            }

            .section-title {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>

<!-- Navbar elegante -->
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="<?php echo base_url(''); ?>">
            <div class="company-logo me-3">
                <i class="fas fa-leaf"></i>
            </div>
            <span>Sistema Estadístico Pro</span>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="#inicio">Inicio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#soluciones">Soluciones</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#empresa">Empresa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#contacto">Contacto</a>
                </li>
            </ul>

            <div class="ms-3">
                <?php if (!$usuarioAutenticado): ?>
                <a href="<?php echo base_url('login'); ?>" class="btn btn-outline-primary me-2">
                    <i class="fas fa-sign-in-alt me-1"></i> Acceder
                </a>
                <a href="<?php echo base_url('registro'); ?>" class="btn btn-primary">
                    <i class="fas fa-user-plus me-1"></i> Registrarse
                </a>
                <?php else: ?>
                <a href="<?php echo base_url('dashboard'); ?>" class="btn btn-primary">
                    <i class="fas fa-tachometer-alt me-1"></i> Dashboard
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section class="hero-section" id="inicio">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="hero-content animate-fade-in-up">
                    <h1>Sistema Estadístico Pro</h1>
                    <p class="lead">
                        Plataforma avanzada para la recolección, gestión y análisis inteligente de datos censales de flora y fauna.
                        Tecnología EAV dinámica que se adapta a cualquier tipo de formulario sin modificar la estructura de datos.
                    </p>
                    <div class="d-flex gap-3 flex-wrap">
                        <?php if (!$usuarioAutenticado): ?>
                        <a href="<?php echo base_url('registro'); ?>" class="btn btn-primary btn-lg">
                            <i class="fas fa-rocket me-2"></i>Comenzar Gratis
                        </a>
                        <a href="#soluciones" class="btn btn-outline-light btn-lg">
                            <i class="fas fa-eye me-2"></i>Ver Soluciones
                        </a>
                        <?php else: ?>
                        <a href="<?php echo base_url('dashboard'); ?>" class="btn btn-primary btn-lg">
                            <i class="fas fa-tachometer-alt me-2"></i>Ir al Dashboard
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="animate-fade-in-up delay-1">
                    <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
                         alt="Tecnología ambiental" class="img-fluid rounded-3 shadow-lg">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Información de la Empresa -->
<section id="empresa" class="section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h2 class="section-title">Sistema Estadístico Pro</h2>
                <div class="company-info">
                    <div class="company-logo">
                        <i class="fas fa-database"></i>
                    </div>
                    <h3>Sistema Estadístico Pro</h3>
                    <p class="lead">Plataforma avanzada para gestión de datos censales con arquitectura EAV</p>
                    <p>
                        Sistema especializado en la recolección y análisis de datos ambientales con tecnología de vanguardia.
                        Nuestro sistema utiliza arquitectura EAV (Entidad-Atributo-Valor) que permite manejar formularios
                        dinámicos sin necesidad de modificar la estructura de la base de datos, adaptándose a cualquier
                        tipo de especie y requisito de investigación.
                    </p>
                    <div class="row mt-4">
                        <div class="col-md-4">
                            <div class="stat-item">
                                <div class="stat-number">∞</div>
                                <div class="stat-label">Formularios Dinámicos</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="stat-item">
                                <div class="stat-number">4</div>
                                <div class="stat-label">Niveles de Usuario</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="stat-item">
                                <div class="stat-number">EAV</div>
                                <div class="stat-label">Arquitectura Flexible</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <img src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                     alt="Equipo de investigación" class="img-fluid rounded-3 shadow-lg">
            </div>
        </div>
    </div>
</section>

<!-- Soluciones Destacadas -->
<section id="soluciones" class="section bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Soluciones Tecnológicas Avanzadas</h2>
            <p class="lead">Descubra cómo nuestra plataforma revoluciona la gestión de datos ambientales</p>
        </div>

        <div class="row g-4">
            <div class="col-lg-4">
                <div class="feature-card">
                    <div class="feature-icon" style="background: var(--gradient-primary);">
                        <i class="fas fa-sitemap"></i>
                    </div>
                    <h4>Jerarquía Taxonómica</h4>
                    <p>Estructura jerárquica completa (Reino → Módulo → Especie) para organización eficiente de datos biológicos.</p>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="feature-card">
                    <div class="feature-icon" style="background: var(--gradient-secondary);">
                        <i class="fas fa-network-wired"></i>
                    </div>
                    <h4>Arquitectura EAV</h4>
                    <p>Sistema flexible que se adapta dinámicamente a cualquier tipo de formulario sin necesidad de modificar la estructura de datos.</p>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="feature-card">
                    <div class="feature-icon" style="background: var(--gradient-success);">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h4>Seguridad Total</h4>
                    <p>Protección avanzada con encriptación de datos, autenticación multifactor y cumplimiento de estándares internacionales.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Acceso de Demostración -->
<section class="section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Experimente Nuestras Soluciones</h2>
            <p class="lead">Acceda a demostraciones personalizadas según su nivel de usuario</p>
        </div>

        <div class="row g-4 justify-content-center">
            <div class="col-lg-4">
                <div class="demo-card">
                    <div class="demo-header">
                        <h5 class="mb-0">Usuario Básico</h5>
                    </div>
                    <div class="card-body text-center p-4">
                        <p class="mb-4">Visualización de datos y análisis generales</p>
                        <a href="<?php echo base_url('login?demo=basico'); ?>" class="btn btn-primary">
                            <i class="fas fa-eye me-2"></i>Ver Demo
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="demo-card">
                    <div class="demo-header">
                        <h5 class="mb-0">Administrador</h5>
                    </div>
                    <div class="card-body text-center p-4">
                        <p class="mb-4">Gestión completa de formularios y especies</p>
                        <a href="<?php echo base_url('login?demo=admin'); ?>" class="btn btn-success">
                            <i class="fas fa-cog me-2"></i>Administrar
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="demo-card">
                    <div class="demo-header">
                        <h5 class="mb-0">Administrador Supremo</h5>
                    </div>
                    <div class="card-body text-center p-4">
                        <p class="mb-4">Control total del sistema y usuarios</p>
                        <a href="<?php echo base_url('login?demo=supremo'); ?>" class="btn btn-warning">
                            <i class="fas fa-crown me-2"></i>Control Total
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer elegante -->
<footer class="bg-dark text-white py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="company-logo mb-3">
                    <i class="fas fa-leaf"></i>
                </div>
                <h5>Sistema Estadístico Pro</h5>
                <p>Plataforma avanzada para gestión de datos censales con arquitectura EAV dinámica.</p>
                <div class="d-flex gap-3">
                    <a href="#" class="text-white opacity-75"><i class="fab fa-facebook fa-lg"></i></a>
                    <a href="#" class="text-white opacity-75"><i class="fab fa-twitter fa-lg"></i></a>
                    <a href="#" class="text-white opacity-75"><i class="fab fa-linkedin fa-lg"></i></a>
                    <a href="#" class="text-white opacity-75"><i class="fab fa-instagram fa-lg"></i></a>
                </div>
            </div>

            <div class="col-lg-2">
                <h6 class="mb-3">Producto</h6>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white opacity-75 text-decoration-none">Características</a></li>
                    <li><a href="#" class="text-white opacity-75 text-decoration-none">Precios</a></li>
                    <li><a href="#" class="text-white opacity-75 text-decoration-none">API</a></li>
                    <li><a href="#" class="text-white opacity-75 text-decoration-none">Documentación</a></li>
                </ul>
            </div>

            <div class="col-lg-2">
                <h6 class="mb-3">Empresa</h6>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white opacity-75 text-decoration-none">Sobre Nosotros</a></li>
                    <li><a href="#" class="text-white opacity-75 text-decoration-none">Equipo</a></li>
                    <li><a href="#" class="text-white opacity-75 text-decoration-none">Carreras</a></li>
                    <li><a href="#" class="text-white opacity-75 text-decoration-none">Contacto</a></li>
                </ul>
            </div>

            <div class="col-lg-4">
                <h6 class="mb-3">Contacto</h6>
                <p><i class="fas fa-envelope me-2"></i>info@sistema-estadistico-pro.com</p>
                <p><i class="fas fa-phone me-2"></i>+1 (555) 123-4567</p>
                <p><i class="fas fa-map-marker-alt me-2"></i>Sistema Web</p>
            </div>
        </div>

        <hr class="my-4">

        <div class="row align-items-center">
            <div class="col-md-6">
                <p class="mb-0">&copy; 2024 Sistema Estadístico Pro. Todos los derechos reservados.</p>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="#" class="text-white opacity-75 text-decoration-none me-3">Política de Privacidad</a>
                <a href="#" class="text-white opacity-75 text-decoration-none">Términos de Servicio</a>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Script personalizado -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Navbar scroll effect
    const navbar = document.querySelector('.navbar');

    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    // Smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Animation on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in-up');
            }
        });
    }, observerOptions);

    document.querySelectorAll('.feature-card, .company-info, .demo-card').forEach(el => {
        observer.observe(el);
    });
});
</script>

</body>
</html>