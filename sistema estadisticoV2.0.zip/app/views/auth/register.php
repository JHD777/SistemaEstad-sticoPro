<?php
/**
 * Sistema Estadístico Pro - Página de Registro Moderna
 * Diseño moderno que coincide con la página principal
 */

// Incluir funciones auxiliares básicas
require_once __DIR__ . '/../../../config/app.php';

// Definir constantes básicas si no están disponibles
if (!defined('APP_VERSION')) {
    define('APP_VERSION', '2.0.0');
}

// Función auxiliar para obtener URL base (por si no está disponible)
if (!function_exists('base_url')) {
    function base_url($path = '') {
        $base = APP_URL ?? 'http://localhost/';
        return rtrim($base, '/') . '/' . ltrim($path, '/');
    }
}

// Función auxiliar para obtener URL de assets
if (!function_exists('asset_url')) {
    function asset_url($path = '') {
        return base_url('assets/' . ltrim($path, '/'));
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Cuenta - Sistema Estadístico Pro</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-color: #6366f1;
            --secondary-color: #64748b;
            --success-color: #10b981;
            --info-color: #06b6d4;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --light-color: #f8f9fa;
            --dark-color: #1e293b;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
        }

        .register-container {
            background: rgba(255, 255, 255, 0.98);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            max-width: 500px;
            width: 100%;
            backdrop-filter: blur(10px);
        }

        .register-header {
            background: linear-gradient(135deg, var(--success-color) 0%, #059669 100%);
            color: white;
            padding: 2.5rem 2rem;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .register-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29-22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%23ffffff' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E");
            opacity: 0.3;
        }

        .register-header .logo-icon {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            width: 70px;
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
            font-size: 1.8rem;
            backdrop-filter: blur(10px);
        }

        .register-header h1 {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 2;
        }

        .register-header p {
            font-size: 1rem;
            opacity: 0.9;
            margin-bottom: 0;
            position: relative;
            z-index: 2;
        }

        .register-body {
            padding: 2.5rem 2rem;
        }

        .form-floating {
            margin-bottom: 1.25rem;
        }

        .form-control {
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            padding: 1rem 1.25rem;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--success-color);
            box-shadow: 0 0 0 0.2rem rgba(16, 185, 129, 0.1);
            transform: translateY(-2px);
        }

        .form-floating label {
            padding: 1rem 1.25rem;
            font-weight: 500;
            color: #64748b;
        }

        .password-strength {
            margin-top: 0.5rem;
            font-size: 0.875rem;
        }

        .password-strength.weak { color: var(--danger-color); }
        .password-strength.medium { color: var(--warning-color); }
        .password-strength.strong { color: var(--success-color); }

        .btn-register {
            background: linear-gradient(135deg, var(--success-color) 0%, #059669 100%);
            border: none;
            border-radius: 12px;
            padding: 1rem 2rem;
            font-size: 1.1rem;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .btn-register::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transition: left 0.5s;
        }

        .btn-register:hover::before {
            left: 100%;
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(16, 185, 129, 0.3);
        }

        .register-footer {
            text-align: center;
            padding: 2rem;
            background: #f8f9fa;
            border-top: 1px solid #e2e8f0;
        }

        .register-footer a {
            color: var(--success-color);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .register-footer a:hover {
            color: #059669;
            text-decoration: underline;
        }

        .back-to-home {
            position: absolute;
            top: 1rem;
            left: 1rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }

        .back-to-home:hover {
            color: white;
        }

        .alert {
            border-radius: 12px;
            border: none;
            margin-bottom: 1.5rem;
        }

        .terms-check {
            background: #f8f9fa;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 1rem;
            margin: 1rem 0;
        }

        .terms-check .form-check-input:checked {
            background-color: var(--success-color);
            border-color: var(--success-color);
        }

        @media (max-width: 768px) {
            .register-container {
                margin: 10px;
                max-width: none;
            }

            .register-header {
                padding: 2rem 1.5rem;
            }

            .register-header h1 {
                font-size: 1.8rem;
            }

            .register-body {
                padding: 2rem 1.5rem;
            }
        }

        /* Animaciones */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fade-in {
            animation: fadeInUp 0.6s ease-out;
        }
    </style>
</head>
<body>
    <div class="register-container animate-fade-in">
        <!-- Header -->
        <div class="register-header">
            <a href="<?php echo base_url(); ?>" class="back-to-home">
                <i class="fas fa-arrow-left me-1"></i>Volver al inicio
            </a>

            <div class="logo-icon">
                <i class="fas fa-user-plus"></i>
            </div>

            <h1>Crear Cuenta</h1>
            <p>Únete al Sistema Estadístico Pro</p>
        </div>

        <!-- Body -->
        <div class="register-body">
            <?php if (isset($flash_message)) : ?>
                <div class="alert alert-<?php echo $flash_type ?? 'info'; ?> alert-dismissible fade show" role="alert">
                    <i class="fas fa-<?php echo $flash_type === 'success' ? 'check-circle' : ($flash_type === 'error' ? 'exclamation-triangle' : 'info-circle'); ?> me-2"></i>
                    <?php echo htmlspecialchars($flash_message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo base_url('register'); ?>" id="registerForm">
                <div class="form-floating">
                    <input type="text" class="form-control" id="nombre" name="nombre"
                           placeholder="Tu nombre completo" required
                           value="<?php echo htmlspecialchars($_POST['nombre'] ?? ''); ?>">
                    <label for="nombre">
                        <i class="fas fa-user me-2"></i>Nombre completo
                    </label>
                </div>

                <div class="form-floating">
                    <input type="email" class="form-control" id="email" name="email"
                           placeholder="correo@ejemplo.com" required
                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    <label for="email">
                        <i class="fas fa-envelope me-2"></i>Correo electrónico
                    </label>
                </div>

                <div class="form-floating">
                    <input type="password" class="form-control" id="password" name="password"
                           placeholder="Contraseña" required>
                    <label for="password">
                        <i class="fas fa-lock me-2"></i>Contraseña
                    </label>
                    <div id="passwordStrength" class="password-strength" style="display: none;"></div>
                </div>

                <div class="form-floating">
                    <input type="password" class="form-control" id="confirmPassword" name="confirmPassword"
                           placeholder="Confirmar contraseña" required>
                    <label for="confirmPassword">
                        <i class="fas fa-lock me-2"></i>Confirmar contraseña
                    </label>
                </div>

                <!-- Términos y condiciones -->
                <div class="terms-check">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="aceptarTerminos" name="aceptarTerminos" required>
                        <label class="form-check-label" for="aceptarTerminos">
                            Acepto los <a href="<?php echo base_url('terminos'); ?>" target="_blank">términos y condiciones</a>
                            y la <a href="<?php echo base_url('privacidad'); ?>" target="_blank">política de privacidad</a>
                        </label>
                    </div>
                </div>

                <button type="submit" class="btn btn-register" id="btnRegister">
                    <i class="fas fa-user-plus me-2"></i>Crear cuenta
                </button>
            </form>
        </div>

        <!-- Footer -->
        <div class="register-footer">
            <p class="mb-2">¿Ya tienes una cuenta?</p>
            <a href="<?php echo base_url('login'); ?>" class="btn btn-outline-success">
                <i class="fas fa-sign-in-alt me-2"></i>Iniciar sesión
            </a>
        </div>
    </div>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const passwordInput = document.getElementById('password');
            const confirmPasswordInput = document.getElementById('confirmPassword');
            const passwordStrength = document.getElementById('passwordStrength');

            // Validación de contraseña en tiempo real
            passwordInput.addEventListener('input', function() {
                const password = this.value;
                const strength = checkPasswordStrength(password);

                if (password.length > 0) {
                    passwordStrength.style.display = 'block';
                    passwordStrength.className = 'password-strength ' + strength.class;
                    passwordStrength.textContent = strength.text;
                } else {
                    passwordStrength.style.display = 'none';
                }

                validatePasswordMatch();
            });

            confirmPasswordInput.addEventListener('input', validatePasswordMatch);

            function checkPasswordStrength(password) {
                let score = 0;

                if (password.length >= 8) score++;
                if (/[a-z]/.test(password)) score++;
                if (/[A-Z]/.test(password)) score++;
                if (/[0-9]/.test(password)) score++;
                if (/[^A-Za-z0-9]/.test(password)) score++;

                if (score < 3) {
                    return { class: 'weak', text: 'Débil - Use mayúsculas, minúsculas, números y símbolos' };
                } else if (score < 4) {
                    return { class: 'medium', text: 'Media - Agregue más variedad de caracteres' };
                } else {
                    return { class: 'strong', text: 'Fuerte - Excelente contraseña' };
                }
            }

            function validatePasswordMatch() {
                const password = passwordInput.value;
                const confirmPassword = confirmPasswordInput.value;

                if (confirmPassword.length > 0) {
                    if (password !== confirmPassword) {
                        confirmPasswordInput.setCustomValidity('Las contraseñas no coinciden');
                        confirmPasswordInput.classList.add('is-invalid');
                    } else {
                        confirmPasswordInput.setCustomValidity('');
                        confirmPasswordInput.classList.remove('is-invalid');
                        confirmPasswordInput.classList.add('is-valid');
                    }
                }
            }

            // Form validation
            const registerForm = document.getElementById('registerForm');
            registerForm.addEventListener('submit', function(e) {
                const nombre = document.getElementById('nombre').value.trim();
                const email = document.getElementById('email').value.trim();
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirmPassword').value;
                const aceptarTerminos = document.getElementById('aceptarTerminos').checked;

                // Validaciones básicas
                if (!nombre || !email || !password || !confirmPassword) {
                    e.preventDefault();
                    alert('Por favor, completa todos los campos requeridos.');
                    return false;
                }

                if (password !== confirmPassword) {
                    e.preventDefault();
                    alert('Las contraseñas no coinciden.');
                    return false;
                }

                if (password.length < 8) {
                    e.preventDefault();
                    alert('La contraseña debe tener al menos 8 caracteres.');
                    return false;
                }

                if (!aceptarTerminos) {
                    e.preventDefault();
                    alert('Debes aceptar los términos y condiciones para continuar.');
                    return false;
                }

                // Show loading state
                const submitBtn = registerForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Creando cuenta...';
                submitBtn.disabled = true;

                // Re-enable after 5 seconds (in case of error)
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 5000);
            });

            // Enter key support
            document.addEventListener('keypress', function(e) {
                if (e.key === 'Enter' && document.activeElement.tagName !== 'BUTTON') {
                    registerForm.dispatchEvent(new Event('submit'));
                }
            });
        });
    </script>
</body>
</html>