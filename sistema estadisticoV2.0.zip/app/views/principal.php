<?php
/**
 * Sistema Estadístico Pro - Página Principal Pública
 * Página de presentación del sistema para usuarios no autenticados
 */

// Incluir funciones auxiliares básicas
require_once __DIR__ . '/../../config/app.php';

// Definir constantes básicas si no están disponibles
if (!defined('APP_VERSION')) {
    define('APP_VERSION', '2.0.0');
}

// Función auxiliar para obtener URL base (por si no está disponible)
if (!function_exists('base_url')) {
    function base_url($path = '') {
        $base = APP_URL ?? 'http://localhost/';
        return rtrim($base, '/') . '/' . ltrim($path, '/');
    }
}

// Esta página no usa el layout estándar ya que es pública
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Estadístico Pro - Plataforma Avanzada</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #6c757d;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --light-color: #f8f9fa;
            --dark-color: #212529;
        }

        body {
            font-family: 'Inter', sans-serif;
            line-height: 1.6;
        }

        .hero-section {
            background: linear-gradient(135deg, var(--primary-color) 0%, #0056b3 100%);
            color: white;
            padding: 100px 0;
            position: relative;
            overflow: hidden;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.05)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.08)"/><circle cx="10" cy="60" r="0.5" fill="rgba(255,255,255,0.08)"/><circle cx="90" cy="40" r="0.5" fill="rgba(255,255,255,0.08)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            opacity: 0.3;
        }

        .hero-content {
            position: relative;
            z-index: 2;
        }

        .feature-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
            margin-bottom: 30px;
        }

        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
        }

        .feature-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 24px;
        }

        .demo-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            transition: transform 0.3s ease;
            cursor: pointer;
        }

        .demo-card:hover {
            transform: scale(1.05);
            color: white;
            text-decoration: none;
        }

        .demo-card.basico { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .demo-card.registrado { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .demo-card.admin { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
        .demo-card.supremo { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); }

        .stats-counter {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-color);
        }

        .section-padding {
            padding: 80px 0;
        }

        .navbar-custom {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <div class="logo-icon me-2">
                    <i class="fas fa-atom fa-lg text-primary"></i>
                </div>
                <span class="fw-bold fs-5">Sistema Estadístico Pro</span>
            </a>

            <div class="d-flex">
                <a href="<?php echo base_url('acerca'); ?>" class="btn btn-outline-primary me-2">Acerca de</a>
                <a href="<?php echo base_url('contacto'); ?>" class="btn btn-outline-secondary me-2">Contacto</a>
                <a href="<?php echo base_url('login'); ?>" class="btn btn-primary">Iniciar Sesión</a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="hero-content">
                        <h1 class="display-4 fw-bold mb-4">
                            Sistema Estadístico Pro
                        </h1>
                        <p class="lead mb-4">
                            Plataforma avanzada para la gestión y análisis de datos estadísticos de especies biológicas.
                            Tecnología de vanguardia para investigación científica y conservación ambiental.
                        </p>
                        <div class="d-flex gap-3">
                            <a href="<?php echo base_url('dashboard/publico'); ?>" class="btn btn-light btn-lg">
                                <i class="fas fa-chart-bar me-2"></i>Ver Datos Estadísticos
                            </a>
                            <a href="<?php echo base_url('register'); ?>" class="btn btn-outline-light btn-lg">
                                <i class="fas fa-user-plus me-2"></i>Crear Cuenta
                            </a>
                            <a href="<?php echo base_url('login'); ?>" class="btn btn-outline-light btn-lg">
                                <i class="fas fa-sign-in-alt me-2"></i>Iniciar Sesión
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="text-center">
                        <img src="<?php echo base_url('assets/images/data-visualization.svg'); ?>"
                             alt="Data Visualization"
                             class="img-fluid"
                             onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                        <div style="display: none; text-align: center; color: rgba(255,255,255,0.8);">
                            <i class="fas fa-chart-line fa-4x mb-3"></i>
                            <h4>Sistema Estadístico Pro</h4>
                            <p>Plataforma avanzada de análisis de datos</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Características Principales -->
    <section class="section-padding bg-light">
        <div class="container">
            <div class="row text-center mb-5">
                <div class="col-12">
                    <h2 class="display-5 fw-bold mb-3">Características Destacadas</h2>
                    <p class="lead text-muted">Tecnología avanzada para el análisis estadístico profesional</p>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-3 col-md-6">
                    <div class="feature-card text-center">
                        <div class="feature-icon bg-primary bg-opacity-10 text-primary">
                            <i class="fas fa-sitemap"></i>
                        </div>
                        <h5>Arquitectura Jerárquica</h5>
                        <p class="text-muted">Organización taxonómica completa: Reino → Módulo → Especie con relaciones inteligentes</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="feature-card text-center">
                        <div class="feature-icon bg-success bg-opacity-10 text-success">
                            <i class="fas fa-database"></i>
                        </div>
                        <h5>Modelo EAV</h5>
                        <p class="text-muted">Entity-Attribute-Value para formularios dinámicos completamente personalizables</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="feature-card text-center">
                        <div class="feature-icon bg-info bg-opacity-10 text-info">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h5>Sistema RBAC</h5>
                        <p class="text-muted">Control de acceso basado en roles con 4 niveles de permisos granulares</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="feature-card text-center">
                        <div class="feature-icon bg-warning bg-opacity-10 text-warning">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h5>Análisis Avanzado</h5>
                        <p class="text-muted">Estadísticas en tiempo real y análisis predictivo para toma de decisiones</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Estadísticas del Sistema -->
    <section class="section-padding">
        <div class="container">
            <div class="row text-center mb-5">
                <div class="col-12">
                    <h2 class="display-5 fw-bold mb-3">Sistema en Números</h2>
                    <p class="lead text-muted">Capacidades y rendimiento del sistema</p>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-3 col-md-6">
                    <div class="text-center">
                        <div class="stats-counter">4</div>
                        <h6 class="text-muted">Niveles de Usuario</h6>
                        <p class="small">Desde básico hasta administrador supremo</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="text-center">
                        <div class="stats-counter">∞</div>
                        <h6 class="text-muted">Formularios Dinámicos</h6>
                        <p class="small">Personalización ilimitada de estructuras de datos</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="text-center">
                        <div class="stats-counter">3</div>
                        <h6 class="text-muted">Niveles Taxonómicos</h6>
                        <p class="small">Reino, Módulo y Especie completamente organizados</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="text-center">
                        <div class="stats-counter">24/7</div>
                        <h6 class="text-muted">Disponibilidad</h6>
                        <p class="small">Sistema siempre disponible para investigación</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Demostraciones por Nivel -->
    <section class="section-padding bg-light">
        <div class="container">
            <div class="row text-center mb-5">
                <div class="col-12">
                    <h2 class="display-5 fw-bold mb-3">Explora por Nivel de Usuario</h2>
                    <p class="lead text-muted">Haz clic en cada nivel para ver sus capacidades específicas</p>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo base_url('login'); ?>?demo=basico" class="text-decoration-none">
                        <div class="demo-card basico">
                            <i class="fas fa-user fa-2x mb-3"></i>
                            <h5>Usuario Básico</h5>
                            <p class="mb-0">Acceso limitado a funciones esenciales y navegación básica del sistema</p>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo base_url('login'); ?>?demo=registrado" class="text-decoration-none">
                        <div class="demo-card registrado">
                            <i class="fas fa-user-check fa-2x mb-3"></i>
                            <h5>Usuario Registrado</h5>
                            <p class="mb-0">Acceso completo a formularios aprobados y funciones de exportación</p>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo base_url('login'); ?>?demo=admin" class="text-decoration-none">
                        <div class="demo-card admin">
                            <i class="fas fa-user-cog fa-2x mb-3"></i>
                            <h5>Administrador</h5>
                            <p class="mb-0">Gestión completa de especies, formularios y análisis avanzado</p>
                        </div>
                    </a>
                </div>

                <div class="col-lg-3 col-md-6">
                    <a href="<?php echo base_url('login'); ?>?demo=supremo" class="text-decoration-none">
                        <div class="demo-card supremo">
                            <i class="fas fa-crown fa-2x mb-3"></i>
                            <h5>Administrador Supremo</h5>
                            <p class="mb-0">Control total del sistema incluyendo gestión de usuarios</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Tecnologías -->
    <section class="section-padding">
        <div class="container">
            <div class="row text-center mb-5">
                <div class="col-12">
                    <h2 class="display-5 fw-bold mb-3">Tecnologías de Vanguardia</h2>
                    <p class="lead text-muted">Construido con las mejores tecnologías disponibles</p>
                </div>
            </div>

            <div class="row g-4 justify-content-center">
                <div class="col-lg-2 col-md-4 col-6">
                    <div class="text-center">
                        <i class="fab fa-php fa-3x text-primary mb-3"></i>
                        <h6>PHP 8+</h6>
                        <small class="text-muted">Lenguaje principal</small>
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-6">
                    <div class="text-center">
                        <i class="fas fa-database fa-3x text-success mb-3"></i>
                        <h6>MySQL</h6>
                        <small class="text-muted">Base de datos</small>
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-6">
                    <div class="text-center">
                        <i class="fab fa-bootstrap fa-3x text-info mb-3"></i>
                        <h6>Bootstrap 5</h6>
                        <small class="text-muted">Framework CSS</small>
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-6">
                    <div class="text-center">
                        <i class="fas fa-chart-bar fa-3x text-warning mb-3"></i>
                        <h6>Chart.js</h6>
                        <small class="text-muted">Gráficos dinámicos</small>
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-6">
                    <div class="text-center">
                        <i class="fas fa-code fa-3x text-secondary mb-3"></i>
                        <h6>MVC Pattern</h6>
                        <small class="text-muted">Arquitectura sólida</small>
                    </div>
                </div>

                <div class="col-lg-2 col-md-4 col-6">
                    <div class="text-center">
                        <i class="fas fa-shield-alt fa-3x text-danger mb-3"></i>
                        <h6>Seguridad</h6>
                        <small class="text-muted">Protección avanzada</small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Llamada a Acción Final -->
    <section class="section-padding bg-primary text-white">
        <div class="container text-center">
            <h2 class="display-5 fw-bold mb-4">¿Listo para comenzar?</h2>
            <p class="lead mb-4">Únete a la plataforma líder en análisis estadístico de especies biológicas</p>
            <div class="d-flex gap-3 justify-content-center">
                <a href="<?php echo base_url('register'); ?>" class="btn btn-light btn-lg">
                    <i class="fas fa-rocket me-2"></i>Comenzar Ahora
                </a>
                <a href="<?php echo base_url('acerca'); ?>" class="btn btn-outline-light btn-lg">
                    <i class="fas fa-info-circle me-2"></i>Saber Más
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h6 class="text-light">Sistema Estadístico Pro</h6>
                    <p class="text-light opacity-75 mb-0">
                        Plataforma avanzada para la gestión y análisis de datos estadísticos de especies biológicas.
                    </p>
                </div>

                <div class="col-md-3">
                    <h6 class="text-light">Enlaces</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo base_url('acerca'); ?>" class="text-light opacity-75 text-decoration-none">Acerca de</a></li>
                        <li><a href="<?php echo base_url('contacto'); ?>" class="text-light opacity-75 text-decoration-none">Contacto</a></li>
                        <li><a href="<?php echo base_url('terminos'); ?>" class="text-light opacity-75 text-decoration-none">Términos</a></li>
                        <li><a href="<?php echo base_url('privacidad'); ?>" class="text-light opacity-75 text-decoration-none">Privacidad</a></li>
                    </ul>
                </div>

                <div class="col-md-3">
                    <h6 class="text-light">Contacto</h6>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-envelope me-2"></i>soporte@sistema-estadistico-pro.com</li>
                        <li><i class="fas fa-phone me-2"></i>+591 123 4567</li>
                        <li><i class="fas fa-map-marker-alt me-2"></i>La Paz, Bolivia</li>
                    </ul>
                </div>
            </div>

            <hr class="my-3 opacity-25">

            <div class="row">
                <div class="col-md-6">
                    <p class="text-light opacity-75 mb-0">
                        &copy; <?php echo date('Y'); ?> Sistema Estadístico Pro. Todos los derechos reservados.
                    </p>
                </div>

                <div class="col-md-6 text-md-end">
                    <small class="text-light opacity-75">
                        Versión <?php echo APP_VERSION ?? '2.0.0'; ?>
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Smooth scrolling para enlaces internos
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Animación de contadores
        function animateCounters() {
            const counters = document.querySelectorAll('.stats-counter');

            counters.forEach(counter => {
                const target = parseInt(counter.textContent);
                const duration = 2000;
                const increment = target / (duration / 16);
                let current = 0;

                const timer = setInterval(() => {
                    current += increment;
                    if (current >= target) {
                        counter.textContent = target;
                        clearInterval(timer);
                    } else {
                        counter.textContent = Math.floor(current);
                    }
                }, 16);
            });
        }

        // Ejecutar animación cuando los contadores estén visibles
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounters();
                    observer.unobserve(entry.target);
                }
            });
        });

        document.querySelectorAll('.stats-counter').forEach(counter => {
            observer.observe(counter);
        });
    </script>
</body>
</html>