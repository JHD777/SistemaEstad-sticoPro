<?php
/**
 * Sistema Estadístico Pro - Listar Especies
 * Vista para mostrar la jerarquía completa de especies
 */

// Verificar permisos
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'registrado', 'supremo'])) {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-sitemap me-2 text-primary"></i>
                    Gestión de Especies
                </h2>
                <p class="text-muted mt-1">Jerarquía taxonómica del sistema</p>
            </div>
            <div>
                <a href="<?php echo base_url('especies/crear'); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i>Crear Nuevo Elemento
                </a>
            </div>
        </div>

        <!-- Estadísticas -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-folder fa-2x mb-2"></i>
                        <h4><?php echo $estadisticas['modulos'] ?? 0; ?></h4>
                        <small>Módulos</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-leaf fa-2x mb-2"></i>
                        <h4><?php echo $estadisticas['especies'] ?? 0; ?></h4>
                        <small>Especies</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-secondary text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-chart-bar fa-2x mb-2"></i>
                        <h4><?php echo $estadisticas['total'] ?? 0; ?></h4>
                        <small>Total Elementos</small>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Modal para eliminar especie -->
        <div class="modal fade" id="eliminarEspecieModal" tabindex="-1" aria-labelledby="eliminarEspecieModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title" id="eliminarEspecieModalLabel">
                            <i class="fas fa-exclamation-triangle me-2"></i>Eliminar Especie
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST" action="<?php echo base_url('especies/eliminar'); ?>" id="eliminarEspecieForm">
                        <div class="modal-body">
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <strong>¡ATENCIÓN!</strong> Esta acción no se puede deshacer.
                            </div>

                            <p>¿Está seguro de que desea eliminar la especie <strong id="especieNombreEliminar"></strong>?</p>

                            <div id="especieInfoEliminar" class="mb-3">
                                <!-- Información de la especie se cargará aquí -->
                            </div>

                            <div class="alert alert-warning">
                                <i class="fas fa-info-circle me-2"></i>
                                <strong>Nota:</strong> Solo puede eliminar especies que no tengan formularios asociados.
                            </div>

                            <div class="mb-3">
                                <label for="codigoConfirmacionEspecie" class="form-label">
                                    <i class="fas fa-key me-1"></i>Código de Confirmación *
                                </label>
                                <input type="text" class="form-control" id="codigoConfirmacionEspecie" name="codigo_confirmacion" required>
                                <div class="form-text">
                                    Ingrese el siguiente código para confirmar: <strong id="codigoMostrarEspecie"></strong>
                                </div>
                            </div>

                            <input type="hidden" id="especieIdEliminar" name="especie_id">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-times me-1"></i>Cancelar
                            </button>
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-trash me-1"></i>Eliminar Especie
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal para eliminar módulo -->
        <div class="modal fade" id="eliminarModuloModal" tabindex="-1" aria-labelledby="eliminarModuloModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title" id="eliminarModuloModalLabel">
                            <i class="fas fa-exclamation-triangle me-2"></i>Eliminar Módulo
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST" action="<?php echo base_url('especies/eliminar-modulo'); ?>" id="eliminarModuloForm">
                        <div class="modal-body">
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <strong>¡ATENCIÓN!</strong> Esta acción no se puede deshacer.
                            </div>
        
                            <p>¿Está seguro de que desea eliminar el módulo <strong id="moduloNombreEliminar"></strong>?</p>
        
                            <div id="moduloInfoEliminar" class="mb-3">
                                <!-- Información del módulo se cargará aquí -->
                            </div>
        
                            <div class="alert alert-warning">
                                <i class="fas fa-info-circle me-2"></i>
                                <strong>Nota:</strong> Solo puede eliminar módulos que no tengan censos realizados.
                            </div>
        
                            <div class="mb-3">
                                <label for="codigoConfirmacion" class="form-label">
                                    <i class="fas fa-key me-1"></i>Código de Confirmación *
                                </label>
                                <input type="text" class="form-control" id="codigoConfirmacion" name="codigo_confirmacion" required>
                                <div class="form-text">
                                    Ingrese el siguiente código para confirmar: <strong id="codigoMostrar"></strong>
                                </div>
                            </div>
        
                            <input type="hidden" id="moduloIdEliminar" name="modulo_id">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-times me-1"></i>Cancelar
                            </button>
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-trash me-1"></i>Eliminar Módulo
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <script>
        // Función para eliminar especie
        function eliminarEspecie(especieId, especieNombre) {
            // Verificar que tenga permisos
            if (!['admin', 'supremo'].includes('<?php echo $_SESSION['user_role'] ?? 'basico'; ?>')) {
                alert('No tiene permisos para eliminar especies.');
                return;
            }

            // Generar código de confirmación
            const codigoConfirmacion = Math.random().toString(36).substring(2, 8).toUpperCase();

            // Mostrar información básica inicialmente
            document.getElementById('especieInfoEliminar').innerHTML = `
                <div class="text-center">
                    <div class="spinner-border spinner-border-sm" role="status">
                        <span class="visually-hidden">Cargando...</span>
                    </div>
                    <small class="text-muted d-block mt-1">Cargando información de la especie...</small>
                </div>
            `;

            // Cargar información de la especie
            fetch(`${window.appConfig.baseUrl}api/especies/ver/${especieId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const especie = data.data.especie;
                        const hijos = data.data.hijos;
                        const tieneFormularios = data.data.tiene_formularios;

                        let infoHtml = `
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>Sub-especies:</strong> ${hijos.length}
                                </div>
                                <div class="col-md-6">
                                    <strong>Formularios asociados:</strong> ${tieneFormularios ? 'Sí' : 'No'}
                                </div>
                            </div>
                        `;

                        if (hijos.length > 0) {
                            infoHtml += `
                                <div class="mt-2">
                                    <strong>Sub-especies:</strong>
                                    <div class="small text-muted mt-1">
                                        ${hijos.map(h => h.nombre).join(', ')}
                                    </div>
                                </div>
                            `;
                        }

                        document.getElementById('especieInfoEliminar').innerHTML = infoHtml;
                    } else {
                        document.getElementById('especieInfoEliminar').innerHTML = `
                            <div class="alert alert-warning">
                                <small>No se pudo cargar la información de la especie. Puede continuar con la eliminación.</small>
                            </div>
                        `;
                    }
                })
                .catch(error => {
                    console.error('Error cargando información de la especie:', error);
                    document.getElementById('especieInfoEliminar').innerHTML = `
                        <div class="alert alert-warning">
                            <small>Error al cargar información. Puede continuar con la eliminación.</small>
                        </div>
                    `;
                });

            // Configurar modal
            document.getElementById('especieNombreEliminar').textContent = especieNombre;
            document.getElementById('especieIdEliminar').value = especieId;
            document.getElementById('codigoMostrarEspecie').textContent = codigoConfirmacion;
            document.getElementById('codigoConfirmacionEspecie').value = ''; // Limpiar campo

            // Mostrar modal
            const modal = new bootstrap.Modal(document.getElementById('eliminarEspecieModal'));
            modal.show();
        }

        // Función para eliminar módulo
        function eliminarModulo(moduloId, moduloNombre) {
            // Verificar que sea admin supremo
            if ('<?php echo $_SESSION['user_role'] ?? 'basico'; ?>' !== 'supremo') {
                alert('Solo el Administrador Supremo puede eliminar módulos.');
                return;
            }
        
            // Generar código de confirmación
            const codigoConfirmacion = Math.random().toString(36).substring(2, 8).toUpperCase();
        
            // Mostrar información básica inicialmente
            document.getElementById('moduloInfoEliminar').innerHTML = `
                <div class="text-center">
                    <div class="spinner-border spinner-border-sm" role="status">
                        <span class="visually-hidden">Cargando...</span>
                    </div>
                    <small class="text-muted d-block mt-1">Cargando información del módulo...</small>
                </div>
            `;

            // Cargar información del módulo
            fetch(`${window.appConfig.baseUrl}api/especies/ver/${moduloId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const modulo = data.data.especie;
                        const especies = data.data.hijos.filter(h => h.tipo === 'especie');
                        const formularios = data.data.tiene_formularios;

                        let infoHtml = `
                            <div class="row">
                                <div class="col-md-6">
                                    <strong>Especies en este módulo:</strong> ${especies.length}
                                </div>
                                <div class="col-md-6">
                                    <strong>Formularios asociados:</strong> ${formularios ? 'Sí' : 'No'}
                                </div>
                            </div>
                        `;

                        if (especies.length > 0) {
                            infoHtml += `
                                <div class="mt-2">
                                    <strong>Especies:</strong>
                                    <div class="small text-muted mt-1">
                                        ${especies.map(e => e.nombre).join(', ')}
                                    </div>
                                </div>
                            `;
                        }

                        document.getElementById('moduloInfoEliminar').innerHTML = infoHtml;
                    } else {
                        document.getElementById('moduloInfoEliminar').innerHTML = `
                            <div class="alert alert-warning">
                                <small>No se pudo cargar la información del módulo. Puede continuar con la eliminación.</small>
                            </div>
                        `;
                    }
                })
                .catch(error => {
                    console.error('Error cargando información del módulo:', error);
                    document.getElementById('moduloInfoEliminar').innerHTML = `
                        <div class="alert alert-warning">
                            <small>Error al cargar información. Puede continuar con la eliminación.</small>
                        </div>
                    `;
                });
        
            // Configurar modal
            document.getElementById('moduloNombreEliminar').textContent = moduloNombre;
            document.getElementById('moduloIdEliminar').value = moduloId;
            document.getElementById('codigoMostrar').textContent = codigoConfirmacion;
            document.getElementById('codigoConfirmacion').value = ''; // Limpiar campo
        
            // Mostrar modal
            const modal = new bootstrap.Modal(document.getElementById('eliminarModuloModal'));
            modal.show();
        }
        
        // Validación del código de confirmación para especies
        document.getElementById('eliminarEspecieForm')?.addEventListener('submit', function(e) {
            const codigoIngresado = document.getElementById('codigoConfirmacionEspecie').value;
            const codigoEsperado = document.getElementById('codigoMostrarEspecie').textContent;

            if (codigoIngresado !== codigoEsperado) {
                e.preventDefault();
                alert('El código de confirmación no es correcto.');
                return false;
            }
        });

        // Validación del código de confirmación para módulos
        document.getElementById('eliminarModuloForm')?.addEventListener('submit', function(e) {
            const codigoIngresado = document.getElementById('codigoConfirmacion').value;
            const codigoEsperado = document.getElementById('codigoMostrar').textContent;

            if (codigoIngresado !== codigoEsperado) {
                e.preventDefault();
                alert('El código de confirmación no es correcto.');
                return false;
            }
        });
        </script>


        <!-- Reinos Fijos -->
        <div class="row mb-4">
            <?php if (!empty($reinos)): ?>
                <?php foreach ($reinos as $reino): ?>
                    <div class="col-md-6">
                        <div class="card h-100">
                            <div class="card-header <?php echo $reino['id'] == 1 ? 'bg-success' : 'bg-info'; ?> text-white">
                                <h5 class="mb-0">
                                    <i class="fas <?php echo $reino['id'] == 1 ? 'fa-seedling' : 'fa-paw'; ?> me-2"></i><?php echo htmlspecialchars($reino['nombre']); ?>
                                </h5>
                            </div>
                            <div class="card-body">
                                <p class="text-muted small mb-3">
                                    <?php echo $reino['id'] == 1 ? 'Reino vegetal - Plantas y organismos fotosintéticos' : 'Reino animal - Animales y organismos heterótrofos'; ?>
                                </p>

                                <!-- Módulos del reino -->
                                <div class="mb-3">
                                    <h6 class="<?php echo $reino['id'] == 1 ? 'text-success' : 'text-info'; ?> mb-2">
                                        <i class="fas fa-folder me-1"></i>Módulos
                                    </h6>
                                    <div id="<?php echo $reino['id'] == 1 ? 'flora' : 'fauna'; ?>-modulos">
                                        <?php
                                        // Obtener módulos de este reino
                                        $especieModel = new Especie();
                                        $modulos = $especieModel->obtenerModulos($reino['id']);
                                        if (!empty($modulos)):
                                        ?>
                                            <div class="list-group list-group-flush">
                                                <?php foreach ($modulos as $modulo): ?>
                                                    <div class="list-group-item px-0">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <div>
                                                                <strong class="<?php echo $reino['id'] == 1 ? 'text-success' : 'text-info'; ?>">
                                                                    <?php echo htmlspecialchars($modulo['nombre']); ?>
                                                                </strong>
                                                                <div class="small text-muted mt-1">
                                                                    <i class="fas fa-leaf me-1"></i>Especies:
                                                                    <?php
                                                                    $especies = $especieModel->obtenerEspecies($modulo['id']);
                                                                    echo count($especies);
                                                                    ?>
                                                                    <?php if (!empty($especies)): ?>
                                                                        <div class="mt-2">
                                                                            <small class="text-muted">
                                                                                <?php foreach ($especies as $especie): ?>
                                                                                    <span class="badge bg-light text-dark me-1 mb-1 d-inline-flex align-items-center">
                                                                                        <?php echo htmlspecialchars($especie['nombre']); ?>
                                                                                        <?php if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'supremo'])): ?>
                                                                                            <button class="btn btn-sm btn-link text-danger p-0 ms-1" onclick="eliminarEspecie(<?php echo $especie['id']; ?>, '<?php echo htmlspecialchars($especie['nombre']); ?>')" title="Eliminar Especie" style="font-size: 0.7rem; line-height: 1;">
                                                                                                <i class="fas fa-times"></i>
                                                                                            </button>
                                                                                        <?php endif; ?>
                                                                                    </span>
                                                                                <?php endforeach; ?>
                                                                            </small>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'supremo'): ?>
                                                                    <button class="btn btn-sm btn-outline-danger me-1" onclick="eliminarModulo(<?php echo $modulo['id']; ?>, '<?php echo htmlspecialchars($modulo['nombre']); ?>')" title="Eliminar Módulo">
                                                                        <i class="fas fa-trash"></i>
                                                                    </button>
                                                                <?php endif; ?>
                                                                <a href="<?php echo base_url('especies/crear'); ?>" class="btn btn-sm btn-outline-<?php echo $reino['id'] == 1 ? 'success' : 'info'; ?>" title="Agregar Especie">
                                                                    <i class="fas fa-plus"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else: ?>
                                            <div class="text-muted small">
                                                <i class="fas fa-info-circle me-1"></i>No hay módulos en este reino
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'supremo'): ?>
                                    <a href="<?php echo base_url('especies/crear'); ?>" class="btn btn-sm btn-outline-<?php echo $reino['id'] == 1 ? 'success' : 'info'; ?>">
                                        <i class="fas fa-plus me-1"></i>Agregar Módulo
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        No se encontraron reinos en la base de datos. Los reinos Flora y Fauna deben existir.
                        <br><small>Variable $reinos: <?php var_dump($reinos); ?></small>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
