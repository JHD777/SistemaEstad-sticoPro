<?php
/**
 * Sistema Estadístico Pro - Crear Reino/Especie
 * Vista para crear nuevos reinos, módulos o especies
 */

// Verificar permisos
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'supremo'])) {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h4 class="card-title mb-0">
                    <i class="fas fa-plus-circle me-2"></i>
                    Crear Nuevo Elemento
                </h4>
            </div>

            <div class="card-body">
                <form method="POST" action="<?php echo base_url('especies/procesarCreacion'); ?>" id="crearEspecieForm">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tipo" class="form-label">
                                    <i class="fas fa-layer-group me-1"></i>Tipo de Elemento
                                </label>
                                <select class="form-select" id="tipo" name="tipo" required>
                                    <option value="">Seleccionar tipo...</option>
                                    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'supremo'): ?>
                                    <option value="modulo">Módulo</option>
                                    <option value="especie">Especie</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3" id="parentContainer" style="display: none;">
                                <label for="parent_id" class="form-label">
                                    <i class="fas fa-sitemap me-1"></i>Padre
                                </label>
                                <select class="form-select" id="parent_id" name="parent_id">
                                    <option value="">Seleccionar padre...</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="nombre" class="form-label">
                            <i class="fas fa-tag me-1"></i>Nombre
                        </label>
                        <input type="text" class="form-control" id="nombre" name="nombre"
                               placeholder="Ingrese el nombre" required>
                    </div>

                    <div class="mb-3">
                        <label for="descripcion" class="form-label">
                            <i class="fas fa-align-left me-1"></i>Descripción (Opcional)
                        </label>
                        <textarea class="form-control" id="descripcion" name="descripcion"
                                  rows="3" placeholder="Ingrese una descripción opcional"></textarea>
                    </div>

                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a href="<?php echo base_url('especies/listar'); ?>" class="btn btn-outline-secondary me-md-2">
                            <i class="fas fa-arrow-left me-1"></i>Cancelar
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Crear Elemento
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Información de ayuda -->
        <div class="card mt-4">
            <div class="card-header">
                <h6 class="card-title mb-0">
                    <i class="fas fa-info-circle me-2"></i>Información de Ayuda
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6><i class="fas fa-folder text-info me-1"></i>Módulo</h6>
                        <p class="small text-muted">Categoría intermedia dentro de un reino existente (Cítricos, Bovinos)</p>
                    </div>
                    <div class="col-md-6">
                        <h6><i class="fas fa-leaf text-success me-1"></i>Especie</h6>
                        <p class="small text-muted">Elemento específico dentro de un módulo (Limón, Vaca)</p>
                    </div>
                </div>
                <div class="alert alert-info mt-3">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Nota:</strong> Los reinos (Flora y Fauna) ya están preestablecidos en el sistema y no pueden modificarse.
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tipoSelect = document.getElementById('tipo');
    const parentContainer = document.getElementById('parentContainer');
    const parentSelect = document.getElementById('parent_id');

    // Cargar opciones de padre según el tipo seleccionado
    tipoSelect.addEventListener('change', function() {
        const tipo = this.value;

        if (tipo === 'modulo') {
            parentContainer.style.display = 'block';
            parentSelect.required = true;
            cargarReinos();
        } else if (tipo === 'especie') {
            parentContainer.style.display = 'block';
            parentSelect.required = true;
            cargarModulos();
        } else {
            parentContainer.style.display = 'none';
            parentSelect.required = false;
        }
    });

    function cargarReinos() {
        // Cargar reinos preestablecidos directamente
        const reinos = [
            { id: 1, nombre: 'Flora' },
            { id: 2, nombre: 'Fauna' }
        ];

        parentSelect.innerHTML = '<option value="">Seleccionar reino...</option>';
        reinos.forEach(reino => {
            parentSelect.innerHTML += `<option value="${reino.id}">${reino.nombre}</option>`;
        });
    }

    function cargarModulos() {
        fetch(window.appConfig.baseUrl + 'api/especies')
            .then(response => response.json())
            .then(responseData => {
                if (responseData.success && responseData.data) {
                    parentSelect.innerHTML = '<option value="">Seleccionar módulo...</option>';
                    responseData.data.forEach(modulo => {
                        // Mostrar jerarquía: "Módulo (Reino)"
                        const reinoNombre = modulo.reino || 'Desconocido';
                        parentSelect.innerHTML += `<option value="${modulo.id}">${modulo.nombre} (${reinoNombre})</option>`;
                    });
                } else {
                    // Fallback: mostrar módulos básicos
                    parentSelect.innerHTML = '<option value="">Seleccionar módulo...</option>';
                    parentSelect.innerHTML += '<option value="3">Cítricos (Flora)</option>';
                    parentSelect.innerHTML += '<option value="4">Bovinos (Fauna)</option>';
                }
            })
            .catch(error => {
                console.error('Error cargando módulos:', error);
                // Fallback: mostrar módulos básicos
                parentSelect.innerHTML = '<option value="">Seleccionar módulo...</option>';
                parentSelect.innerHTML += '<option value="3">Cítricos (Flora)</option>';
                parentSelect.innerHTML += '<option value="4">Bovinos (Fauna)</option>';
            });
    }

    // Validación del formulario
    const form = document.getElementById('crearEspecieForm');
    form.addEventListener('submit', function(e) {
        const tipo = tipoSelect.value;
        const nombre = document.getElementById('nombre').value.trim();

        if (!tipo) {
            e.preventDefault();
            alert('Por favor, seleccione un tipo de elemento.');
            return false;
        }

        if (!nombre) {
            e.preventDefault();
            alert('Por favor, ingrese un nombre.');
            return false;
        }

        // Mostrar loading
        const submitBtn = form.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Creando...';
        submitBtn.disabled = true;

        // Re-enable after 3 seconds (in case of error)
        setTimeout(() => {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }, 3000);
    });
});
</script>