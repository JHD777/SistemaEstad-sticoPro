<?php
/**
 * Vista de Reino - Sistema Estadístico Pro
 * Muestra los módulos de un reino específico
 */

// Verificar permisos básicos
if (!isset($_SESSION['user_role'])) {
    $_SESSION['user_role'] = 'basico'; // Usuario público
}

$page_title = 'Reino: ' . htmlspecialchars($reino['nombre']);
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-globe me-2 text-primary"></i>
                    Reino: <?php echo htmlspecialchars($reino['nombre']); ?>
                </h2>
                <p class="text-muted mt-1"><?php echo htmlspecialchars($reino['descripcion'] ?? 'Información del reino biológico'); ?></p>
            </div>
            <div>
                <a href="<?php echo base_url('dashboard/general'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Volver al Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Estadísticas del Reino -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Módulos
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo count($modulos); ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-folder fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Especies Totales
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $totalEspecies = 0;
                            foreach ($modulos as $modulo) {
                                $especies = array_column($this->especieModel->obtenerEspecies($modulo['id']), 'id');
                                $totalEspecies += count($especies);
                            }
                            echo $totalEspecies;
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-leaf fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Censos Realizados
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $totalCensos = 0;
                            foreach ($modulos as $modulo) {
                                $especies = $this->especieModel->obtenerEspecies($modulo['id']);
                                foreach ($especies as $especie) {
                                    $censos = $this->registroModel->obtenerPorEspecie($especie['id']);
                                    $totalCensos += count($censos);
                                }
                            }
                            echo $totalCensos;
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Formularios Activos
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $totalFormularios = 0;
                            foreach ($modulos as $modulo) {
                                $especies = $this->especieModel->obtenerEspecies($modulo['id']);
                                foreach ($especies as $especie) {
                                    $formularios = $this->formularioModel->obtenerAprobadosPorEspecie($especie['id']);
                                    $totalFormularios += count($formularios);
                                }
                            }
                            echo $totalFormularios;
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Módulos del Reino -->
<div class="row">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-folder me-2"></i>Módulos de <?php echo htmlspecialchars($reino['nombre']); ?>
                </h6>
            </div>
            <div class="card-body">
                <?php if (empty($modulos)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-folder-open fa-3x text-gray-300 mb-3"></i>
                        <h5 class="text-gray-500">No hay módulos registrados</h5>
                        <p class="text-gray-400">Este reino aún no tiene módulos definidos.</p>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($modulos as $modulo): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100 border-left-success shadow-sm">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                <i class="fas fa-folder"></i>
                                            </div>
                                            <div class="ms-3">
                                                <h6 class="card-title mb-0">
                                                    <a href="<?php echo base_url('dashboard/modulo/' . $modulo['id']); ?>" class="text-decoration-none text-dark">
                                                        <?php echo htmlspecialchars($modulo['nombre']); ?>
                                                    </a>
                                                </h6>
                                                <small class="text-muted">Módulo</small>
                                            </div>
                                        </div>

                                        <p class="card-text small text-gray-600 mb-3">
                                            <?php echo htmlspecialchars($modulo['descripcion'] ?? 'Sin descripción'); ?>
                                        </p>

                                        <?php
                                        $especies = $this->especieModel->obtenerEspecies($modulo['id']);
                                        $totalEspecies = count($especies);
                                        $totalCensos = 0;
                                        foreach ($especies as $especie) {
                                            $censos = $this->registroModel->obtenerPorEspecie($especie['id']);
                                            $totalCensos += count($censos);
                                        }
                                        ?>

                                        <div class="row text-center">
                                            <div class="col-6">
                                                <div class="small text-gray-500">Especies</div>
                                                <div class="h6 mb-0 text-success"><?php echo $totalEspecies; ?></div>
                                            </div>
                                            <div class="col-6">
                                                <div class="small text-gray-500">Censos</div>
                                                <div class="h6 mb-0 text-info"><?php echo $totalCensos; ?></div>
                                            </div>
                                        </div>

                                        <div class="mt-3">
                                            <a href="<?php echo base_url('dashboard/modulo/' . $modulo['id']); ?>" class="btn btn-success btn-sm w-100">
                                                <i class="fas fa-eye me-1"></i>Ver Detalles
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Gráficos de Datos del Reino -->
<div class="row mt-4">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    <i class="fas fa-chart-bar me-2"></i>Datos Estadísticos del Reino <?php echo htmlspecialchars($reino['nombre']); ?>
                </h6>
            </div>
            <div class="card-body">
                <?php if (!empty($estadisticas_reino)): ?>
                    <div class="row">
                        <?php foreach ($estadisticas_reino as $preguntaId => $estadistica): ?>
                            <div class="col-md-6 mb-4">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <h6 class="mb-0">
                                            <i class="fas fa-question-circle text-primary me-2"></i>
                                            <?php echo htmlspecialchars($estadistica['pregunta']['texto_pregunta']); ?>
                                        </h6>
                                        <small class="text-muted">
                                            Tipo: <?php echo htmlspecialchars($estadistica['pregunta']['tipo_pregunta']); ?>
                                        </small>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="chart-reino-<?php echo $preguntaId; ?>" width="400" height="300"></canvas>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        No hay datos estadísticos disponibles para este reino aún.
                        Los datos aparecerán cuando se realicen censos en las especies de este reino.
                        <?php if (hasPermission($_SESSION['user_role'] ?? 'basico', 'forms.create')): ?>
                            <a href="<?php echo base_url('preguntas/crear'); ?>" class="alert-link">Crear preguntas base</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
// Funcionalidad para gráficos del reino
document.addEventListener('DOMContentLoaded', function() {
    <?php
    if (!empty($estadisticas_reino)):
        foreach ($estadisticas_reino as $preguntaId => $estadistica):
    ?>
            crearGraficoReino(<?php echo $preguntaId; ?>, <?php echo json_encode($estadistica['pregunta']); ?>, <?php echo json_encode($estadistica['datos']); ?>);
    <?php
        endforeach;
    endif;
    ?>
});

function crearGraficoReino(index, pregunta, estadisticas) {
    const canvas = document.getElementById('chart-reino-' + index);
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    // Configurar datos según el tipo de pregunta
    let chartData = {};
    let chartType = 'bar';

    switch (pregunta.tipo_pregunta) {
        case 'numero':
            chartData = {
                labels: ['Mínimo', 'Promedio', 'Máximo'],
                datasets: [{
                    label: 'Valores Numéricos',
                    data: [
                        estadisticas.datos?.minimo || 0,
                        estadisticas.datos?.promedio || 0,
                        estadisticas.datos?.maximo || 0
                    ],
                    backgroundColor: 'rgba(0, 123, 255, 0.5)',
                    borderColor: 'rgba(0, 123, 255, 1)',
                    borderWidth: 1
                }]
            };
            break;

        case 'booleano':
            chartType = 'pie';
            chartData = {
                labels: ['Sí', 'No'],
                datasets: [{
                    label: 'Respuestas',
                    data: [
                        estadisticas.datos?.respuestas_positivas || 0,
                        estadisticas.datos?.respuestas_negativas || 0
                    ],
                    backgroundColor: [
                        'rgba(40, 167, 69, 0.5)',
                        'rgba(220, 53, 69, 0.5)'
                    ],
                    borderColor: [
                        'rgba(40, 167, 69, 1)',
                        'rgba(220, 53, 69, 1)'
                    ],
                    borderWidth: 1
                }]
            };
            break;

        case 'opcion_multiple':
            chartData = {
                labels: Object.keys(estadisticas.datos || {}),
                datasets: [{
                    label: 'Frecuencia',
                    data: Object.values(estadisticas.datos || {}),
                    backgroundColor: 'rgba(255, 193, 7, 0.5)',
                    borderColor: 'rgba(255, 193, 7, 1)',
                    borderWidth: 1
                }]
            };
            break;

        default:
            chartData = {
                labels: ['Sin datos'],
                datasets: [{
                    label: 'Sin información',
                    data: [0],
                    backgroundColor: 'rgba(108, 117, 125, 0.5)',
                    borderColor: 'rgba(108, 117, 125, 1)',
                    borderWidth: 1
                }]
            };
    }

    new Chart(ctx, {
        type: chartType,
        data: chartData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: pregunta.texto_pregunta || 'Estadística del Reino'
                }
            }
        }
    });
}
</script>