<?php
/**
 * Sistema Estadístico Pro - Página de Términos y Condiciones
 * Información legal del sistema
 */
?>
<div class="page-header">
    <h1><?php echo $titulo ?? 'Términos y Condiciones - Sistema Estadístico Pro'; ?></h1>
    <div class="subtitle">Información legal y condiciones de uso del sistema</div>
</div>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card">
                <div class="card-header bg-warning text-dark">
                    <h2 class="card-title mb-0">
                        <i class="fas fa-file-contract me-2"></i>
                        Términos y Condiciones
                    </h2>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="fas fa-calendar-alt me-2"></i>
                        <strong>Última actualización:</strong> <?php echo htmlspecialchars($ultima_actualizacion ?? date('d/m/Y')); ?>
                    </div>

                    <h3>1. Aceptación de los Términos</h3>
                    <p>Al acceder y utilizar el Sistema Estadístico Pro, usted acepta estar sujeto a estos términos y condiciones de uso. Si no está de acuerdo con alguno de estos términos, le recomendamos no utilizar este sistema.</p>

                    <h3>2. Descripción del Servicio</h3>
                    <p>Sistema Estadístico Pro es una plataforma web diseñada para la gestión y análisis de datos estadísticos relacionados con especies biológicas. El sistema permite:</p>
                    <ul>
                        <li>Gestión jerárquica de especies (Reino → Módulo → Especie)</li>
                        <li>Creación y administración de formularios dinámicos</li>
                        <li>Registro y análisis de datos censales</li>
                        <li>Generación de reportes y estadísticas</li>
                        <li>Sistema de permisos basado en roles de usuario</li>
                    </ul>

                    <h3>3. Uso Aceptable</h3>
                    <p>Al utilizar este sistema, usted se compromete a:</p>
                    <ul>
                        <li>Proporcionar información veraz y precisa</li>
                        <li>Mantener la confidencialidad de sus credenciales de acceso</li>
                        <li>Respetar los derechos de propiedad intelectual</li>
                        <li>No interferir con el funcionamiento normal del sistema</li>
                        <li>No utilizar el sistema para actividades ilegales o no autorizadas</li>
                    </ul>

                    <h3>4. Cuentas de Usuario</h3>
                    <p>Para acceder a ciertas funcionalidades del sistema, es necesario crear una cuenta de usuario. Usted es responsable de:</p>
                    <ul>
                        <li>Mantener la confidencialidad de su contraseña</li>
                        <li>Todas las actividades que ocurran bajo su cuenta</li>
                        <li>Notificar inmediatamente cualquier uso no autorizado</li>
                        <li>Proporcionar información precisa y actualizada</li>
                    </ul>

                    <h3>5. Niveles de Usuario y Permisos</h3>
                    <p>El sistema cuenta con diferentes niveles de acceso:</p>
                    <ul>
                        <li><strong>Básico:</strong> Acceso limitado a funciones básicas</li>
                        <li><strong>Registrado:</strong> Acceso completo a formularios y exportación</li>
                        <li><strong>Administrador:</strong> Gestión de especies y formularios</li>
                        <li><strong>Supremo:</strong> Control total incluyendo gestión de usuarios</li>
                    </ul>

                    <h3>6. Propiedad Intelectual</h3>
                    <p>Todo el contenido del Sistema Estadístico Pro, incluyendo pero no limitado a:</p>
                    <ul>
                        <li>Código fuente y software</li>
                        <li>Diseños gráficos e interfaces</li>
                        <li>Documentación y contenido</li>
                        <li>Bases de datos y estructuras</li>
                    </ul>
                    <p>Son propiedad exclusiva de Sistema Estadístico Pro y están protegidos por leyes de propiedad intelectual.</p>

                    <h3>7. Privacidad y Protección de Datos</h3>
                    <p>La recopilación y uso de datos personales se rige por nuestra Política de Privacidad, la cual forma parte integral de estos términos. Al utilizar el sistema, usted consiente la recopilación y uso de su información según lo establecido en dicha política.</p>

                    <h3>8. Limitación de Responsabilidad</h3>
                    <p>Sistema Estadístico Pro se proporciona "tal cual" sin garantías de ningún tipo. No nos hacemos responsables por:</p>
                    <ul>
                        <li>Pérdida o corrupción de datos</li>
                        <li>Interrupciones del servicio</li>
                        <li>Daños directos o indirectos derivados del uso</li>
                        <li>Pérdidas económicas o de cualquier naturaleza</li>
                    </ul>

                    <h3>9. Modificaciones</h3>
                    <p>Nos reservamos el derecho de modificar estos términos en cualquier momento. Los cambios serán efectivos inmediatamente después de su publicación en el sistema. Es responsabilidad del usuario revisar periódicamente estos términos.</p>

                    <h3>10. Suspensión y Terminación</h3>
                    <p>Nos reservamos el derecho de suspender o terminar el acceso de cualquier usuario que:</p>
                    <ul>
                        <li>Violente estos términos y condiciones</li>
                        <li>Realice actividades sospechosas o maliciosas</li>
                        <li>Ponga en riesgo la seguridad del sistema</li>
                        <li>Utilice el sistema de manera inapropiada</li>
                    </ul>

                    <h3>11. Legislación Aplicable</h3>
                    <p>Estos términos se rigen por las leyes de Bolivia. Cualquier disputa relacionada con estos términos será resuelta en los tribunales competentes de La Paz, Bolivia.</p>

                    <h3>12. Datos de Contacto</h3>
                    <p>Para cualquier consulta relacionada con estos términos, puede contactarnos a través de:</p>
                    <ul>
                        <li>Email: legal@sistema-estadistico-pro.com</li>
                        <li>Dirección: La Paz, Bolivia</li>
                    </ul>

                    <div class="alert alert-warning mt-4">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Importante:</strong> Estos términos y condiciones pueden ser modificados sin previo aviso. Le recomendamos revisar esta página periódicamente para estar al tanto de cualquier cambio.
                    </div>
                </div>
                <div class="card-footer text-center">
                    <small class="text-muted">
                        © <?php echo date('Y'); ?> Sistema Estadístico Pro. Todos los derechos reservados.
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- El footer ya está incluido en el layout público -->