<?php
/**
 * Sistema Estadístico Pro - Vista de Estadísticas Jerárquicas
 * Centro Estadístico principal con navegación Flora -> Módulos -> Especies
 */

// Verificar permisos
if (!isset($_SESSION['user_role'])) {
    header('Location: ' . base_url('login'));
    exit;
}
?>

<div class="dashboard-container">
    <!-- Header del Centro Estadístico -->
    <div class="dashboard-header mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="dashboard-title">
                    <i class="fas fa-chart-line me-3 text-success"></i>
                    Centro Estadístico Pro
                </h1>
                <p class="dashboard-subtitle text-muted mb-0">
                    Navegación jerárquica de datos censales: Reino → Módulo → Especie
                </p>
            </div>
            <div class="dashboard-actions">
                <a href="<?php echo base_url('dashboard'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Volver al Panel
                </a>
            </div>
        </div>
    </div>

    <!-- Breadcrumb de navegación -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb breadcrumb-dashboard">
            <li class="breadcrumb-item">
                <a href="<?php echo base_url('dashboard'); ?>">
                    <i class="fas fa-home me-1"></i>Panel Principal
                </a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                Centro Estadístico
            </li>
        </ol>
    </nav>

    <!-- Contenedor principal del centro estadístico -->
    <div class="dashboard-content">
        <!-- Vista de Reinos (Nivel Superior) -->
        <div id="reinosView" class="dashboard-view">
            <div class="row">
                <div class="col-12">
                    <div class="section-header mb-4">
                        <h2 class="section-title">
                            <i class="fas fa-globe me-2 text-primary"></i>
                            Reinos Biológicos Disponibles
                        </h2>
                        <p class="section-description text-muted">
                            Selecciona un reino para explorar sus módulos y especies con datos estadísticos
                        </p>
                    </div>

                    <!-- Cards de Reinos -->
                    <div class="row g-4">
                        <?php if (!empty($reinos)): ?>
                            <?php foreach ($reinos as $reino): ?>
                                <div class="col-lg-6">
                                    <div class="card reino-card h-100 shadow-sm hover-lift"
                                         data-reino-id="<?php echo $reino['id']; ?>"
                                         data-reino-nombre="<?php echo htmlspecialchars($reino['nombre']); ?>">
                                        <div class="card-body p-4">
                                            <div class="d-flex align-items-center mb-3">
                                                <i class="fas fa-<?php echo $reino['id'] == 1 ? 'leaf' : 'paw'; ?> fa-3x me-3 text-<?php echo $reino['id'] == 1 ? 'success' : 'info'; ?> reino-icon"></i>
                                                <div>
                                                    <h4 class="card-title mb-1"><?php echo htmlspecialchars($reino['nombre']); ?></h4>
                                                    <p class="card-text text-muted small mb-0"><?php echo htmlspecialchars($reino['descripcion'] ?? 'Reino biológico'); ?></p>
                                                </div>
                                            </div>

                                            <div class="reino-stats mb-3">
                                                <div class="row text-center">
                                                    <div class="col-4">
                                                        <div class="stat-item">
                                                            <span class="stat-number"><?php
                                                                $modulos = $especieModel ? $especieModel->obtenerModulos($reino['id']) : [];
                                                                echo count($modulos);
                                                            ?></span>
                                                            <small class="stat-label text-muted">Módulos</small>
                                                        </div>
                                                    </div>
                                                    <div class="col-4">
                                                        <div class="stat-item">
                                                            <span class="stat-number"><?php
                                                                $modulos = isset($especieModel) ? $especieModel->obtenerModulos($reino['id']) : [];
                                                                $totalEspecies = 0;
                                                                foreach ($modulos as $modulo) {
                                                                    $especies = isset($especieModel) ? $especieModel->obtenerEspecies($modulo['id']) : [];
                                                                    $totalEspecies += count($especies);
                                                                }
                                                                echo $totalEspecies;
                                                            ?></span>
                                                            <small class="stat-label text-muted">Especies</small>
                                                        </div>
                                                    </div>
                                                    <div class="col-4">
                                                        <div class="stat-item">
                                                            <span class="stat-number"><?php
                                                                $modulos = isset($especieModel) ? $especieModel->obtenerModulos($reino['id']) : [];
                                                                $totalCensos = 0;
                                                                foreach ($modulos as $modulo) {
                                                                    $especies = isset($especieModel) ? $especieModel->obtenerEspecies($modulo['id']) : [];
                                                                    foreach ($especies as $especie) {
                                                                        $censos = isset($registroModel) ? $registroModel->obtenerPorEspecie($especie['id']) : [];
                                                                        $totalCensos += count($censos);
                                                                    }
                                                                }
                                                                echo $totalCensos;
                                                            ?></span>
                                                            <small class="stat-label text-muted">Censos</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <button class="btn btn-<?php echo $reino['id'] == 1 ? 'success' : 'info'; ?> btn-lg w-100 reino-btn"
                                                    data-reino-id="<?php echo $reino['id']; ?>"
                                                    data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="Explorar <?php echo htmlspecialchars($reino['nombre']); ?> y sus datos estadísticos">
                                                <i class="fas fa-arrow-right me-2"></i>
                                                Explorar <?php echo htmlspecialchars($reino['nombre']); ?>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="col-12">
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>
                                    No hay reinos disponibles. Contacte al administrador del sistema.
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Contenedor para vistas de módulos y especies -->
        <div id="moduloView" class="dashboard-view" style="display: none;">
            <!-- Se carga dinámicamente -->
        </div>

        <div id="especieView" class="dashboard-view" style="display: none;">
            <!-- Se carga dinámicamente -->
        </div>
    </div>
</div>

<!-- Modal para loading -->
<div class="modal fade" id="loadingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center p-4">
                <div class="spinner-border text-primary mb-3" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
                <h5>Cargando datos...</h5>
                <p class="text-muted mb-0">Por favor espera mientras procesamos la información</p>
            </div>
        </div>
    </div>
</div>

<style>
/* Estilos del Dashboard */
.dashboard-container {
    min-height: 80vh;
}

.dashboard-header {
    border-bottom: 2px solid #e9ecef;
    padding-bottom: 1rem;
}

.dashboard-title {
    color: #2c3e50;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

.dashboard-subtitle {
    font-size: 1.1rem;
}

.dashboard-actions .btn {
    border-radius: 25px;
    padding: 0.5rem 1.5rem;
    font-weight: 500;
}

.breadcrumb-dashboard {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 10px;
    padding: 0.75rem 1rem;
}

.breadcrumb-dashboard .breadcrumb-item {
    color: rgba(255, 255, 255, 0.8);
}

.breadcrumb-dashboard .breadcrumb-item.active {
    color: white;
    font-weight: 500;
}

.reino-card {
    border: none;
    border-radius: 15px;
    transition: all 0.3s ease;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
}

.reino-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15) !important;
}

.reino-icon {
    opacity: 0.8;
}

.reino-card:hover .reino-icon {
    opacity: 1;
    transform: scale(1.1);
    transition: all 0.3s ease;
}

.reino-stats {
    background: rgba(255, 255, 255, 0.7);
    border-radius: 10px;
    padding: 1rem;
    margin: 1rem 0;
}

.stat-number {
    font-size: 1.8rem;
    font-weight: bold;
    color: #495057;
    display: block;
}

.stat-label {
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.reino-btn {
    border-radius: 25px;
    padding: 0.75rem 2rem;
    font-weight: 600;
    transition: all 0.3s ease;
}

.reino-btn:hover {
    transform: scale(1.05);
}

.section-header {
    text-align: center;
}

.section-title {
    color: #2c3e50;
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.section-description {
    font-size: 1rem;
}

/* Animaciones */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.dashboard-view {
    animation: fadeInUp 0.5s ease-out;
}

.hover-lift {
    transition: all 0.3s ease;
}

.hover-lift:hover {
    transform: translateY(-3px);
}

/* Responsive */
@media (max-width: 768px) {
    .dashboard-title {
        font-size: 1.8rem;
    }

    .reino-card {
        margin-bottom: 1rem;
    }

    .reino-icon .fa-4x {
        font-size: 3rem;
    }
}
</style>

<script>
// Función helper para base_url (ya que no está disponible en JS)
function base_url(path = '') {
    return 'https://sistema_estadistico_pro.test/' + path.replace(/^\//, '');
}

// Variables globales
let currentView = 'reinos';
let breadcrumbHistory = ['Centro Estadístico'];

// Función para cambiar vista
function cambiarVista(vista) {
    // Ocultar todas las vistas
    document.querySelectorAll('.dashboard-view').forEach(view => {
        view.style.display = 'none';
    });

    // Mostrar vista seleccionada
    const vistaElement = document.getElementById(vista + 'View');
    if (vistaElement) {
        vistaElement.style.display = 'block';
        currentView = vista;
    } else {
        console.warn('Vista no encontrada:', vista + 'View');
    }
}

// Función para cargar módulos de un reino
function cargarModulosReino(reinoId, reinoNombre) {
    const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
    loadingModal.show();

    // Actualizar breadcrumb
    breadcrumbHistory = ['Centro Estadístico', reinoNombre];
    actualizarBreadcrumb();

    // Obtener módulos usando la nueva API
    fetch(base_url('api/especies?reino=' + reinoId))
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(responseData => {
            // Extraer el array de módulos de la respuesta
            let modulos = [];
            if (responseData.success && responseData.data) {
                modulos = responseData.data;
            } else {
                console.warn('Formato de respuesta inesperado:', responseData);
                modulos = [];
            }

            loadingModal.hide();
            mostrarVistaModulos(modulos, reinoId, reinoNombre);
        })
        .catch(error => {
            console.error('Error al cargar módulos:', error);
            loadingModal.hide();
            alert('Error al cargar los módulos: ' + error.message);
        });
}

// Función para mostrar vista de módulos
function mostrarVistaModulos(modulos, reinoId, reinoNombre) {
    cambiarVista('modulo');

    const container = document.getElementById('moduloView');
    if (!container) {
        console.error('Contenedor moduloView no encontrado');
        return;
    }

    // Verificar que modulos sea un array
    if (!Array.isArray(modulos)) {
        console.error('Los módulos no son un array válido:', modulos);
        container.innerHTML = `
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Error: Los datos de módulos no son válidos.
            </div>
        `;
        return;
    }

    // Si no hay módulos, mostrar mensaje
    if (modulos.length === 0) {
        container.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <div class="section-header mb-4">
                        <h3 class="section-title">
                            <i class="fas fa-folder me-2 text-${reinoId == 1 ? 'success' : 'info'}"></i>
                            Módulos de ${reinoNombre}
                        </h3>
                        <p class="section-description text-muted">
                            No hay módulos disponibles para este reino
                        </p>
                    </div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Este reino no tiene módulos configurados aún.
                    </div>
                </div>
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <div class="row">
            <div class="col-12">
                <div class="section-header mb-4">
                    <h3 class="section-title">
                        <i class="fas fa-folder me-2 text-${reinoId == 1 ? 'success' : 'info'}"></i>
                        Módulos de ${reinoNombre}
                    </h3>
                    <p class="section-description text-muted">
                        Selecciona un módulo para ver sus especies y datos estadísticos
                    </p>
                </div>

                <div class="row g-4">
                    ${modulos.map(modulo => `
                        <div class="col-lg-6">
                            <div class="card modulo-card h-100 shadow-sm hover-lift"
                                  data-modulo-id="${modulo.id || ''}"
                                  data-modulo-nombre="${modulo.nombre || ''}">
                                <div class="card-body p-4">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-folder fa-2x me-3 text-${reinoId == 1 ? 'success' : 'info'}"></i>
                                        <div>
                                            <h5 class="card-title mb-1">${modulo.nombre || 'Sin nombre'}</h5>
                                            <small class="text-muted">Módulo de ${reinoNombre.toLowerCase()}</small>
                                        </div>
                                    </div>

                                    <div class="modulo-stats mb-3">
                                        <div class="row text-center">
                                            <div class="col-6">
                                                <div class="stat-item">
                                                    <span class="stat-number">${modulo.especies_count || 0}</span>
                                                    <small class="stat-label text-muted">Especies</small>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="stat-item">
                                                    <span class="stat-number">${modulo.censos_count || 0}</span>
                                                    <small class="stat-label text-muted">Censos</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <button class="btn btn-${reinoId == 1 ? 'success' : 'info'} btn-lg w-100 modulo-btn"
                                            data-modulo-id="${modulo.id || ''}"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title="Ver estadísticas detalladas del módulo ${modulo.nombre || 'Módulo'}">
                                        <i class="fas fa-arrow-right me-2"></i>
                                        Explorar ${modulo.nombre || 'Módulo'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;

    // Agregar event listeners con verificación de existencia
    const moduloBtns = container.querySelectorAll('.modulo-btn');
    if (moduloBtns.length > 0) {
        moduloBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const moduloId = this.dataset.moduloId;
                const moduloNombre = this.dataset.moduloNombre;
                if (moduloId && moduloNombre) {
                    cargarEspeciesModulo(moduloId, moduloNombre, reinoNombre);
                } else {
                    console.error('Datos del módulo no encontrados');
                }
            });
        });
    }
}

// Función para cargar especies de un módulo
function cargarEspeciesModulo(moduloId, moduloNombre, reinoNombre) {
    const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
    loadingModal.show();

    // Actualizar breadcrumb
    breadcrumbHistory = ['Centro Estadístico', reinoNombre, moduloNombre];
    actualizarBreadcrumb();

    // Obtener especies y datos
    fetch(base_url('api/dashboard/datos/modulo/' + moduloId))
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            if (!esJsonValido(text)) {
                console.error('Respuesta no es JSON válido:', text);
                throw new Error('La respuesta del servidor no es JSON válido');
            }
            const responseData = JSON.parse(text);

            // Extraer los datos de la respuesta
            let data = {};
            if (responseData.success && responseData.data) {
                data = responseData.data;
            } else if (typeof responseData === 'object') {
                data = responseData;
            } else {
                console.warn('Formato de respuesta inesperado:', responseData);
                data = { especies: [], preguntas_comunes: [] };
            }

            loadingModal.hide();
            mostrarVistaEspecies(data, moduloId, moduloNombre, reinoNombre);
        })
        .catch(error => {
            console.error('Error al cargar especies:', error);
            loadingModal.hide();
            alert('Error al cargar las especies: ' + error.message);
        });
}

// Función para mostrar vista de especies con gráficos
function mostrarVistaEspecies(data, moduloId, moduloNombre, reinoNombre) {
    cambiarVista('especie');

    const container = document.getElementById('especieView');
    if (!container) {
        console.error('Contenedor especieView no encontrado');
        return;
    }

    // Verificar que data sea un objeto válido
    if (!data || typeof data !== 'object') {
        console.error('Los datos no son válidos:', data);
        container.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Error: Los datos recibidos no son válidos.
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <div class="row">
            <div class="col-12">
                <div class="section-header mb-4">
                    <h3 class="section-title">
                        <i class="fas fa-chart-bar me-2 text-primary"></i>
                        Análisis Estadístico: ${moduloNombre}
                    </h3>
                    <p class="section-description text-muted">
                        Visualización de datos censales y estadísticas del módulo
                    </p>
                </div>

                <!-- Gráficos -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0">
                                    <i class="fas fa-chart-pie me-2"></i>
                                    Estadísticas Generales
                                </h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    ${data.preguntas_comunes && Array.isArray(data.preguntas_comunes) && data.preguntas_comunes.length > 0 ?
                                        data.preguntas_comunes.map(pregunta => `
                                            <div class="col-md-6 mb-4">
                                                <div class="chart-container">
                                                    <h6 class="chart-title">${pregunta.texto_pregunta || 'Pregunta sin texto'}</h6>
                                                    <canvas id="chart-${pregunta.id || 'unknown'}" width="400" height="300"></canvas>
                                                </div>
                                            </div>
                                        `).join('') :
                                        '<div class="col-12"><div class="alert alert-info">No hay datos suficientes para mostrar gráficos</div></div>'
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Lista de especies -->
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h6 class="mb-0">
                                    <i class="fas fa-list me-2"></i>
                                    Especies del Módulo
                                </h6>
                            </div>
                            <div class="card-body">
                                <div class="row g-3">
                                    ${data.especies && Array.isArray(data.especies) && data.especies.length > 0 ?
                                        data.especies.map(especie => `
                                            <div class="col-md-4">
                                                <div class="card especie-mini-card h-100">
                                                    <div class="card-body text-center">
                                                        <i class="fas fa-leaf fa-2x mb-2 text-success"></i>
                                                        <h6 class="card-title">${especie.nombre || 'Sin nombre'}</h6>
                                                        <small class="text-muted">${especie.censos_count || 0} censos</small>
                                                        <br>
                                                        <button class="btn btn-sm btn-outline-primary mt-2 ver-especie-btn"
                                                                data-especie-id="${especie.id || ''}"
                                                                data-especie-nombre="${especie.nombre || ''}"
                                                                data-bs-toggle="tooltip"
                                                                data-bs-placement="bottom"
                                                                title="Ver análisis estadístico completo de ${especie.nombre || 'esta especie'}">
                                                            <i class="fas fa-eye me-1"></i>Ver Detallado
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        `).join('') :
                                        '<div class="col-12"><div class="alert alert-warning">No hay especies en este módulo</div></div>'
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Crear gráficos
    if (data.preguntas_comunes && Array.isArray(data.preguntas_comunes) && data.preguntas_comunes.length > 0) {
        data.preguntas_comunes.forEach(pregunta => {
            if (pregunta && pregunta.id) {
                crearGrafico(pregunta);
            }
        });
    }

    // Agregar event listeners para ver especies detalladas
    const especieBtns = container.querySelectorAll('.ver-especie-btn');
    if (especieBtns.length > 0) {
        especieBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const especieId = this.dataset.especieId;
                const especieNombre = this.dataset.especieNombre;
                if (especieId && especieNombre) {
                    cargarVistaEspecieEspecifica(especieId, especieNombre, moduloNombre, reinoNombre);
                } else {
                    console.error('Datos de la especie no encontrados');
                }
            });
        });
    }
}

// Función para crear gráficos
function crearGrafico(pregunta) {
    const ctx = document.getElementById(`chart-${pregunta.id}`);
    if (!ctx) return;

    let chartConfig = {};

    if (pregunta.tipo_pregunta === 'booleano') {
        // Gráfico de torta para booleanos
        const siCount = pregunta.datos.filter(d => d.valor_respuesta === '1' || d.valor_respuesta === 'Si' || d.valor_respuesta === 'Sí').length;
        const noCount = pregunta.datos.length - siCount;

        chartConfig = {
            type: 'pie',
            data: {
                labels: ['Sí', 'No'],
                datasets: [{
                    data: [siCount, noCount],
                    backgroundColor: ['#28a745', '#dc3545'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    title: {
                        display: true,
                        text: pregunta.texto_pregunta
                    }
                }
            }
        };
    } else if (pregunta.tipo_pregunta === 'numero') {
        // Gráfico de barras para números
        const valores = pregunta.datos.map(d => parseFloat(d.valor_respuesta)).filter(v => !isNaN(v));
        const promedio = valores.reduce((a, b) => a + b, 0) / valores.length;

        chartConfig = {
            type: 'bar',
            data: {
                labels: ['Promedio'],
                datasets: [{
                    label: 'Valor Promedio',
                    data: [promedio.toFixed(2)],
                    backgroundColor: '#007bff',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: pregunta.texto_pregunta
                    }
                }
            }
        };
    } else if (pregunta.tipo_pregunta === 'opcion_multiple') {
        // Gráfico de barras para opciones múltiples
        const conteos = {};
        pregunta.datos.forEach(d => {
            const valor = d.valor_respuesta;
            conteos[valor] = (conteos[valor] || 0) + 1;
        });

        const labels = Object.keys(conteos);
        const data = Object.values(conteos);

        chartConfig = {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Respuestas',
                    data: data,
                    backgroundColor: '#28a745',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: pregunta.texto_pregunta
                    }
                }
            }
        };
    }

    new Chart(ctx, chartConfig);
}

// Función para crear gráficos específicos de especie
function crearGraficoEspecifico(pregunta) {
    const ctx = document.getElementById(`chart-especifico-${pregunta.id}`);
    if (!ctx) return;

    let chartConfig = {};

    if (pregunta.tipo_pregunta === 'booleano') {
        // Gráfico de torta para booleanos
        const siCount = pregunta.datos.filter(d => d.valor_respuesta === '1' || d.valor_respuesta === 'Si' || d.valor_respuesta === 'Sí').length;
        const noCount = pregunta.datos.length - siCount;

        chartConfig = {
            type: 'pie',
            data: {
                labels: ['Sí', 'No'],
                datasets: [{
                    data: [siCount, noCount],
                    backgroundColor: ['#28a745', '#dc3545'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    },
                    title: {
                        display: true,
                        text: pregunta.texto_pregunta
                    }
                }
            }
        };
    } else if (pregunta.tipo_pregunta === 'numero') {
        // Gráfico de barras para números
        const valores = pregunta.datos.map(d => parseFloat(d.valor_respuesta)).filter(v => !isNaN(v));
        const promedio = valores.reduce((a, b) => a + b, 0) / valores.length;

        chartConfig = {
            type: 'bar',
            data: {
                labels: ['Promedio'],
                datasets: [{
                    label: 'Valor Promedio',
                    data: [promedio.toFixed(2)],
                    backgroundColor: '#007bff',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: pregunta.texto_pregunta
                    }
                }
            }
        };
    } else if (pregunta.tipo_pregunta === 'opcion_multiple') {
        // Gráfico de barras para opciones múltiples
        const conteos = {};
        pregunta.datos.forEach(d => {
            const valor = d.valor_respuesta;
            conteos[valor] = (conteos[valor] || 0) + 1;
        });

        const labels = Object.keys(conteos);
        const data = Object.values(conteos);

        chartConfig = {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Respuestas',
                    data: data,
                    backgroundColor: '#28a745',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                },
                plugins: {
                    title: {
                        display: true,
                        text: pregunta.texto_pregunta
                    }
                }
            }
        };
    }

    new Chart(ctx, chartConfig);
}

// Función para cargar vista específica de una especie
function cargarVistaEspecieEspecifica(especieId, especieNombre, moduloNombre, reinoNombre) {
    const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
    loadingModal.show();

    // Actualizar breadcrumb
    breadcrumbHistory = ['Centro Estadístico', reinoNombre, moduloNombre, especieNombre];
    actualizarBreadcrumb();

    // Obtener datos específicos de la especie
    fetch(base_url('api/dashboard/datos/especie/' + especieId))
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            if (!esJsonValido(text)) {
                console.error('Respuesta no es JSON válido:', text);
                throw new Error('La respuesta del servidor no es JSON válido');
            }
            const responseData = JSON.parse(text);

            // Extraer los datos de la respuesta
            let data = {};
            if (responseData.success && responseData.data) {
                data = responseData.data;
            } else if (typeof responseData === 'object') {
                data = responseData;
            } else {
                console.warn('Formato de respuesta inesperado:', responseData);
                data = { preguntas: [] };
            }

            loadingModal.hide();
            mostrarVistaEspecieEspecifica(data, especieId, especieNombre);
        })
        .catch(error => {
            console.error('Error al cargar datos de especie:', error);
            loadingModal.hide();
            alert('Error al cargar los datos de la especie: ' + error.message);
        });
}

// Función para mostrar vista específica de especie
function mostrarVistaEspecieEspecifica(data, especieId, especieNombre) {
    cambiarVista('especie');

    const container = document.getElementById('especieView');
    container.innerHTML = `
        <div class="row">
            <div class="col-12">
                <div class="section-header mb-4">
                    <h3 class="section-title">
                        <i class="fas fa-search me-2 text-primary"></i>
                        Datos Específicos: ${especieNombre}
                    </h3>
                    <p class="section-description text-muted">
                        Visualización completa de todas las preguntas de esta especie
                    </p>
                </div>

                <!-- Gráficos específicos -->
                <div class="row">
                    ${data.preguntas && data.preguntas.length > 0 ?
                        data.preguntas.map(pregunta => `
                            <div class="col-md-6 mb-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h6 class="mb-0">${pregunta.texto_pregunta}</h6>
                                        <small class="text-muted">${pregunta.tipo_pregunta}</small>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="chart-especifico-${pregunta.id}" width="400" height="300"></canvas>
                                    </div>
                                </div>
                            </div>
                        `).join('') :
                        '<div class="col-12"><div class="alert alert-info">No hay datos para mostrar</div></div>'
                    }
                </div>
            </div>
        </div>
    `;

    // Crear gráficos específicos
    if (data.preguntas && data.preguntas.length > 0) {
        data.preguntas.forEach(pregunta => {
            crearGraficoEspecifico(pregunta);
        });
    }
}

// Función para actualizar breadcrumb
function actualizarBreadcrumb() {
    const breadcrumb = document.querySelector('.breadcrumb-dashboard .breadcrumb');
    if (!breadcrumb) {
        console.warn('Breadcrumb element not found, skipping update');
        return;
    }

    breadcrumb.innerHTML = '';

    breadcrumbHistory.forEach((item, index) => {
        const li = document.createElement('li');
        li.className = 'breadcrumb-item' + (index === breadcrumbHistory.length - 1 ? ' active' : '');

        if (index === 0) {
            li.innerHTML = '<a href="' + base_url('dashboard/estadisticas') + '"><i class="fas fa-home me-1"></i>' + item + '</a>';
        } else {
            li.textContent = item;
        }

        breadcrumb.appendChild(li);
    });

    // Actualizar el título de la página si existe
    const pageTitle = document.querySelector('title');
    if (pageTitle && breadcrumbHistory.length > 1) {
        const currentPage = breadcrumbHistory[breadcrumbHistory.length - 1];
        pageTitle.textContent = currentPage + ' - Sistema Estadístico Pro';
    }
}

// Función para verificar si una respuesta es JSON válido
function esJsonValido(str) {
    try {
        JSON.parse(str);
        return true;
    } catch (e) {
        return false;
    }
}

// Event listeners principales
document.addEventListener('DOMContentLoaded', function() {
    // Event listeners para botones de reinos
    const reinoBtns = document.querySelectorAll('.reino-btn');
    if (reinoBtns.length > 0) {
        reinoBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const reinoId = this.dataset.reinoId;
                const reinoNombre = this.dataset.reinoNombre;
                if (reinoId && reinoNombre) {
                    cargarModulosReino(reinoId, reinoNombre);
                } else {
                    console.error('Datos del reino no encontrados');
                }
            });
        });
    }

    // Inicializar tooltips de Bootstrap
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>