<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h2 mb-1">
                    <i class="fas fa-chart-line me-3 text-gradient"></i>
                    Vista Específica
                </h1>
                <p class="text-muted mb-0">Análisis detallado de datos específicos</p>
            </div>
            <div class="d-flex align-items-center">
                <div class="user-info me-3 text-end">
                    <div class="fw-semibold"><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Usuario'); ?></div>
                    <small class="text-muted"><?php echo strtoupper($_SESSION['user_role'] ?? 'BASICO'); ?></small>
                </div>
                <div class="user-avatar">
                    <i class="fas fa-user-circle fa-2x text-primary"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Contenido específico según el contexto -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-search me-2"></i>
                    Análisis Específico
                </h5>
            </div>
            <div class="card-body">
                <div class="text-center py-5">
                    <i class="fas fa-chart-area fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">Vista de análisis específico</h5>
                    <p class="text-muted">Esta vista mostrará análisis detallados según el contexto seleccionado.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('Vista específica cargada correctamente');
});
</script>