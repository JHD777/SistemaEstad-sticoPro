<?php
/**
 * Vista de Especie - Sistema Estadístico Pro
 * Muestra datos detallados de una especie específica
 */

// Verificar permisos básicos
if (!isset($_SESSION['user_role'])) {
    $_SESSION['user_role'] = 'basico'; // Usuario público
}

$page_title = 'Especie: ' . htmlspecialchars($especie['nombre']);
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-seedling me-2 text-info"></i>
                    Especie: <?php echo htmlspecialchars($especie['nombre']); ?>
                </h2>
                <p class="text-muted mt-1"><?php echo htmlspecialchars($especie['descripcion'] ?? 'Información detallada de la especie'); ?></p>
            </div>
            <div>
                <?php
                // Obtener el módulo padre para el botón de volver
                $moduloPadre = $this->especieModel->obtenerPorId($especie['parent_id']);
                if ($moduloPadre) {
                    echo '<a href="' . base_url('dashboard/modulo/' . $moduloPadre['id']) . '" class="btn btn-outline-secondary me-2">
                            <i class="fas fa-arrow-left me-1"></i>Volver al Módulo
                        </a>';
                }
                ?>
                <a href="<?php echo base_url('dashboard/general'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-home me-1"></i>Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Estadísticas de la Especie -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Censos Realizados
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo count($estadisticas); ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Formularios Activos
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo count($formularios); ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Preguntas Totales
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $totalPreguntas = 0;
                            if ($datos_especie && isset($datos_especie['preguntas'])) {
                                $totalPreguntas = count($datos_especie['preguntas']);
                            }
                            echo $totalPreguntas;
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-question-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Último Censo
                        </div>
                        <div class="h6 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $ultimaFecha = null;
                            if (!empty($estadisticas)) {
                                foreach ($estadisticas as $censo) {
                                    if (!$ultimaFecha || $censo['fecha_censo'] > $ultimaFecha) {
                                        $ultimaFecha = $censo['fecha_censo'];
                                    }
                                }
                            }
                            echo $ultimaFecha ? date('d/m/Y', strtotime($ultimaFecha)) : 'Sin datos';
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Formularios de la Especie -->
<?php if (!empty($formularios)): ?>
<div class="row mb-4">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-info">
                    <i class="fas fa-file-alt me-2"></i>Formularios Disponibles
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php foreach ($formularios as $formulario): ?>
                        <div class="col-md-6 col-lg-4 mb-3">
                            <div class="card border-left-info h-100">
                                <div class="card-body">
                                    <h6 class="card-title">
                                        <i class="fas fa-file-alt text-info me-2"></i>
                                        <?php echo htmlspecialchars($formulario['nombre']); ?>
                                    </h6>
                                    <p class="card-text small text-gray-600">
                                        <?php echo htmlspecialchars($formulario['descripcion'] ?? 'Sin descripción'); ?>
                                    </p>
                                    <div class="small text-muted mb-2">
                                        <i class="fas fa-calendar me-1"></i>
                                        Creado: <?php echo date('d/m/Y', strtotime($formulario['fecha_creacion'])); ?>
                                    </div>
                                    <?php if (hasPermission($_SESSION['user_role'] ?? 'basico', 'census.create')): ?>
                                        <a href="<?php echo base_url('formularios/responder/' . $formulario['id']); ?>" class="btn btn-info btn-sm w-100">
                                            <i class="fas fa-plus me-1"></i>Realizar Censo
                                        </a>
                                    <?php else: ?>
                                        <div class="alert alert-info py-2 small">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Requiere permisos de administrador para realizar censos.
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Gráficos y Datos Estadísticos -->
<?php if ($datos_especie && !empty($datos_especie['preguntas'])): ?>
<div class="row">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-info">
                    <i class="fas fa-chart-bar me-2"></i>Datos Estadísticos de <?php echo htmlspecialchars($especie['nombre']); ?>
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php foreach ($datos_especie['preguntas'] as $index => $pregunta): ?>
                        <div class="col-md-6 mb-4">
                            <div class="card h-100">
                                <div class="card-header">
                                    <h6 class="mb-0">
                                        <i class="fas fa-question-circle text-info me-2"></i>
                                        <?php echo htmlspecialchars($pregunta['texto_pregunta']); ?>
                                    </h6>
                                    <small class="text-muted">
                                        Tipo: <?php echo htmlspecialchars($pregunta['tipo_pregunta']); ?>
                                    </small>
                                </div>
                                <div class="card-body">
                                    <canvas id="chart-especie-<?php echo $index; ?>" width="400" height="300"></canvas>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="row">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-body text-center py-5">
                <i class="fas fa-chart-bar fa-3x text-gray-300 mb-3"></i>
                <h5 class="text-gray-500">No hay datos estadísticos disponibles</h5>
                <p class="text-gray-400">
                    Aún no se han realizado censos para esta especie o no hay formularios activos.
                </p>
                <?php if (hasPermission($_SESSION['user_role'] ?? 'basico', 'forms.create')): ?>
                    <a href="<?php echo base_url('formularios/crear'); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i>Crear Formulario
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Lista de Censos Recientes -->
<?php if (!empty($estadisticas)): ?>
<div class="row mt-4">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-info">
                    <i class="fas fa-history me-2"></i>Censos Recientes
                </h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Ubicación</th>
                                <th>Administrador</th>
                                <th>Observaciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach (array_slice($estadisticas, 0, 10) as $censo): ?>
                                <tr>
                                    <td><?php echo date('d/m/Y H:i', strtotime($censo['fecha_censo'])); ?></td>
                                    <td><?php echo htmlspecialchars($censo['ubicacion_geo'] ?? 'No especificada'); ?></td>
                                    <td><?php echo htmlspecialchars($censo['admin_nombre'] ?? 'Desconocido'); ?></td>
                                    <td><?php echo htmlspecialchars($censo['observaciones'] ?? 'Sin observaciones'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Funcionalidad para gráficos
document.addEventListener('DOMContentLoaded', function() {
    <?php if ($datos_especie && !empty($datos_especie['preguntas'])): ?>
        <?php foreach ($datos_especie['preguntas'] as $index => $pregunta): ?>
            crearGraficoEspecie(<?php echo $index; ?>, <?php echo json_encode($pregunta); ?>, <?php echo json_encode($datos_especie['estadisticas'][$pregunta['id']] ?? []); ?>);
        <?php endforeach; ?>
    <?php endif; ?>
});

function crearGraficoEspecie(index, pregunta, estadisticas) {
    const canvas = document.getElementById('chart-especie-' + index);
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    // Configurar datos según el tipo de pregunta
    let chartData = {};
    let chartType = 'bar';

    switch (pregunta.tipo_pregunta) {
        case 'numero':
            chartData = {
                labels: ['Mínimo', 'Promedio', 'Máximo'],
                datasets: [{
                    label: 'Valores Numéricos',
                    data: [
                        estadisticas.datos?.minimo || 0,
                        estadisticas.datos?.promedio || 0,
                        estadisticas.datos?.maximo || 0
                    ],
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            };
            break;

        case 'booleano':
            chartType = 'pie';
            chartData = {
                labels: ['Sí', 'No'],
                datasets: [{
                    label: 'Respuestas',
                    data: [
                        estadisticas.datos?.positivas || 0,
                        estadisticas.datos?.negativas || 0
                    ],
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.5)',
                        'rgba(255, 99, 132, 0.5)'
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                        'rgba(255, 99, 132, 1)'
                    ],
                    borderWidth: 1
                }]
            };
            break;

        case 'opcion_multiple':
            chartData = {
                labels: Object.keys(estadisticas.datos || {}),
                datasets: [{
                    label: 'Frecuencia',
                    data: Object.values(estadisticas.datos || {}),
                    backgroundColor: 'rgba(153, 102, 255, 0.5)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            };
            break;

        default:
            chartData = {
                labels: ['Sin datos'],
                datasets: [{
                    label: 'Sin información',
                    data: [0],
                    backgroundColor: 'rgba(200, 200, 200, 0.5)',
                    borderColor: 'rgba(200, 200, 200, 1)',
                    borderWidth: 1
                }]
            };
    }

    new Chart(ctx, {
        type: chartType,
        data: chartData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: pregunta.texto_pregunta || 'Estadística'
                }
            }
        }
    });
}
</script>