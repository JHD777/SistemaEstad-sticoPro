<?php
/**
 * Sistema Estadístico Pro - Página de Contacto
 * Información de contacto del sistema
 */
?>
<div class="page-header">
    <h1><?php echo $titulo ?? 'Contacto - Sistema Estadístico Pro'; ?></h1>
    <div class="subtitle">Información de contacto y soporte técnico</div>
</div>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h2 class="card-title mb-0">
                        <i class="fas fa-address-book me-2"></i>
                        Información de Contacto
                    </h2>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="text-center mb-4">
                                <img src="<?php echo base_url('assets/images/logo.png'); ?>"
                                     alt="Logo Sistema Estadístico Pro"
                                     class="img-fluid rounded mb-3"
                                     style="max-width: 200px;">
                                <h3>Sistema Estadístico Pro</h3>
                                <p class="text-muted">Sistema avanzado para la gestión y análisis de datos estadísticos</p>
                            </div>

                            <div class="contact-info">
                                <div class="mb-3">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-envelope text-primary me-3 fa-lg"></i>
                                        <div>
                                            <strong>Email:</strong><br>
                                            <a href="mailto:<?php echo htmlspecialchars($email ?? 'contacto@sistema-estadistico-pro.com'); ?>">
                                                <?php echo htmlspecialchars($email ?? 'contacto@sistema-estadistico-pro.com'); ?>
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-phone text-success me-3 fa-lg"></i>
                                        <div>
                                            <strong>Teléfono:</strong><br>
                                            <?php echo htmlspecialchars($telefono ?? '+591 123 4567'); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-map-marker-alt text-danger me-3 fa-lg"></i>
                                        <div>
                                            <strong>Dirección:</strong><br>
                                            <?php echo htmlspecialchars($direccion ?? 'La Paz, Bolivia'); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-clock text-warning me-3 fa-lg"></i>
                                        <div>
                                            <strong>Horario de Atención:</strong><br>
                                            Lunes a Viernes: 8:00 - 18:00<br>
                                            Sábados: 9:00 - 12:00
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="card border-info">
                                <div class="card-header bg-info text-white">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-comments me-2"></i>
                                        ¿Necesitas Ayuda?
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <p>Si tienes preguntas sobre el funcionamiento del sistema, problemas técnicos o necesitas soporte, no dudes en contactarnos.</p>

                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle me-2"></i>
                                        <strong>Tipos de Soporte:</strong>
                                        <ul class="mb-0 mt-2">
                                            <li>Soporte técnico</li>
                                            <li>Consultas sobre funcionalidades</li>
                                            <li>Reporte de errores</li>
                                            <li>Solicitudes de mejoras</li>
                                        </ul>
                                    </div>

                                    <div class="mt-3">
                                        <h6><i class="fas fa-question-circle me-2"></i>Preguntas Frecuentes</h6>
                                        <div class="accordion" id="faqAccordion">
                                            <div class="accordion-item">
                                                <h2 class="accordion-header" id="headingOne">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                                                        ¿Cómo creo un nuevo formulario?
                                                    </button>
                                                </h2>
                                                <div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                                    <div class="accordion-body">
                                                        Para crear un formulario, necesitas permisos de administrador. Ve a la sección "Formularios" y haz clic en "Crear Nuevo".
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="accordion-item">
                                                <h2 class="accordion-header" id="headingTwo">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">
                                                        ¿Cómo cambio mi contraseña?
                                                    </button>
                                                </h2>
                                                <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                                    <div class="accordion-body">
                                                        Ve a tu perfil de usuario y selecciona la opción "Cambiar contraseña". Se te pedirá tu contraseña actual y la nueva.
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="accordion-item">
                                                <h2 class="accordion-header" id="headingThree">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree">
                                                        ¿Cómo exporto mis datos?
                                                    </button>
                                                </h2>
                                                <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                                                    <div class="accordion-body">
                                                        Los usuarios registrados pueden exportar datos desde el dashboard principal usando los botones de exportación disponibles.
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-center">
                    <small class="text-muted">
                        © <?php echo date('Y'); ?> Sistema Estadístico Pro. Todos los derechos reservados.
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Inicializar los acordeones de Bootstrap
document.addEventListener('DOMContentLoaded', function() {
    // Los acordeones ya funcionan con Bootstrap 5, no necesita inicialización adicional
});
</script>

<!-- El footer ya está incluido en el layout público -->