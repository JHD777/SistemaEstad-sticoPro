<?php
/**
 * Sistema Estadístico Pro - Dashboard General
 * Vista principal del dashboard con navegación jerárquica
 */

// Verificar permisos
if (!isset($_SESSION['user_role'])) {
    header('Location: ' . base_url('login'));
    exit;
}
?>

<div class="dashboard-container">
    <!-- Header del Dashboard -->
    <div class="dashboard-header mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h1 class="dashboard-title">
                    <i class="fas fa-chart-line me-3 text-primary"></i>
                    Centro Estadístico Pro
                </h1>
                <p class="dashboard-subtitle text-muted mb-0">
                    Análisis y visualización de datos censales de flora y fauna
                </p>
            </div>
            <div class="dashboard-actions">
                <!-- Botones eliminados - solo queda el panel principal -->
            </div>
        </div>
    </div>

    <!-- Breadcrumb de navegación -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb breadcrumb-dashboard">
            <li class="breadcrumb-item active" aria-current="page">
                <i class="fas fa-home me-1"></i>Inicio
            </li>
        </ol>
    </nav>

    <!-- Contenedor principal del dashboard -->
    <div class="dashboard-content">
        <!-- Panel Principal del Dashboard -->
        <div id="vistaGeneral" class="dashboard-view">
            <div class="row">
                <div class="col-12">
                    <div class="section-header mb-4">
                        <h2 class="section-title">
                            <i class="fas fa-tachometer-alt me-2 text-primary"></i>
                            Panel de Control - <?php echo htmlspecialchars($_SESSION['user_role'] ?? 'Usuario'); ?>
                        </h2>
                        <p class="section-description text-muted">
                            Accede rápidamente a todas las funciones del sistema
                        </p>
                    </div>

                    <!-- Accesos Rápidos -->
                    <div class="row g-4 mb-5">
                        <!-- Centro Estadístico -->
                        <div class="col-lg-3 col-md-6">
                            <div class="card action-card h-100 shadow-sm hover-lift">
                                <div class="card-body text-center p-4">
                                    <div class="action-icon mb-3">
                                        <i class="fas fa-chart-line fa-3x text-success"></i>
                                    </div>
                                    <h5 class="card-title">Centro Estadístico</h5>
                                    <p class="card-text text-muted small">Visualiza datos censales y estadísticas</p>
                                    <button class="btn btn-success btn-lg w-100" onclick="mostrarPanelEstadisticas()">
                                        <i class="fas fa-chart-bar me-2"></i>Ver Estadísticas
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Realizar Censo -->
                        <div class="col-lg-3 col-md-6">
                            <div class="card action-card h-100 shadow-sm hover-lift">
                                <div class="card-body text-center p-4">
                                    <div class="action-icon mb-3">
                                        <i class="fas fa-clipboard-check fa-3x text-primary"></i>
                                    </div>
                                    <h5 class="card-title">Realizar Censo</h5>
                                    <p class="card-text text-muted small">Captura nuevos datos de especies</p>
                                    <a href="<?php echo base_url('formularios'); ?>" class="btn btn-primary btn-lg w-100">
                                        <i class="fas fa-plus me-2"></i>Nuevo Censo
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Gestionar Especies -->
                        <div class="col-lg-3 col-md-6">
                            <div class="card action-card h-100 shadow-sm hover-lift">
                                <div class="card-body text-center p-4">
                                    <div class="action-icon mb-3">
                                        <i class="fas fa-leaf fa-3x text-warning"></i>
                                    </div>
                                    <h5 class="card-title">Gestionar Especies</h5>
                                    <p class="card-text text-muted small">Administra especies y módulos</p>
                                    <a href="<?php echo base_url('especies'); ?>" class="btn btn-warning btn-lg w-100">
                                        <i class="fas fa-cogs me-2"></i>Ver Especies
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Gestionar Usuarios -->
                        <?php if (($_SESSION['user_role'] ?? 'basico') === 'supremo'): ?>
                        <div class="col-lg-3 col-md-6">
                            <div class="card action-card h-100 shadow-sm hover-lift">
                                <div class="card-body text-center p-4">
                                    <div class="action-icon mb-3">
                                        <i class="fas fa-users fa-3x text-danger"></i>
                                    </div>
                                    <h5 class="card-title">Gestionar Usuarios</h5>
                                    <p class="card-text text-muted small">Administra usuarios del sistema</p>
                                    <a href="<?php echo base_url('usuarios'); ?>" class="btn btn-danger btn-lg w-100">
                                        <i class="fas fa-user-cog me-2"></i>Ver Usuarios
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Estadísticas del Sistema - Eliminadas -->
                </div>
            </div>
        </div>


        <!-- Contenedores eliminados - ya no hay vistas dinámicas -->
    </div>
</div>

<!-- Modal para loading -->
<div class="modal fade" id="loadingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center p-4">
                <div class="spinner-border text-primary mb-3" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
                <h5>Cargando datos...</h5>
                <p class="text-muted mb-0">Por favor espera mientras procesamos la información</p>
            </div>
        </div>
    </div>
</div>

<style>
/* Estilos del Dashboard */
.dashboard-container {
    min-height: 80vh;
}

.dashboard-header {
    border-bottom: 2px solid #e9ecef;
    padding-bottom: 1rem;
}

.dashboard-title {
    color: #2c3e50;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

.dashboard-subtitle {
    font-size: 1.1rem;
}

.dashboard-actions .btn {
    border-radius: 25px;
    padding: 0.5rem 1.5rem;
    font-weight: 500;
}

.breadcrumb-dashboard {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 10px;
    padding: 0.75rem 1rem;
}

.breadcrumb-dashboard .breadcrumb-item {
    color: rgba(255, 255, 255, 0.8);
}

.breadcrumb-dashboard .breadcrumb-item.active {
    color: white;
    font-weight: 500;
}

.reino-card {
    border: none;
    border-radius: 15px;
    transition: all 0.3s ease;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
}

.reino-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.15) !important;
}

.reino-icon {
    opacity: 0.8;
}

.reino-card:hover .reino-icon {
    opacity: 1;
    transform: scale(1.1);
    transition: all 0.3s ease;
}

.reino-stats {
    background: rgba(255, 255, 255, 0.7);
    border-radius: 10px;
    padding: 1rem;
    margin: 1rem 0;
}

.stat-number {
    font-size: 1.8rem;
    font-weight: bold;
    color: #495057;
    display: block;
}

.stat-label {
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.reino-btn {
    border-radius: 25px;
    padding: 0.75rem 2rem;
    font-weight: 600;
    transition: all 0.3s ease;
}

.reino-btn:hover {
    transform: scale(1.05);
}

.section-header {
    text-align: center;
}

.section-title {
    color: #2c3e50;
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.section-description {
    font-size: 1rem;
}

/* Animaciones */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.dashboard-view {
    animation: fadeInUp 0.5s ease-out;
}

.hover-lift {
    transition: all 0.3s ease;
}

.hover-lift:hover {
    transform: translateY(-3px);
}

/* Responsive */
@media (max-width: 768px) {
    .dashboard-title {
        font-size: 1.8rem;
    }

    .reino-card {
        margin-bottom: 1rem;
    }

    .reino-icon .fa-4x {
        font-size: 3rem;
    }
}
</style>

<script>
// Función helper para base_url (ya que no está disponible en JS)
function base_url(path = '') {
    return 'https://sistema_estadistico_pro.test/' + path.replace(/^\//, '');
}

// Función eliminada - ahora usa enlace directo

// Variables eliminadas - ya no hay vistas dinámicas

// Funciones eliminadas - solo queda el panel principal

// Funciones eliminadas - solo queda el panel principal

// Event listeners principales
document.addEventListener('DOMContentLoaded', function() {
    // Funciones de cambio de vista eliminadas

    // Funciones de filtros eliminadas

    // Inicializar tooltips de Bootstrap
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

// Funciones eliminadas - solo queda el panel principal

    // Funciones eliminadas - solo queda el panel principal
});
</script>