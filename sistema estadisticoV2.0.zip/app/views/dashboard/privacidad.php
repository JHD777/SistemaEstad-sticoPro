<?php
/**
 * Sistema Estadístico Pro - Página de Política de Privacidad
 * Información sobre el manejo de datos personales
 */
?>
<div class="page-header">
    <h1><?php echo $titulo ?? 'Política de Privacidad - Sistema Estadístico Pro'; ?></h1>
    <div class="subtitle">Información sobre el manejo y protección de datos personales</div>
</div>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h2 class="card-title mb-0">
                        <i class="fas fa-shield-alt me-2"></i>
                        Política de Privacidad
                    </h2>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="fas fa-calendar-alt me-2"></i>
                        <strong>Última actualización:</strong> <?php echo htmlspecialchars($ultima_actualizacion ?? date('d/m/Y')); ?>
                    </div>

                    <h3>1. Información General</h3>
                    <p>En Sistema Estadístico Pro, nos comprometemos a proteger la privacidad y seguridad de los datos personales de nuestros usuarios. Esta política describe cómo recopilamos, utilizamos y protegemos su información.</p>

                    <h3>2. Información que Recopilamos</h3>
                    <p>Recopilamos diferentes tipos de información para proporcionar y mejorar nuestros servicios:</p>

                    <h4>2.1 Información Personal</h4>
                    <ul>
                        <li>Nombre completo y datos de contacto</li>
                        <li>Dirección de correo electrónico</li>
                        <li>Información de la cuenta de usuario</li>
                        <li>Credenciales de acceso (encriptadas)</li>
                    </ul>

                    <h4>2.2 Información de Uso</h4>
                    <ul>
                        <li>Registros de actividad dentro del sistema</li>
                        <li>Formularios creados y respuestas registradas</li>
                        <li>Datos estadísticos y análisis generados</li>
                        <li>Información técnica del dispositivo y navegador</li>
                    </ul>

                    <h4>2.3 Datos Científicos</h4>
                    <ul>
                        <li>Información sobre especies biológicas</li>
                        <li>Datos de censos y formularios</li>
                        <li>Resultados de análisis estadísticos</li>
                        <li>Metadatos asociados a los registros</li>
                    </ul>

                    <h3>3. Cómo Utilizamos la Información</h3>
                    <p>Utilizamos la información recopilada para:</p>
                    <ul>
                        <li>Proporcionar y mantener el funcionamiento del sistema</li>
                        <li>Gestionar cuentas de usuario y permisos</li>
                        <li>Procesar y almacenar datos científicos</li>
                        <li>Generar reportes y análisis estadísticos</li>
                        <li>Mejorar la funcionalidad y seguridad del sistema</li>
                        <li>Comunicarnos con los usuarios cuando sea necesario</li>
                    </ul>

                    <h3>4. Compartir Información</h3>
                    <p>No vendemos, comercializamos ni transferimos información personal a terceros, excepto en los siguientes casos:</p>
                    <ul>
                        <li>Con consentimiento explícito del usuario</li>
                        <li>Para cumplir con obligaciones legales</li>
                        <li>Para proteger nuestros derechos y seguridad</li>
                        <li>En relación con una fusión o adquisición de la empresa</li>
                    </ul>

                    <h3>5. Seguridad de los Datos</h3>
                    <p>Implementamos medidas de seguridad técnicas, administrativas y físicas para proteger su información:</p>
                    <ul>
                        <li>Encriptación de datos sensibles</li>
                        <li>Acceso restringido basado en roles</li>
                        <li>Monitoreo continuo de actividades sospechosas</li>
                        <li>Copias de seguridad regulares</li>
                        <li>Actualizaciones de seguridad periódicas</li>
                    </ul>

                    <h3>6. Retención de Datos</h3>
                    <p>Mantenemos la información mientras:</p>
                    <ul>
                        <li>Sea necesaria para proporcionar nuestros servicios</li>
                        <li>El usuario mantenga una cuenta activa</li>
                        <li>Sea requerida por obligaciones legales</li>
                        <li>Sea necesaria para fines legítimos de negocio</li>
                    </ul>

                    <h3>7. Derechos del Usuario</h3>
                    <p>Los usuarios tienen derecho a:</p>
                    <ul>
                        <li>Acceder a sus datos personales</li>
                        <li>Corregir información inexacta</li>
                        <li>Solicitar la eliminación de datos</li>
                        <li>Restringir el procesamiento de datos</li>
                        <li>Exportar sus datos en formato estándar</li>
                        <li>Oponerse al procesamiento de datos</li>
                    </ul>

                    <h3>8. Cookies y Tecnologías Similares</h3>
                    <p>Utilizamos cookies y tecnologías similares para:</p>
                    <ul>
                        <li>Mantener sesiones de usuario activas</li>
                        <li>Recordar preferencias del usuario</li>
                        <li>Analizar el uso del sistema</li>
                        <li>Mejorar la experiencia del usuario</li>
                    </ul>

                    <h3>9. Enlaces a Terceros</h3>
                    <p>Nuestro sistema puede contener enlaces a sitios web de terceros. No somos responsables por las prácticas de privacidad de estos sitios externos.</p>

                    <h3>10. Menores de Edad</h3>
                    <p>Nuestro sistema no está dirigido a menores de 18 años. No recopilamos intencionalmente información personal de menores sin consentimiento parental.</p>

                    <h3>11. Cambios a esta Política</h3>
                    <p>Podemos actualizar esta política periódicamente. Notificaremos a los usuarios sobre cambios significativos a través del sistema o por correo electrónico.</p>

                    <h3>12. Información de Contacto</h3>
                    <p>Para preguntas sobre esta política de privacidad, contacte a:</p>
                    <ul>
                        <li><strong>Responsable de Privacidad:</strong> Sistema Estadístico Pro</li>
                        <li><strong>Email:</strong> privacidad@sistema-estadistico-pro.com</li>
                        <li><strong>Dirección:</strong> La Paz, Bolivia</li>
                    </ul>

                    <div class="alert alert-success mt-4">
                        <i class="fas fa-check-circle me-2"></i>
                        <strong>Compromiso:</strong> Nos comprometemos a proteger su privacidad y utilizar su información únicamente para los fines descritos en esta política.
                    </div>

                    <h3>13. Consentimiento</h3>
                    <p>Al utilizar Sistema Estadístico Pro, usted consiente con la recopilación y uso de su información según lo establecido en esta política de privacidad.</p>

                    <div class="text-center mt-4">
                        <small class="text-muted">
                            Esta política cumple con estándares internacionales de protección de datos y las leyes aplicables en Bolivia.
                        </small>
                    </div>
                </div>
                <div class="card-footer text-center">
                    <small class="text-muted">
                        © <?php echo date('Y'); ?> Sistema Estadístico Pro. Todos los derechos reservados.
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- El footer ya está incluido en el layout público -->