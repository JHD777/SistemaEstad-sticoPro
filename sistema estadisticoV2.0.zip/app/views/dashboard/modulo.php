<?php
/**
 * Vista de Módulo - Sistema Estadístico Pro
 * Muestra las especies de un módulo específico
 */

// Verificar permisos básicos
if (!isset($_SESSION['user_role'])) {
    $_SESSION['user_role'] = 'basico'; // Usuario público
}

$page_title = 'Módulo: ' . htmlspecialchars($modulo['nombre']);
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-folder me-2 text-success"></i>
                    Módulo: <?php echo htmlspecialchars($modulo['nombre']); ?>
                </h2>
                <p class="text-muted mt-1"><?php echo htmlspecialchars($modulo['descripcion'] ?? 'Información del módulo biológico'); ?></p>
            </div>
            <div>
                <a href="<?php echo base_url('dashboard/reino/' . $modulo['parent_id']); ?>" class="btn btn-outline-secondary me-2">
                    <i class="fas fa-arrow-left me-1"></i>Volver al Reino
                </a>
                <a href="<?php echo base_url('dashboard/general'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-home me-1"></i>Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Estadísticas del Módulo -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Especies
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo count($especies); ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-leaf fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Censos Realizados
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $totalCensos = 0;
                            foreach ($especies as $especie) {
                                $censos = $this->registroModel->obtenerPorEspecie($especie['id']);
                                $totalCensos += count($censos);
                            }
                            echo $totalCensos;
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Formularios Activos
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $totalFormularios = 0;
                            foreach ($especies as $especie) {
                                $formularios = $this->formularioModel->obtenerAprobadosPorEspecie($especie['id']);
                                $totalFormularios += count($formularios);
                            }
                            echo $totalFormularios;
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-file-alt fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Último Censo
                        </div>
                        <div class="h6 mb-0 font-weight-bold text-gray-800">
                            <?php
                            $ultimaFecha = null;
                            foreach ($especies as $especie) {
                                $censos = $this->registroModel->obtenerPorEspecie($especie['id']);
                                if (!empty($censos)) {
                                    $fecha = $censos[0]['fecha_censo'];
                                    if (!$ultimaFecha || $fecha > $ultimaFecha) {
                                        $ultimaFecha = $fecha;
                                    }
                                }
                            }
                            echo $ultimaFecha ? date('d/m/Y', strtotime($ultimaFecha)) : 'Sin datos';
                            ?>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Especies del Módulo -->
<div class="row">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-success">
                    <i class="fas fa-leaf me-2"></i>Especies de <?php echo htmlspecialchars($modulo['nombre']); ?>
                </h6>
            </div>
            <div class="card-body">
                <?php if (empty($especies)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-leaf fa-3x text-gray-300 mb-3"></i>
                        <h5 class="text-gray-500">No hay especies registradas</h5>
                        <p class="text-gray-400">Este módulo aún no tiene especies definidas.</p>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($especies as $especie): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100 border-left-info shadow-sm">
                                    <div class="card-body">
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="bg-info text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                                <i class="fas fa-seedling"></i>
                                            </div>
                                            <div class="ms-3">
                                                <h6 class="card-title mb-0">
                                                    <a href="<?php echo base_url('dashboard/especie/' . $especie['id']); ?>" class="text-decoration-none text-dark">
                                                        <?php echo htmlspecialchars($especie['nombre']); ?>
                                                    </a>
                                                </h6>
                                                <small class="text-muted">Especie</small>
                                            </div>
                                        </div>

                                        <p class="card-text small text-gray-600 mb-3">
                                            <?php echo htmlspecialchars($especie['descripcion'] ?? 'Sin descripción'); ?>
                                        </p>

                                        <?php
                                        $censos = $this->registroModel->obtenerPorEspecie($especie['id']);
                                        $totalCensos = count($censos);
                                        $formularios = $this->formularioModel->obtenerAprobadosPorEspecie($especie['id']);
                                        $totalFormularios = count($formularios);
                                        ?>

                                        <div class="row text-center mb-3">
                                            <div class="col-6">
                                                <div class="small text-gray-500">Censos</div>
                                                <div class="h6 mb-0 text-info"><?php echo $totalCensos; ?></div>
                                            </div>
                                            <div class="col-6">
                                                <div class="small text-gray-500">Formularios</div>
                                                <div class="h6 mb-0 text-warning"><?php echo $totalFormularios; ?></div>
                                            </div>
                                        </div>

                                        <div class="mt-3">
                                            <a href="<?php echo base_url('dashboard/especie/' . $especie['id']); ?>" class="btn btn-info btn-sm w-100">
                                                <i class="fas fa-eye me-1"></i>Ver Detalles
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Gráficos de Datos del Módulo -->
<div class="row mt-4">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-success">
                    <i class="fas fa-chart-bar me-2"></i>Datos Estadísticos del Módulo <?php echo htmlspecialchars($modulo['nombre']); ?>
                </h6>
            </div>
            <div class="card-body">
                <?php if (!empty($estadisticas_modulo)): ?>
                    <div class="row">
                        <?php foreach ($estadisticas_modulo as $preguntaId => $estadistica): ?>
                            <div class="col-md-6 mb-4">
                                <div class="card h-100">
                                    <div class="card-header">
                                        <h6 class="mb-0">
                                            <i class="fas fa-question-circle text-success me-2"></i>
                                            <?php echo htmlspecialchars($estadistica['pregunta']['texto_pregunta']); ?>
                                        </h6>
                                        <small class="text-muted">
                                            Tipo: <?php echo htmlspecialchars($estadistica['pregunta']['tipo_pregunta']); ?>
                                        </small>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="chart-modulo-<?php echo $preguntaId; ?>" width="400" height="300"></canvas>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        No hay datos estadísticos disponibles para este módulo aún.
                        Los datos aparecerán cuando se realicen censos en las especies de este módulo.
                        <?php if (hasPermission($_SESSION['user_role'] ?? 'basico', 'forms.create')): ?>
                            <a href="<?php echo base_url('preguntas/crear'); ?>" class="alert-link">Crear preguntas base</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
// Funcionalidad para gráficos del módulo
document.addEventListener('DOMContentLoaded', function() {
    <?php
    if (!empty($estadisticas_modulo)):
        foreach ($estadisticas_modulo as $preguntaId => $estadistica):
    ?>
            crearGraficoModulo(<?php echo $preguntaId; ?>, <?php echo json_encode($estadistica['pregunta']); ?>, <?php echo json_encode($estadistica['datos']); ?>);
    <?php
        endforeach;
    endif;
    ?>
});

function crearGraficoModulo(index, pregunta, estadisticas) {
    const canvas = document.getElementById('chart-modulo-' + index);
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    // Configurar datos según el tipo de pregunta
    let chartData = {};
    let chartType = 'bar';

    switch (pregunta.tipo_pregunta) {
        case 'numero':
            chartData = {
                labels: ['Mínimo', 'Promedio', 'Máximo'],
                datasets: [{
                    label: 'Valores Numéricos',
                    data: [
                        estadisticas.datos?.minimo || 0,
                        estadisticas.datos?.promedio || 0,
                        estadisticas.datos?.maximo || 0
                    ],
                    backgroundColor: 'rgba(40, 167, 69, 0.5)',
                    borderColor: 'rgba(40, 167, 69, 1)',
                    borderWidth: 1
                }]
            };
            break;

        case 'booleano':
            chartType = 'pie';
            chartData = {
                labels: ['Sí', 'No'],
                datasets: [{
                    label: 'Respuestas',
                    data: [
                        estadisticas.datos?.respuestas_positivas || 0,
                        estadisticas.datos?.respuestas_negativas || 0
                    ],
                    backgroundColor: [
                        'rgba(23, 162, 184, 0.5)',
                        'rgba(255, 193, 7, 0.5)'
                    ],
                    borderColor: [
                        'rgba(23, 162, 184, 1)',
                        'rgba(255, 193, 7, 1)'
                    ],
                    borderWidth: 1
                }]
            };
            break;

        case 'opcion_multiple':
            chartData = {
                labels: Object.keys(estadisticas.datos || {}),
                datasets: [{
                    label: 'Frecuencia',
                    data: Object.values(estadisticas.datos || {}),
                    backgroundColor: 'rgba(255, 99, 132, 0.5)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            };
            break;

        default:
            chartData = {
                labels: ['Sin datos'],
                datasets: [{
                    label: 'Sin información',
                    data: [0],
                    backgroundColor: 'rgba(108, 117, 125, 0.5)',
                    borderColor: 'rgba(108, 117, 125, 1)',
                    borderWidth: 1
                }]
            };
    }

    new Chart(ctx, {
        type: chartType,
        data: chartData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: pregunta.texto_pregunta || 'Estadística del Módulo'
                }
            }
        }
    });
}
</script>