<?php
/**
 * Dashboard Público - Sistema Estadístico Pro
 * Vista para usuarios básicos que acceden sin login
 */

// Verificar que no sea un usuario autenticado (deben usar el dashboard normal)
if (isset($_SESSION['user_id'])) {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}

// Usar el layout principal
$this->setLayout('main');
$page_title = 'Centro Estadístico Pro';
?>

<!-- Contenido principal del dashboard público -->

    <!-- Estadísticas Generales -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Reinos Registrados
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo count($estadisticas['reinos'] ?? []); ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-crown fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Especies Totales
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo $estadisticas['totalEspecies'] ?? 0; ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-leaf fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Formularios Activos
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo $estadisticas['totalFormularios'] ?? 0; ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Registros Censales
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo $estadisticas['totalRegistros'] ?? 0; ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-database fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Estadísticas Completas por Jerarquía -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-success">
                        <i class="fas fa-chart-line me-2"></i>
                        Estadísticas Completas por Nivel Jerárquico
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php
                        // Obtener estadísticas de todos los niveles
                        $especieModel = new Especie();
                        $formularioModel = new Formulario();
                        $registroModel = new RegistroCenso();
                        $respuestaModel = new Respuesta();
                        $preguntaModel = new Pregunta();

                        foreach ($reinos as $reino):
                            $modulosReino = $especieModel->obtenerModulos($reino['id']);
                            $totalEspeciesReino = 0;
                            $totalPreguntasReino = 0;
                            $totalRespuestasReino = 0;

                            foreach ($modulosReino as $modulo) {
                                $especiesModulo = $especieModel->obtenerEspecies($modulo['id']);
                                $totalEspeciesReino += count($especiesModulo);

                                foreach ($especiesModulo as $especie) {
                                    $formulariosEspecie = $formularioModel->obtenerAprobadosPorEspecie($especie['id']);
                                    if (!empty($formulariosEspecie)) {
                                        $preguntasEspecie = $preguntaModel->obtenerPorFormulario($formulariosEspecie[0]['id']);
                                        $totalPreguntasReino += count($preguntasEspecie);
                                        $censosEspecie = $registroModel->obtenerPorEspecie($especie['id']);
                                        $totalRespuestasReino += count($censosEspecie);
                                    }
                                }
                            }
                        ?>
                            <div class="col-md-6 mb-4">
                                <div class="card border-left-primary h-100">
                                    <div class="card-header">
                                        <h6 class="mb-0">
                                            <i class="fas fa-<?php echo $reino['nombre'] === 'Flora' ? 'leaf' : 'paw'; ?> text-primary me-2"></i>
                                            Reino: <?php echo htmlspecialchars($reino['nombre']); ?>
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="row text-center">
                                            <div class="col-4">
                                                <div class="small text-gray-500">Módulos</div>
                                                <div class="h5 mb-0 text-primary"><?php echo count($modulosReino); ?></div>
                                            </div>
                                            <div class="col-4">
                                                <div class="small text-gray-500">Especies</div>
                                                <div class="h5 mb-0 text-success"><?php echo $totalEspeciesReino; ?></div>
                                            </div>
                                            <div class="col-4">
                                                <div class="small text-gray-500">Preguntas</div>
                                                <div class="h5 mb-0 text-info"><?php echo $totalPreguntasReino; ?></div>
                                            </div>
                                        </div>
                                    
                                        <script>
                                        // Gráficos del dashboard público
                                        document.addEventListener('DOMContentLoaded', function() {
                                            // Datos para gráficos
                                            const datosReinos = {
                                                labels: [
                                                    <?php foreach ($reinos as $reino): ?>
                                                        '<?php echo addslashes($reino['nombre']); ?>',
                                                    <?php endforeach; ?>
                                                ],
                                                datasets: [{
                                                    label: 'Especies por Reino',
                                                    data: [
                                                        <?php
                                                        foreach ($reinos as $reino):
                                                            $modulos = $especieModel->obtenerModulos($reino['id']);
                                                            $totalEspecies = 0;
                                                            foreach ($modulos as $modulo) {
                                                                $especies = $especieModel->obtenerEspecies($modulo['id']);
                                                                $totalEspecies += count($especies);
                                                            }
                                                            echo $totalEspecies . ',';
                                                        endforeach;
                                                        ?>
                                                    ],
                                                    backgroundColor: [
                                                        'rgba(0, 123, 255, 0.5)',
                                                        'rgba(40, 167, 69, 0.5)',
                                                        'rgba(255, 193, 7, 0.5)',
                                                        'rgba(220, 53, 69, 0.5)'
                                                    ],
                                                    borderColor: [
                                                        'rgba(0, 123, 255, 1)',
                                                        'rgba(40, 167, 69, 1)',
                                                        'rgba(255, 193, 7, 1)',
                                                        'rgba(220, 53, 69, 1)'
                                                    ],
                                                    borderWidth: 1
                                                }]
                                            };
                                    
                                            // Gráfico de distribución por reinos
                                            const ctxReinos = document.getElementById('chart-reinos-general');
                                            if (ctxReinos) {
                                                new Chart(ctxReinos, {
                                                    type: 'pie',
                                                    data: datosReinos,
                                                    options: {
                                                        responsive: true,
                                                        plugins: {
                                                            legend: {
                                                                position: 'bottom',
                                                            },
                                                            title: {
                                                                display: true,
                                                                text: 'Distribución de Especies por Reino'
                                                            }
                                                        }
                                                    }
                                                });
                                            }
                                    
                                            // Gráfico de tipos de preguntas
                                            const ctxPreguntas = document.getElementById('chart-preguntas-general');
                                            if (ctxPreguntas) {
                                                const datosPreguntas = {
                                                    labels: ['Texto', 'Número', 'Booleano', 'Opción Múltiple', 'Fecha'],
                                                    datasets: [{
                                                        label: 'Tipos de Preguntas',
                                                        data: [
                                                            <?php
                                                            $tipos = ['texto' => 0, 'numero' => 0, 'booleano' => 0, 'opcion_multiple' => 0, 'fecha' => 0];
                                                            foreach ($reinos as $reino) {
                                                                $modulos = $especieModel->obtenerModulos($reino['id']);
                                                                foreach ($modulos as $modulo) {
                                                                    $especies = $especieModel->obtenerEspecies($modulo['id']);
                                                                    foreach ($especies as $especie) {
                                                                        $formularios = $formularioModel->obtenerAprobadosPorEspecie($especie['id']);
                                                                        if (!empty($formularios)) {
                                                                            $preguntas = $preguntaModel->obtenerPorFormulario($formularios[0]['id']);
                                                                            foreach ($preguntas as $pregunta) {
                                                                                if (isset($tipos[$pregunta['tipo_pregunta']])) {
                                                                                    $tipos[$pregunta['tipo_pregunta']]++;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            echo implode(',', array_values($tipos));
                                                            ?>
                                                        ],
                                                        backgroundColor: 'rgba(23, 162, 184, 0.5)',
                                                        borderColor: 'rgba(23, 162, 184, 1)',
                                                        borderWidth: 1
                                                    }]
                                                };
                                    
                                                new Chart(ctxPreguntas, {
                                                    type: 'bar',
                                                    data: datosPreguntas,
                                                    options: {
                                                        responsive: true,
                                                        plugins: {
                                                            legend: {
                                                                display: false
                                                            },
                                                            title: {
                                                                display: true,
                                                                text: 'Distribución de Tipos de Preguntas'
                                                            }
                                                        },
                                                        scales: {
                                                            y: {
                                                                beginAtZero: true
                                                            }
                                                        }
                                                    }
                                                });
                                            }
                                        });
                                        </script>
                                        <hr>
                                        <div class="text-center">
                                            <div class="small text-gray-500 mb-1">Respuestas Recolectadas</div>
                                            <div class="h4 mb-0 text-warning"><?php echo $totalRespuestasReino; ?></div>
                                        </div>
                                        <div class="mt-3">
                                            <a href="<?php echo base_url('dashboard/reino/' . $reino['id']); ?>" class="btn btn-primary btn-sm w-100">
                                                <i class="fas fa-eye me-1"></i>Ver Detalles
                                            </a>
                                            <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] !== 'basico'): ?>
                                                <a href="<?php echo base_url('dashboard/exportar/reino/' . $reino['id'] . '?formato=pdf'); ?>" class="btn btn-outline-success btn-sm w-100 mt-1">
                                                    <i class="fas fa-download me-1"></i>Descargar PDF
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Gráficos generales -->
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0">Distribución por Reino</h6>
                                </div>
                                <div class="card-body">
                                    <canvas id="chart-reinos-general" width="400" height="300"></canvas>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0">Tipos de Preguntas</h6>
                                </div>
                                <div class="card-body">
                                    <canvas id="chart-preguntas-general" width="400" height="300"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Navegación Jerárquica -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-sitemap me-2"></i>
                        Explorar Datos por Categoría
                    </h6>
                </div>
                <div class="card-body">
                    <p class="text-muted mb-4">
                        Selecciona un reino para explorar los datos estadísticos disponibles.
                        Los datos se organizan jerárquicamente: Reino → Módulo → Especie.
                    </p>

                    <?php if (!empty($reinos)): ?>
                        <div class="row">
                            <?php foreach ($reinos as $reino): ?>
                                <div class="col-md-6 col-lg-4 mb-4">
                                    <div class="card h-100 border-left-primary">
                                        <div class="card-body">
                                            <div class="d-flex align-items-center mb-3">
                                                <div class="flex-shrink-0">
                                                    <i class="fas fa-<?php echo $reino['nombre'] === 'Flora' ? 'leaf' : 'paw'; ?> fa-2x text-primary"></i>
                                                </div>
                                                <div class="flex-grow-1 ms-3">
                                                    <h5 class="card-title mb-1"><?php echo htmlspecialchars($reino['nombre']); ?></h5>
                                                    <p class="card-text small text-muted mb-0">
                                                        <?php echo htmlspecialchars($reino['descripcion'] ?? 'Datos estadísticos disponibles'); ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <a href="<?php echo base_url('dashboard/reino/' . $reino['id']); ?>" class="btn btn-primary btn-sm">
                                                <i class="fas fa-chart-bar me-1"></i>Ver Estadísticas
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-database fa-3x text-muted mb-3"></i>
                            <h5 class="text-muted">No hay datos disponibles</h5>
                            <p class="text-muted">Los datos estadísticos se están recopilando.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Información para Usuarios -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Información para Usuarios
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="text-primary mb-3">
                                <i class="fas fa-user me-2"></i>Usuario Básico
                            </h6>
                            <ul class="list-unstyled">
                                <li><i class="fas fa-check text-success me-2"></i>Acceso gratuito a datos estadísticos</li>
                                <li><i class="fas fa-check text-success me-2"></i>Navegación jerárquica de datos</li>
                                <li><i class="fas fa-check text-success me-2"></i>Visualización de gráficos y estadísticas</li>
                                <li><i class="fas fa-times text-muted me-2"></i>Descarga de reportes (requiere registro)</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-success mb-3">
                                <i class="fas fa-user-check me-2"></i>Usuario Registrado
                            </h6>
                            <ul class="list-unstyled">
                                <li><i class="fas fa-check text-success me-2"></i>Todos los beneficios del usuario básico</li>
                                <li><i class="fas fa-check text-success me-2"></i>Descarga de reportes en Excel/PDF</li>
                                <li><i class="fas fa-check text-success me-2"></i>Acceso a datos históricos completos</li>
                                <li><i class="fas fa-check text-success me-2"></i>Posibilidad de solicitar censos personalizados</li>
                            </ul>
                        </div>
                    </div>
                    <hr>
                    <div class="text-center">
                        <p class="mb-3">
                            ¿Quieres realizar censos o necesitas acceso administrativo?
                            <strong>Contacta con nosotros para obtener permisos especiales.</strong>
                        </p>
                        <a href="<?php echo base_url('contacto'); ?>" class="btn btn-outline-primary">
                            <i class="fas fa-envelope me-1"></i>Contactar Soporte
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>