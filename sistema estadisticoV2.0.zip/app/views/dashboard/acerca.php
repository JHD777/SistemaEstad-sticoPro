<?php
/**
 * Sistema Estadístico Pro - Página Acerca de
 * Información sobre el sistema
 */
?>
<div class="page-header">
    <h1><?php echo $titulo ?? 'Acerca del Sistema Estadístico Pro'; ?></h1>
    <div class="subtitle"><?php echo $descripcion ?? 'Sistema avanzado para la gestión y análisis de datos estadísticos de especies.'; ?></div>
</div>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h2 class="card-title mb-0">
                        <i class="fas fa-info-circle me-2"></i>
                        Sistema Estadístico Pro
                    </h2>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-sm-3">
                            <img src="<?php echo base_url('assets/images/logo.png'); ?>"
                                 alt="Logo Sistema Estadístico Pro"
                                 class="img-fluid rounded">
                        </div>
                        <div class="col-sm-9">
                            <h3>Sistema Estadístico Pro</h3>
                            <p class="lead">Sistema avanzado para la gestión y análisis de datos estadísticos de especies biológicas.</p>
                            <p><strong>Versión:</strong> <?php echo htmlspecialchars($version ?? '1.0.0'); ?></p>
                            <p><strong>Desarrollado por:</strong> <?php echo htmlspecialchars($desarrollador ?? 'Sistema Estadístico Pro'); ?></p>
                        </div>
                    </div>

                    <hr>

                    <h4>Características Principales</h4>
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <ul class="list-unstyled">
                                <li><i class="fas fa-check text-success me-2"></i> Gestión jerárquica de especies (Reino → Módulo → Especie)</li>
                                <li><i class="fas fa-check text-success me-2"></i> Formularios dinámicos personalizables</li>
                                <li><i class="fas fa-check text-success me-2"></i> Sistema de permisos basado en roles</li>
                                <li><i class="fas fa-check text-success me-2"></i> Análisis estadístico avanzado</li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <ul class="list-unstyled">
                                <li><i class="fas fa-check text-success me-2"></i> Exportación de datos en múltiples formatos</li>
                                <li><i class="fas fa-check text-success me-2"></i> Interfaz intuitiva y responsiva</li>
                                <li><i class="fas fa-check text-success me-2"></i> Seguridad y autenticación robusta</li>
                                <li><i class="fas fa-check text-success me-2"></i> Registro detallado de actividades</li>
                            </ul>
                        </div>
                    </div>

                    <hr>

                    <h4>Niveles de Usuario</h4>
                    <div class="row mt-3">
                        <div class="col-md-6">
                            <div class="card border-info">
                                <div class="card-body">
                                    <h6 class="card-title text-info">
                                        <i class="fas fa-user me-2"></i>Usuarios Básicos
                                    </h6>
                                    <p class="card-text">Acceso a información general y navegación básica del sistema.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card border-success">
                                <div class="card-body">
                                    <h6 class="card-title text-success">
                                        <i class="fas fa-user-check me-2"></i>Usuarios Registrados
                                    </h6>
                                    <p class="card-text">Acceso completo a formularios y funciones de exportación.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-6">
                            <div class="card border-warning">
                                <div class="card-body">
                                    <h6 class="card-title text-warning">
                                        <i class="fas fa-user-cog me-2"></i>Administradores
                                    </h6>
                                    <p class="card-text">Gestión de especies, formularios y análisis avanzado.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card border-danger">
                                <div class="card-body">
                                    <h6 class="card-title text-danger">
                                        <i class="fas fa-crown me-2"></i>Supremos
                                    </h6>
                                    <p class="card-text">Control total del sistema incluyendo gestión de usuarios.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <h4>Tecnologías Utilizadas</h4>
                    <div class="row mt-3">
                        <div class="col-md-4 text-center">
                            <i class="fab fa-php fa-3x text-primary mb-2"></i>
                            <h6>PHP 8+</h6>
                            <small class="text-muted">Lenguaje principal</small>
                        </div>
                        <div class="col-md-4 text-center">
                            <i class="fas fa-database fa-3x text-success mb-2"></i>
                            <h6>MySQL</h6>
                            <small class="text-muted">Base de datos</small>
                        </div>
                        <div class="col-md-4 text-center">
                            <i class="fab fa-bootstrap fa-3x text-info mb-2"></i>
                            <h6>Bootstrap 5</h6>
                            <small class="text-muted">Framework CSS</small>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-4 text-center">
                            <i class="fab fa-js-square fa-3x text-warning mb-2"></i>
                            <h6>JavaScript</h6>
                            <small class="text-muted">Interactividad</small>
                        </div>
                        <div class="col-md-4 text-center">
                            <i class="fas fa-chart-bar fa-3x text-danger mb-2"></i>
                            <h6>Chart.js</h6>
                            <small class="text-muted">Gráficos estadísticos</small>
                        </div>
                        <div class="col-md-4 text-center">
                            <i class="fas fa-code fa-3x text-secondary mb-2"></i>
                            <h6>MVC Pattern</h6>
                            <small class="text-muted">Arquitectura</small>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-center">
                    <small class="text-muted">
                        © <?php echo date('Y'); ?> Sistema Estadístico Pro. Todos los derechos reservados.
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- El footer ya está incluido en el layout público -->