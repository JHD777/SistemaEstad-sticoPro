<?php
/**
 * Sistema Estadístico Pro - Listar Preguntas Base
 * Vista para gestionar preguntas base de herencia
 */

// Verificar permisos
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'supremo') {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-question-circle me-2 text-primary"></i>
                    Gestión de Preguntas Base
                </h2>
                <p class="text-muted mt-1">Preguntas que se heredan automáticamente en formularios</p>
            </div>
            <div>
                <a href="<?php echo base_url('preguntas/crear'); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i>Crear Pregunta Base
                </a>
            </div>
        </div>

        <!-- Información Explicativa -->
        <div class="alert alert-info mb-4">
            <h6><i class="fas fa-info-circle me-2"></i>¿Qué son las preguntas base?</h6>
            <p class="mb-2">Las preguntas base son preguntas que se aplican automáticamente a todos los formularios de un nivel jerárquico:</p>
            <ul class="mb-0">
                <li><strong>Reino:</strong> Se aplican a todos los módulos y especies dentro de ese reino</li>
                <li><strong>Módulo:</strong> Se aplican a todas las especies dentro de ese módulo</li>
                <li><strong>Especie:</strong> Se aplican solo a esa especie específica</li>
            </ul>
        </div>

        <?php if (empty($preguntas_base)): ?>
            <div class="card">
                <div class="card-body text-center py-5">
                    <i class="fas fa-question-circle fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No hay preguntas base configuradas</h5>
                    <p class="text-muted">Crea preguntas base para establecer la estructura común de tus formularios.</p>
                    <a href="<?php echo base_url('preguntas/crear'); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i>Crear Primera Pregunta Base
                    </a>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($preguntas_base as $ambito => $datos): ?>
                <div class="card mb-4">
                    <div class="card-header">
                        <h6 class="mb-0">
                            <i class="fas fa-<?php echo $datos['ambito_aplicacion'] === 'reino' ? 'globe' : ($datos['ambito_aplicacion'] === 'modulo' ? 'sitemap' : 'leaf'); ?> me-2"></i>
                            <?php echo ucfirst($datos['ambito_aplicacion']); ?>: <?php echo $datos['ambito_nombre']; ?>
                            <span class="badge bg-<?php echo $datos['ambito_aplicacion'] === 'reino' ? 'primary' : ($datos['ambito_aplicacion'] === 'modulo' ? 'info' : 'success'); ?> ms-2">
                                <?php echo count($datos['preguntas']); ?> pregunta(s)
                            </span>
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Pregunta</th>
                                        <th>Tipo</th>
                                        <th>Orden</th>
                                        <th>Obligatoria</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($datos['preguntas'] as $pregunta): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($pregunta['texto_pregunta']); ?></td>
                                            <td>
                                                <span class="badge bg-secondary">
                                                    <?php echo $tipos_pregunta[$pregunta['tipo_pregunta']] ?? $pregunta['tipo_pregunta']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo $pregunta['orden']; ?></td>
                                            <td>
                                                <?php if ($pregunta['obligatoria']): ?>
                                                    <span class="badge bg-warning">Sí</span>
                                                <?php else: ?>
                                                    <span class="badge bg-light text-muted">No</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="<?php echo base_url('preguntas/editar/' . $pregunta['id']); ?>"
                                                       class="btn btn-sm btn-outline-primary"
                                                       title="Editar pregunta base">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <button type="button" class="btn btn-sm btn-outline-danger"
                                                            onclick="eliminarPregunta(<?php echo $pregunta['id']; ?>, '<?php echo htmlspecialchars($pregunta['texto_pregunta']); ?>')"
                                                            title="Eliminar pregunta base">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Modal de Confirmación de Eliminación -->
<div class="modal fade" id="eliminarModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Eliminar Pregunta Base</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>¿Estás seguro de que deseas eliminar la pregunta base?</p>
                <p class="text-danger fw-bold" id="preguntaEliminar"></p>
                <p class="text-muted">Esta acción no se puede deshacer y afectará a todos los formularios que heredan esta pregunta.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-danger" id="confirmarEliminar">Eliminar</button>
            </div>
        </div>
    </div>
</div>

<script>
let preguntaIdEliminar = null;

function eliminarPregunta(id, texto) {
    preguntaIdEliminar = id;
    document.getElementById('preguntaEliminar').textContent = '"' + texto + '"';
    new bootstrap.Modal(document.getElementById('eliminarModal')).show();
}

document.getElementById('confirmarEliminar').addEventListener('click', function() {
    if (preguntaIdEliminar) {
        window.location.href = '<?php echo base_url('preguntas/eliminar'); ?>/' + preguntaIdEliminar;
    }
});
</script>