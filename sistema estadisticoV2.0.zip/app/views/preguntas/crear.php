<?php
/**
 * Sistema Estadístico Pro - Crear Pregunta Base
 * Vista para crear preguntas base de herencia
 */

// Verificar permisos
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'supremo') {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-plus me-2 text-primary"></i>
                    Crear Pregunta Base
                </h2>
                <p class="text-muted mt-1">Define preguntas que se heredarán automáticamente</p>
            </div>
            <div>
                <a href="<?php echo base_url('preguntas/listar'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Volver
                </a>
            </div>
        </div>

        <form id="formularioPregunta" method="POST" action="<?php echo base_url('preguntas/crear'); ?>">
            <!-- Información de Ayuda -->
            <div class="alert alert-info mb-4">
                <h6><i class="fas fa-question-circle me-2"></i>¿Cómo crear una pregunta base?</h6>
                <p class="mb-2">Las preguntas base se aplican automáticamente a todos los formularios del nivel seleccionado:</p>
                <ul class="mb-0">
                    <li><strong>Reino:</strong> Afecta a todos los módulos y especies dentro del reino</li>
                    <li><strong>Módulo:</strong> Afecta a todas las especies dentro del módulo</li>
                    <li><strong>Especie:</strong> Afecta solo a esa especie específica</li>
                </ul>
            </div>

            <!-- Información Básica de la Pregunta -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0">
                        <i class="fas fa-info-circle me-2"></i>Información de la Pregunta Base
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="ambito_aplicacion" class="form-label">
                                    Ámbito de Aplicación <span class="text-danger">*</span>
                                </label>
                                <select class="form-select" id="ambito_aplicacion" name="ambito_aplicacion" required>
                                    <option value="">Seleccionar ámbito...</option>
                                    <option value="reino">Reino (Afecta a todo el reino)</option>
                                    <option value="modulo">Módulo (Afecta al módulo)</option>
                                    <option value="especie">Especie (Afecta solo a la especie)</option>
                                </select>
                                <div class="form-text">Define el alcance de la pregunta</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3" id="ambitoContainer" style="display: none;">
                                <label for="ambito_id" class="form-label">
                                    Aplicar a <span class="text-danger">*</span>
                                </label>
                                <select class="form-select" id="ambito_id" name="ambito_id" required style="display: none;">
                                    <option value="">Seleccionar...</option>
                                </select>
                                <div class="form-text">Selecciona el reino, módulo o especie específico</div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-8">
                            <div class="mb-3">
                                <label for="texto_pregunta" class="form-label">
                                    Texto de la Pregunta <span class="text-danger">*</span>
                                </label>
                                <textarea class="form-control" id="texto_pregunta" name="texto_pregunta"
                                          rows="3" required
                                          placeholder="Ej: ¿Cuál es el pH del suelo?"></textarea>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="tipo_pregunta" class="form-label">
                                    Tipo de Pregunta <span class="text-danger">*</span>
                                </label>
                                <select class="form-select" id="tipo_pregunta" name="tipo_pregunta" required>
                                    <option value="">Seleccionar tipo...</option>
                                    <?php foreach ($tipos_pregunta as $key => $value): ?>
                                        <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3" id="opcionesContainer" style="display: none;">
                                <label for="opciones" class="form-label">
                                    Opciones (separadas por comas)
                                </label>
                                <input type="text" class="form-control" id="opciones" name="opciones"
                                       placeholder="Ej: Sí,No,Tal vez">
                                <div class="form-text">Solo para preguntas de opción múltiple</div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label for="orden" class="form-label">
                                    Orden de Aparición
                                </label>
                                <input type="number" class="form-control" id="orden" name="orden"
                                       value="1" min="1">
                                <div class="form-text">Número que determina el orden en que aparecerá la pregunta (menor número = aparece primero)</div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="mb-3">
                                <label class="form-label d-block">&nbsp;</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="obligatoria" name="obligatoria" value="1">
                                    <label class="form-check-label" for="obligatoria">
                                        Pregunta Obligatoria
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Crear Pregunta Base
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
// Mostrar/ocultar contenedores según el ámbito seleccionado
document.getElementById('ambito_aplicacion').addEventListener('change', function() {
    const ambito = this.value;
    const ambitoContainer = document.getElementById('ambitoContainer');
    const ambitoSelect = document.getElementById('ambito_id');

    if (ambito) {
        ambitoContainer.style.display = 'block';
        ambitoSelect.style.display = 'block';
        ambitoSelect.required = true;

        // Cargar opciones según el ámbito
        cargarOpcionesAmbito(ambito);
    } else {
        ambitoContainer.style.display = 'none';
        ambitoSelect.style.display = 'none';
        ambitoSelect.required = false;
    }
});

// Mostrar/ocultar campo de opciones según el tipo de pregunta
document.getElementById('tipo_pregunta').addEventListener('change', function() {
    const tipo = this.value;
    const opcionesContainer = document.getElementById('opcionesContainer');
    const opcionesInput = document.getElementById('opciones');

    if (tipo === 'opcion_multiple') {
        opcionesContainer.style.display = 'block';
        opcionesInput.required = true;
    } else {
        opcionesContainer.style.display = 'none';
        opcionesInput.required = false;
        opcionesInput.value = '';
    }
});

function cargarOpcionesAmbito(ambito) {
    const ambitoSelect = document.getElementById('ambito_id');
    ambitoSelect.innerHTML = '<option value="">Cargando...</option>';

    let opciones = [];

    if (ambito === 'reino') {
        opciones = <?php echo json_encode(array_map(function($reino) {
            return ['id' => $reino['id'], 'nombre' => $reino['nombre']];
        }, $reinos)); ?>;
    } else if (ambito === 'modulo') {
        opciones = <?php echo json_encode(array_map(function($modulo) {
            return ['id' => $modulo['id'], 'nombre' => $modulo['nombre']];
        }, $modulos)); ?>;
    } else if (ambito === 'especie') {
        // Para especies, cargar dinámicamente según el módulo seleccionado
        // Por ahora, mostrar mensaje
        ambitoSelect.innerHTML = '<option value="">Primero selecciona un módulo...</option>';
        return;
    }

    ambitoSelect.innerHTML = '<option value="">Seleccionar...</option>';
    opciones.forEach(opcion => {
        const option = document.createElement('option');
        option.value = opcion.id;
        option.textContent = opcion.nombre;
        ambitoSelect.appendChild(option);
    });
}

// Validación del formulario
document.getElementById('formularioPregunta').addEventListener('submit', function(e) {
    const ambitoAplicacion = document.getElementById('ambito_aplicacion').value;
    const ambitoId = document.getElementById('ambito_id').value;
    const textoPregunta = document.getElementById('texto_pregunta').value.trim();

    if (!ambitoAplicacion) {
        e.preventDefault();
        alert('Debe seleccionar un ámbito de aplicación');
        return;
    }

    if (!ambitoId) {
        e.preventDefault();
        alert('Debe seleccionar a qué aplicar la pregunta');
        return;
    }

    if (!textoPregunta) {
        e.preventDefault();
        alert('Debe ingresar el texto de la pregunta');
        return;
    }
});
</script>