<?php
/**
 * Sistema Estadístico Pro - Ver Detalles de Formulario
 * Vista para mostrar los detalles completos de un formulario
 */

// Verificar permisos
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'registrado', 'supremo'])) {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-eye me-2 text-primary"></i>
                    Detalles del Formulario
                </h2>
                <p class="text-muted mt-1">Información completa del formulario</p>
            </div>
            <div>
                <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-outline-secondary me-2">
                    <i class="fas fa-arrow-left me-1"></i>Volver
                </a>
                <?php if ($formulario['estado'] === 'aprobado'): ?>
                    <a href="<?php echo base_url('formularios/responder/' . $formulario['id']); ?>" class="btn btn-success">
                        <i class="fas fa-play me-1"></i>Realizar Censo
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Información del Formulario -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">
                            <i class="fas fa-info-circle me-2"></i>Información General
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h5 class="card-title"><?php echo htmlspecialchars($formulario['nombre']); ?></h5>
                                <p class="text-muted"><?php echo htmlspecialchars($formulario['descripcion'] ?? 'Sin descripción'); ?></p>
                            </div>
                            <div class="col-md-6 text-end">
                                <?php
                                $estadoClass = match($formulario['estado']) {
                                    'borrador' => 'secondary',
                                    'pendiente' => 'warning',
                                    'aprobado' => 'success',
                                    'archivado' => 'dark',
                                    default => 'secondary'
                                };
                                ?>
                                <span class="badge bg-<?php echo $estadoClass; ?> fs-6">
                                    <?php echo htmlspecialchars($formulario['estado']); ?>
                                </span>
                            </div>
                        </div>

                        <hr>

                        <div class="row">
                            <div class="col-md-6">
                                <strong>Especie:</strong><br>
                                <span class="badge bg-info"><?php echo htmlspecialchars($formulario['especie_nombre']); ?></span>
                            </div>
                            <div class="col-md-6">
                                <strong>Creador:</strong><br>
                                <?php echo htmlspecialchars($formulario['creador_nombre']); ?>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-6">
                                <strong>Fecha de Creación:</strong><br>
                                <?php echo date('d/m/Y H:i', strtotime($formulario['fecha_creacion'])); ?>
                            </div>
                            <div class="col-md-6">
                                <strong>Última Modificación:</strong><br>
                                <?php echo date('d/m/Y H:i', strtotime($formulario['fecha_aprobacion'] ?? $formulario['fecha_creacion'])); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0">
                            <i class="fas fa-chart-bar me-2"></i>Estadísticas
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-6">
                                <div class="border-end">
                                    <h3 class="text-primary"><?php echo $estadisticas['total_preguntas']; ?></h3>
                                    <small class="text-muted">Preguntas</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <h3 class="text-success"><?php echo $estadisticas['censos_realizados']; ?></h3>
                                <small class="text-muted">Censos</small>
                            </div>
                        </div>

                        <hr>

                        <div class="small">
                            <div class="d-flex justify-content-between mb-1">
                                <span>Obligatorias:</span>
                                <span class="fw-bold"><?php echo $estadisticas['preguntas_obligatorias']; ?></span>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span>Condicionales:</span>
                                <span class="fw-bold"><?php echo $estadisticas['preguntas_condicionales']; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Preguntas del Formulario -->
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-question-circle me-2"></i>Preguntas del Formulario
                    <span class="badge bg-primary ms-2"><?php echo count($preguntas); ?></span>
                </h6>
            </div>
            <div class="card-body">
                <?php if (!empty($preguntas)): ?>
                    <div class="accordion" id="preguntasAccordion">
                        <?php foreach ($preguntas as $index => $pregunta): ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo $pregunta['id']; ?>">
                                    <button class="accordion-button <?php echo $index > 0 ? 'collapsed' : ''; ?>" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $pregunta['id']; ?>"
                                            aria-expanded="<?php echo $index === 0 ? 'true' : 'false'; ?>"
                                            aria-controls="collapse<?php echo $pregunta['id']; ?>">
                                        <div class="d-flex align-items-center w-100">
                                            <span class="badge bg-secondary me-2"><?php echo $pregunta['orden']; ?></span>
                                            <span class="flex-grow-1 text-start"><?php echo htmlspecialchars($pregunta['texto_pregunta']); ?></span>
                                            <span class="badge bg-info ms-2"><?php echo htmlspecialchars($pregunta['tipo_pregunta']); ?></span>
                                            <?php if ($pregunta['obligatoria']): ?>
                                                <span class="badge bg-danger ms-2">Obligatoria</span>
                                            <?php endif; ?>
                                        </div>
                                    </button>
                                </h2>
                                <div id="collapse<?php echo $pregunta['id']; ?>" class="accordion-collapse collapse <?php echo $index === 0 ? 'show' : ''; ?>"
                                     aria-labelledby="heading<?php echo $pregunta['id']; ?>" data-bs-parent="#preguntasAccordion">
                                    <div class="accordion-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <strong>Tipo de Pregunta:</strong><br>
                                                <span class="badge bg-primary"><?php echo htmlspecialchars(QUESTION_TYPES[$pregunta['tipo_pregunta']] ?? $pregunta['tipo_pregunta']); ?></span>
                                            </div>
                                            <div class="col-md-6">
                                                <strong>Obligatoria:</strong><br>
                                                <span class="badge bg-<?php echo $pregunta['obligatoria'] ? 'danger' : 'secondary'; ?>">
                                                    <?php echo $pregunta['obligatoria'] ? 'Sí' : 'No'; ?>
                                                </span>
                                            </div>
                                        </div>

                                        <?php if (!empty($pregunta['opciones'])): ?>
                                            <div class="mt-3">
                                                <strong>Opciones Disponibles:</strong><br>
                                                <div class="mt-2">
                                                    <?php
                                                    $opciones = array_map('trim', explode(',', $pregunta['opciones']));
                                                    foreach ($opciones as $opcion):
                                                    ?>
                                                        <span class="badge bg-light text-dark me-1"><?php echo htmlspecialchars($opcion); ?></span>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (!empty($pregunta['depende_de'])): ?>
                                            <div class="mt-3">
                                                <strong>Pregunta Condicional:</strong><br>
                                                <small class="text-muted">
                                                    Esta pregunta se muestra solo si la respuesta a la pregunta #<?php echo $pregunta['depende_de']; ?>
                                                    es "<?php echo htmlspecialchars($pregunta['respuesta_requerida']); ?>"
                                                </small>
                                            </div>
                                        <?php endif; ?>

                                        <!-- Vista previa del campo -->
                                        <div class="mt-3">
                                            <strong>Vista Previa:</strong><br>
                                            <div class="mt-2 p-3 border rounded bg-light">
                                                <?php
                                                $fieldName = 'preview_' . $pregunta['id'];
                                                switch ($pregunta['tipo_pregunta']) {
                                                    case 'texto':
                                                        echo '<input type="text" class="form-control" placeholder="Respuesta de texto" disabled>';
                                                        break;
                                                    case 'numero':
                                                        echo '<input type="number" class="form-control" placeholder="0" disabled>';
                                                        break;
                                                    case 'booleano':
                                                        echo '<div class="form-check">';
                                                        echo '<input class="form-check-input" type="radio" name="' . $fieldName . '" value="1" disabled> <label class="form-check-label">Sí</label>';
                                                        echo '</div>';
                                                        echo '<div class="form-check">';
                                                        echo '<input class="form-check-input" type="radio" name="' . $fieldName . '" value="0" disabled> <label class="form-check-label">No</label>';
                                                        echo '</div>';
                                                        break;
                                                    case 'opcion_multiple':
                                                        if (!empty($pregunta['opciones'])) {
                                                            $opciones = array_map('trim', explode(',', $pregunta['opciones']));
                                                            echo '<select class="form-select" disabled>';
                                                            echo '<option>Seleccionar opción...</option>';
                                                            foreach ($opciones as $opcion) {
                                                                echo '<option>' . htmlspecialchars($opcion) . '</option>';
                                                            }
                                                            echo '</select>';
                                                        }
                                                        break;
                                                    case 'fecha':
                                                        echo '<input type="date" class="form-control" disabled>';
                                                        break;
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-question-circle fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No hay preguntas en este formulario</h5>
                        <p class="text-muted">El formulario está vacío o no se pudieron cargar las preguntas.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>