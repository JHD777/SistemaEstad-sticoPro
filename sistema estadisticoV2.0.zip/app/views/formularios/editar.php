<?php
/**
 * Sistema Estadístico Pro - Editar Formulario
 * Vista para editar formularios dinámicos con preguntas
 */

// Verificar permisos
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'registrado', 'supremo'])) {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-edit me-2 text-warning"></i>
                    Editar Formulario
                </h2>
                <p class="text-muted mt-1"><?php echo htmlspecialchars($formulario['nombre']); ?></p>
            </div>
            <div>
                <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Volver
                </a>
            </div>
        </div>

        <!-- Información de Ayuda -->
        <div class="alert alert-info mb-4">
            <h6><i class="fas fa-question-circle me-2"></i>¿Cómo editar un formulario?</h6>
            <p class="mb-2">Puedes modificar la información básica y las preguntas del formulario:</p>
            <ol class="mb-0">
                <li><strong>Información básica:</strong> Cambia el nombre, descripción o estado</li>
                <li><strong>Preguntas:</strong> Agrega, edita o elimina preguntas usando los controles disponibles</li>
                <li><strong>Lógica condicional:</strong> Las preguntas condicionales se mantienen pero puedes modificarlas</li>
                <li><strong>Guardar:</strong> Los cambios se guardan como borrador hasta ser aprobados</li>
            </ol>
            <hr>
            <p class="mb-0"><strong>💡 Tip para preguntas condicionales:</strong> Para preguntas Sí/No, usa <code>1</code> para Sí y <code>0</code> para No. Para opciones múltiples, escribe exactamente la opción (ej: "Sí", "Rojo").</p>
        </div>

        <form id="formularioEditar" method="POST" action="<?php echo base_url('formularios/editar/' . $formulario['id']); ?>">
            <!-- Información Básica del Formulario -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0">
                        <i class="fas fa-info-circle me-2"></i>Información del Formulario
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="nombre" class="form-label">
                                    Nombre del Formulario <span class="text-danger">*</span>
                                </label>
                                <input type="text" class="form-control" id="nombre" name="nombre"
                                       value="<?php echo htmlspecialchars($formulario['nombre']); ?>" required>
                                <div class="form-text">Nombre descriptivo del formulario</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="estado" class="form-label">Estado</label>
                                <select class="form-select" id="estado" name="estado">
                                    <option value="borrador" <?php echo $formulario['estado'] === 'borrador' ? 'selected' : ''; ?>>Borrador (puedes editar después)</option>
                                    <option value="pendiente" <?php echo $formulario['estado'] === 'pendiente' ? 'selected' : ''; ?>>Pendiente de Aprobación</option>
                                    <?php if ($formulario['estado'] === 'aprobado'): ?>
                                        <option value="aprobado" selected>Aprobado</option>
                                    <?php endif; ?>
                                </select>
                                <div class="form-text">Estado actual del formulario</div>
                            </div>
                        </div>
                    </div>

                    <!-- Información de la especie (solo lectura) -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Especie Asociada</label>
                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($formulario['especie_nombre']); ?>" readonly>
                                <div class="form-text">La especie no se puede cambiar en la edición</div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <textarea class="form-control" id="descripcion" name="descripcion" rows="3"
                                  placeholder="Describe el propósito y alcance del formulario..."><?php echo htmlspecialchars($formulario['descripcion'] ?? ''); ?></textarea>
                        <div class="form-text">Descripción opcional del formulario</div>
                    </div>

                    <!-- Información del formulario -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="alert alert-light">
                                <strong>Especie:</strong> <?php echo htmlspecialchars($formulario['especie_nombre']); ?><br>
                                <strong>Creador:</strong> <?php echo htmlspecialchars($formulario['creador_nombre']); ?><br>
                                <strong>Fecha de creación:</strong> <?php echo date('d/m/Y H:i', strtotime($formulario['fecha_creacion'])); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="alert alert-light">
                                <strong>Estado actual:</strong>
                                <span class="badge bg-<?php
                                    echo $formulario['estado'] === 'aprobado' ? 'success' :
                                         ($formulario['estado'] === 'pendiente' ? 'warning' : 'secondary');
                                ?>">
                                    <?php echo htmlspecialchars(FORM_STATES[$formulario['estado']] ?? $formulario['estado']); ?>
                                </span><br>
                                <?php if ($formulario['fecha_aprobacion']): ?>
                                    <strong>Fecha de aprobación:</strong> <?php echo date('d/m/Y H:i', strtotime($formulario['fecha_aprobacion'])); ?><br>
                                    <strong>Aprobador:</strong> <?php echo htmlspecialchars($formulario['aprobador_nombre'] ?? 'N/A'); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Constructor de Preguntas -->
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">
                        <i class="fas fa-question-circle me-2"></i>Preguntas del Formulario
                        <span class="badge bg-primary ms-2"><?php echo count($preguntas); ?></span>
                    </h6>
                    <button type="button" class="btn btn-primary btn-sm" id="agregarPregunta">
                        <i class="fas fa-plus me-1"></i>Agregar Pregunta
                    </button>
                </div>
                <div class="card-body">
                    <div id="preguntasContainer">
                        <?php if (!empty($preguntas)): ?>
                            <?php foreach ($preguntas as $index => $pregunta): ?>
                                <div class="pregunta-item card mb-3 <?php echo (isset($pregunta['es_heredada']) && $pregunta['es_heredada']) ? 'border-info' : ''; ?>">
                                    <div class="card-header d-flex justify-content-between align-items-center">
                                        <h6 class="mb-0 pregunta-titulo">
                                            <i class="fas fa-question me-2"></i>Pregunta <span class="numero-pregunta"><?php echo $index + 1; ?></span>
                                            <?php if (isset($pregunta['es_heredada']) && $pregunta['es_heredada']): ?>
                                                <span class="badge bg-info ms-2">
                                                    <i class="fas fa-link me-1"></i>Heredada (<?php echo ucfirst($pregunta['nivel_herencia'] ?? 'desconocido'); ?>)
                                                </span>
                                            <?php endif; ?>
                                        </h6>
                                        <div>
                                            <?php if (!isset($pregunta['es_heredada']) || !$pregunta['es_heredada']): ?>
                                                <button type="button" class="btn btn-outline-danger btn-sm eliminar-pregunta">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div class="mb-3">
                                                    <label class="form-label">Texto de la Pregunta <span class="text-danger">*</span></label>
                                                    <input type="text" class="form-control pregunta-texto"
                                                           name="preguntas[<?php echo $pregunta['id']; ?>][texto_pregunta]"
                                                           value="<?php echo htmlspecialchars($pregunta['texto_pregunta']); ?>"
                                                           <?php echo (isset($pregunta['es_heredada']) && $pregunta['es_heredada']) ? 'readonly' : 'required'; ?>>
                                                    <?php if (isset($pregunta['es_heredada']) && $pregunta['es_heredada']): ?>
                                                        <div class="form-text text-info">
                                                            <i class="fas fa-info-circle me-1"></i>Esta pregunta es heredada y no se puede modificar
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="mb-3">
                                                    <label class="form-label">Tipo de Pregunta <span class="text-danger">*</span></label>
                                                    <select class="form-select pregunta-tipo"
                                                            name="preguntas[<?php echo $pregunta['id']; ?>][tipo_pregunta]"
                                                            <?php echo (isset($pregunta['es_heredada']) && $pregunta['es_heredada']) ? 'disabled' : 'required'; ?>>
                                                        <?php foreach (QUESTION_TYPES as $key => $value): ?>
                                                            <option value="<?php echo $key; ?>" <?php echo $pregunta['tipo_pregunta'] === $key ? 'selected' : ''; ?>>
                                                                <?php echo htmlspecialchars($value); ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Contenedor para opciones (solo para opcion_multiple) -->
                                        <div class="opciones-container" style="<?php echo $pregunta['tipo_pregunta'] === 'opcion_multiple' ? '' : 'display: none;'; ?>">
                                            <div class="mb-3">
                                                <label class="form-label">Opciones (separadas por comas)</label>
                                                <input type="text" class="form-control opciones-input"
                                                       name="preguntas[<?php echo $pregunta['id']; ?>][opciones]"
                                                       value="<?php echo htmlspecialchars($pregunta['opciones'] ?? ''); ?>"
                                                       placeholder="Ej: Sí,No,Tal vez"
                                                       <?php echo (isset($pregunta['es_heredada']) && $pregunta['es_heredada']) ? 'readonly' : ''; ?>>
                                                <div class="form-text">Las opciones aparecerán como un menú desplegable</div>
                                            </div>
                                        </div>

                                        <!-- Contenedor para lógica condicional -->
                                        <div class="condicional-container">
                                            <div class="form-check mb-3">
                                                <input class="form-check-input pregunta-condicional" type="checkbox"
                                                       name="preguntas[<?php echo $pregunta['id']; ?>][condicional]" value="1"
                                                       <?php echo !empty($pregunta['depende_de']) ? 'checked' : ''; ?>
                                                       <?php echo (isset($pregunta['es_heredada']) && $pregunta['es_heredada']) ? 'disabled' : ''; ?>>
                                                <label class="form-check-label">
                                                    Esta pregunta depende de otra
                                                </label>
                                            </div>

                                            <div class="condicional-detalles" style="<?php echo !empty($pregunta['depende_de']) ? '' : 'display: none;'; ?>">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <label class="form-label">Mostrar si la respuesta a:</label>
                                                        <select class="form-select pregunta-padre"
                                                                name="preguntas[<?php echo $pregunta['id']; ?>][depende_de]"
                                                                data-selected="<?php echo $pregunta['depende_de'] ?? ''; ?>"
                                                                <?php echo (isset($pregunta['es_heredada']) && $pregunta['es_heredada']) ? 'disabled' : ''; ?>>
                                                            <option value="">Seleccionar pregunta...</option>
                                                            <?php foreach ($preguntas_padre as $padre): ?>
                                                                <option value="<?php echo $padre['id']; ?>"
                                                                        <?php echo ($pregunta['depende_de'] == $padre['id']) ? 'selected' : ''; ?>>
                                                                    Pregunta <?php echo $padre['orden']; ?>: <?php echo htmlspecialchars(substr($padre['texto_pregunta'], 0, 50)); ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Es igual a:</label>
                                                        <input type="text" class="form-control respuesta-requerida"
                                                               name="preguntas[<?php echo $pregunta['id']; ?>][respuesta_requerida]"
                                                               value="<?php echo htmlspecialchars($pregunta['respuesta_requerida'] ?? ''); ?>"
                                                               placeholder="Ej: Sí, No, Auto"
                                                               title="Para preguntas booleanas: 1=Sí, 0=No"
                                                               <?php echo (isset($pregunta['es_heredada']) && $pregunta['es_heredada']) ? 'readonly' : ''; ?>>
                                                        <div class="form-text">
                                                            <small>Para booleanos: <code>1</code>=Sí, <code>0</code>=No</small><br>
                                                            <small>Para opciones múltiples: escribe exactamente la opción</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <input class="form-check-input pregunta-obligatoria" type="checkbox"
                                                           name="preguntas[<?php echo $pregunta['id']; ?>][obligatoria]" value="1"
                                                           <?php echo $pregunta['obligatoria'] ? 'checked' : ''; ?>
                                                           <?php echo (isset($pregunta['es_heredada']) && $pregunta['es_heredada']) ? 'disabled' : ''; ?>>
                                                    <label class="form-check-label">
                                                        Pregunta obligatoria
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="fas fa-question-circle fa-2x mb-2"></i>
                                <p>Este formulario no tiene preguntas. Haz clic en "Agregar Pregunta" para comenzar.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Botones de Acción -->
            <div class="d-flex justify-content-end mt-4 gap-2">
                <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-1"></i>Cancelar
                </a>
                <button type="submit" class="btn btn-warning">
                    <i class="fas fa-save me-1"></i>Guardar Cambios
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Template para preguntas (oculto) -->
<div id="preguntaTemplate" style="display: none;">
    <div class="pregunta-item card mb-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h6 class="mb-0 pregunta-titulo">
                <i class="fas fa-question me-2"></i>Pregunta <span class="numero-pregunta">1</span>
            </h6>
            <button type="button" class="btn btn-outline-danger btn-sm eliminar-pregunta">
                <i class="fas fa-trash"></i>
            </button>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-8">
                    <div class="mb-3">
                        <label class="form-label">Texto de la Pregunta <span class="text-danger">*</span></label>
                        <input type="text" class="form-control pregunta-texto" name="preguntas[INDEX][texto_pregunta]"
                               placeholder="Escribe la pregunta aquí..." required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label class="form-label">Tipo de Pregunta <span class="text-danger">*</span></label>
                        <select class="form-select pregunta-tipo" name="preguntas[INDEX][tipo_pregunta]" required>
                            <option value="">Seleccionar tipo...</option>
                            <?php foreach (QUESTION_TYPES as $key => $value): ?>
                                <option value="<?php echo $key; ?>"><?php echo htmlspecialchars($value); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Contenedor para opciones (solo para opcion_multiple) -->
            <div class="opciones-container" style="display: none;">
                <div class="mb-3">
                    <label class="form-label">Opciones (separadas por comas)</label>
                    <input type="text" class="form-control opciones-input" name="preguntas[INDEX][opciones]"
                           placeholder="Ej: Sí,No,Tal vez">
                    <div class="form-text">Las opciones aparecerán como un menú desplegable</div>
                </div>
            </div>

            <!-- Contenedor para lógica condicional -->
            <div class="condicional-container">
                <div class="form-check mb-3">
                    <input class="form-check-input pregunta-condicional" type="checkbox"
                           name="preguntas[INDEX][condicional]" value="1">
                    <label class="form-check-label">
                        Esta pregunta depende de otra
                    </label>
                </div>

                <div class="condicional-detalles" style="display: none;">
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">Mostrar si la respuesta a:</label>
                            <select class="form-select pregunta-padre" name="preguntas[INDEX][depende_de]">
                                <option value="">Seleccionar pregunta...</option>
                                <!-- Se llenará dinámicamente -->
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Es igual a:</label>
                            <input type="text" class="form-control respuesta-requerida"
                                   name="preguntas[INDEX][respuesta_requerida]"
                                   placeholder="Ej: Sí, No, Auto"
                                   title="Para preguntas booleanas: 1=Sí, 0=No">
                            <div class="form-text">
                                <small>Para booleanos: <code>1</code>=Sí, <code>0</code>=No</small><br>
                                <small>Para opciones múltiples: escribe exactamente la opción</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-check">
                        <input class="form-check-input pregunta-obligatoria" type="checkbox"
                               name="preguntas[INDEX][obligatoria]" value="1">
                        <label class="form-check-label">
                            Pregunta obligatoria
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Variables globales
let preguntaIndex = <?php echo count($preguntas) + 1; ?>;
let preguntasCreadas = [<?php echo implode(',', array_map(function($p) { return $p['id']; }, $preguntas)); ?>];

// Función para agregar pregunta
function agregarPregunta() {
    preguntaIndex++;
    const template = document.getElementById('preguntaTemplate').innerHTML;
    const preguntaHtml = template.replace(/INDEX/g, preguntaIndex);

    // Agregar al contenedor
    const container = document.getElementById('preguntasContainer');
    if (container.querySelector('.text-center')) {
        container.innerHTML = ''; // Limpiar mensaje inicial
    }
    container.insertAdjacentHTML('beforeend', preguntaHtml);

    // Actualizar números de preguntas
    actualizarNumerosPreguntas();

    // Agregar event listeners
    const nuevaPregunta = container.lastElementChild;
    configurarEventListenersPregunta(nuevaPregunta, preguntaIndex);

    // Agregar a la lista de preguntas creadas
    preguntasCreadas.push(preguntaIndex);

    // Actualizar preguntas padre disponibles
    actualizarPreguntasPadre();
}

// Función para configurar event listeners de una pregunta
function configurarEventListenersPregunta(preguntaElement, index) {
    // Event listener para tipo de pregunta
    const tipoSelect = preguntaElement.querySelector('.pregunta-tipo');
    tipoSelect.addEventListener('change', function() {
        mostrarOpcionesSegunTipo(this.value, preguntaElement);
    });

    // Event listener para pregunta condicional
    const condicionalCheck = preguntaElement.querySelector('.pregunta-condicional');
    condicionalCheck.addEventListener('change', function() {
        mostrarCondicional(this.checked, preguntaElement);
    });

    // Event listener para eliminar pregunta
    const eliminarBtn = preguntaElement.querySelector('.eliminar-pregunta');
    if (eliminarBtn) {
        eliminarBtn.addEventListener('click', function() {
            eliminarPregunta(index);
        });
    }
}

// Función para mostrar/ocultar opciones según tipo
function mostrarOpcionesSegunTipo(tipo, preguntaElement) {
    const opcionesContainer = preguntaElement.querySelector('.opciones-container');
    if (tipo === 'opcion_multiple') {
        opcionesContainer.style.display = 'block';
    } else {
        opcionesContainer.style.display = 'none';
    }
}

// Función para mostrar/ocultar condicional
function mostrarCondicional(mostrar, preguntaElement) {
    const condicionalDetalles = preguntaElement.querySelector('.condicional-detalles');
    if (mostrar) {
        condicionalDetalles.style.display = 'block';
    } else {
        condicionalDetalles.style.display = 'none';
        // Limpiar valores cuando se desactiva
        const padreSelect = preguntaElement.querySelector('.pregunta-padre');
        const respuestaInput = preguntaElement.querySelector('.respuesta-requerida');
        if (padreSelect) padreSelect.value = '';
        if (respuestaInput) respuestaInput.value = '';
    }
}

// Función para actualizar números de preguntas
function actualizarNumerosPreguntas() {
    const preguntas = document.querySelectorAll('.pregunta-item');
    preguntas.forEach((pregunta, index) => {
        const numeroElement = pregunta.querySelector('.numero-pregunta');
        numeroElement.textContent = index + 1;
    });
}

// Función para actualizar preguntas padre disponibles
function actualizarPreguntasPadre() {
    const selectsPadre = document.querySelectorAll('.pregunta-padre');
    selectsPadre.forEach(select => {
        // Guardar el valor seleccionado actual
        const valorSeleccionado = select.value;

        // Las preguntas padre ya están precargadas desde PHP
        // Solo necesitamos restaurar la selección si existe
        if (valorSeleccionado && select.querySelector(`option[value="${valorSeleccionado}"]`)) {
            select.value = valorSeleccionado;
        } else if (select.dataset.selected) {
            // Si hay un valor preseleccionado desde PHP, usarlo
            select.value = select.dataset.selected;
        }
    });
}

// Función para eliminar pregunta
function eliminarPregunta(index) {
    // Obtener el texto de la pregunta para mostrar en la confirmación
    const preguntaElement = document.querySelector(`input[name="preguntas[${index}][texto_pregunta]"]`);
    let textoPregunta = `Pregunta ${index}`;
    if (preguntaElement && preguntaElement.value.trim()) {
        textoPregunta = preguntaElement.value.trim().substring(0, 50) + (preguntaElement.value.length > 50 ? '...' : '');
    }

    if (confirm(`¿Estás seguro de eliminar la siguiente pregunta?\n\n"${textoPregunta}"\n\nEsta acción no se puede deshacer.`)) {
        // Remover del DOM
        const preguntaElement = document.querySelector(`input[name="preguntas[${index}][texto_pregunta]"]`).closest('.pregunta-item');
        preguntaElement.remove();

        // Remover de la lista de preguntas creadas
        const indexInArray = preguntasCreadas.indexOf(index);
        if (indexInArray > -1) {
            preguntasCreadas.splice(indexInArray, 1);
        }

        // Actualizar números
        actualizarNumerosPreguntas();
        actualizarPreguntasPadre();

        // Mostrar mensaje inicial si no hay preguntas
        const container = document.getElementById('preguntasContainer');
        if (container.children.length === 0) {
            container.innerHTML = `
                <div class="text-center py-4 text-muted">
                    <i class="fas fa-question-circle fa-2x mb-2"></i>
                    <p>Este formulario no tiene preguntas. Haz clic en "Agregar Pregunta" para comenzar.</p>
                </div>
            `;
        }
    }
}

// Event listener para el botón de agregar pregunta
document.getElementById('agregarPregunta').addEventListener('click', agregarPregunta);

// Función para verificar si un elemento existe antes de acceder a sus propiedades
function elementoExiste(selector) {
    return document.querySelector(selector) !== null;
}

// Función segura para acceder a propiedades de elementos
function getElementProperty(selector, property, defaultValue = null) {
    const element = document.querySelector(selector);
    return element ? element[property] : defaultValue;
}

// Inicializar preguntas padre disponibles al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    actualizarPreguntasPadre();

    // Configurar preguntas existentes de forma segura
    const preguntasExistentes = document.querySelectorAll('.pregunta-item');
    preguntasExistentes.forEach((pregunta, index) => {
        const textoInput = pregunta.querySelector('input[name*="[texto_pregunta]"]');
        if (textoInput) {
            const preguntaId = textoInput.name.match(/\[(\d+)\]/);
            if (preguntaId && preguntaId[1]) {
                configurarEventListenersPregunta(pregunta, preguntaId[1]);

                // Configurar pregunta padre si existe
                const padreSelect = pregunta.querySelector('.pregunta-padre');
                if (padreSelect && padreSelect.dataset.selected) {
                    padreSelect.value = padreSelect.dataset.selected;
                }
            }
        }
    });
});

// Validación del formulario antes de enviar
document.getElementById('formularioEditar').addEventListener('submit', function(e) {
    console.log('Iniciando validación del formulario...');

    const preguntas = document.querySelectorAll('.pregunta-item:not([style*="display: none"])');
    console.log('Preguntas encontradas:', preguntas.length);

    if (preguntas.length === 0) {
        e.preventDefault();
        alert('El formulario debe tener al menos una pregunta.');
        return;
    }

    // SOLUCIÓN TEMPORAL: Desactivar validación hasta que se arregle el sistema de herencia
    console.log('⚠️ Validación temporalmente desactivada para debugging');
    console.log('✅ Enviando formulario sin validación...');

    // Mostrar indicador de carga
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Guardando...';
    submitBtn.disabled = true;

    // Re-habilitar si hay error
    setTimeout(() => {
        if (submitBtn.disabled) {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    }, 10000); // 10 segundos timeout
});
</script>