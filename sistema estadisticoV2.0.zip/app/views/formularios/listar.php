<?php
/**
 * Sistema Estadístico Pro - Listar Formularios
 * Vista para mostrar todos los formularios del sistema
 */

// Verificar permisos
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'registrado', 'supremo'])) {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-clipboard-list me-2 text-primary"></i>
                    Gestión de Formularios
                </h2>
                <p class="text-muted mt-1">Formularios dinámicos para censos</p>
            </div>
            <div>
                <a href="<?php echo base_url('formularios/crear'); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-1"></i>Crear Formulario
                </a>
            </div>
        </div>

        <!-- Estadísticas -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-clipboard fa-2x mb-2"></i>
                        <h4><?php echo $estadisticas['total_formularios'] ?? 0; ?></h4>
                        <small>Total Formularios</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-check-circle fa-2x mb-2"></i>
                        <h4><?php echo $estadisticas['formularios_aprobados'] ?? 0; ?></h4>
                        <small>Aprobados</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-clock fa-2x mb-2"></i>
                        <h4><?php echo $estadisticas['formularios_pendientes'] ?? 0; ?></h4>
                        <small>Pendientes</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-secondary text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-chart-bar fa-2x mb-2"></i>
                        <h4><?php echo $estadisticas['censos_realizados'] ?? 0; ?></h4>
                        <small>Censos Realizados</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filtros -->
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-filter me-2"></i>Filtros
                </h6>
            </div>
            <div class="card-body">
                <form method="GET" action="<?php echo base_url('formularios/listar'); ?>" class="row g-3">
                    <div class="col-md-3">
                        <label for="especie_id" class="form-label">Especie</label>
                        <select class="form-select" id="especie_id" name="especie_id">
                            <option value="">Todas las especies</option>
                            <?php foreach ($especies as $especie): ?>
                                <option value="<?php echo $especie['id']; ?>" <?php echo (isset($_GET['especie_id']) && $_GET['especie_id'] == $especie['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($especie['nombre']); ?> (<?php echo htmlspecialchars($especie['modulo']); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="estado" class="form-label">Estado</label>
                        <select class="form-select" id="estado" name="estado">
                            <option value="">Todos los estados</option>
                            <?php foreach ($estados as $key => $value): ?>
                                <option value="<?php echo $key; ?>" <?php echo (isset($_GET['estado']) && $_GET['estado'] == $key) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($value); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="buscar" class="form-label">Buscar</label>
                        <input type="text" class="form-control" id="buscar" name="buscar"
                               placeholder="Nombre o descripción..."
                               value="<?php echo htmlspecialchars($_GET['buscar'] ?? ''); ?>">
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-outline-primary me-2">
                            <i class="fas fa-search me-1"></i>Filtrar
                        </button>
                        <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-times me-1"></i>Limpiar
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Lista de Formularios -->
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-list me-2"></i>Formularios
                    <span class="badge bg-primary ms-2"><?php echo $paginacion['total'] ?? 0; ?></span>
                </h6>
            </div>
            <div class="card-body">
                <?php if (!empty($formularios)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Nombre</th>
                                    <th>Especie</th>
                                    <th>Estado</th>
                                    <th>Creador</th>
                                    <th>Fecha Creación</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($formularios as $formulario): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($formulario['nombre']); ?></strong>
                                            <?php if (!empty($formulario['descripcion'])): ?>
                                                <br><small class="text-muted"><?php echo htmlspecialchars(substr($formulario['descripcion'], 0, 50)); ?>...</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?php echo htmlspecialchars($formulario['especie_nombre']); ?></span>
                                        </td>
                                        <td>
                                            <?php
                                            $estadoClass = match($formulario['estado']) {
                                                'borrador' => 'secondary',
                                                'pendiente' => 'warning',
                                                'aprobado' => 'success',
                                                'archivado' => 'dark',
                                                default => 'secondary'
                                            };
                                            ?>
                                            <span class="badge bg-<?php echo $estadoClass; ?>">
                                                <?php echo htmlspecialchars($estados[$formulario['estado']] ?? $formulario['estado']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($formulario['creador_nombre']); ?></td>
                                        <td><?php echo date('d/m/Y', strtotime($formulario['fecha_creacion'])); ?></td>
                                        <td>
                                            <div class="btn-group btn-group-sm" role="group">
                                                <a href="<?php echo base_url('formularios/ver/' . $formulario['id']); ?>"
                                                   class="btn btn-outline-info" title="Ver detalles">
                                                    <i class="fas fa-eye"></i>
                                                </a>

                                                <?php if ($formulario['estado'] === 'aprobado'): ?>
                                                    <a href="<?php echo base_url('formularios/responder/' . $formulario['id']); ?>"
                                                       class="btn btn-outline-success" title="Realizar censo">
                                                        <i class="fas fa-play"></i>
                                                    </a>
                                                <?php endif; ?>

                                                <?php if (($formulario['creador_id'] ?? null) == $_SESSION['user_id'] || (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'supremo')): ?>
                                                    <a href="<?php echo base_url('formularios/editar/' . $formulario['id']); ?>"
                                                       class="btn btn-outline-primary" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </a>

                                                    <?php if ($formulario['estado'] === 'pendiente' && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'supremo'): ?>
                                                        <a href="<?php echo base_url('formularios/aprobar/' . $formulario['id']); ?>"
                                                           class="btn btn-outline-success" title="Aprobar"
                                                           onclick="return confirm('¿Estás seguro de aprobar este formulario?')">
                                                            <i class="fas fa-check"></i>
                                                        </a>
                                                        <a href="<?php echo base_url('formularios/rechazar/' . $formulario['id']); ?>"
                                                           class="btn btn-outline-danger" title="Rechazar"
                                                           onclick="return confirm('¿Estás seguro de rechazar este formulario?')">
                                                            <i class="fas fa-times"></i>
                                                        </a>
                                                    <?php endif; ?>

                                                    <a href="<?php echo base_url('formularios/duplicar/' . $formulario['id']); ?>"
                                                       class="btn btn-outline-secondary" title="Duplicar">
                                                        <i class="fas fa-copy"></i>
                                                    </a>

                                                    <a href="<?php echo base_url('formularios/eliminar/' . $formulario['id']); ?>"
                                                       class="btn btn-outline-danger" title="Eliminar"
                                                       onclick="return confirm('¿Estás seguro de eliminar este formulario?')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Paginación -->
                    <?php if (($paginacion['total_paginas'] ?? 1) > 1): ?>
                        <nav aria-label="Navegación de páginas" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if (($paginacion['pagina_actual'] ?? 1) > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo base_url('formularios/listar/' . (($paginacion['pagina_actual'] ?? 1) - 1)); ?>">
                                            <i class="fas fa-chevron-left"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php
                                $pagina_actual = $paginacion['pagina_actual'] ?? 1;
                                $total_paginas = $paginacion['total_paginas'] ?? 1;
                                for ($i = max(1, $pagina_actual - 2); $i <= min($total_paginas, $pagina_actual + 2); $i++):
                                ?>
                                    <li class="page-item <?php echo $i == $pagina_actual ? 'active' : ''; ?>">
                                        <a class="page-link" href="<?php echo base_url('formularios/listar/' . $i); ?>">
                                            <?php echo $i; ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>

                                <?php if ($pagina_actual < $total_paginas): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo base_url('formularios/listar/' . ($pagina_actual + 1)); ?>">
                                            <i class="fas fa-chevron-right"></i>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No hay formularios registrados</h5>
                        <p class="text-muted">Comienza creando el primer formulario del sistema.</p>
                        <a href="<?php echo base_url('formularios/crear'); ?>" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i>Crear Primer Formulario
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>