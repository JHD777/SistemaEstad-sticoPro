<?php
/**
 * Sistema Estadístico Pro - Formularios Pendientes de Aprobación
 * Vista para que los administradores supremos aprueben o rechacen formularios
 */

// Verificar permisos
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'supremo') {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-clock me-2 text-warning"></i>
                    Formularios Pendientes
                </h2>
                <p class="text-muted mt-1">Formularios esperando aprobación</p>
            </div>
            <div>
                <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Volver a Formularios
                </a>
            </div>
        </div>

        <!-- Estadísticas -->
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="card bg-warning text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-clock fa-2x mb-2"></i>
                        <h4><?php echo count($formularios_pendientes ?? []); ?></h4>
                        <small>Pendientes de Revisión</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-user-tie fa-2x mb-2"></i>
                        <h4><?php echo count(array_unique(array_column($formularios_pendientes ?? [], 'creador_id'))) ?? 0; ?></h4>
                        <small>Creadores Activos</small>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-secondary text-white">
                    <div class="card-body text-center">
                        <i class="fas fa-calendar fa-2x mb-2"></i>
                        <h4><?php echo !empty($formularios_pendientes) ? date('d/m', strtotime($formularios_pendientes[0]['fecha_creacion'] ?? 'now')) : '--'; ?></h4>
                        <small>Última Creación</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Lista de Formularios Pendientes -->
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="fas fa-list me-2"></i>Formularios Pendientes de Aprobación
                    <span class="badge bg-warning ms-2"><?php echo count($formularios_pendientes ?? []); ?></span>
                </h6>
            </div>
            <div class="card-body">
                <?php if (!empty($formularios_pendientes)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Nombre</th>
                                    <th>Especie</th>
                                    <th>Creador</th>
                                    <th>Fecha Creación</th>
                                    <th>Preguntas</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($formularios_pendientes as $formulario): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($formulario['nombre']); ?></strong>
                                            <?php if (!empty($formulario['descripcion'])): ?>
                                                <br><small class="text-muted"><?php echo htmlspecialchars(substr($formulario['descripcion'], 0, 50)); ?>...</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-info"><?php echo htmlspecialchars($formulario['especie_nombre']); ?></span>
                                        </td>
                                        <td><?php echo htmlspecialchars($formulario['creador_nombre']); ?></td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($formulario['fecha_creacion'])); ?></td>
                                        <td>
                                            <?php
                                            // Contar preguntas del formulario
                                            $preguntaModel = new Pregunta();
                                            $preguntas = $preguntaModel->obtenerPorFormulario($formulario['id']);
                                            echo count($preguntas);
                                            ?>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm" role="group">
                                                <a href="<?php echo base_url('formularios/ver/' . $formulario['id']); ?>"
                                                   class="btn btn-outline-info" title="Ver detalles">
                                                    <i class="fas fa-eye"></i>
                                                </a>

                                                <a href="<?php echo base_url('formularios/aprobar/' . $formulario['id']); ?>"
                                                   class="btn btn-outline-success" title="Aprobar"
                                                   onclick="return confirm('¿Estás seguro de aprobar este formulario? Una vez aprobado, podrá ser usado para realizar censos.')">
                                                    <i class="fas fa-check"></i>
                                                </a>

                                                <a href="<?php echo base_url('formularios/rechazar/' . $formulario['id']); ?>"
                                                   class="btn btn-outline-danger" title="Rechazar"
                                                   onclick="return confirm('¿Estás seguro de rechazar este formulario? El creador podrá editarlo y volver a enviarlo para aprobación.')">
                                                    <i class="fas fa-times"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                        <h5 class="text-success">¡Excelente trabajo!</h5>
                        <p class="text-muted">No hay formularios pendientes de aprobación en este momento.</p>
                        <p class="text-muted">Todos los formularios han sido revisados o están en proceso de creación.</p>
                        <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-primary">
                            <i class="fas fa-list me-1"></i>Ver Todos los Formularios
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>