<?php
/**
 * Sistema Estadístico Pro - Crear Formulario
 * Vista para crear formularios dinámicos con preguntas
 */

// Verificar permisos
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'registrado', 'supremo'])) {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-plus me-2 text-primary"></i>
                    Crear Nuevo Formulario
                </h2>
                <p class="text-muted mt-1">Diseña un formulario dinámico para censos</p>
            </div>
            <div>
                <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Volver
                </a>
            </div>
        </div>

        <form id="formularioCrear" method="POST" action="<?php echo base_url('formularios/crear'); ?>">
            <!-- Información de Ayuda -->
            <div class="alert alert-info mb-4">
                <h6><i class="fas fa-question-circle me-2"></i>¿Cómo crear un formulario?</h6>
                <p class="mb-2">Sigue estos pasos para crear un formulario dinámico:</p>
                <ol class="mb-0">
                    <li><strong>Información básica:</strong> Selecciona el tipo de formulario y la especie correspondiente</li>
                    <li><strong>Preguntas:</strong> Agrega preguntas una por una usando el botón "Agregar Pregunta"</li>
                    <li><strong>Lógica condicional:</strong> Marca "Esta pregunta depende de otra" para crear preguntas que aparecen solo bajo ciertas condiciones</li>
                    <li><strong>Guardar:</strong> El formulario se guarda como borrador y puede ser aprobado por un supervisor</li>
                </ol>
                <hr>
                <p class="mb-0"><strong>Nota:</strong> Los formularios base (reino/módulo) heredan automáticamente a niveles inferiores. Los formularios específicos solo aplican a esa especie.</p>
                <hr>
                <p class="mb-0"><strong>💡 Tip para preguntas condicionales:</strong> Para preguntas Sí/No, usa <code>1</code> para Sí y <code>0</code> para No. Para opciones múltiples, escribe exactamente la opción (ej: "Sí", "Rojo").</p>
                <hr>
                <p class="mb-0"><strong>⚠️ Importante:</strong> Las preguntas condicionales solo pueden depender de preguntas anteriores. Si necesitas cambiar el orden, elimina y vuelve a crear las preguntas.</p>
            </div>

            <!-- Información Básica del Formulario -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0">
                        <i class="fas fa-info-circle me-2"></i>Información del Formulario
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="tipo_formulario" class="form-label">
                                    Tipo de Formulario <span class="text-danger">*</span>
                                </label>
                                <select class="form-select" id="tipo_formulario" name="tipo_formulario" required>
                                    <option value="">Seleccionar tipo...</option>
                                    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'supremo'): ?>
                                        <option value="reino">Formulario Base de Reino (Flora/Fauna)</option>
                                        <option value="modulo">Formulario Base de Módulo (Cítricos, Bovinos)</option>
                                    <?php endif; ?>
                                    <option value="especie">Formulario Específico de Especie (Limón, Vaca)</option>
                                </select>
                                <div class="form-text">Los formularios base heredan preguntas automáticamente</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3" id="especieContainer" style="display: none;">
                                <label for="especie_id" class="form-label">
                                    Especie/Módulo/Reino <span class="text-danger">*</span>
                                </label>
                                <select class="form-select" id="especie_id" name="especie_id" required style="display: none;">
                                    <option value="">Seleccionar...</option>
                                </select>
                                <div class="form-text">Selecciona según el tipo de formulario</div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="nombre" class="form-label">
                                    Nombre del Formulario <span class="text-danger">*</span>
                                </label>
                                <input type="text" class="form-control" id="nombre" name="nombre"
                                       placeholder="Ej: Censo de Limón 2024" required>
                                <div class="form-text">Nombre descriptivo del formulario</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="estado" class="form-label">Estado Inicial</label>
                                <select class="form-select" id="estado" name="estado">
                                    <option value="borrador">Borrador (puedes editar después)</option>
                                    <option value="pendiente">Pendiente de Aprobación</option>
                                </select>
                                <div class="form-text">Estado inicial del formulario</div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <textarea class="form-control" id="descripcion" name="descripcion" rows="3"
                                  placeholder="Describe el propósito y alcance del formulario..."></textarea>
                        <div class="form-text">Descripción opcional del formulario</div>
    
                        <!-- Información sobre formularios base -->
                        <div class="alert alert-warning" id="baseInfo" style="display: none;">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>Formulario Base:</strong>
                            Los formularios base heredan preguntas automáticamente a todos los niveles inferiores.
                            Solo los usuarios supremos pueden crear formularios base.
                        </div>

                        <!-- Información sobre herencia -->
                        <div class="alert alert-info" id="herenciaInfo" style="display: none;">
                            <i class="fas fa-link me-2"></i>
                            <strong>Herencia Automática:</strong>
                            <span id="herenciaTexto">Este formulario heredará preguntas de los formularios base de niveles superiores.</span>
                        </div>

                        <!-- Vista previa de preguntas heredadas -->
                        <div id="herenciaPreview" style="display: none;">
                            <!-- El contenido se creará dinámicamente con JavaScript -->
                        </div>

                    </div>
                </div>
            </div>

            <!-- Constructor de Preguntas -->
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">
                        <i class="fas fa-question-circle me-2"></i>Preguntas del Formulario
                    </h6>
                    <button type="button" class="btn btn-primary btn-sm" id="agregarPregunta">
                        <i class="fas fa-plus me-1"></i>Agregar Pregunta
                    </button>
                </div>
                <div class="card-body">
                    <div id="preguntasContainer">
                        <!-- Las preguntas se agregarán aquí dinámicamente -->
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-question-circle fa-2x mb-2"></i>
                            <p>Haz clic en "Agregar Pregunta" para comenzar a construir tu formulario</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Botones de Acción -->
            <div class="d-flex justify-content-end mt-4 gap-2">
                <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-times me-1"></i>Cancelar
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i>Crear Formulario
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Template para preguntas (oculto) -->
<div id="preguntaTemplate" style="display: none;">
    <div class="pregunta-item card mb-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h6 class="mb-0 pregunta-titulo">
                <i class="fas fa-question me-2"></i>Pregunta <span class="numero-pregunta">1</span>
            </h6>
            <div>
                <button type="button" class="btn btn-outline-danger btn-sm eliminar-pregunta">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-8">
                    <div class="mb-3">
                        <label class="form-label">Texto de la Pregunta <span class="text-danger">*</span></label>
                        <input type="text" class="form-control pregunta-texto" name="preguntas[INDEX][texto_pregunta]"
                               placeholder="Escribe la pregunta aquí..." required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-3">
                        <label class="form-label">Tipo de Pregunta <span class="text-danger">*</span></label>
                        <select class="form-select pregunta-tipo" name="preguntas[INDEX][tipo_pregunta]" required>
                            <option value="">Seleccionar tipo...</option>
                            <?php foreach (QUESTION_TYPES as $key => $value): ?>
                                <option value="<?php echo $key; ?>"><?php echo htmlspecialchars($value); ?></option>
                            <?php endforeach; ?>
                            <option value="opcion_multiple">Opción Múltiple</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Contenedor para opciones (solo para opcion_multiple) -->
            <div class="opciones-container" style="display: none;">
                <div class="mb-3">
                    <label class="form-label">Opciones (separadas por comas)</label>
                    <input type="text" class="form-control opciones-input" name="preguntas[INDEX][opciones]"
                           placeholder="Ej: Sí,No,Tal vez">
                    <div class="form-text">Las opciones aparecerán como un menú desplegable</div>
                </div>
            </div>


            <!-- Contenedor para lógica condicional -->
            <div class="condicional-container">
                <div class="form-check mb-3">
                    <input class="form-check-input pregunta-condicional" type="checkbox"
                           name="preguntas[INDEX][condicional]" value="1">
                    <label class="form-check-label">
                        Esta pregunta depende de otra
                    </label>
                </div>

                <div class="condicional-detalles" style="display: none;">
                    <div class="row">
                        <div class="col-md-6">
                            <label class="form-label">Mostrar si la respuesta a:</label>
                            <select class="form-select pregunta-padre" name="preguntas[INDEX][depende_de]">
                                <option value="">Seleccionar pregunta...</option>
                                <!-- Se llenará dinámicamente con preguntas anteriores -->
                            </select>
                        </div>
                        <div class="col-md-6">
                        <label class="form-label">Es igual a:</label>
                        <input type="text" class="form-control respuesta-requerida"
                               name="preguntas[INDEX][respuesta_requerida]"
                               placeholder="Ej: Sí, No, Auto"
                               title="Para preguntas booleanas: 1=Sí, 0=No">
                        <div class="form-text">
                            <small><strong>Para preguntas Sí/No:</strong> Escribe <code>1</code> para Sí, <code>0</code> para No</small><br>
                            <small><strong>Para opciones múltiples:</strong> Escribe exactamente la opción (ej: "Sí", "Rojo")</small><br>
                            <small><strong>Ejemplo:</strong> Si quieres que aparezca cuando respondan "Sí", escribe: <code>1</code></small>
                        </div>
                    </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-check">
                        <input class="form-check-input pregunta-obligatoria" type="checkbox"
                                name="preguntas[INDEX][obligatoria]" value="1">
                        <label class="form-check-label">
                            Pregunta obligatoria
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Variables globales
let preguntaIndex = 0;
let preguntasCreadas = [];
let debugMode = false; // Desactivar modo debug para producción

// Función para agregar pregunta
function agregarPregunta() {
    debugEstadoActual('ANTES DE AGREGAR PREGUNTA');

    preguntaIndex++;
    const template = document.getElementById('preguntaTemplate').innerHTML;
    const preguntaHtml = template.replace(/INDEX/g, preguntaIndex);

    // Agregar al contenedor
    const container = document.getElementById('preguntasContainer');
    if (container.querySelector('.text-center')) {
        container.innerHTML = ''; // Limpiar mensaje inicial
    }
    container.insertAdjacentHTML('beforeend', preguntaHtml);

    // Actualizar números de preguntas
    actualizarNumerosPreguntas();

    // Agregar event listeners
    const nuevaPregunta = container.lastElementChild;
    configurarEventListenersPregunta(nuevaPregunta, preguntaIndex);

    // Agregar a la lista de preguntas creadas
    preguntasCreadas.push(preguntaIndex);

    debugEstadoActual('DESPUÉS DE AGREGAR PREGUNTA');

    // Actualizar preguntas padre disponibles
    actualizarPreguntasPadre();

    // Hacer scroll hacia la nueva pregunta
    setTimeout(() => {
        nuevaPregunta.scrollIntoView({ behavior: 'smooth', block: 'center' });
        // Enfocar el campo de texto de la nueva pregunta
        const textoInput = nuevaPregunta.querySelector('.pregunta-texto');
        if (textoInput) textoInput.focus();
    }, 100);
}

// Función para sincronizar array con DOM (llamada periódica) - SILENCIOSA
function sincronizarArrayConDOM() {
    const preguntasDOM = document.querySelectorAll('.pregunta-item');
    const arrayActualizado = [];

    preguntasDOM.forEach((pregunta) => {
        const numeroPregunta = parseInt(pregunta.querySelector('.numero-pregunta').textContent);
        arrayActualizado.push(numeroPregunta);
    });

    // Solo actualizar si hay diferencias Y sin logs
    if (JSON.stringify(arrayActualizado.sort()) !== JSON.stringify(preguntasCreadas.sort())) {
        preguntasCreadas = [...arrayActualizado]; // Copia profunda sin logs
    }
}

// Función para limpiar array de preguntas vacías/phantom (DESACTIVADA PERMANENTEMENTE)
function limpiarArrayPreguntas() {
    // COMPLETAMENTE DESACTIVADO: Causa bucles infinitos
    // La validación se hace SOLO al enviar el formulario
    // NO ejecutar nunca esta función automáticamente
    return;
}

// Ejecutar solo sincronización cada 5000ms (muy poco frecuente)
setInterval(sincronizarArrayConDOM, 5000);

// Función para configurar event listeners de una pregunta
function configurarEventListenersPregunta(preguntaElement, index) {
    // Event listener para tipo de pregunta
    const tipoSelect = preguntaElement.querySelector('.pregunta-tipo');
    tipoSelect.addEventListener('change', function() {
        mostrarOpcionesSegunTipo(this.value, preguntaElement);
    });

    // Event listener para pregunta condicional
    const condicionalCheck = preguntaElement.querySelector('.pregunta-condicional');
    condicionalCheck.addEventListener('change', function() {
        mostrarCondicional(this.checked, preguntaElement);
    });

    // Event listener para eliminar pregunta
    const eliminarBtn = preguntaElement.querySelector('.eliminar-pregunta');
    eliminarBtn.addEventListener('click', function() {
        eliminarPregunta(index);
    });
}

// Función para mostrar/ocultar opciones según tipo
function mostrarOpcionesSegunTipo(tipo, preguntaElement) {
    const opcionesContainer = preguntaElement.querySelector('.opciones-container');

    if (tipo === 'opcion_multiple') {
        opcionesContainer.style.display = 'block';
    } else {
        opcionesContainer.style.display = 'none';
    }
}


// Función para mostrar/ocultar condicional
function mostrarCondicional(mostrar, preguntaElement) {
    const condicionalDetalles = preguntaElement.querySelector('.condicional-detalles');
    if (mostrar) {
        condicionalDetalles.style.display = 'block';
    } else {
        condicionalDetalles.style.display = 'none';
        // Limpiar valores cuando se desactiva
        const padreSelect = preguntaElement.querySelector('.pregunta-padre');
        const respuestaInput = preguntaElement.querySelector('.respuesta-requerida');
        if (padreSelect) padreSelect.value = '';
        if (respuestaInput) respuestaInput.value = '';
    }
}

// Función para mostrar/ocultar preguntas condicionales en tiempo real durante la creación
function actualizarCondicionales() {
    const preguntas = document.querySelectorAll('.pregunta-item');

    preguntas.forEach((pregunta, index) => {
        const numeroPregunta = index + 1;
        const condicionalCheck = pregunta.querySelector('.pregunta-condicional');

        if (condicionalCheck && condicionalCheck.checked) {
            const padreSelect = pregunta.querySelector('.pregunta-padre');
            const respuestaInput = pregunta.querySelector('.respuesta-requerida');

            if (padreSelect && padreSelect.value && respuestaInput && respuestaInput.value.trim()) {
                // Esta pregunta es condicional, verificar si debe mostrarse
                const preguntaPadreIndex = padreSelect.value;
                const respuestaRequerida = respuestaInput.value.trim();

                // Buscar la pregunta padre de forma segura
                const preguntaPadre = document.querySelector(`input[name="preguntas[${preguntaPadreIndex}][texto_pregunta]"]`);
                if (preguntaPadre) {
                    const tipoPadre = document.querySelector(`select[name="preguntas[${preguntaPadreIndex}][tipo_pregunta]"]`);

                    if (tipoPadre && tipoPadre.value === 'booleano') {
                        // Para booleanos, mostrar ayuda sobre valores
                        const ayudaElement = pregunta.querySelector('.respuesta-requerida');
                        if (ayudaElement && !ayudaElement.title) {
                            ayudaElement.title = 'Para preguntas booleanas: 1=Sí, 0=No';
                        }
                    }
                } else {
                    console.warn(`Pregunta padre ${preguntaPadreIndex} no encontrada para pregunta condicional ${numeroPregunta}`);
                }
            }
        }
    });
}

// Función para actualizar números de preguntas
function actualizarNumerosPreguntas() {
    const preguntas = document.querySelectorAll('.pregunta-item');
    preguntas.forEach((pregunta, index) => {
        const numeroElement = pregunta.querySelector('.numero-pregunta');
        numeroElement.textContent = index + 1;
    });
}

// Función para actualizar preguntas padre disponibles
function actualizarPreguntasPadre() {
    const selectsPadre = document.querySelectorAll('.pregunta-padre');
    selectsPadre.forEach(select => {
        // Guardar el valor seleccionado actual
        const valorSeleccionado = select.value;

        // Limpiar opciones existentes (excepto la primera)
        while (select.children.length > 1) {
            select.removeChild(select.lastChild);
        }

        // Agregar preguntas disponibles (solo las anteriores a la actual)
        const preguntaIndexActual = parseInt(select.closest('.pregunta-item').querySelector('.numero-pregunta').textContent);

        preguntasCreadas.forEach(num => {
            if (num < preguntaIndexActual) { // Solo preguntas anteriores
                const option = document.createElement('option');
                option.value = num; // Usar número de pregunta (1-based) que permanece estable al eliminar preguntas

                // Obtener el texto de la pregunta padre para mostrarlo
                const preguntaPadreElement = document.querySelector(`input[name="preguntas[${num}][texto_pregunta]"]`);
                let textoPregunta = `Pregunta ${num}`;
                if (preguntaPadreElement && preguntaPadreElement.value.trim()) {
                    textoPregunta = preguntaPadreElement.value.trim().substring(0, 40) + (preguntaPadreElement.value.length > 40 ? '...' : '');
                }

                option.textContent = textoPregunta;
                select.appendChild(option);
            }
        });

        // Si no hay preguntas anteriores disponibles, mostrar mensaje
        if (select.children.length === 1) { // Solo la opción "Seleccionar pregunta..."
            const option = document.createElement('option');
            option.value = '';
            option.disabled = true;
            option.textContent = 'No hay preguntas anteriores disponibles';
            select.appendChild(option);
        }

        // Restaurar la selección si aún existe
        if (valorSeleccionado && select.querySelector(`option[value="${valorSeleccionado}"]`)) {
            select.value = valorSeleccionado;
        } else if (valorSeleccionado) {
            // Si la selección ya no existe, limpiarla
            select.value = '';
        }
    });
}

// Función para eliminar pregunta
function eliminarPregunta(index) {
    debugEstadoActual(`ANTES DE ELIMINAR PREGUNTA ${index}`);

    // Obtener el texto de la pregunta para mostrar en la confirmación
    const preguntaElement = document.querySelector(`input[name="preguntas[${index}][texto_pregunta]"]`);
    let textoPregunta = `Pregunta ${index}`;
    if (preguntaElement && preguntaElement.value.trim()) {
        textoPregunta = preguntaElement.value.trim().substring(0, 50) + (preguntaElement.value.length > 50 ? '...' : '');
    }

    if (confirm(`¿Estás seguro de eliminar la siguiente pregunta?\n\n"${textoPregunta}"\n\nEsta acción no se puede deshacer.`)) {
        // Remover del DOM
        const preguntaElement = document.querySelector(`input[name="preguntas[${index}][texto_pregunta]"]`).closest('.pregunta-item');
        if (preguntaElement) {
            preguntaElement.remove();
            console.log(`✅ Pregunta ${index} removida del DOM`);
        } else {
            console.error(`❌ No se encontró el elemento DOM para pregunta ${index}`);
        }

        // Remover de la lista de preguntas creadas
        const indexInArray = preguntasCreadas.indexOf(index);
        if (indexInArray > -1) {
            preguntasCreadas.splice(indexInArray, 1);
            console.log(`✅ Pregunta ${index} removida del array`);
        } else {
            console.error(`❌ Pregunta ${index} no encontrada en array preguntasCreadas`);
        }

        debugEstadoActual(`DESPUÉS DE REMOVER PREGUNTA ${index}`);

        // Reindexar las preguntas restantes para evitar huecos
        const preguntasRestantes = document.querySelectorAll('.pregunta-item');
        console.log(`🔄 Reindexando ${preguntasRestantes.length} preguntas restantes`);

        preguntasCreadas = [];

        preguntasRestantes.forEach((pregunta, newIndex) => {
            const newIndexValue = newIndex + 1;
            const numeroElement = pregunta.querySelector('.numero-pregunta');
            const oldNumber = numeroElement.textContent;
            numeroElement.textContent = newIndexValue;

            // Actualizar los names de todos los inputs
            const inputs = pregunta.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                if (input.name) {
                    input.name = input.name.replace(/preguntas\[\d+\]/, `preguntas[${newIndexValue}]`);
                }
            });

            preguntasCreadas.push(newIndexValue);
            console.log(`   Pregunta ${oldNumber} → Pregunta ${newIndexValue}`);
        });

        debugEstadoActual('DESPUÉS DE REINDEXAR');

        // Actualizar preguntas padre disponibles
        actualizarPreguntasPadre();

        // Mostrar mensaje inicial si no hay preguntas
        const container = document.getElementById('preguntasContainer');
        if (container.children.length === 0) {
            container.innerHTML = `
                <div class="text-center py-4 text-muted">
                    <i class="fas fa-question-circle fa-2x mb-2"></i>
                    <p>Haz clic en "Agregar Pregunta" para comenzar a construir tu formulario</p>
                </div>
            `;
        }
    }
}

// Event listener para el botón de agregar pregunta
document.getElementById('agregarPregunta').addEventListener('click', agregarPregunta);

// Función de debug para mostrar estado actual
function debugEstadoActual(mensaje = '') {
    if (!debugMode) return;

    const preguntas = document.querySelectorAll('.pregunta-item');
    console.log(`=== DEBUG ${mensaje} ===`);
    console.log('Preguntas en DOM:', preguntas.length);
    console.log('Array preguntasCreadas:', preguntasCreadas);
    console.log('preguntaIndex actual:', preguntaIndex);

    preguntas.forEach((pregunta, index) => {
        const numero = pregunta.querySelector('.numero-pregunta').textContent;
        const texto = pregunta.querySelector('.pregunta-texto').value;
        const tipo = pregunta.querySelector('.pregunta-tipo').value;
        console.log(`  Pregunta ${numero}: "${texto}" (${tipo})`);
    });
    console.log('===================');
}

// Validación del formulario antes de enviar
document.getElementById('formularioCrear').addEventListener('submit', function(e) {
    // Verificar que se haya seleccionado un tipo de formulario
    const tipoFormulario = document.getElementById('tipo_formulario');
    if (!tipoFormulario.value) {
        e.preventDefault();
        alert('Debes seleccionar un tipo de formulario.');
        tipoFormulario.focus();
        return;
    }

    // Verificar que el select de especie esté visible y tenga valor
    const especieContainer = document.getElementById('especieContainer');
    const especieSelect = document.getElementById('especie_id');

    if (especieContainer.style.display !== 'none' && especieSelect) {
        if (!especieSelect.value) {
            e.preventDefault();
            alert('Debes seleccionar una especie para el formulario.');
            especieSelect.focus();
            return;
        }
    }

    // Forzar sincronización antes de validar
    sincronizarArrayConDOM();

    const preguntas = document.querySelectorAll('.pregunta-item');

    if (preguntas.length === 0) {
        e.preventDefault();
        alert('Debes agregar al menos una pregunta al formulario.');
        return;
    }

    // FILTRAR SOLO PREGUNTAS VÁLIDAS (que tienen texto y tipo)
    const preguntasValidasDOM = [];
    preguntas.forEach((pregunta) => {
        const textoInput = pregunta.querySelector('.pregunta-texto');
        const tipoSelect = pregunta.querySelector('.pregunta-tipo');

        // Mostrar información de TODAS las preguntas primero
        const numero = pregunta.querySelector('.numero-pregunta').textContent;
        const texto = textoInput ? textoInput.value.trim() : '';
        const tipo = tipoSelect ? tipoSelect.value : '';
        const condicional = pregunta.querySelector('.pregunta-condicional').checked;
        console.log(`🔍 Pregunta ${numero}: texto="${texto}", tipo="${tipo}", condicional=${condicional}`);

        if (textoInput && textoInput.value.trim() && tipoSelect && tipoSelect.value) {
            preguntasValidasDOM.push(pregunta);
            console.log(`✅ Pregunta ${numero} VÁLIDA - se enviará`);
        } else {
            console.log(`❌ Pregunta ${numero} INVÁLIDA - NO se enviará`);
        }
    });

    if (preguntasValidasDOM.length === 0) {
        e.preventDefault();
        alert('Debes completar al menos una pregunta con texto y tipo antes de guardar.');
        return;
    }

    // Mostrar información de depuración
    console.log(`📊 Enviando formulario con ${preguntasValidasDOM.length} preguntas válidas`);
    preguntasValidasDOM.forEach((pregunta, index) => {
        const texto = pregunta.querySelector('.pregunta-texto').value;
        const tipo = pregunta.querySelector('.pregunta-tipo').value;
        const condicional = pregunta.querySelector('.pregunta-condicional').checked;
        console.log(`   Pregunta ${index + 1}: "${texto}" (${tipo}) ${condicional ? '[CONDICIONAL]' : ''}`);
    });

    // Validar SOLO las preguntas válidas
    let formularioValido = true;
    let primeraPreguntaInvalida = null;
    let errores = [];

    preguntasValidasDOM.forEach((pregunta, index) => {
        const numeroPregunta = pregunta.querySelector('.numero-pregunta').textContent;

        // Validar preguntas condicionales
        const condicionalCheck = pregunta.querySelector('.pregunta-condicional');
        if (condicionalCheck && condicionalCheck.checked) {
            const padreSelect = pregunta.querySelector('.pregunta-padre');
            const respuestaInput = pregunta.querySelector('.respuesta-requerida');

            if (!padreSelect.value) {
                formularioValido = false;
                errores.push(`Pregunta ${numeroPregunta}: selecciona pregunta padre para condición`);
                if (!primeraPreguntaInvalida) {
                    primeraPreguntaInvalida = padreSelect;
                }
            }

            if (!respuestaInput.value.trim()) {
                formularioValido = false;
                errores.push(`Pregunta ${numeroPregunta}: especifica respuesta requerida para condición`);
                if (!primeraPreguntaInvalida) {
                    primeraPreguntaInvalida = respuestaInput;
                }
            }
        }

        // Validar opciones para preguntas de opción múltiple
        const tipoSelect = pregunta.querySelector('.pregunta-tipo');
        if (tipoSelect.value === 'opcion_multiple') {
            const opcionesInput = pregunta.querySelector('.opciones-input');
            if (!opcionesInput || !opcionesInput.value.trim()) {
                formularioValido = false;
                errores.push(`Pregunta ${numeroPregunta}: especifica las opciones separadas por comas`);
                if (!primeraPreguntaInvalida) {
                    primeraPreguntaInvalida = opcionesInput;
                }
            }
        }

    });

    if (!formularioValido) {
        e.preventDefault();
        if (primeraPreguntaInvalida) {
            primeraPreguntaInvalida.focus();
            primeraPreguntaInvalida.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        alert('Errores encontrados:\n' + errores.join('\n'));
        return;
    }

    // Mostrar indicador de carga
    const submitBtn = document.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Creando...';
    submitBtn.disabled = true;

    // Re-habilitar si hay error
    setTimeout(() => {
        if (submitBtn.disabled) {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    }, 10000); // 10 segundos timeout

    // Mostrar resumen de lo que se va a enviar
    console.log('=== RESUMEN DEL FORMULARIO ===');
    console.log(`Tipo de formulario: ${document.getElementById('tipo_formulario').value}`);
    console.log(`Especie: ${document.getElementById('especie_id').value}`);
    console.log(`Nombre: ${document.getElementById('nombre').value}`);
    console.log(`Preguntas válidas encontradas: ${preguntasValidasDOM.length}`);
    console.log(`Total de preguntas en DOM: ${preguntas.length}`);

    // Mostrar TODAS las preguntas del formulario
    console.log('--- TODAS LAS PREGUNTAS ---');
    preguntas.forEach((pregunta, index) => {
        const numero = pregunta.querySelector('.numero-pregunta').textContent;
        const texto = pregunta.querySelector('.pregunta-texto').value;
        const tipo = pregunta.querySelector('.pregunta-tipo').value;
        const condicional = pregunta.querySelector('.pregunta-condicional').checked;
        const esValida = texto.trim() && tipo;
        console.log(`  Pregunta ${numero}: "${texto}" (${tipo}) ${condicional ? '[CONDICIONAL]' : ''} ${esValida ? '✅ VÁLIDA' : '❌ INVÁLIDA'}`);
    });

    console.log('--- PREGUNTAS QUE SE ENVIARÁN ---');
    preguntasValidasDOM.forEach((pregunta, index) => {
        const texto = pregunta.querySelector('.pregunta-texto').value;
        const tipo = pregunta.querySelector('.pregunta-tipo').value;
        const condicional = pregunta.querySelector('.pregunta-condicional').checked;
        console.log(`  ${index + 1}. "${texto}" (${tipo}) ${condicional ? '[CONDICIONAL]' : ''}`);
    });
    console.log('==============================');
});


// Esperar a que el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, setting up event listeners');
    
    // Event listener para el cambio de tipo de formulario
    document.getElementById('tipo_formulario').addEventListener('change', function() {
    const tipo = this.value;
    const especieContainer = document.getElementById('especieContainer');
    const especieSelect = document.getElementById('especie_id');
    const herenciaInfo = document.getElementById('herenciaInfo');
    const baseInfo = document.getElementById('baseInfo');
    const herenciaPreview = document.getElementById('herenciaPreview');

    if (tipo === 'reino' || tipo === 'modulo' || tipo === 'especie') {
        especieContainer.style.display = 'block';
        especieSelect.style.display = 'block';
        especieSelect.required = true;

        // Cargar opciones según el tipo
        cargarOpcionesEspecie(tipo);

        // Mostrar información de herencia
        if (tipo === 'reino' || tipo === 'modulo') {
            if (baseInfo) baseInfo.style.display = 'block';
            if (herenciaInfo) herenciaInfo.style.display = 'none';
            if (herenciaPreview) herenciaPreview.style.display = 'none';
        } else {
            if (baseInfo) baseInfo.style.display = 'none';
            if (herenciaInfo) herenciaInfo.style.display = 'block';
            if (herenciaPreview) herenciaPreview.style.display = 'none'; // Se mostrará cuando se seleccione especie
            const herenciaTexto = document.getElementById('herenciaTexto');
            if (herenciaTexto) {
                herenciaTexto.textContent =
                    'Este formulario heredará preguntas de los formularios base de niveles superiores.';
            }
        }
    } else {
        especieContainer.style.display = 'none';
        especieSelect.style.display = 'none';
        especieSelect.required = false;
        if (herenciaInfo) herenciaInfo.style.display = 'none';
        if (baseInfo) baseInfo.style.display = 'none';
        if (herenciaPreview) herenciaPreview.style.display = 'none';
    }
});

// Event listener para mostrar preguntas heredadas cuando se selecciona especie
document.getElementById('especie_id').addEventListener('change', function() {
    const especieId = this.value;
    const tipoFormulario = document.getElementById('tipo_formulario').value;
    const herenciaPreview = document.getElementById('herenciaPreview');

    console.log('especie_id changed:', especieId, 'tipoFormulario:', tipoFormulario);
    console.log('herenciaPreview found:', herenciaPreview);

    if (herenciaPreview) {
        if (tipoFormulario === 'especie' && especieId) {
            console.log('Mostrando preguntas heredadas para especie:', especieId);
            // Crear el contenido dinámicamente
            herenciaPreview.innerHTML = `
                <div class="alert alert-success">
                    <h6><i class="fas fa-eye me-2"></i>Preguntas que se heredarán automáticamente:</h6>
                    <div id="preguntasHeredadas" class="mt-3">
                        <div class="text-center">
                            <div class="spinner-border spinner-border-sm text-success" role="status">
                                <span class="visually-hidden">Cargando...</span>
                            </div>
                            <small class="text-muted ms-2">Cargando preguntas heredadas...</small>
                        </div>
                    </div>
                </div>
            `;
            cargarPreguntasHeredadas(especieId);
            herenciaPreview.style.display = 'block';
        } else {
            console.log('Ocultando preguntas heredadas');
            herenciaPreview.style.display = 'none';
            herenciaPreview.innerHTML = ''; // Limpiar contenido
        }
    } else {
        console.error('herenciaPreview element not found');
    }
});

// Función para cargar preguntas heredadas
function cargarPreguntasHeredadas(especieId) {
    console.log('Cargando preguntas heredadas para especie:', especieId);
    const container = document.getElementById('preguntasHeredadas');

    if (!container) {
        console.error('Container preguntasHeredadas no encontrado');
        return;
    }

    container.innerHTML = `
        <div class="text-center">
            <div class="spinner-border spinner-border-sm text-success" role="status">
                <span class="visually-hidden">Cargando...</span>
            </div>
            <small class="text-muted ms-2">Cargando preguntas heredadas...</small>
        </div>
    `;

    // Definir baseUrl si no existe
    if (!window.appConfig) {
        window.appConfig = {};
    }
    if (!window.appConfig.baseUrl) {
        window.appConfig.baseUrl = '<?php echo base_url(); ?>';
    }

    // Simular carga (en producción esto sería una llamada AJAX)
    setTimeout(() => {
        fetch(`${window.appConfig.baseUrl}api/preguntas/heredadas/${especieId}`, {
            credentials: 'same-origin'
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success && data.data && data.data.length > 0) {
                    mostrarPreguntasHeredadas(data.data);
                } else {
                    container.innerHTML = `
                        <div class="text-muted">
                            <i class="fas fa-info-circle me-2"></i>
                            No hay preguntas base definidas para heredar en esta jerarquía.
                        </div>
                    `;
                }
            })
            .catch(error => {
                console.error('Error cargando preguntas heredadas:', error);
                container.innerHTML = `
                    <div class="text-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Error al cargar preguntas heredadas: ${error.message}
                    </div>
                `;
            });
    }, 500);
}

// Función para mostrar preguntas heredadas
function mostrarPreguntasHeredadas(preguntas) {
    const container = document.getElementById('preguntasHeredadas');
    if (!container) {
        console.error('Container preguntasHeredadas no encontrado en mostrarPreguntasHeredadas');
        return;
    }

    let html = '<div class="list-group list-group-flush">';

    preguntas.forEach(pregunta => {
        const nivelTexto = pregunta.nivel_herencia === 'reino' ? 'Reino' :
                          pregunta.nivel_herencia === 'modulo' ? 'Módulo' : 'Especie';

        html += `
            <div class="list-group-item px-0">
                <div class="d-flex align-items-start">
                    <div class="flex-shrink-0 me-3">
                        <span class="badge bg-secondary">${nivelTexto}</span>
                    </div>
                    <div class="flex-grow-1">
                        <div class="fw-bold">${pregunta.texto_pregunta}</div>
                        <small class="text-muted">
                            Tipo: ${pregunta.tipo_pregunta}
                            ${pregunta.obligatoria ? ' | Obligatoria' : ''}
                            ${pregunta.depende_de ? ' | Condicional' : ''}
                        </small>
                    </div>
                    <div class="flex-shrink-0">
                        <i class="fas fa-lock text-muted" title="Pregunta heredada (no editable)"></i>
                    </div>
                </div>
            </div>
        `;
    });

    html += '</div>';
    container.innerHTML = html;
}

// Función para cargar opciones de especie según el tipo
function cargarOpcionesEspecie(tipo) {
    const especieSelect = document.getElementById('especie_id');
    especieSelect.innerHTML = '<option value="">Cargando...</option>';

    // Definir baseUrl si no existe
    if (!window.appConfig) {
        window.appConfig = {};
    }
    if (!window.appConfig.baseUrl) {
        window.appConfig.baseUrl = '<?php echo base_url(); ?>';
    }

    if (tipo === 'reino') {
        // Para reinos, usar datos estáticos ya que son fijos
        const opciones = [
            {id: 1, nombre: 'Flora'},
            {id: 2, nombre: 'Fauna'}
        ];
        especieSelect.innerHTML = '<option value="">Seleccionar...</option>';
        opciones.forEach(opcion => {
            const option = document.createElement('option');
            option.value = opcion.id;
            option.textContent = opcion.nombre;
            especieSelect.appendChild(option);
        });
        return;
    } else if (tipo === 'modulo') {
        // Cargar módulos dinámicamente usando API pública
        fetch(`${window.appConfig.baseUrl}api/estadistica/modulos`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success && data.data) {
                    especieSelect.innerHTML = '<option value="">Seleccionar...</option>';
                    data.data.forEach(opcion => {
                        const option = document.createElement('option');
                        option.value = opcion.id;
                        option.textContent = opcion.nombre;
                        especieSelect.appendChild(option);
                    });
                } else {
                    especieSelect.innerHTML = '<option value="">Error al cargar opciones</option>';
                }
            })
            .catch(error => {
                console.error('Error cargando opciones de especie:', error);
                especieSelect.innerHTML = '<option value="">Error al cargar opciones</option>';
            });
    } else if (tipo === 'especie') {
        // Cargar todas las especies disponibles usando API pública
        fetch(`${window.appConfig.baseUrl}api/estadistica/especies`)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success && data.data) {
                    especieSelect.innerHTML = '<option value="">Seleccionar...</option>';
                    data.data.forEach(especie => {
                        const option = document.createElement('option');
                        option.value = especie.id;
                        option.textContent = especie.nombre;
                        especieSelect.appendChild(option);
                    });
                } else {
                    especieSelect.innerHTML = '<option value="">Error al cargar especies</option>';
                }
            })
            .catch(error => {
                console.error('Error cargando especies:', error);
                especieSelect.innerHTML = '<option value="">Error al cargar especies</option>';
            });
    }
}

// Agregar event listener para actualizar preguntas condicionales cuando cambien respuestas
document.addEventListener('change', function(e) {
if (e.target.classList.contains('pregunta-tipo') ||
    e.target.classList.contains('pregunta-padre') ||
    e.target.classList.contains('respuesta-requerida') ||
    e.target.classList.contains('pregunta-condicional') ||
    e.target.classList.contains('opciones-input')) {
    setTimeout(() => {
        actualizarPreguntasPadre(); // Primero actualizar los selects padre
    }, 50);
}
});

// Función para verificar si un elemento existe antes de acceder a sus propiedades
function elementoExiste(selector) {
    return document.querySelector(selector) !== null;
}

// Función segura para acceder a propiedades de elementos
function getElementProperty(selector, property, defaultValue = null) {
    const element = document.querySelector(selector);
    return element ? element[property] : defaultValue;
}

// Event listener para detectar cambios en inputs de texto (para actualizar selects padre)
document.addEventListener('input', function(e) {
if (e.target.classList.contains('pregunta-texto')) {
    // Actualizar los selects padre cuando cambie el texto de alguna pregunta
    setTimeout(() => {
        actualizarPreguntasPadre();
    }, 100);
}
});
}); // Cierre del DOMContentLoaded





</script>