<?php
/**
 * Sistema Estadístico Pro - Responder Formulario (Realizar Censo)
 * Vista para responder formularios dinámicos con lógica condicional
 */

// Verificar permisos
if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'registrado', 'supremo'])) {
    header('Location: ' . base_url('dashboard/general'));
    exit;
}
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="mb-0">
                    <i class="fas fa-play me-2 text-success"></i>
                    Realizar Censo
                </h2>
                <p class="text-muted mt-1"><?php echo htmlspecialchars($formulario['nombre']); ?></p>
            </div>
            <div>
                <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Volver
                </a>
            </div>
        </div>

        <!-- Información del Formulario -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h5><?php echo htmlspecialchars($formulario['nombre']); ?></h5>
                        <?php if (!empty($formulario['descripcion'])): ?>
                            <p class="text-muted mb-2"><?php echo htmlspecialchars($formulario['descripcion']); ?></p>
                        <?php endif; ?>
                        <p class="mb-0">
                            <span class="badge bg-info"><?php echo htmlspecialchars($formulario['especie_nombre']); ?></span>
                        </p>
                    </div>
                    <div class="col-md-6 text-end">
                        <div class="text-muted small">
                            <i class="fas fa-calendar me-1"></i>Creado: <?php echo date('d/m/Y', strtotime($formulario['fecha_creacion'])); ?>
                            <br>
                            <i class="fas fa-user me-1"></i>Por: <?php echo htmlspecialchars($formulario['creador_nombre']); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Formulario de Respuestas -->
        <form id="formularioRespuestas" method="POST" action="<?php echo base_url('formularios/responder/' . $formulario['id']); ?>">
            <!-- Información del Censo -->
            <div class="card mb-4">
                <div class="card-header">
                    <h6 class="mb-0">
                        <i class="fas fa-map-marker-alt me-2"></i>Información del Censo
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="ubicacion_geo" class="form-label">Ubicación Geográfica</label>
                                <input type="text" class="form-control" id="ubicacion_geo" name="ubicacion_geo"
                                       placeholder="Ej: -12.0464, -77.0428">
                                <div class="form-text">Coordenadas GPS (opcional)</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="observaciones" class="form-label">Observaciones</label>
                                <textarea class="form-control" id="observaciones" name="observaciones" rows="2"
                                          placeholder="Observaciones adicionales del censo..."></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Preguntas del Formulario -->
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0">
                        <i class="fas fa-question-circle me-2"></i>Preguntas del Formulario
                        <span class="badge bg-primary ms-2"><?php echo count($preguntas); ?></span>
                    </h6>
                </div>
                <div class="card-body">
                    <?php if (!empty($preguntas)): ?>
                        <div id="preguntasContainer">
                            <?php foreach ($preguntas as $pregunta): ?>
                                <div class="pregunta-item mb-4 <?php echo !empty($pregunta['depende_de']) ? 'pregunta-condicional' : ''; ?>"
                                     data-depende-de="<?php echo $pregunta['depende_de'] ?? ''; ?>"
                                     data-respuesta-necesaria="<?php echo htmlspecialchars($pregunta['respuesta_requerida'] ?? ''); ?>"
                                     style="<?php echo !empty($pregunta['depende_de']) ? 'display: none;' : ''; ?>">

                                    <div class="card">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-8">
                                                    <h6 class="card-title">
                                                        <span class="badge bg-secondary me-2"><?php echo $pregunta['orden']; ?></span>
                                                        <?php echo htmlspecialchars($pregunta['texto_pregunta']); ?>
                                                        <?php if ($pregunta['obligatoria']): ?>
                                                            <span class="text-danger">*</span>
                                                        <?php endif; ?>
                                                    </h6>
                                                </div>
                                                <div class="col-md-4 text-end">
                                                    <small class="text-muted">
                                                        <?php echo htmlspecialchars(QUESTION_TYPES[$pregunta['tipo_pregunta']] ?? $pregunta['tipo_pregunta']); ?>
                                                    </small>
                                                </div>
                                            </div>

                                            <div class="mt-3">
                                                <?php
                                                $fieldName = 'pregunta_' . $pregunta['id'];
                                                $required = $pregunta['obligatoria'] ? 'required' : '';
                                                ?>

                                                <?php if ($pregunta['tipo_pregunta'] === 'texto'): ?>
                                                    <input type="text" class="form-control pregunta-input"
                                                           name="<?php echo $fieldName; ?>" <?php echo $required; ?>
                                                           placeholder="Escribe tu respuesta aquí...">

                                                <?php elseif ($pregunta['tipo_pregunta'] === 'numero'): ?>
                                                    <input type="number" class="form-control pregunta-input"
                                                           name="<?php echo $fieldName; ?>" <?php echo $required; ?>
                                                           placeholder="0" step="any">

                                                <?php elseif ($pregunta['tipo_pregunta'] === 'booleano'): ?>
                                                    <div class="form-check">
                                                        <input class="form-check-input pregunta-input" type="radio"
                                                               name="<?php echo $fieldName; ?>" value="1" <?php echo $required; ?> id="<?php echo $fieldName; ?>_si">
                                                        <label class="form-check-label" for="<?php echo $fieldName; ?>_si">
                                                            Sí <small class="text-muted">(valor: 1)</small>
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input pregunta-input" type="radio"
                                                               name="<?php echo $fieldName; ?>" value="0" <?php echo $required; ?> id="<?php echo $fieldName; ?>_no">
                                                        <label class="form-check-label" for="<?php echo $fieldName; ?>_no">
                                                            No <small class="text-muted">(valor: 0)</small>
                                                        </label>
                                                    </div>

                                                <?php elseif ($pregunta['tipo_pregunta'] === 'opcion_multiple' && !empty($pregunta['opciones'])): ?>
                                                    <select class="form-select pregunta-input" name="<?php echo $fieldName; ?>" <?php echo $required; ?>>
                                                        <option value="">Seleccionar opción...</option>
                                                        <?php
                                                        $opciones = array_map('trim', explode(',', $pregunta['opciones']));
                                                        foreach ($opciones as $opcion):
                                                        ?>
                                                            <option value="<?php echo htmlspecialchars($opcion); ?>">
                                                                <?php echo htmlspecialchars($opcion); ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>

                                                <?php elseif ($pregunta['tipo_pregunta'] === 'fecha'): ?>
                                                    <input type="date" class="form-control pregunta-input"
                                                           name="<?php echo $fieldName; ?>" <?php echo $required; ?>>

                                                <?php endif; ?>

                                                <?php if (!empty($pregunta['depende_de'])): ?>
                                                    <div class="mt-2">
                                                        <div class="alert alert-info py-2">
                                                            <small>
                                                                <i class="fas fa-info-circle me-1"></i>
                                                                <strong>Esta pregunta es condicional:</strong><br>
                                                                Aparece solo si la respuesta a la pregunta #<?php echo $pregunta['depende_de']; ?> es "<?php echo htmlspecialchars($pregunta['respuesta_requerida']); ?>"
                                                                <?php if ($pregunta['tipo_pregunta_padre'] === 'booleano'): ?>
                                                                    <br><em>(Para preguntas Sí/No: 1 = Sí, 0 = No)</em>
                                                                <?php endif; ?>
                                                            </small>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="fas fa-exclamation-triangle fa-3x text-warning mb-3"></i>
                            <h5 class="text-warning">Formulario vacío</h5>
                            <p class="text-muted">Este formulario no tiene preguntas configuradas.</p>
                            <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-primary">
                                <i class="fas fa-arrow-left me-1"></i>Volver a Formularios
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Botones de Acción -->
            <?php if (!empty($preguntas)): ?>
                <div class="d-flex justify-content-end mt-4 gap-2">
                    <a href="<?php echo base_url('formularios/listar'); ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-times me-1"></i>Cancelar
                    </a>
                    <button type="submit" class="btn btn-success btn-lg">
                        <i class="fas fa-save me-1"></i>Guardar Censo
                    </button>
                </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<script>
// Función para manejar lógica condicional
function manejarLogicaCondicional() {
    console.log('🔄 Iniciando manejo de lógica condicional...');

    const preguntasCondicionales = document.querySelectorAll('.pregunta-condicional');
    console.log(`📊 Encontradas ${preguntasCondicionales.length} preguntas condicionales`);

    preguntasCondicionales.forEach(pregunta => {
        const dependeDe = pregunta.dataset.dependeDe;
        const respuestaNecesaria = pregunta.dataset.respuestaNecesaria;
        const numeroPregunta = pregunta.querySelector('.badge').textContent;

        console.log(`🔍 Procesando pregunta condicional ${numeroPregunta}: depende_de=${dependeDe}, respuesta_necesaria="${respuestaNecesaria}"`);

        if (dependeDe && respuestaNecesaria) {
            // Buscar la pregunta padre (puede ser input, select, o radio buttons)
            let preguntaPadre = document.querySelector(`input[name="pregunta_${dependeDe}"], select[name="pregunta_${dependeDe}"]`);

            // Si no encuentra por ID, intentar buscar por orden visual
            if (!preguntaPadre) {
                console.log(`⚠️ No encontrada pregunta padre por ID ${dependeDe}, buscando por orden...`);
                // Buscar todas las preguntas y encontrar la que tenga el orden correcto
                const todasPreguntas = document.querySelectorAll('.pregunta-item');
                todasPreguntas.forEach(p => {
                    const ordenPregunta = p.querySelector('.badge').textContent;
                    if (ordenPregunta === dependeDe.toString()) {
                        // Encontramos la pregunta padre por orden
                        preguntaPadre = p.querySelector('input, select');
                        console.log(`✅ Encontrada pregunta padre por orden ${ordenPregunta}: ${preguntaPadre ? preguntaPadre.name : 'NO ENCONTRADA'}`);
                    }
                });
            }

            if (preguntaPadre) {
                // Función para verificar condición
                const verificarCondicion = () => {
                    let valorActual = '';

                    // Para radio buttons, buscar el seleccionado
                    if (preguntaPadre.type === 'radio') {
                        const radios = document.querySelectorAll(`input[name="pregunta_${dependeDe}"]:checked`);
                        valorActual = radios.length > 0 ? radios[0].value : '';
                    } else {
                        valorActual = preguntaPadre.value;
                    }

                    console.log(`Pregunta ${pregunta.querySelector('.badge').textContent}: depende de pregunta ${dependeDe}, respuesta necesaria: "${respuestaNecesaria}", valor actual: "${valorActual}"`);

                    // Mostrar/ocultar pregunta condicional
                    if (valorActual === respuestaNecesaria) {
                        pregunta.style.display = 'block';
                        console.log(`✅ Mostrando pregunta condicional ${pregunta.querySelector('.badge').textContent}`);
                        // Marcar como requerida si es obligatoria
                        const inputs = pregunta.querySelectorAll('input[required], select[required]');
                        inputs.forEach(input => {
                            input.setAttribute('data-was-required', input.hasAttribute('required'));
                        });
                    } else {
                        pregunta.style.display = 'none';
                        console.log(`❌ Ocultando pregunta condicional ${pregunta.querySelector('.badge').textContent}`);
                        // Limpiar valores cuando se oculta
                        const inputs = pregunta.querySelectorAll('input, select, textarea');
                        inputs.forEach(input => {
                            if (input.type === 'radio' || input.type === 'checkbox') {
                                input.checked = false;
                            } else {
                                input.value = '';
                            }
                            // Remover required temporalmente
                            if (input.hasAttribute('data-was-required')) {
                                input.removeAttribute('required');
                            }
                        });
                    }
                };

                // Agregar event listeners
                if (preguntaPadre.type === 'radio') {
                    const radios = document.querySelectorAll(`input[name="pregunta_${dependeDe}"]`);
                    radios.forEach(radio => {
                        radio.addEventListener('change', verificarCondicion);
                    });
                } else {
                    preguntaPadre.addEventListener('change', verificarCondicion);
                    preguntaPadre.addEventListener('input', verificarCondicion);
                }

                // Verificar condición inicial después de un delay
                setTimeout(() => {
                    console.log(`🚀 Verificando condición inicial para pregunta ${numeroPregunta}`);
                    verificarCondicion();
                }, 500); // Aumentar delay para asegurar que todo esté listo
            } else {
                console.error(`❌ No se encontró la pregunta padre ${dependeDe} para la pregunta condicional ${numeroPregunta}`);
                console.log('🔍 Lista de todas las preguntas disponibles:');
                const todasPreguntas = document.querySelectorAll('.pregunta-item');
                todasPreguntas.forEach(p => {
                    const orden = p.querySelector('.badge').textContent;
                    const input = p.querySelector('input, select');
                    const nombre = input ? input.name : 'SIN INPUT';
                    console.log(`   Pregunta ${orden}: ${nombre}`);
                });
            }
        }
    });
}

// Función para validar formulario antes de enviar
function validarFormulario() {
    const preguntasVisibles = document.querySelectorAll('.pregunta-item:not([style*="display: none"])');
    let formularioValido = true;

    preguntasVisibles.forEach(pregunta => {
        const inputs = pregunta.querySelectorAll('input[required], select[required]');
        inputs.forEach(campo => {
            if (!campo.value.trim()) {
                campo.classList.add('is-invalid');
                formularioValido = false;
            } else {
                campo.classList.remove('is-invalid');
            }
        });
    });

    return formularioValido;
}

// Event listener para envío del formulario
document.getElementById('formularioRespuestas').addEventListener('submit', function(e) {
    if (!validarFormulario()) {
        e.preventDefault();
        alert('Por favor, responde todas las preguntas obligatorias.');
        return false;
    }

    // Mostrar indicador de carga
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Guardando...';
    submitBtn.disabled = true;

    // El formulario se enviará normalmente
});

// Inicializar lógica condicional cuando se carga la página
document.addEventListener('DOMContentLoaded', function() {
    manejarLogicaCondicional();
});

// Función para obtener ubicación GPS (opcional)
function obtenerUbicacionGPS() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            const coords = position.coords.latitude + ', ' + position.coords.longitude;
            document.getElementById('ubicacion_geo').value = coords;
        }, function(error) {
            console.log('Error obteniendo ubicación:', error);
        });
    } else {
        alert('Tu navegador no soporta geolocalización.');
    }
}

// Agregar botón para obtener GPS si está disponible
document.addEventListener('DOMContentLoaded', function() {
    const ubicacionInput = document.getElementById('ubicacion_geo');
    if (ubicacionInput && navigator.geolocation) {
        const gpsBtn = document.createElement('button');
        gpsBtn.type = 'button';
        gpsBtn.className = 'btn btn-outline-info btn-sm ms-2';
        gpsBtn.innerHTML = '<i class="fas fa-map-marker-alt me-1"></i>GPS';
        gpsBtn.onclick = obtenerUbicacionGPS;

        ubicacionInput.parentNode.appendChild(gpsBtn);
    }
});
</script>