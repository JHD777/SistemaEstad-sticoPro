<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error Interno del Servidor - <?php echo APP_NAME; ?></title>

    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .error-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            text-align: center;
            padding: 3rem;
            max-width: 500px;
            width: 100%;
        }

        .error-code {
            font-size: 5rem;
            font-weight: 700;
            color: #dc3545;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
        }

        .error-title {
            font-size: 1.8rem;
            color: #343a40;
            margin-bottom: 1rem;
        }

        .error-message {
            color: #6c757d;
            margin-bottom: 2rem;
            line-height: 1.6;
        }

        .btn-retry {
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
            border: none;
            border-radius: 25px;
            padding: 0.75rem 2rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .btn-retry:hover {
            background: linear-gradient(135deg, #45a049 0%, #4CAF50 100%);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .error-icon {
            font-size: 4rem;
            color: #ffc107;
            margin-bottom: 1rem;
        }

        .error-details {
            background: #f8f9fa;
            border-radius: 5px;
            padding: 1rem;
            margin-top: 2rem;
            text-align: left;
        }

        .error-details summary {
            cursor: pointer;
            font-weight: 600;
            margin-bottom: 1rem;
        }

        .error-details pre {
            background: #fff;
            border: 1px solid #dee2e6;
            border-radius: 3px;
            padding: 0.5rem;
            font-size: 0.8rem;
            max-height: 200px;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-icon">
            <i class="fas fa-exclamation-circle"></i>
        </div>

        <div class="error-code">500</div>
        <h1 class="error-title">Error Interno del Servidor</h1>
        <p class="error-message">
            Ha ocurrido un error inesperado en el servidor. Nuestro equipo ha sido notificado y estamos trabajando para solucionarlo.
        </p>

        <div class="d-grid gap-2 d-md-flex justify-content-md-center">
            <button onclick="window.location.reload()" class="btn btn-retry">
                <i class="fas fa-redo me-2"></i>
                Intentar de Nuevo
            </button>
            <a href="<?php echo base_url('dashboard/general'); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-home me-2"></i>
                Ir al Dashboard
            </a>
        </div>

        <?php if (isDebugMode()) : ?>
        <div class="error-details mt-4">
            <details>
                <summary>
                    <i class="fas fa-code me-1"></i>
                    Detalles del Error (Modo Debug)
                </summary>
                <pre><?php
                if (isset($error)) {
                    echo htmlspecialchars(json_encode($error, JSON_PRETTY_PRINT));
                } else {
                    echo 'No hay detalles adicionales del error disponibles.';
                }
                ?></pre>
            </details>
        </div>
        <?php endif; ?>

        <div class="mt-4">
            <small class="text-muted">
                Código de error: <?php echo uniqid('ERR-'); ?>
                <br>
                Tiempo: <?php echo date('Y-m-d H:i:s'); ?>
            </small>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Reportar error automáticamente
        window.addEventListener('load', function() {
            // Aquí podrías enviar el error a un servicio de monitoreo
            console.error('Error 500 detectado en:', window.location.href);
        });

        // Auto-reintentar después de 10 segundos
        setTimeout(function() {
            if (confirm('¿Deseas intentar cargar la página de nuevo automáticamente?')) {
                window.location.reload();
            }
        }, 10000);
    </script>
</body>
</html>