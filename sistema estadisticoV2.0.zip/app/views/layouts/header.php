<?php
$currentUri = request_uri();
$isLoggedIn = isset($_SESSION['user_id']);
$userRole = $_SESSION['user_role'] ?? 'basico';
$userName = $_SESSION['user_name'] ?? 'Usuario';
?>
<header class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
    <div class="container-fluid">
        <!-- Logo y título -->
        <a class="navbar-brand d-flex align-items-center" href="<?php echo base_url('dashboard/general'); ?>">
            <div class="logo-icon me-2">
                <i class="fas fa-atom fa-lg"></i>
            </div>
            <span class="fw-bold fs-5">Sistema Estadístico Pro</span>
        </a>

        <!-- Botón para móviles -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menú de navegación -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <!-- Dashboard Principal (todos los usuarios) -->
                <li class="nav-item">
                    <a class="nav-link <?php echo strpos($currentUri, '/dashboard') === 0 ? 'active' : ''; ?>" href="<?php echo base_url($isLoggedIn ? 'dashboard/general' : 'dashboard/publico'); ?>">
                        <i class="fas fa-tachometer-alt me-1"></i>
                        <?php
                        if (!$isLoggedIn) {
                            echo 'Centro Estadístico';
                        } else {
                            switch ($userRole) {
                                case 'supremo':
                                    echo 'Panel Supremo';
                                    break;
                                case 'admin':
                                    echo 'Panel Administrativo';
                                    break;
                                case 'registrado':
                                    echo 'Panel de Usuario';
                                    break;
                                default:
                                    echo 'Dashboard';
                            }
                        }
                        ?>
                    </a>
                </li>

                <!-- Estadísticas Rápidas (todos los usuarios) -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-chart-line me-1"></i>
                        Estadísticas
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo base_url('dashboard/general'); ?>">
                            <i class="fas fa-globe me-2"></i>Ver Todas
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#" onclick="filtrarEstadisticas('flora')">
                            <i class="fas fa-seedling me-2 text-success"></i>Flora
                        </a></li>
                        <li><a class="dropdown-item" href="#" onclick="filtrarEstadisticas('fauna')">
                            <i class="fas fa-paw me-2 text-info"></i>Fauna
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?php echo base_url('estadistica'); ?>">
                            <i class="fas fa-chart-line me-2"></i>Centro Estadístico
                        </a></li>
                    </ul>
                </li>

                <?php if (hasPermission($userRole, 'census.create')) : ?>
                <!-- Censos (admins y superiores) -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php echo strpos($currentUri, '/formularios') === 0 ? 'active' : ''; ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-clipboard-list me-1"></i>
                        Censos
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo base_url('formularios'); ?>">
                            <i class="fas fa-list me-2"></i>Ver Formularios
                        </a></li>
                        <?php if (hasPermission($userRole, 'forms.create')) : ?>
                        <li><a class="dropdown-item" href="<?php echo base_url('formularios/crear'); ?>"
                               data-bs-toggle="tooltip"
                               data-bs-placement="right"
                               title="Crear nuevos formularios dinámicos para censos de especies">
                            <i class="fas fa-plus me-2"></i>Crear Formulario
                        </a></li>
                        <?php endif; ?>
                        <?php if (hasPermission($userRole, 'forms.approve')) : ?>
                        <li><a class="dropdown-item" href="<?php echo base_url('formularios/pendientes'); ?>"
                               data-bs-toggle="tooltip"
                               data-bs-placement="right"
                               title="Revisar y aprobar formularios creados por administradores">
                            <i class="fas fa-clock me-2"></i>Pendientes de Aprobación
                        </a></li>
                        <?php endif; ?>
                        <?php if (hasPermission($userRole, 'questions.manage')) : ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?php echo base_url('preguntas/listar'); ?>"
                               data-bs-toggle="tooltip"
                               data-bs-placement="right"
                               title="Gestionar preguntas base que se heredan automáticamente">
                            <i class="fas fa-database me-2"></i>Preguntas Base
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo base_url('preguntas/crear'); ?>"
                               data-bs-toggle="tooltip"
                               data-bs-placement="right"
                               title="Crear nuevas preguntas base para reinos, módulos o especies">
                            <i class="fas fa-plus-circle me-2"></i>Crear Pregunta Base
                        </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (hasPermission($userRole, 'species.view')) : ?>
                <!-- Especies (usuarios con permisos) -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php echo strpos($currentUri, '/especies') === 0 ? 'active' : ''; ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-tree me-1"></i>
                        Especies
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo base_url('especies'); ?>">
                            <i class="fas fa-list me-2"></i>Ver Especies
                        </a></li>
                        <?php if (hasPermission($userRole, 'species.create')) : ?>
                        <li><a class="dropdown-item" href="<?php echo base_url('especies/crear'); ?>"
                               data-bs-toggle="tooltip"
                               data-bs-placement="right"
                               title="Crear nuevas especies dentro de módulos existentes">
                            <i class="fas fa-plus me-2"></i>Crear Especie
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo base_url('especies/crear-modulo'); ?>"
                               data-bs-toggle="tooltip"
                               data-bs-placement="right"
                               title="Crear nuevos módulos dentro de reinos biológicos">
                            <i class="fas fa-folder-plus me-2"></i>Crear Módulo
                        </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (hasPermission($userRole, 'users.view')) : ?>
                <!-- Usuarios (usuarios supremos) -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php echo strpos($currentUri, '/usuarios') === 0 ? 'active' : ''; ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-users me-1"></i>
                        Usuarios
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo base_url('usuarios'); ?>">
                            <i class="fas fa-list me-2"></i>Ver Usuarios
                        </a></li>
                        <?php if (hasPermission($userRole, 'users.create')) : ?>
                        <li><a class="dropdown-item" href="<?php echo base_url('usuarios/crear'); ?>"
                               data-bs-toggle="tooltip"
                               data-bs-placement="right"
                               title="Crear nuevos usuarios básicos o registrados">
                            <i class="fas fa-user-plus me-2"></i>Crear Usuario
                        </a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#" onclick="mostrarCrearAdmin()"
                               data-bs-toggle="tooltip"
                               data-bs-placement="right"
                               title="Crear nuevos administradores para gestionar formularios y censos">
                            <i class="fas fa-user-shield me-2"></i>Crear Administrador
                        </a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <!-- Reportes (usuarios registrados y superiores) -->
                <?php if (hasPermission($userRole, 'reports.download')) : ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo strpos($currentUri, '/reportes') === 0 ? 'active' : ''; ?>" href="<?php echo base_url('reportes'); ?>"
                       data-bs-toggle="tooltip"
                       data-bs-placement="bottom"
                       title="Generar y descargar reportes estadísticos en PDF o Excel">
                        <i class="fas fa-chart-bar me-1"></i>
                        Reportes
                    </a>
                </li>
                <?php endif; ?>

                <!-- Información (todos los usuarios) -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php echo in_array($currentUri, ['/acerca', '/contacto', '/terminos', '/privacidad']) ? 'active' : ''; ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-info-circle me-1"></i>
                        Información
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo base_url('acerca'); ?>">
                            <i class="fas fa-atom me-2"></i>Acerca del Sistema
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo base_url('contacto'); ?>">
                            <i class="fas fa-address-book me-2"></i>Contacto
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo base_url('terminos'); ?>">
                            <i class="fas fa-file-contract me-2"></i>Términos y Condiciones
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo base_url('privacidad'); ?>">
                            <i class="fas fa-shield-alt me-2"></i>Política de Privacidad
                        </a></li>
                    </ul>
                </li>
            </ul>

            <!-- Menú del usuario -->
            <ul class="navbar-nav">
                <?php if ($isLoggedIn): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle me-2"></i>
                        <span class="d-lg-inline d-none"><?php echo $userName; ?></span>
                        <span class="badge bg-secondary ms-2"><?php echo strtoupper($userRole); ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <h6 class="dropdown-header">
                                <i class="fas fa-user me-2"></i>
                                <?php echo $userName; ?>
                            </h6>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#" onclick="cambiarPassword()">
                            <i class="fas fa-key me-2"></i>Cambiar Contraseña
                        </a></li>
                        <li><a class="dropdown-item" href="<?php echo base_url('logout'); ?>">
                            <i class="fas fa-sign-out-alt me-2"></i>Cerrar Sesión
                        </a></li>
                    </ul>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url('register'); ?>">
                        <i class="fas fa-user-plus me-1"></i>Registrarse
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo base_url('login'); ?>">
                        <i class="fas fa-sign-in-alt me-1"></i>Iniciar Sesión
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</header>

<!-- Modal para cambiar contraseña -->
<div class="modal fade" id="passwordModal" tabindex="-1" aria-labelledby="passwordModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="passwordModalLabel">Cambiar Contraseña</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="<?php echo base_url('cambiar-password'); ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Contraseña Actual</label>
                        <input type="password" class="form-control" id="current_password" name="current_password" required>
                    </div>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">Nueva Contraseña</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required minlength="<?php echo PASSWORD_MIN_LENGTH; ?>">
                        <div class="form-text">Mínimo <?php echo PASSWORD_MIN_LENGTH; ?> caracteres</div>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirmar Nueva Contraseña</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Cambiar Contraseña</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Función para cambiar contraseña
function cambiarPassword() {
    $('#passwordModal').modal('show');
}

// Función para mostrar modal de crear administrador
function mostrarCrearAdmin() {
    // Crear modal dinámicamente
    const modalHtml = `
        <div class="modal fade" id="crearAdminModal" tabindex="-1" aria-labelledby="crearAdminModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="crearAdminModalLabel">
                            <i class="fas fa-user-shield me-2"></i>Crear Nuevo Administrador
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form method="POST" action="${window.appConfig.baseUrl}usuarios/crear-admin" id="crearAdminForm">
                        <div class="modal-body">
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                Los administradores pueden crear formularios, realizar censos y gestionar especies.
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="admin_nombre" class="form-label">
                                            <i class="fas fa-user me-1"></i>Nombre Completo *
                                        </label>
                                        <input type="text" class="form-control" id="admin_nombre" name="nombre" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="admin_email" class="form-label">
                                            <i class="fas fa-envelope me-1"></i>Email *
                                        </label>
                                        <input type="email" class="form-control" id="admin_email" name="email" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="admin_password" class="form-label">
                                            <i class="fas fa-key me-1"></i>Contraseña Temporal *
                                        </label>
                                        <input type="password" class="form-control" id="admin_password" name="password" required minlength="8">
                                        <div class="form-text">Mínimo 8 caracteres. El usuario podrá cambiarla después.</div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="admin_confirm_password" class="form-label">
                                            <i class="fas fa-key me-1"></i>Confirmar Contraseña *
                                        </label>
                                        <input type="password" class="form-control" id="admin_confirm_password" name="confirm_password" required>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="admin_rol" class="form-label">
                                    <i class="fas fa-user-tag me-1"></i>Tipo de Administrador
                                </label>
                                <select class="form-select" id="admin_rol" name="rol">
                                    <option value="admin">Administrador Regular</option>
                                    <option value="supremo" disabled>Administrador Supremo (Solo uno)</option>
                                </select>
                                <div class="form-text">Los administradores regulares pueden crear formularios y realizar censos.</div>
                            </div>

                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="admin_notificar" name="notificar" checked>
                                    <label class="form-check-label" for="admin_notificar">
                                        <i class="fas fa-envelope me-1"></i>Enviar notificación por email al nuevo administrador
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-times me-1"></i>Cancelar
                            </button>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-user-plus me-1"></i>Crear Administrador
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;

    // Agregar modal al DOM
    document.body.insertAdjacentHTML('beforeend', modalHtml);

    // Mostrar modal
    const modal = new bootstrap.Modal(document.getElementById('crearAdminModal'));
    modal.show();

    // Limpiar modal cuando se cierre
    document.getElementById('crearAdminModal').addEventListener('hidden.bs.modal', function() {
        this.remove();
    });

    // Validación de contraseñas
    document.getElementById('admin_confirm_password').addEventListener('input', function() {
        const password = document.getElementById('admin_password').value;
        const confirmPassword = this.value;

        if (password !== confirmPassword) {
            this.setCustomValidity('Las contraseñas no coinciden');
        } else {
            this.setCustomValidity('');
        }
    });
}

// Función para filtrar estadísticas
function filtrarEstadisticas(tipo) {
    // Mostrar loading
    const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal') || createLoadingModal());
    loadingModal.show();

    // Simular carga y luego redirigir
    setTimeout(() => {
        loadingModal.hide();
        window.location.href = `${window.appConfig.baseUrl}dashboard/general?filtro=${tipo}`;
    }, 500);
}

// Función para mostrar panel de estadísticas
function mostrarPanelEstadisticas() {
    const modalHtml = `
        <div class="modal fade" id="estadisticasModal" tabindex="-1" aria-labelledby="estadisticasModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="estadisticasModalLabel">
                            <i class="fas fa-chart-line me-2"></i>Centro Estadístico - Datos Censales
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body p-0">
                        <!-- Filtros en fila superior -->
                        <div class="bg-light p-3 border-bottom">
                            <div class="row g-3 align-items-end">
                                <div class="col-md-3">
                                    <label for="filtroReino" class="form-label fw-bold">Reino Biológico</label>
                                    <select class="form-select form-select-lg" id="filtroReino" name="reino">
                                        <option value="">Todos los reinos</option>
                                        <option value="flora">🌿 Flora</option>
                                        <option value="fauna">🐾 Fauna</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="filtroModulo" class="form-label fw-bold">Módulo</label>
                                    <select class="form-select form-select-lg" id="filtroModulo" name="modulo" disabled>
                                        <option value="">Selecciona un reino</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="filtroEspecie" class="form-label fw-bold">Especie</label>
                                    <select class="form-select form-select-lg" id="filtroEspecie" name="especie" disabled>
                                        <option value="">Selecciona un módulo</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <button type="button" class="btn btn-success btn-lg w-100" onclick="cargarEstadisticas()">
                                        <i class="fas fa-search me-2"></i>Mostrar Estadísticas
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Contenedor de estadísticas -->
                        <div id="estadisticasContainer" class="p-4">
                            <div class="text-center py-5">
                                <i class="fas fa-chart-bar fa-3x text-muted mb-3"></i>
                                <h4 class="text-muted">Selecciona los filtros para ver las estadísticas</h4>
                                <p class="text-muted">Elige reino, módulo y especie para visualizar los datos censales</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Remover modal anterior si existe
    const existingModal = document.getElementById('estadisticasModal');
    if (existingModal) {
        existingModal.remove();
    }

    document.body.insertAdjacentHTML('beforeend', modalHtml);

    // Configurar eventos de cascada
    configurarFiltrosEstadisticas();

    const modal = new bootstrap.Modal(document.getElementById('estadisticasModal'));
    modal.show();
}

// Función para configurar filtros en cascada para estadísticas
function configurarFiltrosEstadisticas() {
    const filtroReino = document.getElementById('filtroReino');
    const filtroModulo = document.getElementById('filtroModulo');
    const filtroEspecie = document.getElementById('filtroEspecie');

    if (!filtroReino || !filtroModulo || !filtroEspecie) return;

    filtroReino.addEventListener('change', function() {
        const reinoId = this.value;
        filtroModulo.innerHTML = '<option value="">Cargando...</option>';
        filtroEspecie.innerHTML = '<option value="">Selecciona un módulo</option>';
        filtroEspecie.disabled = true;

        if (reinoId) {
            // Convertir "flora" a ID numérico (Flora = 1, Fauna = 2)
            const reinoIdNumerico = reinoId === 'flora' ? 1 : reinoId === 'fauna' ? 2 : reinoId;

            // Cargar módulos del reino seleccionado
            fetch(`${window.appConfig.baseUrl}api/estadistica/modulos?reino=${reinoIdNumerico}`)
                .then(response => response.json())
                .then(responseData => {
                    filtroModulo.innerHTML = '<option value="">Selecciona un módulo</option>';
                    if (responseData.success && responseData.data && responseData.data.length > 0) {
                        responseData.data.forEach(modulo => {
                            filtroModulo.innerHTML += `<option value="${modulo.id}">📁 ${modulo.nombre}</option>`;
                        });
                        filtroModulo.disabled = false;
                    } else {
                        filtroModulo.innerHTML = '<option value="">No hay módulos disponibles</option>';
                    }
                })
                .catch(error => {
                    console.error('Error cargando módulos:', error);
                    filtroModulo.innerHTML = '<option value="">Error al cargar</option>';
                });
        } else {
            filtroModulo.innerHTML = '<option value="">Selecciona un reino</option>';
            filtroModulo.disabled = true;
        }
    });

    filtroModulo.addEventListener('change', function() {
        const moduloId = this.value;
        filtroEspecie.innerHTML = '<option value="">Cargando...</option>';

        if (moduloId) {
            // Cargar especies del módulo seleccionado
            fetch(`${window.appConfig.baseUrl}api/estadistica/especies?modulo=${moduloId}`)
                .then(response => response.json())
                .then(responseData => {
                    filtroEspecie.innerHTML = '<option value="">Selecciona una especie</option>';
                    if (responseData.success && responseData.data && responseData.data.length > 0) {
                        responseData.data.forEach(especie => {
                            filtroEspecie.innerHTML += `<option value="${especie.id}">🌱 ${especie.nombre}</option>`;
                        });
                        filtroEspecie.disabled = false;
                    } else {
                        filtroEspecie.innerHTML = '<option value="">No hay especies disponibles</option>';
                    }
                })
                .catch(error => {
                    console.error('Error cargando especies:', error);
                    filtroEspecie.innerHTML = '<option value="">Error al cargar</option>';
                });
        } else {
            filtroEspecie.innerHTML = '<option value="">Selecciona un módulo</option>';
            filtroEspecie.disabled = true;
        }
    });
}

// Función para cargar estadísticas
function cargarEstadisticas() {
    const reino = document.getElementById('filtroReino').value;
    const modulo = document.getElementById('filtroModulo').value;
    const especie = document.getElementById('filtroEspecie').value;

    const container = document.getElementById('estadisticasContainer');
    if (!container) return;

    // Mostrar loading
    container.innerHTML = `
        <div class="text-center py-5">
            <div class="spinner-border text-primary mb-3" role="status">
                <span class="visually-hidden">Cargando...</span>
            </div>
            <h5>Cargando estadísticas...</h5>
            <p class="text-muted">Procesando datos censales</p>
        </div>
    `;

    // Construir URL de la API según el nivel de filtro
    let apiUrl = '';
    let titulo = '';

    if (especie) {
        apiUrl = `${window.appConfig.baseUrl}api/dashboard/datos/especie/${especie}`;
        titulo = `Estadísticas de Especie: ${document.getElementById('filtroEspecie').options[document.getElementById('filtroEspecie').selectedIndex].text}`;
    } else if (modulo) {
        apiUrl = `${window.appConfig.baseUrl}api/dashboard/datos/modulo/${modulo}`;
        titulo = `Estadísticas de Módulo: ${document.getElementById('filtroModulo').options[document.getElementById('filtroModulo').selectedIndex].text}`;
    } else if (reino) {
        apiUrl = `${window.appConfig.baseUrl}api/dashboard/datos/reino/${reino}`;
        titulo = `Estadísticas de Reino: ${document.getElementById('filtroReino').options[document.getElementById('filtroReino').selectedIndex].text}`;
    } else {
        container.innerHTML = `
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Selecciona al menos un reino para ver las estadísticas.
            </div>
        `;
        return;
    }

    // Cargar datos
    fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            if (!esJsonValido(text)) {
                throw new Error('La respuesta del servidor no es JSON válido');
            }
            const responseData = JSON.parse(text);
            const data = responseData.success && responseData.data ? responseData.data : responseData;

            // Mostrar estadísticas
            mostrarEstadisticas(data, titulo);
        })
        .catch(error => {
            console.error('Error cargando estadísticas:', error);
            container.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Error al cargar las estadísticas: ${error.message}
                </div>
            `;
        });
}

// Función para mostrar estadísticas
function mostrarEstadisticas(data, titulo) {
    const container = document.getElementById('estadisticasContainer');
    if (!container) return;

    let html = `
        <div class="row">
            <div class="col-12 mb-4">
                <h4 class="text-center">${titulo}</h4>
                <hr>
            </div>
        </div>
        <div class="row">
    `;

    // Si hay preguntas con datos, mostrar gráficos
    if (data.preguntas && Array.isArray(data.preguntas) && data.preguntas.length > 0) {
        data.preguntas.forEach((pregunta, index) => {
            html += `
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h6 class="mb-0">${pregunta.texto_pregunta || 'Pregunta ' + (index + 1)}</h6>
                        </div>
                        <div class="card-body">
                            <canvas id="chart-estadistica-${index}" width="400" height="300"></canvas>
                        </div>
                    </div>
                </div>
            `;
        });
    } else {
        html += `
            <div class="col-12">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    No hay datos suficientes para mostrar estadísticas en este nivel.
                    <br><small>Intenta seleccionar un filtro más específico o verifica que existan censos realizados.</small>
                </div>
            </div>
        `;
    }

    html += `
        </div>

        <!-- Información adicional -->
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h6 class="mb-0"><i class="fas fa-info-circle me-2"></i>Información del Conjunto de Datos</h6>
                    </div>
                    <div class="card-body">
                        <div class="row text-center">
                            <div class="col-md-3">
                                <div class="p-3 bg-light rounded">
                                    <h4 class="text-primary mb-1">${data.total_registros || 0}</h4>
                                    <small class="text-muted">Registros Censales</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="p-3 bg-light rounded">
                                    <h4 class="text-success mb-1">${data.preguntas ? data.preguntas.length : 0}</h4>
                                    <small class="text-muted">Preguntas Analizadas</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="p-3 bg-light rounded">
                                    <h4 class="text-info mb-1">${data.especies ? data.especies.length : 0}</h4>
                                    <small class="text-muted">Especies Incluidas</small>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="p-3 bg-light rounded">
                                    <h4 class="text-warning mb-1">${new Date().getFullYear()}</h4>
                                    <small class="text-muted">Año de Análisis</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    container.innerHTML = html;

    // Crear gráficos si hay datos
    if (data.preguntas && Array.isArray(data.preguntas) && data.preguntas.length > 0) {
        setTimeout(() => {
            data.preguntas.forEach((pregunta, index) => {
                crearGraficoEstadistica(pregunta, index);
            });
        }, 100);
    }
}

// Función para crear gráfico de estadística
function crearGraficoEstadistica(pregunta, index) {
    const canvas = document.getElementById(`chart-estadistica-${index}`);
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    // Datos de ejemplo para demostración (reemplazar con datos reales)
    const datos = pregunta.datos || [];
    let chartData = {};

    if (pregunta.tipo_pregunta === 'numero') {
        chartData = {
            labels: ['Mínimo', 'Promedio', 'Máximo'],
            datasets: [{
                label: 'Valores Numéricos',
                data: [10, 25, 40], // Datos de ejemplo
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        };
    } else if (pregunta.tipo_pregunta === 'booleano') {
        chartData = {
            labels: ['Sí', 'No'],
            datasets: [{
                label: 'Respuestas',
                data: [65, 35], // Datos de ejemplo
                backgroundColor: [
                    'rgba(75, 192, 192, 0.5)',
                    'rgba(255, 99, 132, 0.5)'
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 99, 132, 1)'
                ],
                borderWidth: 1
            }]
        };
    } else {
        chartData = {
            labels: ['Opción A', 'Opción B', 'Opción C'],
            datasets: [{
                label: 'Frecuencia',
                data: [30, 45, 25], // Datos de ejemplo
                backgroundColor: 'rgba(153, 102, 255, 0.5)',
                borderColor: 'rgba(153, 102, 255, 1)',
                borderWidth: 1
            }]
        };
    }

    new Chart(ctx, {
        type: pregunta.tipo_pregunta === 'booleano' ? 'pie' : 'bar',
        data: chartData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: pregunta.texto_pregunta || 'Estadística'
                }
            }
        }
    });
}

// Función helper para verificar JSON
function esJsonValido(str) {
    try {
        JSON.parse(str);
        return true;
    } catch (e) {
        return false;
    }
}

// Función helper para crear modal de loading si no existe
function createLoadingModal() {
    // Verificar si ya existe
    let modal = document.getElementById('loadingModal');
    if (modal) {
        return modal;
    }

    const modalHtml = `
        <div class="modal fade" id="loadingModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body text-center p-4">
                        <div class="spinner-border text-primary mb-3" role="status">
                            <span class="visually-hidden">Cargando...</span>
                        </div>
                        <h5>Cargando datos...</h5>
                        <p class="text-muted mb-0">Por favor espera mientras procesamos la información</p>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    return document.getElementById('loadingModal');
}

// Validación de contraseñas en tiempo real
document.getElementById('confirm_password')?.addEventListener('input', function() {
    const newPassword = document.getElementById('new_password').value;
    const confirmPassword = this.value;

    if (newPassword !== confirmPassword) {
        this.setCustomValidity('Las contraseñas no coinciden');
    } else {
        this.setCustomValidity('');
    }
});
</script>