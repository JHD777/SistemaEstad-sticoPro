<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo APP_NAME; ?> - Sistema Estadístico para Censos de Flora y Fauna">
    <meta name="author" content="Sistema Estadístico Pro">

    <title><?php echo isset($page_title) ? $page_title . ' - ' . APP_NAME : APP_NAME; ?></title>

    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/main.css'); ?>" rel="stylesheet">

    <!-- Favicon -->
    <link href="<?php echo base_url('assets/images/logo.png'); ?>" rel="icon" type="image/png">

    <!-- Meta tags de seguridad -->
    <meta http-equiv="X-Content-Type-Options" content="nosniff">
    <meta http-equiv="X-XSS-Protection" content="1; mode=block">

    <?php if (isset($extra_css)) : ?>
        <?php foreach ($extra_css as $css) : ?>
            <link href="<?php echo $css; ?>" rel="stylesheet">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <div id="app" class="d-flex flex-column min-vh-100">
        <!-- Header -->
        <?php include_once __DIR__ . '/header.php'; ?>

        <!-- Main Content -->
        <main class="flex-grow-1">
            <div class="container-fluid">
                <?php if (isset($flash_message)) : ?>
                    <div class="row justify-content-center mt-3">
                        <div class="col-md-8">
                            <div class="alert alert-<?php echo $flash_message['type'] === 'error' ? 'danger' : ($flash_message['type'] === 'success' ? 'success' : 'info'); ?> alert-dismissible fade show" role="alert">
                                <?php echo $flash_message['message']; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php include __DIR__ . '/../' . $this->view . '.php'; ?>
            </div>
        </main>

        <!-- Footer -->
        <?php include_once __DIR__ . '/footer.php'; ?>
    </div>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="<?php echo base_url('assets/js/main.js'); ?>"></script>

    <?php if (isset($extra_js)) : ?>
        <?php foreach ($extra_js as $js) : ?>
            <script src="<?php echo $js; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- JavaScript personalizado para la página actual -->
    <?php if (isset($page_js)) : ?>
        <script>
            <?php echo $page_js; ?>
        </script>
    <?php endif; ?>

    <!-- Configuración global para JavaScript -->
    <script>
        window.appConfig = {
            baseUrl: '<?php echo base_url(); ?>',
            csrfToken: '<?php echo $csrf_token ?? ''; ?>',
            currentUser: <?php echo isset($_SESSION['user_id']) ? json_encode([
                'id' => $_SESSION['user_id'],
                'name' => $_SESSION['user_name'],
                'email' => $_SESSION['user_email'],
                'role' => $_SESSION['user_role']
            ]) : 'null'; ?>,
            debugMode: <?php echo isDebugMode() ? 'true' : 'false'; ?>
        };
    </script>
</body>
</html>