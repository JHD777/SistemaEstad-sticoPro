<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $titulo ?? 'Sistema Estadístico Pro'; ?>">
    <meta name="author" content="Sistema Estadístico Pro">

    <title><?php echo $titulo ?? 'Sistema Estadístico Pro'; ?></title>

    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/main.css'); ?>" rel="stylesheet">

    <!-- Favicon -->
    <link href="<?php echo base_url('assets/images/logo.png'); ?>" rel="icon" type="image/png">

    <!-- Meta tags de seguridad -->
    <meta http-equiv="X-Content-Type-Options" content="nosniff">
    <meta http-equiv="X-XSS-Protection" content="1; mode=block">

    <?php if (isset($extra_css)) : ?>
        <?php foreach ($extra_css as $css) : ?>
            <link href="<?php echo $css; ?>" rel="stylesheet">
        <?php endforeach; ?>
    <?php endif; ?>

    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #6c757d;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --light-color: #f8f9fa;
            --dark-color: #212529;
        }

        body {
            font-family: 'Inter', sans-serif;
            line-height: 1.6;
            background-color: #f8f9fa;
        }

        .navbar-custom {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .content-wrapper {
            min-height: calc(100vh - 200px);
            padding: 2rem 0;
        }

        .content-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
            margin-bottom: 2rem;
        }

        .page-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #0056b3 100%);
            color: white;
            padding: 3rem 2rem;
            text-align: center;
            margin-bottom: 2rem;
            border-radius: 15px;
        }

        .page-header h1 {
            margin: 0;
            font-size: 2.5rem;
            font-weight: 700;
        }

        .page-header .subtitle {
            margin-top: 0.5rem;
            opacity: 0.9;
            font-size: 1.2rem;
            font-weight: 300;
        }

        .footer-custom {
            background: var(--dark-color);
            color: white;
            padding: 3rem 0 1rem;
            margin-top: auto;
        }

        .footer-custom .footer-link {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-custom .footer-link:hover {
            color: white;
        }
    </style>

    <style>
        :root {
            --primary-color: #0d6efd;
            --secondary-color: #6c757d;
            --success-color: #198754;
            --info-color: #0dcaf0;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --light-color: #f8f9fa;
            --dark-color: #212529;
        }

        body {
            font-family: 'Inter', sans-serif;
            line-height: 1.6;
            background-color: #f8f9fa;
        }

        .navbar-custom {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .content-wrapper {
            min-height: calc(100vh - 200px);
            padding: 2rem 0;
        }

        .content-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: none;
            margin-bottom: 2rem;
        }

        .page-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #0056b3 100%);
            color: white;
            padding: 3rem 2rem;
            text-align: center;
            margin-bottom: 2rem;
            border-radius: 15px;
        }

        .page-header h1 {
            margin: 0;
            font-size: 2.5rem;
            font-weight: 700;
        }

        .page-header .subtitle {
            margin-top: 0.5rem;
            opacity: 0.9;
            font-size: 1.2rem;
            font-weight: 300;
        }

        .footer-custom {
            background: var(--dark-color);
            color: white;
            padding: 3rem 0 1rem;
            margin-top: auto;
        }

        .footer-custom .footer-link {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .footer-custom .footer-link:hover {
            color: white;
        }
    </style>
</head>
<body>
    <!-- Navbar Público -->
    <nav class="navbar navbar-expand-lg navbar-custom fixed-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="<?php echo base_url(''); ?>">
                <div class="logo-icon me-2">
                    <i class="fas fa-atom fa-lg text-primary"></i>
                </div>
                <span class="fw-bold fs-5">Sistema Estadístico Pro</span>
            </a>

            <div class="d-flex">
                <a href="<?php echo base_url('acerca'); ?>" class="btn btn-outline-primary me-2">Acerca de</a>
                <a href="<?php echo base_url('contacto'); ?>" class="btn btn-outline-secondary me-2">Contacto</a>
                <a href="<?php echo base_url('login'); ?>" class="btn btn-primary">Iniciar Sesión</a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="content-wrapper">
        <div class="container">
            <?php if (isset($flash_message)) : ?>
                <div class="row justify-content-center mb-4">
                    <div class="col-md-8">
                        <div class="alert alert-<?php echo $flash_message['type'] === 'error' ? 'danger' : ($flash_message['type'] === 'success' ? 'success' : 'info'); ?> alert-dismissible fade show" role="alert">
                            <?php echo $flash_message['message']; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php
            // Extraer todas las variables de los datos para que estén disponibles en las vistas
            if (isset($this->data) && is_array($this->data)) {
                extract($this->data);
            }

            // Incluir la vista específica
            include __DIR__ . '/../' . $view . '.php';
            ?>
        </div>
    </div>

    <!-- Footer Público -->
    <footer class="footer-custom">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h6 class="text-light">Sistema Estadístico Pro</h6>
                    <p class="text-light opacity-75 mb-0">
                        Plataforma avanzada para la gestión y análisis de datos estadísticos de especies biológicas.
                    </p>
                </div>

                <div class="col-md-3">
                    <h6 class="text-light">Enlaces</h6>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo base_url('acerca'); ?>" class="footer-link">Acerca de</a></li>
                        <li><a href="<?php echo base_url('contacto'); ?>" class="footer-link">Contacto</a></li>
                        <li><a href="<?php echo base_url('terminos'); ?>" class="footer-link">Términos</a></li>
                        <li><a href="<?php echo base_url('privacidad'); ?>" class="footer-link">Privacidad</a></li>
                    </ul>
                </div>

                <div class="col-md-3">
                    <h6 class="text-light">Contacto</h6>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-envelope me-2"></i>soporte@sistema-estadistico-pro.com</li>
                        <li><i class="fas fa-phone me-2"></i>+591 123 4567</li>
                        <li><i class="fas fa-map-marker-alt me-2"></i>La Paz, Bolivia</li>
                    </ul>
                </div>
            </div>

            <hr class="my-3 opacity-25">

            <div class="row">
                <div class="col-md-6">
                    <p class="text-light opacity-75 mb-0">
                        &copy; <?php echo date('Y'); ?> Sistema Estadístico Pro. Todos los derechos reservados.
                    </p>
                </div>

                <div class="col-md-6 text-md-end">
                    <small class="text-light opacity-75">
                        Versión <?php echo APP_VERSION ?? '2.0.0'; ?>
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="<?php echo base_url('assets/js/main.js'); ?>"></script>

    <?php if (isset($extra_js)) : ?>
        <?php foreach ($extra_js as $js) : ?>
            <script src="<?php echo $js; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- JavaScript personalizado para la página actual -->
    <?php if (isset($page_js)) : ?>
        <script>
            <?php echo $page_js; ?>
        </script>
    <?php endif; ?>

    <!-- Configuración global para JavaScript -->
    <script>
        window.appConfig = {
            baseUrl: '<?php echo base_url(); ?>',
            csrfToken: '<?php echo $csrf_token ?? ''; ?>',
            currentUser: <?php echo isset($_SESSION['user_id']) ? json_encode([
                'id' => $_SESSION['user_id'],
                'name' => $_SESSION['user_name'],
                'email' => $_SESSION['user_email'],
                'role' => $_SESSION['user_role']
            ]) : 'null'; ?>,
            debugMode: <?php echo isDebugMode() ? 'true' : 'false'; ?>
        };
    </script>
</body>
</html>