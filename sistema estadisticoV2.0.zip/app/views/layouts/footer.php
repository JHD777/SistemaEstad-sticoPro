<footer class="bg-light py-4 mt-auto">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <h6 class="text-muted"><?php echo APP_NAME; ?></h6>
                <p class="text-muted mb-0">
                    Sistema Estadístico Pro - Plataforma avanzada para gestión y análisis de datos estadísticos
                    <br>
                    <small>Versión <?php echo APP_VERSION; ?></small>
                </p>
            </div>

            <div class="col-md-3">
                <h6 class="text-muted">Enlaces Rápidos</h6>
                <ul class="list-unstyled">
                    <li><a href="<?php echo base_url(''); ?>" class="text-muted text-decoration-none">
                        <i class="fas fa-home me-1"></i>Página Principal
                    </a></li>
                    <li><a href="<?php echo base_url('dashboard/general'); ?>" class="text-muted text-decoration-none">Dashboard</a></li>
                    <?php if (hasPermission($_SESSION['user_role'] ?? 'basico', 'forms.view')) : ?>
                    <li><a href="<?php echo base_url('formularios'); ?>" class="text-muted text-decoration-none">Formularios</a></li>
                    <?php endif; ?>
                    <?php if (hasPermission($_SESSION['user_role'] ?? 'basico', 'species.view')) : ?>
                    <li><a href="<?php echo base_url('especies'); ?>" class="text-muted text-decoration-none">Especies</a></li>
                    <?php endif; ?>
                    <?php if (hasPermission($_SESSION['user_role'] ?? 'basico', 'reports.download')) : ?>
                    <li><a href="<?php echo base_url('reportes'); ?>" class="text-muted text-decoration-none">Reportes</a></li>
                    <?php endif; ?>
                </ul>
            </div>

            <div class="col-md-3">
                <h6 class="text-muted">Información</h6>
                <ul class="list-unstyled">
                    <li><a href="<?php echo base_url('acerca'); ?>" class="text-muted text-decoration-none">Acerca de</a></li>
                    <li><a href="<?php echo base_url('contacto'); ?>" class="text-muted text-decoration-none">Contacto</a></li>
                    <li><a href="<?php echo base_url('terminos'); ?>" class="text-muted text-decoration-none">Términos</a></li>
                    <li><a href="<?php echo base_url('privacidad'); ?>" class="text-muted text-decoration-none">Privacidad</a></li>
                </ul>
            </div>
        </div>

        <hr class="my-3">

        <div class="row">
            <div class="col-md-6">
                <p class="text-muted mb-0">
                    &copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>.
                    Todos los derechos reservados.
                </p>
            </div>

            <div class="col-md-6 text-md-end">
                <small class="text-muted">
                    Tiempo de carga: <?php echo number_format(microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'], 3); ?>s
                    <?php if (isDebugMode()) : ?>
                        | <a href="<?php echo base_url('debug/session'); ?>" class="text-muted">Debug</a>
                    <?php endif; ?>
                </small>
            </div>
        </div>
    </div>
</footer>

<!-- Modal de información del sistema -->
<div class="modal fade" id="infoSistemaModal" tabindex="-1" aria-labelledby="infoSistemaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="infoSistemaModalLabel">Información del Sistema</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Aplicación</h6>
                        <table class="table table-sm">
                            <tr>
                                <td>Nombre:</td>
                                <td><?php echo APP_NAME; ?></td>
                            </tr>
                            <tr>
                                <td>Versión:</td>
                                <td><?php echo APP_VERSION; ?></td>
                            </tr>
                            <tr>
                                <td>PHP:</td>
                                <td><?php echo PHP_VERSION; ?></td>
                            </tr>
                            <tr>
                                <td>Servidor:</td>
                                <td><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Desconocido'; ?></td>
                            </tr>
                        </table>
                    </div>

                    <div class="col-md-6">
                        <h6>Base de Datos</h6>
                        <table class="table table-sm">
                            <tr>
                                <td>Estado:</td>
                                <td>
                                    <span class="badge bg-<?php
                                    try {
                                        $db = Database::getInstance();
                                        echo $db->isConnected() ? 'success">Conectado' : 'danger">Desconectado';
                                    } catch (Exception $e) {
                                        echo 'danger">Error';
                                    }
                                    ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td>Host:</td>
                                <td><?php echo DB_HOST; ?></td>
                            </tr>
                            <tr>
                                <td>Base de Datos:</td>
                                <td><?php echo DB_NAME; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <?php if (isDebugMode()) : ?>
                <div class="row mt-3">
                    <div class="col-12">
                        <h6>Debug Information</h6>
                        <div class="bg-light p-2 small" style="max-height: 200px; overflow-y: auto;">
                            <strong>Session:</strong>
                            <pre><?php print_r($_SESSION); ?></pre>
                            <strong>Request:</strong>
                            <pre><?php print_r([
                                'URI' => $_SERVER['REQUEST_URI'],
                                'Method' => $_SERVER['REQUEST_METHOD'],
                                'User Agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'N/A'
                            ]); ?></pre>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>

<script>
function mostrarInfoSistema() {
    $('#infoSistemaModal').modal('show');
}

// Auto-ocultar mensajes flash después de 5 segundos
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        if (!alert.querySelector('.btn-close')) {
            setTimeout(function() {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }, 5000);
        }
    });
});

// Confirmación para acciones destructivas
function confirmarAccion(mensaje) {
    return confirm(mensaje);
}

// Función global para hacer peticiones AJAX
function ajaxRequest(url, method = 'GET', data = null) {
    return fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRF-Token': window.appConfig.csrfToken
        },
        body: data ? JSON.stringify(data) : null
    })
    .then(response => response.json())
    .catch(error => {
        console.error('Error:', error);
        return { success: false, error: 'Error de conexión' };
    });
}
</script>