<?php
/**
 * Sistema Estadístico Pro - Modelo Pregunta
 * Maneja las preguntas de formularios dinámicos con lógica condicional
 */

class Pregunta {
    private $db;

    public function __construct() {
        // Inicializar conexión a base de datos de forma lazy
        $this->db = null;
    }

    /**
     * Obtener instancia de conexión a base de datos
     */
    private function getDb() {
        if ($this->db === null) {
            $this->db = Database::getInstance();
        }
        return $this->db;
    }

    /**
     * Crear una nueva pregunta
     */
    public function crear($datos) {
        try {
            // Check database schema for backward compatibility
            $columns = $this->getDb()->select("DESCRIBE preguntas");
            $hasBloque = false;
            $hasHerencia = false;
            $hasAmbito = false;

            foreach ($columns as $column) {
                if ($column['Field'] === 'bloque') {
                    $hasBloque = true;
                }
                if ($column['Field'] === 'nivel_herencia') {
                    $hasHerencia = true;
                }
                if ($column['Field'] === 'ambito_aplicacion') {
                    $hasAmbito = true;
                }
            }

            // Build SQL dynamically based on available columns
            $fields = ['formulario_id', 'texto_pregunta', 'tipo_pregunta', 'opciones', 'orden', 'obligatoria', 'depende_de', 'respuesta_requerida'];
            $placeholders = ['?', '?', '?', '?', '?', '?', '?', '?'];
            $params = [
                $datos['formulario_id'] ?? null, // Allow NULL for base questions
                $datos['texto_pregunta'],
                $datos['tipo_pregunta'],
                $datos['opciones'] ?? null,
                $datos['orden'],
                !empty($datos['obligatoria']) ? 1 : 0,
                $datos['depende_de'] ?? null,
                $datos['respuesta_requerida'] ?? null
            ];

            if ($hasBloque) {
                $fields[] = 'bloque';
                $fields[] = 'orden_bloque';
                $placeholders[] = '?';
                $placeholders[] = '?';
                $params[] = $datos['bloque'] ?? null;
                $params[] = $datos['orden_bloque'] ?? 1;
            }

            // Always try to include ambito fields if data is provided (for base questions)
            if (isset($datos['ambito_aplicacion']) && isset($datos['ambito_id'])) {
                $fields[] = 'ambito_aplicacion';
                $fields[] = 'ambito_id';
                $placeholders[] = '?';
                $placeholders[] = '?';
                $params[] = $datos['ambito_aplicacion'] ?: 'especie';
                $params[] = $datos['ambito_id'] ?: null;
            } elseif ($hasHerencia) {
                // Fallback to old inheritance system
                $fields[] = 'nivel_herencia';
                $fields[] = 'es_heredada';
                $fields[] = 'pregunta_original_id';
                $placeholders[] = '?';
                $placeholders[] = '?';
                $placeholders[] = '?';
                $params[] = $datos['nivel_herencia'] ?? 'especie';
                $params[] = $datos['es_heredada'] ?? false;
                $params[] = $datos['pregunta_original_id'] ?? null;
            }

            $sql = "INSERT INTO preguntas (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $placeholders) . ")";

            return $this->getDb()->insert($sql, $params);
        } catch (Exception $e) {
            error_log("Error creating question: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Obtener preguntas heredadas dinámicamente para un formulario
     * Nueva arquitectura: las preguntas base existen con formulario_id = NULL
     */
    public function obtenerPreguntasHeredadas($especieId) {
        try {
            // Check if new ambito columns exist
            $columns = $this->getDb()->select("DESCRIBE preguntas");
            $hasAmbito = false;

            foreach ($columns as $column) {
                if ($column['Field'] === 'ambito_aplicacion') {
                    $hasAmbito = true;
                    break;
                }
            }

            if (!$hasAmbito) {
                // Fallback to old inheritance system
                return $this->obtenerPreguntasHeredadasLegacy($especieId);
            }

            // Obtener jerarquía completa de la especie
            $jerarquia = $this->obtenerJerarquiaEspecie($especieId);

            if (empty($jerarquia)) {
                return [];
            }

            $preguntasHeredadas = [];

            // Para cada nivel de la jerarquía
            foreach ($jerarquia as $nivel) {
                // Obtener preguntas base para este nivel
                $sql = "SELECT
                            p.id,
                            p.texto_pregunta,
                            p.tipo_pregunta,
                            p.opciones,
                            p.orden,
                            p.obligatoria,
                            p.depende_de,
                            p.respuesta_requerida,
                            p.ambito_aplicacion,
                            p.ambito_id,
                            s.nombre as ambito_nombre,
                            'heredada' as tipo_origen,
                            p.ambito_aplicacion as nivel_herencia
                        FROM preguntas p
                        INNER JOIN especies s ON p.ambito_id = s.id
                        WHERE p.formulario_id IS NULL
                        AND p.ambito_aplicacion = ?
                        AND p.ambito_id = ?
                        ORDER BY p.orden ASC";

                $preguntasNivel = $this->getDb()->select($sql, [$nivel['tipo'], $nivel['id']]);
                $preguntasHeredadas = array_merge($preguntasHeredadas, $preguntasNivel);
            }

            // Procesar opciones para las preguntas heredadas
            foreach ($preguntasHeredadas as &$pregunta) {
                if ($pregunta['opciones']) {
                    $pregunta['opciones_array'] = array_map('trim', explode(',', $pregunta['opciones']));
                } else {
                    $pregunta['opciones_array'] = [];
                }
                // Marcar como heredada para la UI
                $pregunta['es_heredada'] = true;
            }

            return $preguntasHeredadas;
        } catch (Exception $e) {
            error_log("Error obteniendo preguntas heredadas: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Legacy method for old inheritance system (backward compatibility)
     */
    private function obtenerPreguntasHeredadasLegacy($especieId) {
        // Obtener jerarquía completa de la especie
        $jerarquia = $this->obtenerJerarquiaEspecie($especieId);

        if (empty($jerarquia)) {
            return [];
        }

        $preguntasHeredadas = [];

        // Para cada nivel de la jerarquía (excepto el actual)
        foreach ($jerarquia as $nivel) {
            if ($nivel['id'] == $especieId) {
                continue; // No incluir el mismo nivel
            }

            // Buscar formularios aprobados para este nivel
            $sqlFormularios = "SELECT id FROM formularios WHERE especie_id = ? AND estado = 'aprobado'";
            $formulariosNivel = $this->getDb()->select($sqlFormularios, [$nivel['id']]);

            foreach ($formulariosNivel as $formularioNivel) {
                // Obtener preguntas del formulario padre
                $preguntasPadre = $this->obtenerPorFormulario($formularioNivel['id']);

                foreach ($preguntasPadre as $preguntaPadre) {
                    $preguntaPadre['tipo_origen'] = 'heredada';
                    $preguntaPadre['nivel_herencia'] = $nivel['tipo'];
                    $preguntaPadre['es_heredada'] = true;
                    $preguntasHeredadas[] = $preguntaPadre;
                }
            }
        }

        return $preguntasHeredadas;
    }

    /**
     * Heredar preguntas de niveles superiores (copia física al formulario)
     */
    public function heredarPreguntas($formularioId, $especieId) {
        try {
            // Obtener jerarquía completa de la especie
            $jerarquia = $this->obtenerJerarquiaEspecie($especieId);

            if (empty($jerarquia)) {
                return true; // No hay jerarquía, continuar normalmente
            }

            $ordenActual = 1;

            // Para cada nivel de la jerarquía (excepto el actual)
            foreach ($jerarquia as $nivel) {
                if ($nivel['id'] == $especieId) {
                    continue; // No heredar del mismo nivel
                }

                // Obtener preguntas base para este nivel
                $preguntasBase = $this->obtenerPreguntasBase($nivel['tipo'], $nivel['id']);

                foreach ($preguntasBase as $preguntaBase) {
                    // Verificar si ya existe una pregunta idéntica en este formulario
                    $existe = $this->verificarPreguntaExisteEnFormulario($formularioId, $preguntaBase);
                    if ($existe) {
                        continue; // Ya existe, saltar
                    }

                    // Copiar la pregunta base al formulario
                    $datosPreguntaHeredada = [
                        'formulario_id' => $formularioId,
                        'texto_pregunta' => $preguntaBase['texto_pregunta'],
                        'tipo_pregunta' => $preguntaBase['tipo_pregunta'],
                        'opciones' => $preguntaBase['opciones'],
                        'orden' => $ordenActual++,
                        'bloque' => 'Preguntas Heredadas',
                        'orden_bloque' => 1,
                        'obligatoria' => $preguntaBase['obligatoria'],
                        'depende_de' => null, // Las dependencias se manejarán después
                        'respuesta_requerida' => null,
                        'nivel_herencia' => $nivel['tipo'],
                        'es_heredada' => true,
                        'pregunta_original_id' => $preguntaBase['id']
                    ];

                    $this->crear($datosPreguntaHeredada);
                }
            }

            return true;
        } catch (Exception $e) {
            error_log("Error en heredarPreguntas: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Verificar si una pregunta ya existe en un formulario
     */
    private function verificarPreguntaExisteEnFormulario($formularioId, $preguntaBase) {
        $sql = "SELECT COUNT(*) as count FROM preguntas
                WHERE formulario_id = ? AND texto_pregunta = ? AND tipo_pregunta = ?
                AND (opciones = ? OR (opciones IS NULL AND ? IS NULL))";

        $resultado = $this->getDb()->selectOne($sql, [
            $formularioId,
            $preguntaBase['texto_pregunta'],
            $preguntaBase['tipo_pregunta'],
            $preguntaBase['opciones'],
            $preguntaBase['opciones']
        ]);

        return $resultado['count'] > 0;
    }

    /**
     * Obtener jerarquía completa de una especie
     */
    private function obtenerJerarquiaEspecie($especieId) {
        $jerarquia = [];
        $currentId = $especieId;

        // Subir por la jerarquía hasta llegar a la raíz
        while ($currentId) {
            $sql = "SELECT id, nombre, parent_id, tipo FROM especies WHERE id = ? LIMIT 1";
            $especie = $this->getDb()->selectOne($sql, [$currentId]);

            if (!$especie) {
                break;
            }

            $jerarquia[] = $especie;
            $currentId = $especie['parent_id'];
        }

        return array_reverse($jerarquia); // Ordenar de raíz a hoja
    }

    /**
     * Obtener pregunta por ID (soporta preguntas base y específicas)
     */
    public function obtenerPorId($id) {
        $sql = "SELECT
                    p.id,
                    p.formulario_id,
                    p.texto_pregunta,
                    p.tipo_pregunta,
                    p.opciones,
                    p.orden,
                    p.obligatoria,
                    p.depende_de,
                    p.respuesta_requerida,
                    p.ambito_aplicacion,
                    p.ambito_id,
                    f.nombre as formulario_nombre,
                    s.nombre as ambito_nombre,
                    padre.texto_pregunta as pregunta_padre
                FROM preguntas p
                LEFT JOIN formularios f ON p.formulario_id = f.id
                LEFT JOIN especies s ON p.ambito_id = s.id
                LEFT JOIN preguntas padre ON p.depende_de = padre.id
                WHERE p.id = ?
                LIMIT 1";

        return $this->getDb()->selectOne($sql, [$id]);
    }

    /**
     * Obtener preguntas de un formulario ordenadas con información de herencia
     * Nueva arquitectura: combina preguntas específicas del formulario con preguntas heredadas
     */
    public function obtenerPorFormulario($formularioId) {
        // Primero obtener información del formulario para saber la especie
        $sqlFormulario = "SELECT especie_id FROM formularios WHERE id = ?";
        $formulario = $this->getDb()->selectOne($sqlFormulario, [$formularioId]);

        if (!$formulario) {
            return [];
        }

        $especieId = $formulario['especie_id'];

        // Obtener preguntas específicas del formulario
        $sql = "SELECT
                    p.id,
                    p.texto_pregunta,
                    p.tipo_pregunta,
                    p.opciones,
                    p.orden,
                    p.obligatoria,
                    p.depende_de,
                    p.respuesta_requerida,
                    padre.texto_pregunta as pregunta_padre,
                    padre.tipo_pregunta as tipo_pregunta_padre,
                    'especifica' as tipo_origen,
                    'especie' as nivel_herencia,
                    false as es_heredada
                FROM preguntas p
                LEFT JOIN preguntas padre ON p.depende_de = padre.id
                WHERE p.formulario_id = ?
                ORDER BY p.orden ASC";

        $preguntasEspecificas = $this->getDb()->select($sql, [$formularioId]);

        // Obtener preguntas heredadas dinámicamente
        $preguntasHeredadas = $this->obtenerPreguntasHeredadas($especieId);

        // Combinar preguntas: heredadas primero, luego específicas
        $todasPreguntas = array_merge($preguntasHeredadas, $preguntasEspecificas);

        // Reordenar todas las preguntas por orden
        usort($todasPreguntas, function($a, $b) {
            return $a['orden'] <=> $b['orden'];
        });

        // Procesar opciones para todas las preguntas
        foreach ($todasPreguntas as &$pregunta) {
            if ($pregunta['opciones']) {
                $pregunta['opciones_array'] = array_map('trim', explode(',', $pregunta['opciones']));
            } else {
                $pregunta['opciones_array'] = [];
            }
        }

        return $todasPreguntas;
    }

    /**
     * Obtener preguntas visibles según respuestas (lógica condicional)
     */
    public function obtenerPreguntasVisibles($formularioId, $respuestas = []) {
        $preguntas = $this->obtenerPorFormulario($formularioId);
        $preguntasVisibles = [];

        foreach ($preguntas as $pregunta) {
            if ($this->esPreguntaVisible($pregunta, $respuestas)) {
                $preguntasVisibles[] = $pregunta;
            }
        }

        return $preguntasVisibles;
    }

    /**
     * Verificar si una pregunta es visible según lógica condicional
     */
    private function esPreguntaVisible($pregunta, $respuestas) {
        // Si no depende de otra pregunta, siempre es visible
        if (!$pregunta['depende_de']) {
            return true;
        }

        // Si depende de otra pregunta, verificar la respuesta
        $preguntaPadreId = $pregunta['depende_de'];
        $respuestaRequerida = $pregunta['respuesta_requerida'];

        // Buscar respuesta de la pregunta padre
        $respuestaPadre = null;
        foreach ($respuestas as $respuesta) {
            if ($respuesta['pregunta_id'] == $preguntaPadreId) {
                $respuestaPadre = $respuesta['valor_respuesta'];
                break;
            }
        }

        // Si no hay respuesta para la pregunta padre, la pregunta hija no es visible
        if ($respuestaPadre === null) {
            return false;
        }

        // Verificar si la respuesta coincide con la requerida
        return $respuestaPadre == $respuestaRequerida;
    }

    /**
     * Actualizar pregunta
     */
    public function actualizar($id, $datos) {
        try {
            $campos = [];
            $params = [];

            if (isset($datos['texto_pregunta'])) {
                $campos[] = "texto_pregunta = ?";
                $params[] = $datos['texto_pregunta'];
            }

            if (isset($datos['tipo_pregunta'])) {
                $campos[] = "tipo_pregunta = ?";
                $params[] = $datos['tipo_pregunta'];
            }

            if (isset($datos['opciones'])) {
                $campos[] = "opciones = ?";
                $params[] = $datos['opciones'];
            }

            if (isset($datos['orden'])) {
                $campos[] = "orden = ?";
                $params[] = $datos['orden'];
            }

            if (isset($datos['obligatoria'])) {
                $campos[] = "obligatoria = ?";
                $params[] = !empty($datos['obligatoria']) ? 1 : 0;
            }

            if (isset($datos['depende_de'])) {
                $campos[] = "depende_de = ?";
                $params[] = $datos['depende_de'];
            }

            if (isset($datos['respuesta_requerida'])) {
                $campos[] = "respuesta_requerida = ?";
                $params[] = $datos['respuesta_requerida'];
            }

            if (empty($campos)) {
                return false;
            }

            $params[] = $id;
            $sql = "UPDATE preguntas SET " . implode(', ', $campos) . " WHERE id = ?";

            return $this->getDb()->update($sql, $params) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Eliminar pregunta
     */
    public function eliminar($id) {
        try {
            $sql = "DELETE FROM preguntas WHERE id = ?";
            return $this->getDb()->delete($sql, [$id]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Reordenar preguntas
     */
    public function reordenar($preguntaId, $nuevoOrden) {
        try {
            $this->getDb()->beginTransaction();

            // Obtener información de la pregunta actual
            $pregunta = $this->obtenerPorId($preguntaId);
            if (!$pregunta) {
                throw new Exception('Pregunta no encontrada');
            }

            // No permitir reordenar preguntas base (globales)
            if ($pregunta['formulario_id'] === null) {
                throw new Exception('No se pueden reordenar preguntas base');
            }

            $formularioId = $pregunta['formulario_id'];
            $ordenActual = $pregunta['orden'];

            if ($nuevoOrden > $ordenActual) {
                // Mover hacia abajo: decrementar orden de preguntas intermedias
                $sql = "UPDATE preguntas SET orden = orden - 1 WHERE formulario_id = ? AND orden > ? AND orden <= ?";
                $this->getDb()->update($sql, [$formularioId, $ordenActual, $nuevoOrden]);
            } else {
                // Mover hacia arriba: incrementar orden de preguntas intermedias
                $sql = "UPDATE preguntas SET orden = orden + 1 WHERE formulario_id = ? AND orden >= ? AND orden < ?";
                $this->getDb()->update($sql, [$formularioId, $nuevoOrden, $ordenActual]);
            }

            // Establecer nuevo orden
            $sql = "UPDATE preguntas SET orden = ? WHERE id = ?";
            $this->getDb()->update($sql, [$nuevoOrden, $preguntaId]);

            $this->getDb()->commit();
            return true;
        } catch (Exception $e) {
            $this->getDb()->rollback();
            return false;
        }
    }

    /**
     * Obtener siguiente orden disponible para formulario
     */
    public function obtenerSiguienteOrden($formularioId) {
        $sql = "SELECT MAX(orden) as max_orden FROM preguntas WHERE formulario_id = ?";
        $resultado = $this->getDb()->selectOne($sql, [$formularioId]);
        return ($resultado['max_orden'] ?? 0) + 1;
    }

    /**
     * Validar datos de pregunta
     */
    public function validarDatos($datos, $esActualizacion = false) {
        $errores = [];

        // Validar texto de pregunta
        if (empty($datos['texto_pregunta'])) {
            $errores['texto_pregunta'] = 'El texto de la pregunta es requerido';
        } elseif (strlen($datos['texto_pregunta']) < 5) {
            $errores['texto_pregunta'] = 'El texto de la pregunta debe tener al menos 5 caracteres';
        }

        // Validar tipo de pregunta
        if (empty($datos['tipo_pregunta'])) {
            $errores['tipo_pregunta'] = 'El tipo de pregunta es requerido';
        } elseif (!array_key_exists($datos['tipo_pregunta'], QUESTION_TYPES)) {
            $errores['tipo_pregunta'] = 'El tipo de pregunta seleccionado no es válido';
        }

        // Validar opciones para preguntas de opción múltiple
        if (isset($datos['tipo_pregunta']) && $datos['tipo_pregunta'] === 'opcion_multiple') {
            if (empty($datos['opciones'])) {
                $errores['opciones'] = 'Las opciones son requeridas para preguntas de opción múltiple';
            } elseif (strlen($datos['opciones']) < 3) {
                $errores['opciones'] = 'Debe especificar al menos una opción';
            }
        }

        // Validar orden
        if (!isset($datos['orden']) || $datos['orden'] < 1) {
            $errores['orden'] = 'El orden debe ser un número positivo';
        }

        // Validar lógica condicional
        if (isset($datos['depende_de']) && $datos['depende_de']) {
            // Para creación, no necesitamos validar tanto (las preguntas padre se crean después)
            if ($esActualizacion && !isset($datos['id'])) {
                $errores['depende_de'] = 'Error interno: ID de pregunta requerido para lógica condicional en actualización';
            }

            // Validar respuesta requerida
            if (empty($datos['respuesta_requerida'])) {
                $errores['respuesta_requerida'] = 'La respuesta requerida es necesaria para preguntas condicionales';
            }
        }

        return $errores;
    }

    /**
     * Obtener preguntas padre disponibles para un formulario
     */
    public function obtenerPreguntasPadre($formularioId, $excluirId = null) {
        $sql = "SELECT id, texto_pregunta, tipo_pregunta, orden FROM preguntas WHERE formulario_id = ?";
        $params = [$formularioId];

        if ($excluirId) {
            $sql .= " AND id != ?";
            $params[] = $excluirId;
        }

        $sql .= " ORDER BY orden ASC";

        return $this->getDb()->select($sql, $params);
    }

    /**
     * Obtener estadísticas de preguntas
     */
    public function obtenerEstadisticas() {
        $sql = "SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN tipo_pregunta = 'texto' THEN 1 ELSE 0 END) as textos,
                    SUM(CASE WHEN tipo_pregunta = 'numero' THEN 1 ELSE 0 END) as numeros,
                    SUM(CASE WHEN tipo_pregunta = 'booleano' THEN 1 ELSE 0 END) as booleanos,
                    SUM(CASE WHEN tipo_pregunta = 'opcion_multiple' THEN 1 ELSE 0 END) as opciones_multiples,
                    SUM(CASE WHEN tipo_pregunta = 'fecha' THEN 1 ELSE 0 END) as fechas,
                    SUM(CASE WHEN obligatoria = 1 THEN 1 ELSE 0 END) as obligatorias,
                    SUM(CASE WHEN depende_de IS NOT NULL THEN 1 ELSE 0 END) as condicionales
                FROM preguntas";

        return $this->getDb()->selectOne($sql);
    }

    /**
     * Duplicar pregunta
     */
    public function duplicar($preguntaId, $nuevoFormularioId = null) {
        try {
            $pregunta = $this->obtenerPorId($preguntaId);
            if (!$pregunta) {
                return false;
            }

            // Para preguntas base, mantener formulario_id = NULL
            $formularioId = $nuevoFormularioId;
            if ($pregunta['formulario_id'] === null && $nuevoFormularioId === null) {
                $formularioId = null;
            }

            $datos = [
                'formulario_id' => $formularioId,
                'texto_pregunta' => $pregunta['texto_pregunta'] . ' (Copia)',
                'tipo_pregunta' => $pregunta['tipo_pregunta'],
                'opciones' => $pregunta['opciones'],
                'orden' => $formularioId ? $this->obtenerSiguienteOrden($formularioId) : ($pregunta['orden'] + 1),
                'obligatoria' => $pregunta['obligatoria'],
                'depende_de' => $pregunta['depende_de'],
                'respuesta_requerida' => $pregunta['respuesta_requerida'],
                'ambito_aplicacion' => $pregunta['ambito_aplicacion'] ?? null,
                'ambito_id' => $pregunta['ambito_id'] ?? null
            ];

            return $this->crear($datos);
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Obtener opciones de pregunta como array
     */
    public function obtenerOpcionesComoArray($pregunta) {
        if (empty($pregunta['opciones'])) {
            return [];
        }

        return array_map('trim', explode(',', $pregunta['opciones']));
    }

    /**
     * Validar respuesta según tipo de pregunta
     */
    public function validarRespuesta($pregunta, $valor) {
        // Si la pregunta no es obligatoria y no hay valor, es válido
        if (!$pregunta['obligatoria'] && empty($valor)) {
            return true;
        }

        switch ($pregunta['tipo_pregunta']) {
            case 'texto':
                return is_string($valor) && strlen($valor) > 0;

            case 'numero':
                return is_numeric($valor);

            case 'booleano':
                return in_array($valor, ['0', '1', 0, 1, true, false]);

            case 'fecha':
                return strtotime($valor) !== false;

            case 'opcion_multiple':
                $opciones = $this->obtenerOpcionesComoArray($pregunta);
                return in_array($valor, $opciones);


            default:
                return false;
        }
    }

    /**
     * Obtener preguntas agrupadas por bloques para un formulario (simplificado)
     */
    public function obtenerPorBloques($formularioId) {
        $preguntas = $this->obtenerPorFormulario($formularioId);
        // Por ahora, devolver todas las preguntas en un solo bloque "General"
        return ['General' => $preguntas];
    }

    /**
     * Obtener preguntas base por ámbito (reino/modulo)
     */
    public function obtenerPreguntasBase($ambito, $ambitoId) {
        $sql = "SELECT id, texto_pregunta, tipo_pregunta, opciones, orden
                FROM preguntas
                WHERE ambito_aplicacion = ? AND ambito_id = ? AND formulario_id IS NULL
                ORDER BY orden ASC";

        return $this->getDb()->select($sql, [$ambito, $ambitoId]);
    }

    /**
     * Obtener preguntas comunes (intersección) entre múltiples especies (simplificado)
     */
    public function obtenerPreguntasComunes($especieIds) {
        if (empty($especieIds)) {
            return [];
        }

        // Para cada especie, obtener sus formularios aprobados
        $formularioIds = [];
        foreach ($especieIds as $especieId) {
            $formularios = $this->getDb()->select(
                "SELECT id FROM formularios WHERE especie_id = ? AND estado = 'aprobado'",
                [$especieId]
            );

            if (!empty($formularios)) {
                $formularioIds[] = $formularios[0]['id'];
            }
        }

        if (empty($formularioIds)) {
            return [];
        }

        // Obtener preguntas comunes usando intersección (simplificado)
        $placeholders = str_repeat('?,', count($formularioIds) - 1) . '?';

        $sql = "SELECT p.id, p.texto_pregunta, p.tipo_pregunta, p.opciones,
                        COUNT(DISTINCT p.formulario_id) as formularios_count
                FROM preguntas p
                WHERE p.formulario_id IN ({$placeholders})
                GROUP BY p.texto_pregunta, p.tipo_pregunta, p.opciones
                HAVING COUNT(DISTINCT p.formulario_id) = ?
                ORDER BY p.orden";

        $params = array_merge($formularioIds, [count($formularioIds)]);

        return $this->getDb()->select($sql, $params);
    }
}