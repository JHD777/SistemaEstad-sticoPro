<?php
/**
 * Sistema Estadístico Pro - Modelo RegistroCenso
 * Maneja los registros individuales de censo completados
 */

class RegistroCenso {
    private $db;

    public function __construct() {
        // Inicializar conexión a base de datos de forma lazy
        $this->db = null;
    }

    /**
     * Obtener instancia de conexión a base de datos
     */
    private function getDb() {
        if ($this->db === null) {
            $this->db = Database::getInstance();
        }
        return $this->db;
    }

    /**
     * Crear un nuevo registro de censo
     */
    public function crear($datos) {
        try {
            $this->getDb()->beginTransaction();

            $sql = "INSERT INTO registros_censo (formulario_id, usuario_admin_id, fecha_censo, ubicacion_geo, observaciones)
                    VALUES (?, ?, ?, ?, ?)";

            $params = [
                $datos['formulario_id'],
                $datos['usuario_admin_id'],
                $datos['fecha_censo'] ?? date('Y-m-d H:i:s'),
                $datos['ubicacion_geo'] ?? null,
                $datos['observaciones'] ?? null
            ];

            $registroId = $this->getDb()->insert($sql, $params);

            if (!$registroId) {
                throw new Exception('Error al crear registro de censo');
            }

            $this->getDb()->commit();
            return $registroId;
        } catch (Exception $e) {
            $this->getDb()->rollback();
            return false;
        }
    }

    /**
     * Obtener registro por ID con detalles
     */
    public function obtenerPorId($id) {
        $sql = "SELECT
                    rc.id,
                    rc.formulario_id,
                    rc.usuario_admin_id,
                    rc.fecha_censo,
                    rc.ubicacion_geo,
                    rc.observaciones,
                    f.nombre as formulario_nombre,
                    e.nombre as especie_nombre,
                    u.nombre as admin_nombre
                FROM registros_censo rc
                INNER JOIN formularios f ON rc.formulario_id = f.id
                INNER JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON rc.usuario_admin_id = u.id
                WHERE rc.id = ?
                LIMIT 1";

        return $this->getDb()->selectOne($sql, [$id]);
    }

    /**
     * Obtener registros con paginación
     */
    public function listar($pagina = 1, $limite = ITEMS_PER_PAGE, $filtros = []) {
        $offset = ($pagina - 1) * $limite;

        $where = [];
        $params = [];

        if (!empty($filtros['formulario_id'])) {
            $where[] = "rc.formulario_id = ?";
            $params[] = $filtros['formulario_id'];
        }

        if (!empty($filtros['especie_id'])) {
            $where[] = "f.especie_id = ?";
            $params[] = $filtros['especie_id'];
        }

        if (!empty($filtros['usuario_admin_id'])) {
            $where[] = "rc.usuario_admin_id = ?";
            $params[] = $filtros['usuario_admin_id'];
        }

        if (!empty($filtros['fecha_desde'])) {
            $where[] = "rc.fecha_censo >= ?";
            $params[] = $filtros['fecha_desde'];
        }

        if (!empty($filtros['fecha_hasta'])) {
            $where[] = "rc.fecha_censo <= ?";
            $params[] = $filtros['fecha_hasta'];
        }

        $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);

        $sql = "SELECT
                    rc.id,
                    rc.fecha_censo,
                    rc.ubicacion_geo,
                    rc.observaciones,
                    f.nombre as formulario_nombre,
                    e.nombre as especie_nombre,
                    u.nombre as admin_nombre
                FROM registros_censo rc
                INNER JOIN formularios f ON rc.formulario_id = f.id
                INNER JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON rc.usuario_admin_id = u.id
                $whereClause
                ORDER BY rc.fecha_censo DESC
                LIMIT ? OFFSET ?";

        $params[] = $limite;
        $params[] = $offset;

        $registros = $this->getDb()->select($sql, $params);

        // Obtener total para paginación
        $sqlTotal = "SELECT COUNT(*) as total FROM registros_censo rc
                     INNER JOIN formularios f ON rc.formulario_id = f.id
                     $whereClause";

        $total = $this->getDb()->selectOne($sqlTotal, array_slice($params, 0, -2));

        return [
            'registros' => $registros,
            'total' => $total['total'],
            'pagina' => $pagina,
            'limite' => $limite,
            'total_paginas' => ceil($total['total'] / $limite)
        ];
    }

    /**
     * Obtener registros por formulario
     */
    public function obtenerPorFormulario($formularioId) {
        $sql = "SELECT
                    rc.id,
                    rc.fecha_censo,
                    rc.ubicacion_geo,
                    rc.observaciones,
                    u.nombre as admin_nombre
                FROM registros_censo rc
                INNER JOIN usuarios u ON rc.usuario_admin_id = u.id
                WHERE rc.formulario_id = ?
                ORDER BY rc.fecha_censo DESC";

        return $this->getDb()->select($sql, [$formularioId]);
    }

    /**
     * Obtener registros por especie
     */
    public function obtenerPorEspecie($especieId) {
        $sql = "SELECT
                    rc.id,
                    rc.fecha_censo,
                    rc.ubicacion_geo,
                    rc.observaciones,
                    f.nombre as formulario_nombre,
                    u.nombre as admin_nombre
                FROM registros_censo rc
                INNER JOIN formularios f ON rc.formulario_id = f.id
                INNER JOIN usuarios u ON rc.usuario_admin_id = u.id
                WHERE f.especie_id = ?
                ORDER BY rc.fecha_censo DESC";

        return $this->getDb()->select($sql, [$especieId]);
    }

    /**
     * Obtener registros por admin
     */
    public function obtenerPorAdmin($adminId) {
        $sql = "SELECT
                    rc.id,
                    rc.fecha_censo,
                    rc.ubicacion_geo,
                    rc.observaciones,
                    f.nombre as formulario_nombre,
                    e.nombre as especie_nombre
                FROM registros_censo rc
                INNER JOIN formularios f ON rc.formulario_id = f.id
                INNER JOIN especies e ON f.especie_id = e.id
                WHERE rc.usuario_admin_id = ?
                ORDER BY rc.fecha_censo DESC";

        return $this->getDb()->select($sql, [$adminId]);
    }

    /**
     * Actualizar registro
     */
    public function actualizar($id, $datos) {
        try {
            $campos = [];
            $params = [];

            if (isset($datos['ubicacion_geo'])) {
                $campos[] = "ubicacion_geo = ?";
                $params[] = $datos['ubicacion_geo'];
            }

            if (isset($datos['observaciones'])) {
                $campos[] = "observaciones = ?";
                $params[] = $datos['observaciones'];
            }

            if (empty($campos)) {
                return false;
            }

            $params[] = $id;
            $sql = "UPDATE registros_censo SET " . implode(', ', $campos) . " WHERE id = ?";

            return $this->getDb()->update($sql, $params) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Eliminar registro
     */
    public function eliminar($id) {
        try {
            $sql = "DELETE FROM registros_censo WHERE id = ?";
            return $this->getDb()->delete($sql, [$id]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Buscar registros
     */
    public function buscar($termino, $pagina = 1, $limite = ITEMS_PER_PAGE) {
        $offset = ($pagina - 1) * $limite;
        $termino = "%$termino%";

        $sql = "SELECT
                    rc.id,
                    rc.fecha_censo,
                    rc.ubicacion_geo,
                    rc.observaciones,
                    f.nombre as formulario_nombre,
                    e.nombre as especie_nombre,
                    u.nombre as admin_nombre
                FROM registros_censo rc
                INNER JOIN formularios f ON rc.formulario_id = f.id
                INNER JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON rc.usuario_admin_id = u.id
                WHERE f.nombre LIKE ? OR e.nombre LIKE ? OR rc.observaciones LIKE ?
                ORDER BY rc.fecha_censo DESC
                LIMIT ? OFFSET ?";

        $registros = $this->getDb()->select($sql, [$termino, $termino, $termino, $limite, $offset]);

        // Obtener total para paginación
        $sqlTotal = "SELECT COUNT(*) as total
                     FROM registros_censo rc
                     INNER JOIN formularios f ON rc.formulario_id = f.id
                     INNER JOIN especies e ON f.especie_id = e.id
                     WHERE f.nombre LIKE ? OR e.nombre LIKE ? OR rc.observaciones LIKE ?";

        $total = $this->getDb()->selectOne($sqlTotal, [$termino, $termino, $termino]);

        return [
            'registros' => $registros,
            'total' => $total['total'],
            'pagina' => $pagina,
            'limite' => $limite,
            'total_paginas' => ceil($total['total'] / $limite)
        ];
    }

    /**
     * Obtener estadísticas de registros
     */
    public function obtenerEstadisticas() {
        $sql = "SELECT
                    COUNT(*) as total,
                    COUNT(DISTINCT formulario_id) as formularios_utilizados,
                    COUNT(DISTINCT usuario_admin_id) as admins_activos,
                    MIN(fecha_censo) as primer_censo,
                    MAX(fecha_censo) as ultimo_censo
                FROM registros_censo";

        return $this->getDb()->selectOne($sql);
    }

    /**
     * Obtener registros recientes
     */
    public function obtenerRecientes($limite = 10) {
        $sql = "SELECT
                    rc.id,
                    rc.fecha_censo,
                    f.nombre as formulario_nombre,
                    e.nombre as especie_nombre,
                    u.nombre as admin_nombre
                FROM registros_censo rc
                INNER JOIN formularios f ON rc.formulario_id = f.id
                INNER JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON rc.usuario_admin_id = u.id
                ORDER BY rc.fecha_censo DESC
                LIMIT ?";

        return $this->getDb()->select($sql, [$limite]);
    }

    /**
     * Validar datos de registro
     */
    public function validarDatos($datos) {
        $errores = [];

        // Validar formulario
        if (empty($datos['formulario_id'])) {
            $errores['formulario_id'] = 'El formulario es requerido';
        } else {
            // Verificar que el formulario existe y está aprobado
            $formularioModel = new Formulario();
            $formulario = $formularioModel->obtenerPorId($datos['formulario_id']);
            if (!$formulario) {
                $errores['formulario_id'] = 'El formulario seleccionado no existe';
            } elseif ($formulario['estado'] !== 'aprobado') {
                $errores['formulario_id'] = 'El formulario debe estar aprobado para realizar censos';
            }
        }

        // Validar admin
        if (empty($datos['usuario_admin_id'])) {
            $errores['usuario_admin_id'] = 'El administrador es requerido';
        } else {
            // Verificar que el admin existe y está activo
            $usuarioModel = new Usuario();
            $admin = $usuarioModel->obtenerPorId($datos['usuario_admin_id']);
            if (!$admin) {
                $errores['usuario_admin_id'] = 'El administrador seleccionado no existe';
            } elseif (!$admin['activo']) {
                $errores['usuario_admin_id'] = 'El administrador debe estar activo';
            }
        }

        // Validar ubicación geográfica (si se proporciona)
        if (!empty($datos['ubicacion_geo'])) {
            if (strlen($datos['ubicacion_geo']) > 100) {
                $errores['ubicacion_geo'] = 'La ubicación geográfica no puede tener más de 100 caracteres';
            }
        }

        return $errores;
    }

    /**
     * Obtener registros por período de tiempo
     */
    public function obtenerPorPeriodo($fechaInicio, $fechaFin, $especieId = null) {
        $sql = "SELECT
                    rc.id,
                    rc.fecha_censo,
                    rc.ubicacion_geo,
                    f.nombre as formulario_nombre,
                    e.nombre as especie_nombre,
                    u.nombre as admin_nombre
                FROM registros_censo rc
                INNER JOIN formularios f ON rc.formulario_id = f.id
                INNER JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON rc.usuario_admin_id = u.id
                WHERE rc.fecha_censo BETWEEN ? AND ?";

        $params = [$fechaInicio, $fechaFin];

        if ($especieId) {
            $sql .= " AND e.id = ?";
            $params[] = $especieId;
        }

        $sql .= " ORDER BY rc.fecha_censo DESC";

        return $this->getDb()->select($sql, $params);
    }

    /**
     * Obtener estadísticas por especie
     */
    public function obtenerEstadisticasPorEspecie() {
        $sql = "SELECT
                    e.id,
                    e.nombre as especie_nombre,
                    COUNT(rc.id) as total_censos,
                    MIN(rc.fecha_censo) as primer_censo,
                    MAX(rc.fecha_censo) as ultimo_censo
                FROM especies e
                INNER JOIN formularios f ON e.id = f.especie_id
                INNER JOIN registros_censo rc ON f.id = rc.formulario_id
                GROUP BY e.id, e.nombre
                ORDER BY total_censos DESC";

        return $this->getDb()->select($sql);
    }

    /**
     * Obtener estadísticas por admin
     */
    public function obtenerEstadisticasPorAdmin() {
        $sql = "SELECT
                    u.id,
                    u.nombre as admin_nombre,
                    COUNT(rc.id) as total_censos,
                    COUNT(DISTINCT f.especie_id) as especies_censadas,
                    MIN(rc.fecha_censo) as primer_censo,
                    MAX(rc.fecha_censo) as ultimo_censo
                FROM usuarios u
                INNER JOIN registros_censo rc ON u.id = rc.usuario_admin_id
                INNER JOIN formularios f ON rc.formulario_id = f.id
                GROUP BY u.id, u.nombre
                ORDER BY total_censos DESC";

        return $this->getDb()->select($sql);
    }
}