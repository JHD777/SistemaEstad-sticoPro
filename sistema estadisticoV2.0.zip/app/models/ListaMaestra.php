<?php
/**
 * Sistema Estadístico Pro - Modelo Lista Maestra
 * Maneja las listas de opciones reutilizables para preguntas condicionales
 */

class ListaMaestra {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    /**
     * Crear una nueva lista maestra
     */
    public function crear($datos) {
        try {
            // Validar que las opciones sean un array válido
            $opciones = json_decode($datos['opciones'], true);
            if (!is_array($opciones) || empty($opciones)) {
                return false;
            }

            $sql = "INSERT INTO listas_maestras (nombre, descripcion, especie_id, tipo, opciones, creador_id, activa)
                    VALUES (?, ?, ?, ?, ?, ?, ?)";

            $params = [
                $datos['nombre'],
                $datos['descripcion'] ?? null,
                $datos['especie_id'],
                $datos['tipo'],
                json_encode($opciones), // Guardar como JSON
                $datos['creador_id'],
                $datos['activa'] ?? true
            ];

            return $this->db->insert($sql, $params);
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Obtener lista maestra por ID
     */
    public function obtenerPorId($id) {
        $sql = "SELECT lm.*, e.nombre as especie_nombre, u.nombre as creador_nombre
                FROM listas_maestras lm
                JOIN especies e ON lm.especie_id = e.id
                JOIN usuarios u ON lm.creador_id = u.id
                WHERE lm.id = ? AND lm.activa = 1
                LIMIT 1";

        $lista = $this->db->selectOne($sql, [$id]);

        if ($lista) {
            // Decodificar las opciones JSON
            $lista['opciones_array'] = json_decode($lista['opciones'], true);
        }

        return $lista;
    }

    /**
     * Listar listas maestras con filtros
     */
    public function listar($pagina = 1, $limite = 20, $filtros = []) {
        $offset = ($pagina - 1) * $limite;
        $where = ["lm.activa = 1"];
        $params = [];

        // Aplicar filtros
        if (!empty($filtros['especie_id'])) {
            $where[] = "lm.especie_id = ?";
            $params[] = $filtros['especie_id'];
        }

        if (!empty($filtros['tipo'])) {
            $where[] = "lm.tipo = ?";
            $params[] = $filtros['tipo'];
        }

        if (!empty($filtros['buscar'])) {
            $where[] = "(lm.nombre LIKE ? OR lm.descripcion LIKE ?)";
            $params[] = "%{$filtros['buscar']}%";
            $params[] = "%{$filtros['buscar']}%";
        }

        $whereClause = implode(' AND ', $where);

        // Consulta principal
        $sql = "SELECT lm.*, e.nombre as especie_nombre, u.nombre as creador_nombre
                FROM listas_maestras lm
                JOIN especies e ON lm.especie_id = e.id
                JOIN usuarios u ON lm.creador_id = u.id
                WHERE {$whereClause}
                ORDER BY lm.fecha_creacion DESC
                LIMIT ? OFFSET ?";

        $params[] = $limite;
        $params[] = $offset;

        $listas = $this->db->select($sql, $params);

        // Decodificar opciones JSON para cada lista
        foreach ($listas as &$lista) {
            $lista['opciones_array'] = json_decode($lista['opciones'], true);
        }

        // Contar total
        $sqlTotal = "SELECT COUNT(*) as total FROM listas_maestras lm WHERE {$whereClause}";
        $total = $this->db->selectOne($sqlTotal, array_slice($params, 0, -2)); // Remover LIMIT y OFFSET

        return [
            'listas' => $listas,
            'total' => $total['total'],
            'pagina' => $pagina,
            'limite' => $limite,
            'total_paginas' => ceil($total['total'] / $limite)
        ];
    }

    /**
     * Obtener listas maestras por especie
     */
    public function obtenerPorEspecie($especieId, $tipo = null) {
        $sql = "SELECT * FROM listas_maestras WHERE especie_id = ? AND activa = 1";
        $params = [$especieId];

        if ($tipo) {
            $sql .= " AND tipo = ?";
            $params[] = $tipo;
        }

        $sql .= " ORDER BY nombre";

        $listas = $this->db->select($sql, $params);

        // Decodificar opciones JSON
        foreach ($listas as &$lista) {
            $lista['opciones_array'] = json_decode($lista['opciones'], true);
        }

        return $listas;
    }

    /**
     * Obtener listas maestras aplicables a una especie (incluyendo ancestros)
     */
    public function obtenerAplicables($especieId) {
        // Obtener la jerarquía completa de la especie
        $jerarquia = $this->obtenerJerarquiaEspecie($especieId);

        if (empty($jerarquia)) {
            return [];
        }

        // Obtener IDs de especies en la jerarquía
        $especieIds = array_column($jerarquia, 'id');

        $placeholders = str_repeat('?,', count($especieIds) - 1) . '?';

        $sql = "SELECT lm.*, e.nombre as especie_nombre, e.tipo as especie_tipo
                FROM listas_maestras lm
                JOIN especies e ON lm.especie_id = e.id
                WHERE lm.especie_id IN ({$placeholders}) AND lm.activa = 1
                ORDER BY lm.tipo, lm.nombre";

        $listas = $this->db->select($sql, $especieIds);

        // Decodificar opciones JSON y agrupar por tipo
        $listasPorTipo = [];
        foreach ($listas as $lista) {
            $lista['opciones_array'] = json_decode($lista['opciones'], true);
            $tipo = $lista['tipo'];

            if (!isset($listasPorTipo[$tipo])) {
                $listasPorTipo[$tipo] = [];
            }

            $listasPorTipo[$tipo][] = $lista;
        }

        return $listasPorTipo;
    }

    /**
     * Actualizar lista maestra
     */
    public function actualizar($id, $datos) {
        try {
            $campos = [];
            $params = [];

            if (isset($datos['nombre'])) {
                $campos[] = "nombre = ?";
                $params[] = $datos['nombre'];
            }

            if (isset($datos['descripcion'])) {
                $campos[] = "descripcion = ?";
                $params[] = $datos['descripcion'];
            }

            if (isset($datos['tipo'])) {
                $campos[] = "tipo = ?";
                $params[] = $datos['tipo'];
            }

            if (isset($datos['opciones']) && is_array($datos['opciones'])) {
                $campos[] = "opciones = ?";
                $params[] = json_encode($datos['opciones']);
            }

            if (isset($datos['activa'])) {
                $campos[] = "activa = ?";
                $params[] = $datos['activa'];
            }

            if (empty($campos)) {
                return false;
            }

            $params[] = $id;
            $sql = "UPDATE listas_maestras SET " . implode(', ', $campos) . " WHERE id = ?";

            return $this->db->update($sql, $params) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Desactivar lista maestra
     */
    public function desactivar($id) {
        return $this->actualizar($id, ['activa' => false]);
    }

    /**
     * Obtener jerarquía completa de una especie
     */
    private function obtenerJerarquiaEspecie($especieId) {
        $jerarquia = [];
        $currentId = $especieId;

        // Subir por la jerarquía hasta llegar a la raíz
        while ($currentId) {
            $sql = "SELECT id, nombre, parent_id, tipo FROM especies WHERE id = ? LIMIT 1";
            $especie = $this->db->selectOne($sql, [$currentId]);

            if (!$especie) {
                break;
            }

            $jerarquia[] = $especie;
            $currentId = $especie['parent_id'];
        }

        return array_reverse($jerarquia); // Ordenar de raíz a hoja
    }

    /**
     * Validar datos de lista maestra
     */
    public function validarDatos($datos) {
        $errores = [];

        if (empty($datos['nombre'])) {
            $errores['nombre'] = 'El nombre es requerido';
        } elseif (strlen($datos['nombre']) < 3) {
            $errores['nombre'] = 'El nombre debe tener al menos 3 caracteres';
        }

        if (empty($datos['especie_id'])) {
            $errores['especie_id'] = 'La especie es requerida';
        }

        if (empty($datos['tipo'])) {
            $errores['tipo'] = 'El tipo es requerido';
        }

        if (empty($datos['opciones']) || !is_array($datos['opciones'])) {
            $errores['opciones'] = 'Las opciones son requeridas y deben ser un array';
        } elseif (count($datos['opciones']) < 2) {
            $errores['opciones'] = 'Debe haber al menos 2 opciones';
        } else {
            // Verificar que no haya opciones vacías
            foreach ($datos['opciones'] as $opcion) {
                if (empty(trim($opcion))) {
                    $errores['opciones'] = 'No se permiten opciones vacías';
                    break;
                }
            }
        }

        return $errores;
    }

    /**
     * Obtener tipos disponibles de listas maestras
     */
    public static function getTiposDisponibles() {
        return [
            'parásitos' => 'Parásitos',
            'enfermedades' => 'Enfermedades',
            'hábitos' => 'Hábitos',
            'colores' => 'Colores',
            'texturas' => 'Texturas',
            'otros' => 'Otros'
        ];
    }
}