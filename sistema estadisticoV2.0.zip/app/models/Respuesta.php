<?php
/**
 * Sistema Estadístico Pro - Modelo Respuesta
 * Maneja las respuestas usando el patrón EAV (Entidad-Atributo-Valor)
 */

class Respuesta {
    private $db;

    public function __construct() {
        // Inicializar conexión a base de datos de forma lazy
        $this->db = null;
    }

    /**
     * Obtener instancia de conexión a base de datos
     */
    private function getDb() {
        if ($this->db === null) {
            $this->db = Database::getInstance();
        }
        return $this->db;
    }

    /**
     * Crear una nueva respuesta
     */
    public function crear($datos) {
        try {
            $sql = "INSERT INTO respuestas (registro_censo_id, pregunta_id, valor_respuesta) VALUES (?, ?, ?)";
            $params = [
                $datos['registro_censo_id'],
                $datos['pregunta_id'],
                $datos['valor_respuesta']
            ];

            return $this->getDb()->insert($sql, $params);
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Crear múltiples respuestas para un registro de censo
     */
    public function crearMultiples($registroCensoId, $respuestas) {
        try {
            $this->getDb()->beginTransaction();

            foreach ($respuestas as $preguntaId => $valor) {
                // Solo guardar respuestas que no estén vacías
                if ($valor !== '' && $valor !== null) {
                    $sql = "INSERT INTO respuestas (registro_censo_id, pregunta_id, valor_respuesta) VALUES (?, ?, ?)";
                    $this->getDb()->insert($sql, [$registroCensoId, $preguntaId, $valor]);
                }
            }

            $this->getDb()->commit();
            return true;
        } catch (Exception $e) {
            $this->getDb()->rollback();
            return false;
        }
    }

    /**
     * Obtener respuesta por ID
     */
    public function obtenerPorId($id) {
        $sql = "SELECT
                    r.id,
                    r.registro_censo_id,
                    r.pregunta_id,
                    r.valor_respuesta,
                    p.texto_pregunta,
                    p.tipo_pregunta,
                    rc.fecha_censo
                FROM respuestas r
                INNER JOIN preguntas p ON r.pregunta_id = p.id
                INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                WHERE r.id = ?
                LIMIT 1";

        return $this->getDb()->selectOne($sql, [$id]);
    }

    /**
     * Obtener respuestas por registro de censo
     */
    public function obtenerPorRegistroCenso($registroCensoId) {
        $sql = "SELECT
                    r.id,
                    r.pregunta_id,
                    r.valor_respuesta,
                    p.texto_pregunta,
                    p.tipo_pregunta,
                    p.opciones,
                    p.obligatoria
                FROM respuestas r
                INNER JOIN preguntas p ON r.pregunta_id = p.id
                WHERE r.registro_censo_id = ?
                ORDER BY p.orden ASC";

        return $this->getDb()->select($sql, [$registroCensoId]);
    }

    /**
     * Obtener respuestas por pregunta
     */
    public function obtenerPorPregunta($preguntaId) {
        $sql = "SELECT
                    r.id,
                    r.registro_censo_id,
                    r.valor_respuesta,
                    rc.fecha_censo,
                    u.nombre as admin_nombre
                FROM respuestas r
                INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                INNER JOIN usuarios u ON rc.usuario_admin_id = u.id
                WHERE r.pregunta_id = ?
                ORDER BY rc.fecha_censo DESC";

        return $this->getDb()->select($sql, [$preguntaId]);
    }

    /**
     * Obtener respuestas para análisis de datos (dashboard)
     */
    public function obtenerParaAnalisis($especieIds, $preguntaIds = null) {
        if (empty($especieIds)) {
            return [];
        }

        $sql = "SELECT
                     r.valor_respuesta,
                     r.pregunta_id,
                     p.tipo_pregunta,
                     p.opciones,
                     rc.fecha_censo,
                     f.especie_id
                 FROM respuestas r
                 INNER JOIN preguntas p ON r.pregunta_id = p.id
                 INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                 INNER JOIN formularios f ON rc.formulario_id = f.id
                 WHERE f.especie_id IN (" . str_repeat('?,', count($especieIds) - 1) . "?)";

        $params = $especieIds;

        if ($preguntaIds) {
            $placeholders = str_repeat('?,', count($preguntaIds) - 1) . '?';
            $sql .= " AND r.pregunta_id IN ($placeholders)";
            $params = array_merge($params, $preguntaIds);
        }

        $sql .= " ORDER BY rc.fecha_censo DESC";

        return $this->getDb()->select($sql, $params);
    }

    /**
     * Obtener preguntas comunes entre múltiples especies (algoritmo de intersección)
     */
    public function obtenerPreguntasComunes($especieIds) {
        if (empty($especieIds)) {
            return [];
        }

        // Obtener todos los formularios aprobados de las especies
        $sqlFormularios = "SELECT id FROM formularios
                          WHERE especie_id IN (" . str_repeat('?,', count($especieIds) - 1) . "?)
                          AND estado = 'aprobado'";

        $formularios = $this->getDb()->select($sqlFormularios, $especieIds);
        $formularioIds = array_column($formularios, 'id');

        if (empty($formularioIds)) {
            return [];
        }

        // Algoritmo de intersección: preguntas que existen en TODOS los formularios
        $sql = "SELECT p.id, p.texto_pregunta, p.tipo_pregunta, p.opciones, COUNT(DISTINCT f.id) as formularios_count
                FROM preguntas p
                INNER JOIN formularios f ON p.formulario_id = f.id
                WHERE f.id IN (" . str_repeat('?,', count($formularioIds) - 1) . "?)
                GROUP BY p.texto_pregunta, p.tipo_pregunta, p.opciones
                HAVING formularios_count = ?";

        $params = array_merge($formularioIds, [count($formularioIds)]);
        $preguntasComunes = $this->getDb()->select($sql, $params);

        return $preguntasComunes;
    }

    /**
     * Obtener datos estadísticos para preguntas comunes
     */
    public function obtenerDatosEstadisticos($especieIds, $preguntaIds) {
        if (empty($especieIds) || empty($preguntaIds)) {
            return [];
        }

        $sql = "SELECT
                     r.pregunta_id,
                     r.valor_respuesta,
                     p.texto_pregunta,
                     p.tipo_pregunta,
                     p.opciones,
                     COUNT(*) as frecuencia
                 FROM respuestas r
                 INNER JOIN preguntas p ON r.pregunta_id = p.id
                 INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                 INNER JOIN formularios f ON rc.formulario_id = f.id
                 WHERE f.especie_id IN (" . str_repeat('?,', count($especieIds) - 1) . "?)
                 AND r.pregunta_id IN (" . str_repeat('?,', count($preguntaIds) - 1) . "?)
                 AND f.estado = 'aprobado'
                 GROUP BY r.pregunta_id, r.valor_respuesta, p.texto_pregunta, p.tipo_pregunta, p.opciones
                 ORDER BY r.pregunta_id, frecuencia DESC";

        $params = array_merge($especieIds, $preguntaIds);
        return $this->getDb()->select($sql, $params);
    }

    /**
     * Obtener todas las preguntas de una especie específica
     */
    public function obtenerPreguntasPorEspecie($especieId) {
        $sql = "SELECT DISTINCT
                     p.id,
                     p.texto_pregunta,
                     p.tipo_pregunta,
                     p.opciones
                 FROM preguntas p
                 INNER JOIN formularios f ON p.formulario_id = f.id
                 WHERE f.especie_id = ?
                 AND f.estado = 'aprobado'
                 ORDER BY p.orden ASC";

        return $this->getDb()->select($sql, [$especieId]);
    }

    /**
     * Obtener datos específicos de una especie
     */
    public function obtenerDatosPorEspecie($especieId) {
        $sql = "SELECT
                     r.pregunta_id,
                     r.valor_respuesta,
                     p.texto_pregunta,
                     p.tipo_pregunta,
                     p.opciones,
                     COUNT(*) as frecuencia
                 FROM respuestas r
                 INNER JOIN preguntas p ON r.pregunta_id = p.id
                 INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                 INNER JOIN formularios f ON rc.formulario_id = f.id
                 WHERE f.especie_id = ?
                 AND f.estado = 'aprobado'
                 GROUP BY r.pregunta_id, r.valor_respuesta, p.texto_pregunta, p.tipo_pregunta, p.opciones
                 ORDER BY r.pregunta_id, frecuencia DESC";

        return $this->getDb()->select($sql, [$especieId]);
    }

    /**
     * Obtener estadísticas por pregunta
     * Para preguntas comunes, busca respuestas equivalentes en todos los formularios aprobados
     */
    public function obtenerEstadisticasPorPregunta($preguntaId) {
        $pregunta = $this->obtenerPreguntaInfo($preguntaId);
        if (!$pregunta) {
            return false;
        }

        // Para preguntas comunes (usadas en Centro Estadístico), buscar respuestas equivalentes
        // en todos los formularios aprobados que contengan la misma pregunta
        $sql = "SELECT r.valor_respuesta
                FROM respuestas r
                INNER JOIN preguntas p ON r.pregunta_id = p.id
                INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                INNER JOIN formularios f ON rc.formulario_id = f.id
                WHERE p.texto_pregunta = ? AND p.tipo_pregunta = ?
                AND (p.opciones = ? OR (p.opciones IS NULL AND ? IS NULL))
                AND f.estado = 'aprobado'";

        $params = [
            $pregunta['texto_pregunta'],
            $pregunta['tipo_pregunta'],
            $pregunta['opciones'],
            $pregunta['opciones']
        ];

        $respuestas = $this->getDb()->select($sql, $params);

        if (empty($respuestas)) {
            return false;
        }

        // Procesar estadísticas según el tipo de pregunta
        switch ($pregunta['tipo_pregunta']) {
            case 'numero':
                return $this->procesarEstadisticasNumericas($respuestas);
            case 'booleano':
                return $this->procesarEstadisticasBooleanas($respuestas);
            case 'opcion_multiple':
                return $this->procesarEstadisticasOpciones($respuestas, $pregunta['opciones']);
            case 'texto':
                return $this->procesarEstadisticasTexto($respuestas);
            case 'fecha':
                return $this->procesarEstadisticasFecha($respuestas);
            default:
                return false;
        }
    }

    /**
     * Obtener información de pregunta
     */
    private function obtenerPreguntaInfo($preguntaId) {
        $sql = "SELECT tipo_pregunta, opciones, ambito_aplicacion, ambito_id, formulario_id, texto_pregunta FROM preguntas WHERE id = ?";
        return $this->getDb()->selectOne($sql, [$preguntaId]);
    }

    /**
     * Estadísticas para preguntas numéricas
     */
    private function obtenerEstadisticasNumericas($preguntaId) {
        $sql = "SELECT
                    COUNT(*) as total_respuestas,
                    AVG(CAST(valor_respuesta AS DECIMAL)) as promedio,
                    MIN(CAST(valor_respuesta AS DECIMAL)) as minimo,
                    MAX(CAST(valor_respuesta AS DECIMAL)) as maximo,
                    SUM(CAST(valor_respuesta AS DECIMAL)) as suma
                FROM respuestas
                WHERE pregunta_id = ? AND valor_respuesta REGEXP '^[0-9]+(\.[0-9]+)?$'";

        return $this->getDb()->selectOne($sql, [$preguntaId]);
    }

    /**
     * Estadísticas para preguntas booleanas
     */
    private function obtenerEstadisticasBooleanas($preguntaId) {
        $sql = "SELECT
                    COUNT(*) as total_respuestas,
                    SUM(CASE WHEN valor_respuesta IN ('1', 'true', 'Si', 'Sí') THEN 1 ELSE 0 END) as respuestas_positivas,
                    SUM(CASE WHEN valor_respuesta IN ('0', 'false', 'No') THEN 1 ELSE 0 END) as respuestas_negativas
                FROM respuestas
                WHERE pregunta_id = ?";

        $resultado = $this->getDb()->selectOne($sql, [$preguntaId]);

        if ($resultado && $resultado['total_respuestas'] > 0) {
            $resultado['porcentaje_positivo'] = ($resultado['respuestas_positivas'] / $resultado['total_respuestas']) * 100;
            $resultado['porcentaje_negativo'] = ($resultado['respuestas_negativas'] / $resultado['total_respuestas']) * 100;
        }

        return $resultado;
    }

    /**
     * Estadísticas para preguntas de opción múltiple
     */
    private function obtenerEstadisticasOpciones($preguntaId) {
        $pregunta = $this->obtenerPreguntaInfo($preguntaId);

        if (!$pregunta || !$pregunta['opciones']) {
            return false;
        }

        $opciones = array_map('trim', explode(',', $pregunta['opciones']));
        $estadisticas = [];

        foreach ($opciones as $opcion) {
            $sql = "SELECT COUNT(*) as conteo FROM respuestas WHERE pregunta_id = ? AND valor_respuesta = ?";
            $conteo = $this->getDb()->selectOne($sql, [$preguntaId, $opcion]);

            $estadisticas[] = [
                'opcion' => $opcion,
                'conteo' => $conteo['conteo']
            ];
        }

        return $estadisticas;
    }

    /**
     * Estadísticas para preguntas de texto
     */
    private function obtenerEstadisticasTexto($preguntaId) {
        $sql = "SELECT
                    COUNT(*) as total_respuestas,
                    COUNT(DISTINCT valor_respuesta) as respuestas_unicas
                FROM respuestas
                WHERE pregunta_id = ? AND valor_respuesta != ''";

        return $this->getDb()->selectOne($sql, [$preguntaId]);
    }

    /**
     * Estadísticas para preguntas de fecha
     */
    private function obtenerEstadisticasFecha($preguntaId) {
        $sql = "SELECT
                    COUNT(*) as total_respuestas,
                    MIN(valor_respuesta) as fecha_mas_antigua,
                    MAX(valor_respuesta) as fecha_mas_reciente
                FROM respuestas
                WHERE pregunta_id = ? AND valor_respuesta != ''";

        return $this->getDb()->selectOne($sql, [$preguntaId]);
    }

    /**
     * Actualizar respuesta
     */
    public function actualizar($id, $valor) {
        try {
            $sql = "UPDATE respuestas SET valor_respuesta = ? WHERE id = ?";
            return $this->getDb()->update($sql, [$valor, $id]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Eliminar respuesta
     */
    public function eliminar($id) {
        try {
            $sql = "DELETE FROM respuestas WHERE id = ?";
            return $this->getDb()->delete($sql, [$id]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Eliminar respuestas por registro de censo
     */
    public function eliminarPorRegistroCenso($registroCensoId) {
        try {
            $sql = "DELETE FROM respuestas WHERE registro_censo_id = ?";
            return $this->getDb()->delete($sql, [$registroCensoId]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Buscar respuestas por valor
     */
    public function buscarPorValor($valor, $preguntaId = null) {
        $sql = "SELECT
                    r.id,
                    r.valor_respuesta,
                    r.pregunta_id,
                    p.texto_pregunta,
                    rc.fecha_censo
                FROM respuestas r
                INNER JOIN preguntas p ON r.pregunta_id = p.id
                INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                WHERE r.valor_respuesta LIKE ?";

        $params = ["%$valor%"];

        if ($preguntaId) {
            $sql .= " AND r.pregunta_id = ?";
            $params[] = $preguntaId;
        }

        $sql .= " ORDER BY rc.fecha_censo DESC";

        return $this->getDb()->select($sql, $params);
    }

    /**
     * Obtener respuestas para exportación
     */
    public function obtenerParaExportacion($especieIds = null, $fechaInicio = null, $fechaFin = null) {
        $sql = "SELECT
                    r.valor_respuesta,
                    p.texto_pregunta,
                    p.tipo_pregunta,
                    e.nombre as especie_nombre,
                    f.nombre as formulario_nombre,
                    rc.fecha_censo,
                    u.nombre as admin_nombre,
                    rc.ubicacion_geo
                FROM respuestas r
                INNER JOIN preguntas p ON r.pregunta_id = p.id
                INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                INNER JOIN formularios f ON rc.formulario_id = f.id
                INNER JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON rc.usuario_admin_id = u.id";

        $where = [];
        $params = [];

        if ($especieIds) {
            $placeholders = str_repeat('?,', count($especieIds) - 1) . '?';
            $where[] = "e.id IN ($placeholders)";
            $params = array_merge($params, $especieIds);
        }

        if ($fechaInicio) {
            $where[] = "rc.fecha_censo >= ?";
            $params[] = $fechaInicio;
        }

        if ($fechaFin) {
            $where[] = "rc.fecha_censo <= ?";
            $params[] = $fechaFin;
        }

        if (!empty($where)) {
            $sql .= " WHERE " . implode(' AND ', $where);
        }

        $sql .= " ORDER BY e.nombre, rc.fecha_censo, p.orden";

        return $this->getDb()->select($sql, $params);
    }

    /**
     * Obtener conteo total de respuestas
     */
    public function contarTotal() {
        $sql = "SELECT COUNT(*) as total FROM respuestas";
        $resultado = $this->getDb()->selectOne($sql);
        return $resultado['total'];
    }

    /**
     * Obtener respuestas recientes
     */
    public function obtenerRecientes($limite = 20) {
        $sql = "SELECT
                    r.valor_respuesta,
                    p.texto_pregunta,
                    e.nombre as especie_nombre,
                    rc.fecha_censo,
                    u.nombre as admin_nombre
                FROM respuestas r
                INNER JOIN preguntas p ON r.pregunta_id = p.id
                INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                INNER JOIN formularios f ON rc.formulario_id = f.id
                INNER JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON rc.usuario_admin_id = u.id
                ORDER BY rc.fecha_censo DESC
                LIMIT ?";

        return $this->getDb()->select($sql, [$limite]);
    }

    /**
     * Validar respuesta según tipo de pregunta
     */
    public function validarRespuesta($pregunta, $valor) {
        // Si no hay valor y la pregunta no es obligatoria, es válido
        if (($valor === '' || $valor === null) && (!$pregunta['obligatoria'])) {
            return true;
        }

        switch ($pregunta['tipo_pregunta']) {
            case 'texto':
                return is_string($valor) && strlen(trim($valor)) > 0;

            case 'numero':
                return is_numeric($valor);

            case 'booleano':
                return in_array($valor, ['0', '1', 0, 1, 'true', 'false', 'Si', 'No', 'Sí']);

            case 'fecha':
                return strtotime($valor) !== false;

            case 'opcion_multiple':
                if (!$pregunta['opciones']) {
                    return false;
                }
                $opciones = array_map('trim', explode(',', $pregunta['opciones']));
                return in_array($valor, $opciones);

            default:
                return false;
        }
    }

    /**
     * Obtener distribución de respuestas por especie
     */
    public function obtenerDistribucionPorEspecie() {
        $sql = "SELECT
                    e.nombre as especie_nombre,
                    COUNT(r.id) as total_respuestas
                FROM especies e
                INNER JOIN formularios f ON e.id = f.especie_id
                INNER JOIN registros_censo rc ON f.id = rc.formulario_id
                INNER JOIN respuestas r ON rc.id = r.registro_censo_id
                GROUP BY e.id, e.nombre
                ORDER BY total_respuestas DESC";

        return $this->getDb()->select($sql);
    }

    /**
     * Obtener tendencias de respuestas por período
     */
    public function obtenerTendencias($preguntaId, $fechaInicio, $fechaFin, $intervalo = 'MONTH') {
        $sql = "SELECT
                    DATE_FORMAT(rc.fecha_censo, '%Y-%m') as periodo,
                    COUNT(r.id) as total_respuestas,
                    AVG(CASE WHEN r.valor_respuesta REGEXP '^[0-9]+(\.[0-9]+)?$' THEN CAST(r.valor_respuesta AS DECIMAL) END) as promedio_numerico
                FROM respuestas r
                INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                WHERE r.pregunta_id = ? AND rc.fecha_censo BETWEEN ? AND ?
                GROUP BY DATE_FORMAT(rc.fecha_censo, '%Y-%m')
                ORDER BY periodo";

        return $this->getDb()->select($sql, [$preguntaId, $fechaInicio, $fechaFin]);
    }

    /**
     * Obtener estadísticas agregadas para niveles superiores (reino/módulo)
     * Agrega datos de todas las especies hijas
     */
    public function obtenerEstadisticasAgregadas($nivelId, $tipoNivel) {
        // Obtener preguntas base del nivel especificado
        $sql = "SELECT id, texto_pregunta, tipo_pregunta, opciones
                FROM preguntas
                WHERE ambito_aplicacion = ? AND ambito_id = ? AND formulario_id IS NULL
                ORDER BY orden ASC";

        $preguntasBase = $this->getDb()->select($sql, [$tipoNivel, $nivelId]);

        if (empty($preguntasBase)) {
            return [];
        }

        // Obtener todas las especies hijas del nivel
        $especieModel = new Especie();
        $especiesHijas = [];

        if ($tipoNivel === 'reino') {
            // Obtener todos los módulos del reino
            $modulos = $especieModel->obtenerModulos($nivelId);
            foreach ($modulos as $modulo) {
                $especies = $especieModel->obtenerEspecies($modulo['id']);
                $especiesHijas = array_merge($especiesHijas, $especies);
            }
        } elseif ($tipoNivel === 'modulo') {
            // Obtener todas las especies del módulo
            $especiesHijas = $especieModel->obtenerEspecies($nivelId);
        }

        if (empty($especiesHijas)) {
            return [];
        }

        $especieIds = array_column($especiesHijas, 'id');

        // Obtener estadísticas para cada pregunta base
        $estadisticas = [];
        foreach ($preguntasBase as $pregunta) {
            $estadistica = $this->obtenerEstadisticasPorPreguntaAgregada($pregunta['id'], $especieIds);
            if ($estadistica) {
                $estadisticas[$pregunta['id']] = [
                    'pregunta' => $pregunta,
                    'datos' => $estadistica
                ];
            }
        }

        return $estadisticas;
    }

    /**
     * Obtener estadísticas para una pregunta específica agregando datos de múltiples especies
     * Funciona tanto para preguntas de formularios específicos como para preguntas base
     */
    public function obtenerEstadisticasPorPreguntaAgregada($preguntaId, $especieIds) {
        if (empty($especieIds)) {
            error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: No hay especies especificadas");
            return false;
        }

        $pregunta = $this->obtenerPreguntaInfo($preguntaId);
        if (!$pregunta) {
            error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Pregunta {$preguntaId} no encontrada");
            return false;
        }

        error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Procesando pregunta {$preguntaId} - {$pregunta['texto_pregunta']} (formulario_id: " . ($pregunta['formulario_id'] ?? 'NULL') . ")");

        // Para preguntas base (formulario_id IS NULL), buscar respuestas de preguntas que coincidan
        // en texto, tipo y opciones en formularios de las especies especificadas
        if ($pregunta['formulario_id'] === null) {
            error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Es pregunta base, buscando equivalentes");

            // Es una pregunta base, buscar respuestas de preguntas equivalentes en formularios
            $placeholders = str_repeat('?,', count($especieIds) - 1) . '?';
            $sql = "SELECT r.valor_respuesta
                    FROM respuestas r
                    INNER JOIN preguntas p ON r.pregunta_id = p.id
                    INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                    INNER JOIN formularios f ON rc.formulario_id = f.id
                    WHERE p.texto_pregunta = ? AND p.tipo_pregunta = ?
                    AND (p.opciones = ? OR (p.opciones IS NULL AND ? IS NULL))
                    AND f.especie_id IN ($placeholders)
                    AND f.estado = 'aprobado'";

            $params = array_merge([
                $pregunta['texto_pregunta'],
                $pregunta['tipo_pregunta'],
                $pregunta['opciones'],
                $pregunta['opciones']
            ], $especieIds);

            error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: SQL para pregunta base: " . $sql);
            error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Params: " . json_encode($params));
        } else {
            error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Es pregunta de formulario específico");

            // Es una pregunta de formulario específico
            $placeholders = str_repeat('?,', count($especieIds) - 1) . '?';
            $sql = "SELECT r.valor_respuesta
                    FROM respuestas r
                    INNER JOIN registros_censo rc ON r.registro_censo_id = rc.id
                    INNER JOIN formularios f ON rc.formulario_id = f.id
                    WHERE r.pregunta_id = ? AND f.especie_id IN ($placeholders)";

            $params = array_merge([$preguntaId], $especieIds);

            error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: SQL para pregunta específica: " . $sql);
            error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Params: " . json_encode($params));
        }

        $respuestas = $this->getDb()->select($sql, $params);
        error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Respuestas encontradas: " . count($respuestas));

        if (empty($respuestas)) {
            error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: No hay respuestas para esta pregunta");
            return false;
        }

        // Procesar estadísticas según el tipo de pregunta
        switch ($pregunta['tipo_pregunta']) {
            case 'numero':
                $result = $this->procesarEstadisticasNumericas($respuestas);
                error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Estadísticas numéricas: " . json_encode($result));
                return $result;
            case 'booleano':
                $result = $this->procesarEstadisticasBooleanas($respuestas);
                error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Estadísticas booleanas: " . json_encode($result));
                return $result;
            case 'opcion_multiple':
                $result = $this->procesarEstadisticasOpciones($respuestas, $pregunta['opciones']);
                error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Estadísticas opciones: " . json_encode($result));
                return $result;
            case 'texto':
                $result = $this->procesarEstadisticasTexto($respuestas);
                error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Estadísticas texto: " . json_encode($result));
                return $result;
            case 'fecha':
                $result = $this->procesarEstadisticasFecha($respuestas);
                error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Estadísticas fecha: " . json_encode($result));
                return $result;
            default:
                error_log("DEBUG obtenerEstadisticasPorPreguntaAgregada: Tipo de pregunta no soportado: {$pregunta['tipo_pregunta']}");
                return false;
        }
    }

    /**
     * Procesar estadísticas numéricas desde array de respuestas
     */
    private function procesarEstadisticasNumericas($respuestas) {
        $valores = [];
        foreach ($respuestas as $respuesta) {
            $valor = trim($respuesta['valor_respuesta']);
            if (is_numeric($valor)) {
                $valores[] = (float)$valor;
            }
        }

        if (empty($valores)) {
            return false;
        }

        return [
            'total_respuestas' => count($valores),
            'promedio' => array_sum($valores) / count($valores),
            'minimo' => min($valores),
            'maximo' => max($valores),
            'suma' => array_sum($valores)
        ];
    }

    /**
     * Procesar estadísticas booleanas desde array de respuestas
     */
    private function procesarEstadisticasBooleanas($respuestas) {
        $positivas = 0;
        $negativas = 0;

        foreach ($respuestas as $respuesta) {
            $valor = trim(strtolower($respuesta['valor_respuesta']));
            if (in_array($valor, ['1', 'true', 'si', 'sí'])) {
                $positivas++;
            } elseif (in_array($valor, ['0', 'false', 'no'])) {
                $negativas++;
            }
        }

        $total = $positivas + $negativas;

        if ($total === 0) {
            return false;
        }

        return [
            'total_respuestas' => $total,
            'respuestas_positivas' => $positivas,
            'respuestas_negativas' => $negativas,
            'porcentaje_positivo' => ($positivas / $total) * 100,
            'porcentaje_negativo' => ($negativas / $total) * 100
        ];
    }

    /**
     * Procesar estadísticas de opciones múltiples desde array de respuestas
     */
    private function procesarEstadisticasOpciones($respuestas, $opcionesString) {
        if (!$opcionesString) {
            return false;
        }

        $opciones = array_map('trim', explode(',', $opcionesString));
        $conteos = array_fill_keys($opciones, 0);

        foreach ($respuestas as $respuesta) {
            $valor = trim($respuesta['valor_respuesta']);
            if (isset($conteos[$valor])) {
                $conteos[$valor]++;
            }
        }

        $estadisticas = [];
        foreach ($conteos as $opcion => $conteo) {
            $estadisticas[] = [
                'opcion' => $opcion,
                'conteo' => $conteo
            ];
        }

        return $estadisticas;
    }

    /**
     * Procesar estadísticas de texto desde array de respuestas
     */
    private function procesarEstadisticasTexto($respuestas) {
        $valores = [];
        foreach ($respuestas as $respuesta) {
            $valor = trim($respuesta['valor_respuesta']);
            if (!empty($valor)) {
                $valores[] = $valor;
            }
        }

        if (empty($valores)) {
            return false;
        }

        return [
            'total_respuestas' => count($valores),
            'respuestas_unicas' => count(array_unique($valores))
        ];
    }

    /**
     * Procesar estadísticas de fecha desde array de respuestas
     */
    private function procesarEstadisticasFecha($respuestas) {
        $fechas = [];
        foreach ($respuestas as $respuesta) {
            $fecha = trim($respuesta['valor_respuesta']);
            if (!empty($fecha) && strtotime($fecha)) {
                $fechas[] = $fecha;
            }
        }

        if (empty($fechas)) {
            return false;
        }

        return [
            'total_respuestas' => count($fechas),
            'fecha_mas_antigua' => min($fechas),
            'fecha_mas_reciente' => max($fechas)
        ];
    }
}