<?php
/**
 * Sistema Estadístico Pro - Modelo Especie
 * Maneja la jerarquía taxonómica (Reino -> Módulo -> Especie)
 */

class Especie {
    private $db;

    public function __construct() {
        // Inicializar conexión a base de datos de forma lazy
        $this->db = null;
    }

    /**
     * Obtener instancia de conexión a base de datos
     */
    private function getDb() {
        if ($this->db === null) {
            $this->db = Database::getInstance();
        }
        return $this->db;
    }

    /**
     * Crear una nueva especie
     */
    public function crear($datos) {
        try {
            $sql = "INSERT INTO especies (nombre, parent_id, tipo, descripcion) VALUES (?, ?, ?, ?)";
            $params = [
                $datos['nombre'],
                $datos['parent_id'] ?? null,
                $datos['tipo'],
                $datos['descripcion'] ?? null
            ];

            return $this->getDb()->insert($sql, $params);
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Obtener especie por ID
     */
    public function obtenerPorId($id) {
        $sql = "SELECT id, nombre, parent_id, tipo, descripcion FROM especies WHERE id = ? LIMIT 1";
        return $this->getDb()->selectOne($sql, [$id]);
    }

    /**
     * Obtener todas las especies con su jerarquía
     */
    public function obtenerTodas() {
        $sql = "SELECT
                    e.id,
                    e.nombre,
                    e.parent_id,
                    e.tipo,
                    e.descripcion,
                    p.nombre as nombre_padre
                FROM especies e
                LEFT JOIN especies p ON e.parent_id = p.id
                ORDER BY
                    CASE
                        WHEN e.tipo = 'reino' THEN 1
                        WHEN e.tipo = 'modulo' THEN 2
                        WHEN e.tipo = 'especie' THEN 3
                    END,
                    e.nombre";

        return $this->getDb()->select($sql);
    }

    /**
     * Obtener reinos (nivel superior)
     */
    public function obtenerReinos() {
        $sql = "SELECT id, nombre, descripcion FROM especies WHERE tipo = 'reino' ORDER BY nombre";
        return $this->getDb()->select($sql);
    }

    /**
     * Obtener módulos de un reino
     */
    public function obtenerModulos($reinoId) {
        $sql = "SELECT id, nombre, descripcion FROM especies WHERE tipo = 'modulo' AND parent_id = ? ORDER BY nombre";
        return $this->getDb()->select($sql, [$reinoId]);
    }

    /**
     * Obtener especies de un módulo
     */
    public function obtenerEspecies($moduloId) {
        $sql = "SELECT id, nombre, descripcion FROM especies WHERE tipo = 'especie' AND parent_id = ? ORDER BY nombre";
        return $this->getDb()->select($sql, [$moduloId]);
    }

    /**
     * Obtener hijos de una especie (módulos o especies)
     */
    public function obtenerHijos($parentId) {
        $sql = "SELECT id, nombre, tipo, descripcion FROM especies WHERE parent_id = ? ORDER BY tipo, nombre";
        return $this->getDb()->select($sql, [$parentId]);
    }

    /**
     * Obtener jerarquía completa desde una especie hacia arriba
     */
    public function obtenerJerarquia($especieId) {
        $jerarquia = [];
        $currentId = $especieId;

        while ($currentId) {
            $especie = $this->obtenerPorId($currentId);
            if (!$especie) break;

            array_unshift($jerarquia, $especie);
            $currentId = $especie['parent_id'];
        }

        return $jerarquia;
    }

    /**
     * Obtener jerarquía completa desde una especie hacia arriba (para API)
     */
    public function obtenerJerarquiaApi($especieId) {
        $jerarquia = $this->obtenerJerarquia($especieId);
        return $jerarquia;
    }

    /**
     * Obtener especies hoja (sin hijos)
     */
    public function obtenerEspeciesHoja() {
        $sql = "SELECT e.id, e.nombre, e.descripcion
                FROM especies e
                WHERE e.tipo = 'especie'
                AND NOT EXISTS (
                    SELECT 1 FROM especies h WHERE h.parent_id = e.id
                )
                ORDER BY e.nombre";

        return $this->getDb()->select($sql);
    }

    /**
     * Actualizar especie
     */
    public function actualizar($id, $datos) {
        try {
            $campos = [];
            $params = [];

            if (isset($datos['nombre'])) {
                $campos[] = "nombre = ?";
                $params[] = $datos['nombre'];
            }

            if (isset($datos['parent_id'])) {
                $campos[] = "parent_id = ?";
                $params[] = $datos['parent_id'];
            }

            if (isset($datos['tipo'])) {
                $campos[] = "tipo = ?";
                $params[] = $datos['tipo'];
            }

            if (isset($datos['descripcion'])) {
                $campos[] = "descripcion = ?";
                $params[] = $datos['descripcion'];
            }

            if (empty($campos)) {
                return false;
            }

            $params[] = $id;
            $sql = "UPDATE especies SET " . implode(', ', $campos) . " WHERE id = ?";

            return $this->getDb()->update($sql, $params) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Eliminar especie
     */
    public function eliminar($id) {
        try {
            // Verificar si tiene hijos
            $hijos = $this->obtenerHijos($id);
            if (!empty($hijos)) {
                return false; // No se puede eliminar si tiene hijos
            }

            $sql = "DELETE FROM especies WHERE id = ?";
            return $this->getDb()->delete($sql, [$id]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Buscar especies
     */
    public function buscar($termino, $tipo = null) {
        $sql = "SELECT id, nombre, tipo, descripcion FROM especies WHERE nombre LIKE ?";
        $params = ["%$termino%"];

        if ($tipo) {
            $sql .= " AND tipo = ?";
            $params[] = $tipo;
        }

        $sql .= " ORDER BY nombre";

        return $this->getDb()->select($sql, $params);
    }

    /**
     * Obtener estadísticas de especies
     */
    public function obtenerEstadisticas() {
        $sql = "SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN tipo = 'reino' THEN 1 ELSE 0 END) as reinos,
                    SUM(CASE WHEN tipo = 'modulo' THEN 1 ELSE 0 END) as modulos,
                    SUM(CASE WHEN tipo = 'especie' THEN 1 ELSE 0 END) as especies
                FROM especies";

        return $this->getDb()->selectOne($sql);
    }

    /**
     * Validar datos de especie
     */
    public function validarDatos($datos, $esActualizacion = false) {
        $errores = [];

        // Validar nombre
        if (empty($datos['nombre'])) {
            $errores['nombre'] = 'El nombre es requerido';
        } elseif (strlen($datos['nombre']) < 2) {
            $errores['nombre'] = 'El nombre debe tener al menos 2 caracteres';
        }

        // Validar tipo
        if (empty($datos['tipo'])) {
            $errores['tipo'] = 'El tipo es requerido';
        } elseif (!array_key_exists($datos['tipo'], SPECIES_TYPES)) {
            $errores['tipo'] = 'El tipo seleccionado no es válido';
        }

        // Validar jerarquía lógica
        if (isset($datos['parent_id']) && $datos['parent_id']) {
            $padre = $this->obtenerPorId($datos['parent_id']);
            if (!$padre) {
                $errores['parent_id'] = 'El padre seleccionado no existe';
            } else {
                // Validar que no se cree una referencia circular
                if ($esActualizacion && isset($datos['id']) && $datos['parent_id'] == $datos['id']) {
                    $errores['parent_id'] = 'Una especie no puede ser padre de sí misma';
                }

                // Validar jerarquía lógica según tipo
                if ($datos['tipo'] === 'reino' && $datos['parent_id']) {
                    $errores['tipo'] = 'Un reino no puede tener padre';
                }

                if ($datos['tipo'] === 'modulo' && $padre['tipo'] !== 'reino') {
                    $errores['parent_id'] = 'Un módulo debe tener un reino como padre';
                }

                if ($datos['tipo'] === 'especie' && $padre['tipo'] !== 'modulo') {
                    $errores['parent_id'] = 'Una especie debe tener un módulo como padre';
                }
            }
        }

        return $errores;
    }

    /**
     * Obtener especies disponibles para formularios
     */
    public function obtenerParaFormularios() {
        $sql = "SELECT e.id, e.nombre, m.nombre as modulo, r.nombre as reino
                FROM especies e
                INNER JOIN especies m ON e.parent_id = m.id
                INNER JOIN especies r ON m.parent_id = r.id
                WHERE e.tipo = 'especie'
                ORDER BY r.nombre, m.nombre, e.nombre";

        return $this->getDb()->select($sql);
    }

    /**
     * Obtener árbol jerárquico completo
     */
    public function obtenerArbol() {
        $reinos = $this->obtenerReinos();

        $arbol = [];

        foreach ($reinos as $reino) {
            $reinoData = [
                'id' => $reino['id'],
                'nombre' => $reino['nombre'],
                'tipo' => $reino['tipo'] ?? 'reino',
                'descripcion' => $reino['descripcion'],
                'hijos' => $this->construirRama($reino['id'])
            ];

            $arbol[] = $reinoData;
        }

        return $arbol;
    }

    /**
     * Construir rama del árbol jerárquico
     */
    private function construirRama($parentId) {
        $hijos = $this->obtenerHijos($parentId);
        $rama = [];

        foreach ($hijos as $hijo) {
            $hijoData = [
                'id' => $hijo['id'],
                'nombre' => $hijo['nombre'],
                'tipo' => $hijo['tipo'] ?? 'especie',
                'descripcion' => $hijo['descripcion']
            ];

            // Si es módulo o reino, agregar sus hijos
            if (($hijo['tipo'] ?? 'especie') !== 'especie') {
                $hijoData['hijos'] = $this->construirRama($hijo['id']);
            }

            $rama[] = $hijoData;
        }

        return $rama;
    }

    /**
     * Verificar si una especie tiene formularios asociados
     */
    public function tieneFormularios($especieId) {
        $sql = "SELECT COUNT(*) as count FROM formularios WHERE especie_id = ?";
        $resultado = $this->getDb()->selectOne($sql, [$especieId]);
        return $resultado['count'] > 0;
    }

    /**
     * Obtener especies con formularios aprobados
     */
    public function obtenerConFormulariosAprobados() {
        $sql = "SELECT DISTINCT e.id, e.nombre, e.tipo, e.descripcion
                FROM especies e
                INNER JOIN formularios f ON e.id = f.especie_id
                WHERE f.estado = 'aprobado'
                ORDER BY e.nombre";

        return $this->getDb()->select($sql);
    }
}