<?php
/**
 * Sistema Estadístico Pro - Modelo Formulario
 * Maneja la gestión de formularios dinámicos
 */

class Formulario {
    private $db;

    public function __construct() {
        // Inicializar conexión a base de datos de forma lazy
        $this->db = null;
    }

    /**
     * Obtener instancia de conexión a base de datos
     */
    private function getDb() {
        if ($this->db === null) {
            $this->db = Database::getInstance();
        }
        return $this->db;
    }

    /**
     * Crear un nuevo formulario
     */
    public function crear($datos) {
        try {
            $this->getDb()->beginTransaction();

            // Si no hay especie_id, crear un formulario genérico
            $sql = "INSERT INTO formularios (especie_id, nombre, descripcion, estado, creador_id) VALUES (?, ?, ?, ?, ?)";
            $params = [
                $datos['especie_id'] ?? null,
                $datos['nombre'],
                $datos['descripcion'] ?? null,
                $datos['estado'] ?? 'borrador',
                $datos['creador_id']
            ];

            $formularioId = $this->getDb()->insert($sql, $params);

            if (!$formularioId) {
                throw new Exception('Error al crear formulario');
            }

            $this->getDb()->commit();
            return $formularioId;
        } catch (Exception $e) {
            $this->getDb()->rollback();
            return false;
        }
    }

    /**
     * Obtener formulario por ID con detalles completos
     */
    public function obtenerPorId($id) {
        $sql = "SELECT
                    f.id,
                    f.especie_id,
                    f.nombre,
                    f.descripcion,
                    f.estado,
                    f.creador_id,
                    f.fecha_creacion,
                    f.fecha_aprobacion,
                    f.aprobador_id,
                    e.nombre as especie_nombre,
                    e.tipo as especie_tipo,
                    u.nombre as creador_nombre,
                    a.nombre as aprobador_nombre
                FROM formularios f
                LEFT JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON f.creador_id = u.id
                LEFT JOIN usuarios a ON f.aprobador_id = a.id
                WHERE f.id = ?
                LIMIT 1";

        return $this->getDb()->selectOne($sql, [$id]);
    }

    /**
     * Obtener formularios con paginación
     */
    public function listar($pagina = 1, $limite = ITEMS_PER_PAGE, $filtros = []) {
        $offset = ($pagina - 1) * $limite;

        $where = [];
        $params = [];

        if (!empty($filtros['especie_id'])) {
            $where[] = "f.especie_id = ?";
            $params[] = $filtros['especie_id'];
        }

        if (!empty($filtros['estado'])) {
            $where[] = "f.estado = ?";
            $params[] = $filtros['estado'];
        }

        if (!empty($filtros['creador_id'])) {
            $where[] = "f.creador_id = ?";
            $params[] = $filtros['creador_id'];
        }


        $whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);

        $sql = "SELECT
                    f.id,
                    f.nombre,
                    f.descripcion,
                    f.estado,
                    f.fecha_creacion,
                    f.fecha_aprobacion,
                    e.nombre as especie_nombre,
                    e.tipo as especie_tipo,
                    u.nombre as creador_nombre
                FROM formularios f
                LEFT JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON f.creador_id = u.id
                $whereClause
                ORDER BY f.fecha_creacion DESC
                LIMIT ? OFFSET ?";

        $params[] = $limite;
        $params[] = $offset;

        $formularios = $this->getDb()->select($sql, $params);

        // Obtener total para paginación
        $sqlTotal = "SELECT COUNT(*) as total FROM formularios f $whereClause";
        $total = $this->getDb()->selectOne($sqlTotal, array_slice($params, 0, -2));

        return [
            'formularios' => $formularios,
            'total' => $total['total'],
            'pagina' => $pagina,
            'limite' => $limite,
            'total_paginas' => ceil($total['total'] / $limite)
        ];
    }

    /**
     * Obtener formulario aprobado para una especie (el más reciente)
     */
    public function obtenerAprobadoPorEspecie($especieId) {
        $sql = "SELECT
                    f.id,
                    f.nombre,
                    f.descripcion,
                    f.fecha_creacion,
                    f.fecha_aprobacion,
                    u.nombre as creador_nombre,
                    a.nombre as aprobador_nombre
                FROM formularios f
                INNER JOIN usuarios u ON f.creador_id = u.id
                LEFT JOIN usuarios a ON f.aprobador_id = a.id
                WHERE f.especie_id = ? AND f.estado = 'aprobado'
                ORDER BY f.fecha_aprobacion DESC
                LIMIT 1";

        return $this->getDb()->selectOne($sql, [$especieId]);
    }

    /**
     * Obtener formularios aprobados para una especie
     */
    public function obtenerAprobadosPorEspecie($especieId) {
        $sql = "SELECT
                    f.id,
                    f.nombre,
                    f.descripcion,
                    f.fecha_creacion,
                    u.nombre as creador_nombre
                FROM formularios f
                INNER JOIN usuarios u ON f.creador_id = u.id
                WHERE f.especie_id = ? AND f.estado = 'aprobado'
                ORDER BY f.fecha_creacion DESC";

        return $this->getDb()->select($sql, [$especieId]);
    }


    /**
     * Obtener preguntas heredadas de niveles superiores
     */
    public function obtenerPreguntasHeredadas($especieId) {
        // Obtener jerarquía de la especie
        $especieModel = new Especie();
        $jerarquia = $especieModel->obtenerJerarquia($especieId);

        $preguntasHeredadas = [];

        // Recorrer jerarquía de abajo hacia arriba (especie -> módulo -> reino)
        foreach ($jerarquia as $nivel) {
            $formulariosNivel = $this->obtenerAprobadosPorEspecie($nivel['id']);

            foreach ($formulariosNivel as $formulario) {
                if ($formulario['estado'] === 'aprobado') {
                    $preguntas = $this->obtenerPreguntasPorFormulario($formulario['id']);
                    foreach ($preguntas as $pregunta) {
                        $preguntasHeredadas[] = [
                            'id' => $pregunta['id'],
                            'texto_pregunta' => $pregunta['texto_pregunta'],
                            'tipo_pregunta' => $pregunta['tipo_pregunta'],
                            'opciones' => $pregunta['opciones'],
                            'orden' => $pregunta['orden'],
                            'obligatoria' => $pregunta['obligatoria'],
                            'nivel_origen' => $nivel['tipo'],
                            'especie_origen' => $nivel['nombre'],
                            'heredada' => true
                        ];
                    }
                }
            }
        }

        return $preguntasHeredadas;
    }

    /**
     * Obtener preguntas de un formulario específico
     */
    private function obtenerPreguntasPorFormulario($formularioId) {
        $sql = "SELECT
                    id,
                    texto_pregunta,
                    tipo_pregunta,
                    opciones,
                    orden,
                    obligatoria,
                    depende_de,
                    respuesta_requerida
                FROM preguntas
                WHERE formulario_id = ?
                ORDER BY orden ASC";

        return $this->getDb()->select($sql, [$formularioId]);
    }

    /**
     * Obtener formularios pendientes de aprobación
     */
    public function obtenerPendientes() {
        $sql = "SELECT
                    f.id,
                    f.nombre,
                    f.descripcion,
                    f.fecha_creacion,
                    e.nombre as especie_nombre,
                    u.nombre as creador_nombre
                FROM formularios f
                LEFT JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON f.creador_id = u.id
                WHERE f.estado = 'pendiente'
                ORDER BY f.fecha_creacion ASC";

        return $this->getDb()->select($sql);
    }

    /**
     * Aprobar formulario
     */
    public function aprobar($id, $aprobadorId) {
        try {
            $sql = "UPDATE formularios SET estado = 'aprobado', fecha_aprobacion = NOW(), aprobador_id = ? WHERE id = ? AND estado = 'pendiente'";
            return $this->getDb()->update($sql, [$aprobadorId, $id]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Rechazar formulario
     */
    public function rechazar($id) {
        try {
            $sql = "UPDATE formularios SET estado = 'borrador', fecha_aprobacion = NULL, aprobador_id = NULL WHERE id = ? AND estado = 'pendiente'";
            return $this->getDb()->update($sql, [$id]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Archivar formulario
     */
    public function archivar($id) {
        try {
            $sql = "UPDATE formularios SET estado = 'archivado' WHERE id = ?";
            return $this->getDb()->update($sql, [$id]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Actualizar formulario
     */
    public function actualizar($id, $datos) {
        try {
            // Asegurar que el ID sea un integer
            $id = (int)$id;

            $campos = [];
            $params = [];

            if (isset($datos['nombre'])) {
                $campos[] = "nombre = ?";
                $params[] = $datos['nombre'];
            }

            if (isset($datos['descripcion'])) {
                $campos[] = "descripcion = ?";
                $params[] = $datos['descripcion'];
            }

            if (isset($datos['estado'])) {
                $campos[] = "estado = ?";
                $params[] = $datos['estado'];

                // Si se aprueba, establecer fecha y aprobador
                if ($datos['estado'] === 'aprobado' && isset($datos['aprobador_id'])) {
                    $campos[] = "fecha_aprobacion = NOW()";
                    $campos[] = "aprobador_id = ?";
                    $params[] = $datos['aprobador_id'];
                }
            }

            if (empty($campos)) {
                return false;
            }

            $params[] = $id;
            $sql = "UPDATE formularios SET " . implode(', ', $campos) . " WHERE id = ?";

            $resultado = $this->getDb()->update($sql, $params);
            return $resultado > 0;
        } catch (Exception $e) {
            error_log("Error en actualizar formulario {$id}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Eliminar formulario
     */
    public function eliminar($id) {
        try {
            $sql = "DELETE FROM formularios WHERE id = ?";
            return $this->getDb()->delete($sql, [$id]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Buscar formularios
     */
    public function buscar($termino, $pagina = 1, $limite = ITEMS_PER_PAGE) {
        $offset = ($pagina - 1) * $limite;
        $termino = "%$termino%";

        $sql = "SELECT
                    f.id,
                    f.nombre,
                    f.descripcion,
                    f.estado,
                    f.fecha_creacion,
                    e.nombre as especie_nombre,
                    u.nombre as creador_nombre
                FROM formularios f
                LEFT JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON f.creador_id = u.id
                WHERE f.nombre LIKE ? OR f.descripcion LIKE ? OR e.nombre LIKE ?
                ORDER BY f.fecha_creacion DESC
                LIMIT ? OFFSET ?";

        $formularios = $this->getDb()->select($sql, [$termino, $termino, $termino, $limite, $offset]);

        // Obtener total para paginación
        $sqlTotal = "SELECT COUNT(*) as total
                     FROM formularios f
                     LEFT JOIN especies e ON f.especie_id = e.id
                     WHERE f.nombre LIKE ? OR f.descripcion LIKE ? OR e.nombre LIKE ?";

        $total = $this->getDb()->selectOne($sqlTotal, [$termino, $termino, $termino]);

        return [
            'formularios' => $formularios,
            'total' => $total['total'],
            'pagina' => $pagina,
            'limite' => $limite,
            'total_paginas' => ceil($total['total'] / $limite)
        ];
    }

    /**
     * Obtener estadísticas de formularios
     */
    public function obtenerEstadisticas() {
        $sql = "SELECT
                    COUNT(*) as total_formularios,
                    SUM(CASE WHEN estado = 'borrador' THEN 1 ELSE 0 END) as borradores,
                    SUM(CASE WHEN estado = 'pendiente' THEN 1 ELSE 0 END) as formularios_pendientes,
                    SUM(CASE WHEN estado = 'aprobado' THEN 1 ELSE 0 END) as formularios_aprobados,
                    SUM(CASE WHEN estado = 'archivado' THEN 1 ELSE 0 END) as archivados
                FROM formularios";

        $stats = $this->getDb()->selectOne($sql);

        // Agregar estadísticas de censos
        $sqlCensos = "SELECT COUNT(*) as censos_realizados FROM registros_censo";
        $censos = $this->getDb()->selectOne($sqlCensos);

        return array_merge($stats, $censos);
    }

    /**
     * Validar datos de formulario
     */
    public function validarDatos($datos, $esActualizacion = false) {
        $errores = [];

        // Validar nombre
        if (empty($datos['nombre'])) {
            $errores['nombre'] = 'El nombre es requerido';
        } elseif (strlen($datos['nombre']) < 3) {
            $errores['nombre'] = 'El nombre debe tener al menos 3 caracteres';
        }

        // Validar especie (ahora opcional)
        if (!empty($datos['especie_id'])) {
            // Verificar que la especie existe si se proporcionó
            $especieModel = new Especie();
            $especie = $especieModel->obtenerPorId($datos['especie_id']);
            if (!$especie) {
                $errores['especie_id'] = 'La especie seleccionada no existe';
            }
        }

        // Validar estado
        if (isset($datos['estado']) && !array_key_exists($datos['estado'], FORM_STATES)) {
            $errores['estado'] = 'El estado seleccionado no es válido';
        }

        return $errores;
    }

    /**
     * Obtener formularios por creador
     */
    public function obtenerPorCreador($creadorId, $estado = null) {
        $sql = "SELECT
                    f.id,
                    f.nombre,
                    f.descripcion,
                    f.estado,
                    f.fecha_creacion,
                    e.nombre as especie_nombre
                FROM formularios f
                LEFT JOIN especies e ON f.especie_id = e.id
                WHERE f.creador_id = ?";

        $params = [$creadorId];

        if ($estado) {
            $sql .= " AND f.estado = ?";
            $params[] = $estado;
        }

        $sql .= " ORDER BY f.fecha_creacion DESC";

        return $this->getDb()->select($sql, $params);
    }

    /**
     * Verificar si especie ya tiene formulario con mismo nombre
     */
    public function nombreExiste($nombre, $especieId, $excluirId = null) {
        $sql = "SELECT COUNT(*) as count FROM formularios WHERE nombre = ? AND especie_id = ?";
        $params = [$nombre, $especieId];

        if ($excluirId) {
            $sql .= " AND id != ?";
            $params[] = $excluirId;
        }

        $resultado = $this->getDb()->selectOne($sql, $params);
        return $resultado['count'] > 0;
    }

    /**
     * Obtener formularios recientes
     */
    public function obtenerRecientes($limite = 10) {
        $sql = "SELECT
                    f.id,
                    f.nombre,
                    f.fecha_creacion,
                    e.nombre as especie_nombre,
                    u.nombre as creador_nombre
                FROM formularios f
                LEFT JOIN especies e ON f.especie_id = e.id
                INNER JOIN usuarios u ON f.creador_id = u.id
                ORDER BY f.fecha_creacion DESC
                LIMIT ?";

        return $this->getDb()->select($sql, [$limite]);
    }
}