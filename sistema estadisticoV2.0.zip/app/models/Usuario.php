<?php
/**
 * Sistema Estadístico Pro - Modelo Usuario
 * Maneja la gestión de usuarios y autenticación
 */

class Usuario {
    private $db;

    public function __construct() {
        // Inicializar conexión a base de datos de forma lazy
        $this->db = null;
    }

    /**
     * Obtener instancia de conexión a base de datos
     */
    private function getDb() {
        if ($this->db === null) {
            $this->db = Database::getInstance();
        }
        return $this->db;
    }

    /**
     * Crear un nuevo usuario
     */
    public function crear($datos) {
        try {
            $sql = "INSERT INTO usuarios (nombre, email, password_hash, rol, activo) VALUES (?, ?, ?, ?, ?)";
            $params = [
                $datos['nombre'],
                $datos['email'],
                $datos['password_hash'],
                $datos['rol'] ?? 'registrado', // Por defecto 'registrado' para registros públicos
                $datos['activo'] ?? true
            ];

            return $this->getDb()->insert($sql, $params);
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Obtener usuario por ID
     */
    public function obtenerPorId($id) {
        $sql = "SELECT id, nombre, email, rol, fecha_creacion, activo FROM usuarios WHERE id = ? LIMIT 1";
        return $this->getDb()->selectOne($sql, [$id]);
    }

    /**
     * Obtener usuario por email
     */
    public function obtenerPorEmail($email) {
        $sql = "SELECT id, nombre, email, password_hash, rol, fecha_creacion, activo FROM usuarios WHERE email = ? LIMIT 1";
        return $this->getDb()->selectOne($sql, [$email]);
    }

    /**
     * Verificar credenciales de usuario
     */
    public function verificarCredenciales($email, $password) {
        $usuario = $this->obtenerPorEmail($email);

        if (!$usuario || !$usuario['activo']) {
            return false;
        }

        return password_verify($password, $usuario['password_hash']) ? $usuario : false;
    }

    /**
     * Listar todos los usuarios con paginación
     */
    public function listar($pagina = 1, $limite = ITEMS_PER_PAGE) {
        $offset = ($pagina - 1) * $limite;

        $sql = "SELECT id, nombre, email, rol, fecha_creacion, activo FROM usuarios ORDER BY fecha_creacion DESC LIMIT ? OFFSET ?";
        $usuarios = $this->getDb()->select($sql, [$limite, $offset]);

        // Obtener total para paginación
        $sqlTotal = "SELECT COUNT(*) as total FROM usuarios";
        $total = $this->getDb()->selectOne($sqlTotal);

        return [
            'usuarios' => $usuarios,
            'total' => $total['total'],
            'pagina' => $pagina,
            'limite' => $limite,
            'total_paginas' => ceil($total['total'] / $limite)
        ];
    }

    /**
     * Actualizar usuario
     */
    public function actualizar($id, $datos) {
        try {
            $campos = [];
            $params = [];

            if (isset($datos['nombre'])) {
                $campos[] = "nombre = ?";
                $params[] = $datos['nombre'];
            }

            if (isset($datos['email'])) {
                $campos[] = "email = ?";
                $params[] = $datos['email'];
            }

            if (isset($datos['rol'])) {
                $campos[] = "rol = ?";
                $params[] = $datos['rol'];
            }

            if (isset($datos['activo'])) {
                $campos[] = "activo = ?";
                $params[] = $datos['activo'];
            }

            if (empty($campos)) {
                return false;
            }

            $params[] = $id;
            $sql = "UPDATE usuarios SET " . implode(', ', $campos) . " WHERE id = ?";

            return $this->getDb()->update($sql, $params) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Cambiar contraseña
     */
    public function cambiarPassword($id, $nuevaPassword) {
        try {
            $sql = "UPDATE usuarios SET password_hash = ? WHERE id = ?";
            return $this->getDb()->update($sql, [password_hash($nuevaPassword, PASSWORD_DEFAULT), $id]) > 0;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Desactivar usuario
     */
    public function desactivar($id) {
        return $this->actualizar($id, ['activo' => false]);
    }

    /**
     * Activar usuario
     */
    public function activar($id) {
        return $this->actualizar($id, ['activo' => true]);
    }

    /**
     * Verificar si el email ya existe
     */
    public function emailExiste($email, $excluirId = null) {
        $sql = "SELECT COUNT(*) as count FROM usuarios WHERE email = ?";
        $params = [$email];

        if ($excluirId) {
            $sql .= " AND id != ?";
            $params[] = $excluirId;
        }

        $resultado = $this->getDb()->selectOne($sql, $params);
        return $resultado['count'] > 0;
    }

    /**
     * Obtener usuarios por rol
     */
    public function obtenerPorRol($rol) {
        $sql = "SELECT id, nombre, email, fecha_creacion, activo FROM usuarios WHERE rol = ? ORDER BY nombre";
        return $this->getDb()->select($sql, [$rol]);
    }

    /**
     * Obtener estadísticas de usuarios
     */
    public function obtenerEstadisticas() {
        $sql = "SELECT
                    COUNT(*) as total,
                    SUM(CASE WHEN activo = 1 THEN 1 ELSE 0 END) as activos,
                    SUM(CASE WHEN activo = 0 THEN 1 ELSE 0 END) as inactivos,
                    SUM(CASE WHEN rol = 'supremo' THEN 1 ELSE 0 END) as supremos,
                    SUM(CASE WHEN rol = 'admin' THEN 1 ELSE 0 END) as admins,
                    SUM(CASE WHEN rol = 'registrado' THEN 1 ELSE 0 END) as registrados,
                    SUM(CASE WHEN rol = 'basico' THEN 1 ELSE 0 END) as basicos
                FROM usuarios";

        return $this->getDb()->selectOne($sql);
    }

    /**
     * Buscar usuarios
     */
    public function buscar($termino, $pagina = 1, $limite = ITEMS_PER_PAGE) {
        $offset = ($pagina - 1) * $limite;
        $termino = "%$termino%";

        $sql = "SELECT id, nombre, email, rol, fecha_creacion, activo
                FROM usuarios
                WHERE nombre LIKE ? OR email LIKE ?
                ORDER BY nombre
                LIMIT ? OFFSET ?";

        $usuarios = $this->getDb()->select($sql, [$termino, $termino, $limite, $offset]);

        // Obtener total para paginación
        $sqlTotal = "SELECT COUNT(*) as total FROM usuarios WHERE nombre LIKE ? OR email LIKE ?";
        $total = $this->getDb()->selectOne($sqlTotal, [$termino, $termino]);

        return [
            'usuarios' => $usuarios,
            'total' => $total['total'],
            'pagina' => $pagina,
            'limite' => $limite,
            'total_paginas' => ceil($total['total'] / $limite)
        ];
    }

    /**
     * Validar datos de usuario
     */
    public function validarDatos($datos, $esActualizacion = false) {
        $errores = [];

        // Validar nombre
        if (empty($datos['nombre'])) {
            $errores['nombre'] = 'El nombre es requerido';
        } elseif (strlen($datos['nombre']) < 2) {
            $errores['nombre'] = 'El nombre debe tener al menos 2 caracteres';
        }

        // Validar email
        if (empty($datos['email'])) {
            $errores['email'] = 'El email es requerido';
        } elseif (!$this->validateEmail($datos['email'])) {
            $errores['email'] = 'El email no es válido';
        } elseif ($this->emailExiste($datos['email'], $datos['id'] ?? null)) {
            $errores['email'] = 'El email ya está registrado';
        }

        // Validar contraseña (solo para creación)
        if (!$esActualizacion && empty($datos['password'])) {
            $errores['password'] = 'La contraseña es requerida';
        } elseif (!$esActualizacion && !$this->validarPassword($datos['password'])) {
            $errores['password'] = 'La contraseña debe tener al menos ' . PASSWORD_MIN_LENGTH . ' caracteres';
        }

        // Validar rol
        if (isset($datos['rol']) && !array_key_exists($datos['rol'], USER_ROLES)) {
            $errores['rol'] = 'El rol seleccionado no es válido';
        }

        return $errores;
    }

    /**
     * Validar formato de email
     */
    private function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    /**
     * Validar contraseña
     */
    private function validarPassword($password) {
        return strlen($password) >= PASSWORD_MIN_LENGTH;
    }

    /**
     * Obtener permisos del usuario
     */
    public function obtenerPermisos($usuario) {
        $rol = $usuario['rol'] ?? 'basico';
        return getRolePermissions($rol);
    }

    /**
     * Verificar si usuario tiene permiso
     */
    public function tienePermiso($usuario, $permiso) {
        $permisos = $this->obtenerPermisos($usuario);
        return in_array($permiso, $permisos) || in_array('*', $permisos);
    }
}