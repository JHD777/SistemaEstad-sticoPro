<?php
/**
 * Configuración de la aplicación - ARCHIVO OBSOLETO
 * Este archivo ha sido reemplazado por config/app.php
 * No debe ser incluido directamente
 */

// Este archivo ya no se utiliza
// Todas las funciones y constantes están en config/app.php
