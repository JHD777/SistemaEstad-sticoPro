sistema_estadistico_pro/                  <-- RAÍZ DEL PROYECTO
│
├── 📄 .gitignore                         <-- Archivos que Git debe ignorar
├── 📄 composer.json                      <-- Gestión de dependencias de PHP (Composer)
├── 📄 ESPECIFICACIONES.md                <-- Documentación completa del proyecto
├── 📄 README.md                          <-- Descripción general del proyecto
│
├── 📁 app/                               <-- LÓGICA DE LA APLICACIÓN (No accesible desde web)
│   │
│   ├── 📁 controllers/                   <-- Controladores (Manejan la lógica de cada página)
│   │   ├── 📄 AuthController.php
│   │   ├── 📄 DashboardController.php
│   │   ├── 📄 FormularioController.php
│   │   └── 📄 UsuarioController.php      <-- (Nuevo) Para la gestión de usuarios
│   │
│   ├── 📁 core/                          <-- Clases base y fundamentales
│   │   ├── 📄 Controller.php             <-- Clase padre para todos los controladores
│   │   ├── 📄 Database.php               <-- Gestiona la conexión a la BD
│   │   └── 📄 Router.php                 <-- Para manejar URLs amigables
│   │
│   ├── 📁 helpers/                       <-- Funciones de ayuda (utilidades)
│   │   ├── 📄 auth_helper.php            <-- is_admin(), is_logged_in(), etc.
│   │   └── 📄 general_helper.php         <-- funciones para limpiar texto, fechas, etc.
│   │
│   ├── 📁 models/                        <-- Modelos (Interactúan con la base de datos)
│   │   ├── 📄 Especie.php
│   │   ├── 📄 Formulario.php
│   │   ├── 📄 Pregunta.php
│   │   ├── 📄 RegistroCenso.php
│   │   └── 📄 Usuario.php
│   │
│   └── 📁 views/                         <-- Vistas (El HTML que ve el usuario)
│       │
│       ├── 📁 auth/
│       │   ├── 📄 login.php
│       │   ├── 📄 register.php           <-- (NUEVO) Formulario de registro público
│       │   └── 📄 register.php
│       │
│       ├── 📁 dashboard/
│       │   ├── 📄 general.php
│       │   └── 📄 especifico.php
│       │
│       ├── 📁 formularios/
│       │   ├── 📄 crear.php
│       │   ├── 📄 editar.php
│       │   ├── 📄 listar.php
│       │   └── 📄 responder.php
│       │
│       ├── 📁 layouts/                   <-- Plantillas base (Header, Footer, etc.)
│       │   ├── 📄 header.php
│       │   ├── 📄 footer.php
│       │   └── 📄 main.php                <-- Plantilla principal que envuelve a las demás
│       │
│       ├── 📁 usuarios/                  <-- (Nuevo) Vistas para la gestión de usuarios
│       │   ├── 📄 listar.php
│       │   └── 📄 crear.php
│       │
│       └── 📁 especies/
│           ├── 📄 crear_modulo.php
│           └── 📄 listar.php
│
├── 📁 config/                            <-- Archivos de configuración
│   ├── 📄 database.php                   <-- Configuración de la base de datos
│   └── 📄 app.php                        <-- Constantes y configuración general de la app
│
├── 📁 public/                            <-- RAÍZ WEB (La única carpeta accesible por Apache)
│   │
│   ├── 📁 api/                           <-- Endpoints de tu API
│   │   └── 📁 v1/                        <-- (Recomendado) Versionar la API
│   │       ├── 📄 formularios.php
│   │       ├── 📄 especies.php
│   │       └── 📄 registros.php
│   │
│   ├── 📁 assets/                        <-- Recursos estáticos (CSS, JS, imágenes)
│   │   ├── 📁 css/
│   │   │   ├── 📄 main.css
│   │   │   └── 📄 dashboard.css
│   │   ├── 📁 js/
│   │   │   ├── 📄 main.js
│   │   │   ├── 📄 dashboard.js
│   │   │   └── 📄 form-builder.js
│   │   └── 📁 images/
│   │       └── 📄 logo.png
│   │
│   ├── 📄 index.php                      <-- CONTROLADOR FRONTAL (Todas las peticiones entran aquí)
│   └── 📄 .htaccess                      <-- Para reescribir URLs y dirigir a index.php
│
└── 📁 vendor/                            <-- Dependencias de Composer (si las usas)
