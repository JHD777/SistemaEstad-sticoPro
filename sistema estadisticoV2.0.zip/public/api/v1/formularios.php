<?php
/**
 * API v1 - Formularios
 * Endpoints REST para gestión de formularios
 */

// Headers para API
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

// Incluir archivos necesarios
require_once __DIR__ . '/../../app/core/Database.php';
require_once __DIR__ . '/../../app/models/Formulario.php';
require_once __DIR__ . '/../../app/models/Especie.php';
require_once __DIR__ . '/../../app/models/Pregunta.php';

// Crear instancias de modelos
$formularioModel = new Formulario();
$especieModel = new Especie();
$preguntaModel = new Pregunta();

// Obtener método HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Obtener parámetro ID si existe
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

// Procesar según método
switch ($method) {
    case 'GET':
        if ($id) {
            // Obtener formulario específico con preguntas
            $formulario = $formularioModel->obtenerPorId($id);
            if ($formulario) {
                $preguntas = $preguntaModel->obtenerPorFormulario($id);
                $formulario['preguntas'] = $preguntas;

                echo json_encode([
                    'success' => true,
                    'data' => $formulario
                ]);
            } else {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'message' => 'Formulario no encontrado'
                ]);
            }
        } else {
            // Listar formularios
            $filtros = [];
            if (isset($_GET['especie_id'])) {
                $filtros['especie_id'] = (int)$_GET['especie_id'];
            }
            if (isset($_GET['estado'])) {
                $filtros['estado'] = $_GET['estado'];
            }

            $formularios = $formularioModel->obtenerConPreguntas($filtros);
            echo json_encode([
                'success' => true,
                'data' => $formularios
            ]);
        }
        break;

    case 'POST':
        // Crear nuevo formulario
        $input = json_decode(file_get_contents('php://input'), true);

        if (!$input || !isset($input['nombre'], $input['especie_id'])) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Datos incompletos'
            ]);
            break;
        }

        $datos = [
            'nombre' => $input['nombre'],
            'especie_id' => $input['especie_id'],
            'descripcion' => $input['descripcion'] ?? null,
            'estado' => $input['estado'] ?? 'borrador'
        ];

        $errores = $formularioModel->validarDatos($datos);
        if (!empty($errores)) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Errores de validación',
                'errors' => $errores
            ]);
            break;
        }

        $nuevoId = $formularioModel->crear($datos);
        if ($nuevoId) {
            http_response_code(201);
            echo json_encode([
                'success' => true,
                'message' => 'Formulario creado exitosamente',
                'data' => ['id' => $nuevoId]
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Error al crear formulario'
            ]);
        }
        break;

    case 'PUT':
        if (!$id) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'ID requerido para actualizar'
            ]);
            break;
        }

        $input = json_decode(file_get_contents('php://input'), true);

        if (!$input) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Datos inválidos'
            ]);
            break;
        }

        $datos = [];
        if (isset($input['nombre'])) $datos['nombre'] = $input['nombre'];
        if (isset($input['especie_id'])) $datos['especie_id'] = $input['especie_id'];
        if (isset($input['descripcion'])) $datos['descripcion'] = $input['descripcion'];
        if (isset($input['estado'])) $datos['estado'] = $input['estado'];

        if ($formularioModel->actualizar($id, $datos)) {
            echo json_encode([
                'success' => true,
                'message' => 'Formulario actualizado exitosamente'
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Error al actualizar formulario'
            ]);
        }
        break;

    case 'DELETE':
        if (!$id) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'ID requerido para eliminar'
            ]);
            break;
        }

        if ($formularioModel->tieneRegistros($id)) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'No se puede eliminar formulario con registros asociados'
            ]);
            break;
        }

        if ($formularioModel->eliminar($id)) {
            echo json_encode([
                'success' => true,
                'message' => 'Formulario eliminado exitosamente'
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Error al eliminar formulario'
            ]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'message' => 'Método no permitido'
        ]);
        break;
}
?>