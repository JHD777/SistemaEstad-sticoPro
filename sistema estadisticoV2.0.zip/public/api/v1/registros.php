<?php
/**
 * API v1 - Registros de Censo
 * Endpoints REST para gestión de registros de censo
 */

// Headers para API
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

// Incluir archivos necesarios
require_once __DIR__ . '/../../app/core/Database.php';
require_once __DIR__ . '/../../app/models/RegistroCenso.php';
require_once __DIR__ . '/../../app/models/Respuesta.php';
require_once __DIR__ . '/../../app/models/Formulario.php';

// Crear instancias de modelos
$registroModel = new RegistroCenso();
$respuestaModel = new Respuesta();
$formularioModel = new Formulario();

// Obtener método HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Obtener parámetro ID si existe
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

// Procesar según método
switch ($method) {
    case 'GET':
        if ($id) {
            // Obtener registro específico con respuestas
            $registro = $registroModel->obtenerPorId($id);
            if ($registro) {
                $respuestas = $respuestaModel->obtenerPorRegistroCenso($id);
                $registro['respuestas'] = $respuestas;

                echo json_encode([
                    'success' => true,
                    'data' => $registro
                ]);
            } else {
                http_response_code(404);
                echo json_encode([
                    'success' => false,
                    'message' => 'Registro no encontrado'
                ]);
            }
        } else {
            // Listar registros
            $filtros = [];
            if (isset($_GET['formulario_id'])) {
                $filtros['formulario_id'] = (int)$_GET['formulario_id'];
            }
            if (isset($_GET['usuario_admin_id'])) {
                $filtros['usuario_admin_id'] = (int)$_GET['usuario_admin_id'];
            }
            if (isset($_GET['fecha_inicio'])) {
                $filtros['fecha_inicio'] = $_GET['fecha_inicio'];
            }
            if (isset($_GET['fecha_fin'])) {
                $filtros['fecha_fin'] = $_GET['fecha_fin'];
            }

            $registros = $registroModel->obtenerConFiltros($filtros);
            echo json_encode([
                'success' => true,
                'data' => $registros
            ]);
        }
        break;

    case 'POST':
        // Crear nuevo registro de censo
        $input = json_decode(file_get_contents('php://input'), true);

        if (!$input || !isset($input['formulario_id'], $input['usuario_admin_id'])) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Datos incompletos'
            ]);
            break;
        }

        $datos = [
            'formulario_id' => $input['formulario_id'],
            'usuario_admin_id' => $input['usuario_admin_id'],
            'ubicacion_geo' => $input['ubicacion_geo'] ?? null,
            'observaciones' => $input['observaciones'] ?? null
        ];

        $errores = $registroModel->validarDatos($datos);
        if (!empty($errores)) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Errores de validación',
                'errors' => $errores
            ]);
            break;
        }

        $nuevoId = $registroModel->crear($datos);
        if ($nuevoId) {
            http_response_code(201);
            echo json_encode([
                'success' => true,
                'message' => 'Registro creado exitosamente',
                'data' => ['id' => $nuevoId]
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Error al crear registro'
            ]);
        }
        break;

    case 'PUT':
        if (!$id) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'ID requerido para actualizar'
            ]);
            break;
        }

        $input = json_decode(file_get_contents('php://input'), true);

        if (!$input) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Datos inválidos'
            ]);
            break;
        }

        $datos = [];
        if (isset($input['ubicacion_geo'])) $datos['ubicacion_geo'] = $input['ubicacion_geo'];
        if (isset($input['observaciones'])) $datos['observaciones'] = $input['observaciones'];

        if ($registroModel->actualizar($id, $datos)) {
            echo json_encode([
                'success' => true,
                'message' => 'Registro actualizado exitosamente'
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Error al actualizar registro'
            ]);
        }
        break;

    case 'DELETE':
        if (!$id) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'ID requerido para eliminar'
            ]);
            break;
        }

        if ($registroModel->eliminar($id)) {
            echo json_encode([
                'success' => true,
                'message' => 'Registro eliminado exitosamente'
            ]);
        } else {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'message' => 'Error al eliminar registro'
            ]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'message' => 'Método no permitido'
        ]);
        break;
}
?>