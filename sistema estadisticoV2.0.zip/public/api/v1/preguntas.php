<?php
/**
 * API v1 - Preguntas
 * Endpoints REST para gestión de preguntas y herencia
 */

// Headers para API
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

try {
    // Definir constantes básicas
    define('ROOT_PATH', dirname(__DIR__, 3)); // public/api/v1 -> public -> root
    define('APP_PATH', ROOT_PATH . '/app');
    define('PUBLIC_PATH', ROOT_PATH . '/public');

    // Cargar configuración esencial
    require_once ROOT_PATH . '/config/database.php';
    require_once ROOT_PATH . '/config/app.php';

    // Incluir archivos necesarios
    require_once APP_PATH . '/core/Database.php';
    require_once APP_PATH . '/models/Pregunta.php';
    require_once APP_PATH . '/models/Formulario.php';
    require_once APP_PATH . '/models/Especie.php';

    // Crear instancias de modelos
    $preguntaModel = new Pregunta();
    $formularioModel = new Formulario();
    $especieModel = new Especie();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error loading configuration/models: ' . $e->getMessage()
    ]);
    exit;
}

// Obtener método HTTP
$method = $_SERVER['REQUEST_METHOD'];

// Parsear parámetros de la URL
$endpoint = isset($_GET['endpoint']) ? $_GET['endpoint'] : '';
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

// Debug logging
error_log("API Preguntas - Method: $method, Endpoint: $endpoint, ID: $id");
error_log("GET params: " . json_encode($_GET));

// Procesar según endpoint y método
switch ($method) {
    case 'GET':
        if ($endpoint === 'heredadas' && $id) {
            // Obtener preguntas heredadas para una especie
            obtenerPreguntasHeredadas($id);
        } else {
            http_response_code(404);
            echo json_encode([
                'success' => false,
                'message' => 'Endpoint no encontrado'
            ]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'message' => 'Método no permitido'
        ]);
        break;
}

/**
 * Obtener preguntas heredadas para una especie
 */
function obtenerPreguntasHeredadas($especieId) {
    global $preguntaModel, $formularioModel, $especieModel;

    try {
        // Verificar que los modelos estén disponibles
        if (!$especieModel || !$formularioModel || !$preguntaModel) {
            throw new Exception('Modelos no disponibles');
        }

        // Obtener jerarquía completa de la especie
        $jerarquia = $especieModel->obtenerJerarquia($especieId);

        if (empty($jerarquia)) {
            echo json_encode([
                'success' => true,
                'data' => []
            ]);
            return;
        }

        $preguntasHeredadas = [];

        // Para cada nivel de la jerarquía (excepto el actual)
        foreach ($jerarquia as $nivel) {
            if ($nivel['id'] == $especieId) {
                continue; // No incluir el mismo nivel
            }

            // Buscar preguntas base para este nivel (no asociadas a formularios específicos)
            $sql = "SELECT
                        id,
                        texto_pregunta,
                        tipo_pregunta,
                        opciones,
                        orden,
                        obligatoria,
                        depende_de,
                        respuesta_requerida,
                        ambito_aplicacion,
                        ambito_id
                    FROM preguntas
                    WHERE ambito_aplicacion = ? AND ambito_id = ?
                    ORDER BY orden ASC";

            $db = Database::getInstance();
            $preguntas = $db->select($sql, [$nivel['tipo'], $nivel['id']]);

            foreach ($preguntas as $pregunta) {
                // Agregar información del nivel
                $pregunta['nivel_herencia'] = $nivel['tipo'];
                $pregunta['especie_padre'] = $nivel['nombre'];
                $preguntasHeredadas[] = $pregunta;
            }
        }

        echo json_encode([
            'success' => true,
            'data' => $preguntasHeredadas
        ]);

    } catch (Exception $e) {
        error_log("Error en obtenerPreguntasHeredadas: " . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Error interno del servidor: ' . $e->getMessage()
        ]);
    }
}
?>