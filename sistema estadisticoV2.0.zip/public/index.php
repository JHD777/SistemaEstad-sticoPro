<?php
/**
 * Sistema Estadístico Pro - Página Principal Corporativa
 * Aplicación completa con información de Empresa XYZ
 */

// Configuración básica de errores para desarrollo
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Definir constantes básicas
define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH', ROOT_PATH . '/app');
define('PUBLIC_PATH', __DIR__);

// Cargar configuración esencial
require_once APP_PATH . '/../config/database.php';
require_once APP_PATH . '/../config/app.php';

// Crear directorio de logs si no existe
if (!is_dir(LOG_PATH)) {
    mkdir(LOG_PATH, 0755, true);
}

// Iniciar el buffer de salida
ob_start();

// Incluir autoloader
require_once APP_PATH . '/core/Autoloader.php';

// Registrar el autoloader
spl_autoload_register(['Autoloader', 'load']);

// Iniciar sesión
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'name' => SESSION_NAME,
        'cookie_lifetime' => SESSION_LIFETIME,
        'cookie_secure' => isset($_SERVER['HTTPS']),
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax',
        'use_strict_mode' => true,
        'use_cookies' => true,
        'use_only_cookies' => true,
        'cookie_path' => '/',
        'cookie_domain' => $_SERVER['HTTP_HOST'] ?? 'sistema_estadistico_pro.test'
    ]);
}

// Procesar la petición
try {
    // Obtener la URL solicitada
    $requestUri = $_SERVER['REQUEST_URI'];

    // Remover parámetros de query
    if (($pos = strpos($requestUri, '?')) !== false) {
        $requestUri = substr($requestUri, 0, $pos);
    }

    // Remover barra inicial y limpiar la URI
    $requestUri = ltrim($requestUri, '/');
    $requestUri = trim($requestUri);

    // Si la URI está vacía o es solo el dominio, redirigir al controlador Home
    if (empty($requestUri) || $requestUri === 'index.php' || $requestUri === '' || $requestUri === '/') {
        $requestUri = 'home';
    }

    // Incluir la clase Router
    require_once __DIR__ . '/../app/core/Router.php';

    // Crear instancia del router
    $router = new Router();

    // Cargar rutas
    require_once __DIR__ . '/../app/routes.php';

    // Procesar la ruta
    $router->dispatch($requestUri);

} catch (Exception $e) {
    // Manejar excepciones de routing
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        echo '<pre>';
        echo 'Error de routing: ' . $e->getMessage() . PHP_EOL;
        echo 'Archivo: ' . $e->getFile() . PHP_EOL;
        echo 'Línea: ' . $e->getLine() . PHP_EOL;
        echo 'URI solicitada: ' . $requestUri . PHP_EOL;
        echo 'Trace: ' . $e->getTraceAsString() . PHP_EOL;
        echo '</pre>';
    } else {
        // Verificar si es un error de base de datos
        if (strpos($e->getMessage(), 'database') !== false || strpos($e->getMessage(), 'PDO') !== false) {
            http_response_code(500);
            echo '<h1>Error de Base de Datos</h1>';
            echo '<p>Hay un problema con la conexión a la base de datos.</p>';
            echo '<p>Por favor, asegúrese de que:</p>';
            echo '<ul>';
            echo '<li>MySQL esté ejecutándose</li>';
            echo '<li>La base de datos exista</li>';
            echo '<li>Las credenciales de conexión sean correctas</li>';
            echo '</ul>';
        } else {
            http_response_code(404);
            echo '<h1>Página no encontrada</h1>';
            echo '<p>La página solicitada no existe.</p>';
        }
    }
}

// Limpiar buffer de salida
ob_end_flush();
?>