/**
 * Sistema Estadístico Pro - JavaScript Principal
 * Funcionalidades comunes del sistema
 */

// Configuración global
window.SistemaEstadistico = {
    baseUrl: window.appConfig?.baseUrl || '',
    csrfToken: window.appConfig?.csrfToken || '',
    debugMode: window.appConfig?.debugMode || false,

    // Utilidades
    utils: {
        /**
         * Mostrar mensaje de carga
         */
        showLoading: function(message = 'Cargando...') {
            if (!$('#loadingModal').length) {
                $('body').append(`
                    <div class="modal fade" id="loadingModal" data-bs-backdrop="static" data-bs-keyboard="false">
                        <div class="modal-dialog modal-sm modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-body text-center">
                                    <div class="spinner-border text-primary" role="status">
                                        <span class="visually-hidden">Loading...</span>
                                    </div>
                                    <div class="mt-2">${message}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                `);
            }
            $('#loadingModal').modal('show');
        },

        /**
         * Ocultar mensaje de carga
         */
        hideLoading: function() {
            $('#loadingModal').modal('hide');
        },

        /**
         * Mostrar mensaje de éxito
         */
        showSuccess: function(message, duration = 3000) {
            this.showToast(message, 'success', duration);
        },

        /**
         * Mostrar mensaje de error
         */
        showError: function(message, duration = 5000) {
            this.showToast(message, 'error', duration);
        },

        /**
         * Mostrar mensaje de información
         */
        showInfo: function(message, duration = 3000) {
            this.showToast(message, 'info', duration);
        },

        /**
         * Mostrar toast
         */
        showToast: function(message, type = 'info', duration = 3000) {
            const toastId = 'toast-' + Date.now();
            const bgClass = type === 'success' ? 'bg-success' :
                           type === 'error' ? 'bg-danger' :
                           type === 'warning' ? 'bg-warning' : 'bg-info';

            const toast = $(`
                <div id="${toastId}" class="toast align-items-center text-white ${bgClass} border-0" role="alert">
                    <div class="d-flex">
                        <div class="toast-body">
                            ${message}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                    </div>
                </div>
            `);

            $('#toastContainer').append(toast);
            toast.toast({ autohide: true, delay: duration });
            toast.toast('show');

            toast.on('hidden.bs.toast', function() {
                $(this).remove();
            });
        },

        /**
         * Confirmar acción
         */
        confirm: function(message, callback) {
            if (confirm(message)) {
                callback();
            }
        },

        /**
         * Formatear fecha
         */
        formatDate: function(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('es-ES', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        },

        /**
         * Formatear número
         */
        formatNumber: function(number) {
            return new Intl.NumberFormat('es-ES').format(number);
        },

        /**
         * Validar email
         */
        isValidEmail: function(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },

        /**
         * Escapar HTML
         */
        escapeHtml: function(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        },

        /**
         * Copiar al portapapeles
         */
        copyToClipboard: function(text) {
            if (navigator.clipboard) {
                navigator.clipboard.writeText(text).then(() => {
                    this.showSuccess('Copiado al portapapeles');
                });
            } else {
                // Fallback para navegadores antiguos
                const textArea = document.createElement('textarea');
                textArea.value = text;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                this.showSuccess('Copiado al portapapeles');
            }
        }
    },

    // Peticiones HTTP
    http: {
        /**
         * Realizar petición GET
         */
        get: function(url, successCallback, errorCallback) {
            this.request('GET', url, null, successCallback, errorCallback);
        },

        /**
         * Realizar petición POST
         */
        post: function(url, data, successCallback, errorCallback) {
            this.request('POST', url, data, successCallback, errorCallback);
        },

        /**
         * Realizar petición AJAX
         */
        request: function(method, url, data, successCallback, errorCallback) {
            SistemaEstadistico.utils.showLoading();

            $.ajax({
                url: url,
                method: method,
                data: data,
                headers: {
                    'X-CSRF-Token': SistemaEstadistico.csrfToken,
                    'X-Requested-With': 'XMLHttpRequest'
                },
                success: function(response) {
                    SistemaEstadistico.utils.hideLoading();
                    if (successCallback) {
                        successCallback(response);
                    }
                },
                error: function(xhr, status, error) {
                    SistemaEstadistico.utils.hideLoading();

                    let errorMessage = 'Error desconocido';
                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMessage = xhr.responseJSON.error;
                    } else if (xhr.status === 403) {
                        errorMessage = 'No tienes permisos para realizar esta acción';
                    } else if (xhr.status === 404) {
                        errorMessage = 'Recurso no encontrado';
                    } else if (xhr.status >= 500) {
                        errorMessage = 'Error interno del servidor';
                    }

                    SistemaEstadistico.utils.showError(errorMessage);

                    if (errorCallback) {
                        errorCallback(xhr, status, error);
                    }
                }
            });
        }
    },

    // Gestión de formularios
    forms: {
        /**
         * Validar formulario
         */
        validate: function(form) {
            let isValid = true;
            const $form = $(form);

            // Limpiar errores anteriores
            $form.find('.is-invalid').removeClass('is-invalid');
            $form.find('.invalid-feedback').remove();

            // Validar campos requeridos
            $form.find('[required]').each(function() {
                const $field = $(this);
                if (!$field.val().trim()) {
                    SistemaEstadistico.forms.showFieldError($field, 'Este campo es requerido');
                    isValid = false;
                }
            });

            // Validar emails
            $form.find('[type="email"]').each(function() {
                const $field = $(this);
                const email = $field.val().trim();
                if (email && !SistemaEstadistico.utils.isValidEmail(email)) {
                    SistemaEstadistico.forms.showFieldError($field, 'Email no válido');
                    isValid = false;
                }
            });

            return isValid;
        },

        /**
         * Mostrar error en campo
         */
        showFieldError: function($field, message) {
            $field.addClass('is-invalid');
            $field.after(`<div class="invalid-feedback">${message}</div>`);
        },

        /**
         * Serializar formulario para envío AJAX
         */
        serializeForAjax: function(form) {
            const formData = new FormData(form);
            const data = {};

            for (let [key, value] of formData.entries()) {
                if (data[key]) {
                    if (!Array.isArray(data[key])) {
                        data[key] = [data[key]];
                    }
                    data[key].push(value);
                } else {
                    data[key] = value;
                }
            }

            return data;
        }
    },

    // Gestión de sesiones
    session: {
        /**
         * Verificar sesión activa
         */
        check: function() {
            SistemaEstadistico.http.get(
                SistemaEstadistico.baseUrl + 'api/auth/verificar-sesion',
                function(response) {
                    if (SistemaEstadistico.debugMode) {
                        console.log('Sesión verificada:', response);
                    }
                },
                function(xhr) {
                    if (xhr.status === 401) {
                        window.location.href = SistemaEstadistico.baseUrl + 'login';
                    }
                }
            );
        },

        /**
         * Obtener información del usuario actual
         */
        getCurrentUser: function(callback) {
            SistemaEstadistico.http.get(
                SistemaEstadistico.baseUrl + 'api/auth/usuario-actual',
                function(response) {
                    if (callback) {
                        callback(response.data);
                    }
                }
            );
        }
    }
};

// Inicialización cuando el DOM esté listo
$(document).ready(function() {
    // Crear contenedor para toasts
    if (!$('#toastContainer').length) {
        $('body').append('<div id="toastContainer" class="toast-container position-fixed top-0 end-0 p-3" style="z-index: 1050;"></div>');
    }

    // Verificar sesión cada 5 minutos
    setInterval(function() {
        SistemaEstadistico.session.check();
    }, 5 * 60 * 1000);

    // Manejar errores AJAX globales
    $(document).ajaxError(function(event, xhr, settings, thrownError) {
        if (SistemaEstadistico.debugMode) {
            console.error('Error AJAX:', {
                url: settings.url,
                status: xhr.status,
                error: thrownError,
                response: xhr.responseText
            });
        }
    });

    // Inicializar tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();

    // Inicializar popovers
    $('[data-bs-toggle="popover"]').popover();

    // Auto-submit para formularios con cambios
    $('form[data-auto-submit]').on('change', function() {
        $(this).submit();
    });

    // Confirmación para enlaces peligrosos
    $('a[data-confirm]').on('click', function(e) {
        const message = $(this).data('confirm');
        if (!confirm(message)) {
            e.preventDefault();
        }
    });

    // Debug info
    if (SistemaEstadistico.debugMode) {
        console.log('Sistema Estadístico Pro inicializado');
        console.log('Configuración:', window.appConfig);
    }
});

// Funciones globales para compatibilidad
function showLoading(message) {
    SistemaEstadistico.utils.showLoading(message);
}

function hideLoading() {
    SistemaEstadistico.utils.hideLoading();
}

function showSuccess(message, duration) {
    SistemaEstadistico.utils.showSuccess(message, duration);
}

function showError(message, duration) {
    SistemaEstadistico.utils.showError(message, duration);
}

function showInfo(message, duration) {
    SistemaEstadistico.utils.showInfo(message, duration);
}

function confirmAction(message, callback) {
    SistemaEstadistico.utils.confirm(message, callback);
}