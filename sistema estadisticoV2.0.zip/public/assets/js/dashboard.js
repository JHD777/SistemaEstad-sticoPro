// Sistema Estadístico Pro - JavaScript del Dashboard
// Maneja la visualización jerárquica de datos y gráficos

class DashboardManager {
    constructor() {
        this.currentView = 'general';
        this.chartInstances = [];
        this.init();
    }

    init() {
        this.bindEvents();
        this.loadChartJS();
    }

    bindEvents() {
        // Botones de cambio de vista
        document.getElementById('btnVistaGeneral')?.addEventListener('click', () => this.cambiarVista('general'));
        document.getElementById('btnVistaEspecifica')?.addEventListener('click', () => this.cambiarVista('especifica'));

        // Selector de especie específica
        document.getElementById('especieSelector')?.addEventListener('change', (e) => {
            const btn = document.getElementById('btnVerEspecie');
            btn.disabled = !e.target.value;
        });

        document.getElementById('btnVerEspecie')?.addEventListener('click', () => this.cargarVistaEspecieEspecifica());
    }

    cambiarVista(vista) {
        // Ocultar todas las vistas
        document.querySelectorAll('.dashboard-view').forEach(view => {
            view.style.display = 'none';
        });

        // Mostrar vista seleccionada
        const vistaElement = document.getElementById(vista + 'View');
        if (vistaElement) {
            vistaElement.style.display = 'block';
        }

        this.currentView = vista;

        // Actualizar botones
        document.querySelectorAll('.dashboard-actions .btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.getElementById('btnVista' + vista.charAt(0).toUpperCase() + vista.slice(1))?.classList.add('active');
    }

    async cargarModulosReino(reinoId, reinoNombre) {
        this.mostrarLoading();

        try {
            const response = await fetch(base_url('api/dashboard/modulos/' + reinoId));
            const data = await response.json();

            this.ocultarLoading();
            this.mostrarVistaModulos(data, reinoId, reinoNombre);
        } catch (error) {
            console.error('Error:', error);
            this.ocultarLoading();
            this.mostrarError('Error al cargar los módulos');
        }
    }

    async cargarEspeciesModulo(moduloId, moduloNombre, reinoNombre) {
        this.mostrarLoading();

        try {
            const response = await fetch(base_url('api/dashboard/datos/modulo/' + moduloId));
            const data = await response.json();

            this.ocultarLoading();
            this.mostrarVistaEspecies(data, moduloId, moduloNombre, reinoNombre);
        } catch (error) {
            console.error('Error:', error);
            this.ocultarLoading();
            this.mostrarError('Error al cargar las especies');
        }
    }

    async cargarVistaEspecieEspecifica() {
        const especieId = document.getElementById('especieSelector').value;
        const especieNombre = document.getElementById('especieSelector').selectedOptions[0].dataset.nombre;

        if (!especieId) return;

        this.mostrarLoading();

        try {
            const response = await fetch(base_url('api/dashboard/datos/especie/' + especieId));
            const data = await response.json();

            this.ocultarLoading();
            this.mostrarVistaEspecieEspecifica(data, especieId, especieNombre);
        } catch (error) {
            console.error('Error:', error);
            this.ocultarLoading();
            this.mostrarError('Error al cargar los datos de la especie');
        }
    }

    mostrarVistaModulos(modulos, reinoId, reinoNombre) {
        this.actualizarBreadcrumb(['Inicio', reinoNombre]);
        this.cambiarVista('modulo');

        const container = document.getElementById('moduloView');
        container.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <div class="section-header mb-4">
                        <h3 class="section-title">
                            <i class="fas fa-folder me-2 text-${reinoId == 1 ? 'success' : 'info'}"></i>
                            Módulos de ${reinoNombre}
                        </h3>
                        <p class="section-description text-muted">
                            Selecciona un módulo para ver sus especies y datos estadísticos
                        </p>
                    </div>

                    <div class="row g-4">
                        ${modulos.map(modulo => `
                            <div class="col-lg-6">
                                <div class="card modulo-card h-100 shadow-sm hover-lift"
                                     data-modulo-id="${modulo.id}"
                                     data-modulo-nombre="${modulo.nombre}">
                                    <div class="card-body p-4">
                                        <div class="d-flex align-items-center mb-3">
                                            <i class="fas fa-folder fa-2x me-3 text-${reinoId == 1 ? 'success' : 'info'}"></i>
                                            <div>
                                                <h5 class="card-title mb-1">${modulo.nombre}</h5>
                                                <small class="text-muted">Módulo de ${reinoNombre.toLowerCase()}</small>
                                            </div>
                                        </div>

                                        <div class="modulo-stats mb-3">
                                            <div class="row text-center">
                                                <div class="col-6">
                                                    <div class="stat-item">
                                                        <span class="stat-number">${modulo.especies_count || 0}</span>
                                                        <small class="stat-label text-muted">Especies</small>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="stat-item">
                                                        <span class="stat-number">${modulo.censos_count || 0}</span>
                                                        <small class="stat-label text-muted">Censos</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <button class="btn btn-${reinoId == 1 ? 'success' : 'info'} btn-lg w-100 modulo-btn"
                                                data-modulo-id="${modulo.id}">
                                            <i class="fas fa-arrow-right me-2"></i>
                                            Explorar ${modulo.nombre}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;

        // Agregar event listeners
        container.querySelectorAll('.modulo-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const moduloId = btn.dataset.moduloId;
                const moduloNombre = btn.dataset.moduloNombre;
                this.cargarEspeciesModulo(moduloId, moduloNombre, reinoNombre);
            });
        });
    }

    mostrarVistaEspecies(data, moduloId, moduloNombre, reinoNombre) {
        this.actualizarBreadcrumb(['Inicio', reinoNombre, moduloNombre]);
        this.cambiarVista('especie');

        const container = document.getElementById('especieView');
        container.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <div class="section-header mb-4">
                        <h3 class="section-title">
                            <i class="fas fa-chart-bar me-2 text-primary"></i>
                            Datos de ${moduloNombre}
                        </h3>
                        <p class="section-description text-muted">
                            Visualización estadística de las especies del módulo
                        </p>
                    </div>

                    <!-- Gráficos -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0">
                                        <i class="fas fa-chart-pie me-2"></i>
                                        Estadísticas Generales
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="row" id="chartsContainer">
                                        ${data.preguntas_comunes && data.preguntas_comunes.length > 0 ?
                                            data.preguntas_comunes.map(pregunta => `
                                                <div class="col-md-6 mb-4">
                                                    <div class="chart-container">
                                                        <h6 class="chart-title">${pregunta.texto_pregunta}</h6>
                                                        <canvas id="chart-${pregunta.id}" width="400" height="300"></canvas>
                                                    </div>
                                                </div>
                                            `).join('') :
                                            '<div class="col-12"><div class="alert alert-info">No hay datos suficientes para mostrar gráficos</div></div>'
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Lista de especies -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0">
                                        <i class="fas fa-list me-2"></i>
                                        Especies del Módulo
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        ${data.especies && data.especies.length > 0 ?
                                            data.especies.map(especie => `
                                                <div class="col-md-4">
                                                    <div class="card especie-mini-card h-100">
                                                        <div class="card-body text-center">
                                                            <i class="fas fa-leaf fa-2x mb-2 text-success"></i>
                                                            <h6 class="card-title">${especie.nombre}</h6>
                                                            <small class="text-muted">${especie.censos_count || 0} censos</small>
                                                            <br>
                                                            <button class="btn btn-sm btn-outline-primary mt-2 ver-especie-btn"
                                                                    data-especie-id="${especie.id}"
                                                                    data-especie-nombre="${especie.nombre}">
                                                                <i class="fas fa-eye me-1"></i>Ver Detallado
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            `).join('') :
                                            '<div class="col-12"><div class="alert alert-warning">No hay especies en este módulo</div></div>'
                                        }
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Crear gráficos
        if (data.preguntas_comunes && data.preguntas_comunes.length > 0) {
            data.preguntas_comunes.forEach(pregunta => {
                this.crearGrafico(pregunta);
            });
        }

        // Agregar event listeners para ver especies detalladas
        container.querySelectorAll('.ver-especie-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const especieId = btn.dataset.especieId;
                const especieNombre = btn.dataset.especieNombre;
                this.cargarVistaEspecieEspecificaDesdeModulo(especieId, especieNombre, moduloNombre, reinoNombre);
            });
        });
    }

    async cargarVistaEspecieEspecificaDesdeModulo(especieId, especieNombre, moduloNombre, reinoNombre) {
        this.mostrarLoading();

        try {
            const response = await fetch(base_url('api/dashboard/datos/especie/' + especieId));
            const data = await response.json();

            this.ocultarLoading();
            this.mostrarVistaEspecieEspecifica(data, especieId, especieNombre, moduloNombre, reinoNombre);
        } catch (error) {
            console.error('Error:', error);
            this.ocultarLoading();
            this.mostrarError('Error al cargar los datos de la especie');
        }
    }

    mostrarVistaEspecieEspecifica(data, especieId, especieNombre, moduloNombre = 'Vista Específica', reinoNombre = 'Vista Específica') {
        this.actualizarBreadcrumb(['Inicio', reinoNombre, moduloNombre, especieNombre]);
        this.cambiarVista('especie');

        const container = document.getElementById('especieView');
        container.innerHTML = `
            <div class="row">
                <div class="col-12">
                    <div class="section-header mb-4">
                        <h3 class="section-title">
                            <i class="fas fa-search me-2 text-primary"></i>
                            Datos Específicos: ${especieNombre}
                        </h3>
                        <p class="section-description text-muted">
                            Visualización completa de todas las preguntas de esta especie
                        </p>
                    </div>

                    <!-- Gráficos específicos -->
                    <div class="row" id="especificChartsContainer">
                        ${data.preguntas && data.preguntas.length > 0 ?
                            data.preguntas.map(pregunta => `
                                <div class="col-md-6 mb-4">
                                    <div class="card">
                                        <div class="card-header">
                                            <h6 class="mb-0">${pregunta.texto_pregunta}</h6>
                                            <small class="text-muted">${pregunta.tipo_pregunta}</small>
                                        </div>
                                        <div class="card-body">
                                            <canvas id="chart-especifico-${pregunta.id}" width="400" height="300"></canvas>
                                        </div>
                                    </div>
                                </div>
                            `).join('') :
                            '<div class="col-12"><div class="alert alert-info">No hay datos para mostrar</div></div>'
                        }
                    </div>
                </div>
            </div>
        `;

        // Crear gráficos específicos
        if (data.preguntas && data.preguntas.length > 0) {
            data.preguntas.forEach(pregunta => {
                this.crearGraficoEspecifico(pregunta);
            });
        }
    }

    crearGrafico(pregunta) {
        const ctx = document.getElementById(`chart-${pregunta.id}`);
        if (!ctx) return;

        let chartConfig = {};

        if (pregunta.tipo_pregunta === 'booleano') {
            // Gráfico de torta para booleanos
            const datos = pregunta.datos || [];
            const siCount = datos.filter(d => d.valor === '1' || d.valor === 'Si' || d.valor === 'Sí').length;
            const noCount = datos.length - siCount;

            chartConfig = {
                type: 'pie',
                data: {
                    labels: ['Sí', 'No'],
                    datasets: [{
                        data: [siCount, noCount],
                        backgroundColor: ['#28a745', '#dc3545'],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        },
                        title: {
                            display: true,
                            text: pregunta.texto_pregunta
                        }
                    }
                }
            };
        } else if (pregunta.tipo_pregunta === 'numero') {
            // Gráfico de barras para números
            const datos = pregunta.datos || [];
            const valores = datos.map(d => parseFloat(d.valor)).filter(v => !isNaN(v));
            const promedio = valores.length > 0 ? valores.reduce((a, b) => a + b, 0) / valores.length : 0;

            chartConfig = {
                type: 'bar',
                data: {
                    labels: ['Promedio'],
                    datasets: [{
                        label: 'Valor Promedio',
                        data: [promedio.toFixed(2)],
                        backgroundColor: '#007bff',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: pregunta.texto_pregunta
                        }
                    }
                }
            };
        } else if (pregunta.tipo_pregunta === 'opcion_multiple') {
            // Gráfico de barras para opciones múltiples
            const datos = pregunta.datos || [];
            const conteos = {};

            // Contar respuestas
            datos.forEach(d => {
                const valor = d.valor;
                conteos[valor] = (conteos[valor] || 0) + 1;
            });

            chartConfig = {
                type: 'bar',
                data: {
                    labels: Object.keys(conteos),
                    datasets: [{
                        label: 'Respuestas',
                        data: Object.values(conteos),
                        backgroundColor: '#17a2b8',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: pregunta.texto_pregunta
                        }
                    }
                }
            };
        }

        // Crear instancia del gráfico
        const chart = new Chart(ctx, chartConfig);
        this.chartInstances.push(chart);
    }

    crearGraficoEspecifico(pregunta) {
        const ctx = document.getElementById(`chart-especifico-${pregunta.id}`);
        if (!ctx) return;

        const datos = pregunta.datos || [];
        let chartConfig = {};

        if (pregunta.tipo_pregunta === 'booleano') {
            const siCount = datos.filter(d => d.valor === '1' || d.valor === 'Si' || d.valor === 'Sí').length;
            const noCount = datos.length - siCount;

            chartConfig = {
                type: 'doughnut',
                data: {
                    labels: ['Sí', 'No'],
                    datasets: [{
                        data: [siCount, noCount],
                        backgroundColor: ['#28a745', '#dc3545'],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            };
        } else if (pregunta.tipo_pregunta === 'numero') {
            const valores = datos.map(d => parseFloat(d.valor)).filter(v => !isNaN(v));

            chartConfig = {
                type: 'line',
                data: {
                    labels: valores.map((_, i) => `Registro ${i + 1}`),
                    datasets: [{
                        label: 'Valores',
                        data: valores,
                        borderColor: '#007bff',
                        backgroundColor: 'rgba(0, 123, 255, 0.1)',
                        borderWidth: 2,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            };
        } else if (pregunta.tipo_pregunta === 'opcion_multiple') {
            const conteos = {};
            datos.forEach(d => {
                const valor = d.valor;
                conteos[valor] = (conteos[valor] || 0) + 1;
            });

            chartConfig = {
                type: 'pie',
                data: {
                    labels: Object.keys(conteos),
                    datasets: [{
                        data: Object.values(conteos),
                        backgroundColor: [
                            '#007bff', '#28a745', '#ffc107', '#dc3545',
                            '#6f42c1', '#e83e8c', '#fd7e14', '#20c997'
                        ],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'right'
                        }
                    }
                }
            };
        }

        const chart = new Chart(ctx, chartConfig);
        this.chartInstances.push(chart);
    }

    actualizarBreadcrumb(rutas) {
        const breadcrumb = document.querySelector('.breadcrumb-dashboard .breadcrumb');
        breadcrumb.innerHTML = '';

        rutas.forEach((ruta, index) => {
            const li = document.createElement('li');
            li.className = 'breadcrumb-item' + (index === rutas.length - 1 ? ' active' : '');

            if (index === 0) {
                li.innerHTML = '<i class="fas fa-home me-1"></i>' + ruta;
            } else {
                li.textContent = ruta;
            }

            breadcrumb.appendChild(li);
        });
    }

    mostrarLoading() {
        const modal = new bootstrap.Modal(document.getElementById('loadingModal'));
        modal.show();
    }

    ocultarLoading() {
        const modalElement = document.getElementById('loadingModal');
        const modal = bootstrap.Modal.getInstance(modalElement);
        if (modal) {
            modal.hide();
        }
    }

    mostrarError(mensaje) {
        // Crear alerta de error
        const alert = document.createElement('div');
        alert.className = 'alert alert-danger alert-dismissible fade show position-fixed';
        alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        alert.innerHTML = `
            <i class="fas fa-exclamation-triangle me-2"></i>
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        document.body.appendChild(alert);

        // Auto-remover después de 5 segundos
        setTimeout(() => {
            alert.remove();
        }, 5000);
    }

    loadChartJS() {
        if (typeof Chart === 'undefined') {
            // Cargar Chart.js si no está disponible
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
            script.onload = () => {
                console.log('Chart.js cargado correctamente');
            };
            document.head.appendChild(script);
        }
    }

    // Limpiar gráficos al cambiar de vista
    limpiarGraficos() {
        this.chartInstances.forEach(chart => {
            chart.destroy();
        });
        this.chartInstances = [];
    }
}

// Función global para acceder al dashboard manager
let dashboardManager;

document.addEventListener('DOMContentLoaded', function() {
    dashboardManager = new DashboardManager();

    // Hacer disponible globalmente para los event listeners inline
    window.cargarModulosReino = (reinoId, reinoNombre) => {
        dashboardManager.cargarModulosReino(reinoId, reinoNombre);
    };
});