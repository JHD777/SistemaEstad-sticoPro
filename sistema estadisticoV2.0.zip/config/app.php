<?php
/**
 * Configuración de la Aplicación
 * Sistema Estadístico Pro
 */

// Información básica de la aplicación
define('APP_NAME', 'Sistema Estadístico Pro');
define('APP_VERSION', '2.0.0');
define('APP_URL', 'https://sistema_estadistico_pro.test/');
define('BASE_URL', 'https://sistema_estadistico_pro.test/');
define('ASSETS_URL', BASE_URL . 'assets/');

// Configuración de seguridad
define('SECRET_KEY', 'sistema_estadistico_pro_2024_secret_key_change_in_production');
define('ENCRYPTION_KEY', 'encryption_key_change_in_production_32_chars');

// Configuración de sesiones
define('SESSION_NAME', 'sistema_estadistico_pro_session');
define('SESSION_LIFETIME', 3600); // 1 hora en segundos

// Configuración de contraseñas
define('PASSWORD_MIN_LENGTH', 8);
define('PASSWORD_REQUIRE_UPPERCASE', true);
define('PASSWORD_REQUIRE_LOWERCASE', true);
define('PASSWORD_REQUIRE_NUMBERS', true);
define('PASSWORD_REQUIRE_SPECIAL_CHARS', false);

// Roles del sistema (basados en las especificaciones)
define('USER_ROLES', [
    'basico' => [
        'name' => 'Usuario Básico',
        'permissions' => ['dashboard.view', 'dashboard.public'] // Solo ver datos estadísticos sin login
    ],
    'registrado' => [
        'name' => 'Usuario Registrado',
        'permissions' => ['dashboard.view', 'dashboard.public', 'reports.download'] // Ver datos + descargar reportes
    ],
    'admin' => [
        'name' => 'Administrador',
        'permissions' => ['dashboard.view', 'reports.download', 'census.create', 'census.view_own', 'forms.view_approved', 'forms.create', 'forms.edit', 'forms.view', 'species.view', 'species.create', 'species.edit']
    ],
    'supremo' => [
        'name' => 'Administrador Supremo',
        'permissions' => ['*', 'questions.manage'] // Todos los permisos + gestión de preguntas base
    ]
]);

// Estados de formularios
define('FORM_STATES', [
    'borrador' => 'Borrador',
    'pendiente' => 'Pendiente de Aprobación',
    'aprobado' => 'Aprobado',
    'archivado' => 'Archivado'
]);

// Tipos de especies
define('SPECIES_TYPES', [
    'reino' => 'Reino',
    'modulo' => 'Módulo',
    'especie' => 'Especie'
]);

// Tipos de preguntas
define('QUESTION_TYPES', [
    'texto' => 'Texto',
    'numero' => 'Número',
    'booleano' => 'Booleano (Sí/No)',
    'opcion_multiple' => 'Opción Múltiple',
    'fecha' => 'Fecha'
]);

// Configuración de paginación
define('ITEMS_PER_PAGE', 20);

// Configuración de upload de archivos (futuro)
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_FILE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'pdf']);

// Configuración de logs
define('LOG_PATH', __DIR__ . '/../logs/');
define('LOG_LEVEL', 'INFO'); // DEBUG, INFO, WARNING, ERROR

// Configuración de email (futuro)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('SMTP_ENCRYPTION', 'tls');

// Configuración de API
define('API_VERSION', 'v1');
define('API_RATE_LIMIT', 100); // requests per minute

// Configuración de desarrollo
define('DEBUG_MODE', true);
define('DISPLAY_ERRORS', false);

// Zona horaria
define('TIMEZONE', 'America/La_Paz');

// Configuración de backup (futuro)
define('BACKUP_PATH', __DIR__ . '/../backups/');
define('BACKUP_RETENTION_DAYS', 30);

/**
 * Función para obtener configuración de roles
 */
function getRoleConfig($role) {
    return USER_ROLES[$role] ?? null;
}

/**
 * Función para verificar permisos
 */
function hasPermission($userRole, $permission) {
    $roleConfig = getRoleConfig($userRole);

    if (!$roleConfig) {
        return false;
    }

    if ($userRole === 'supremo' || in_array('*', $roleConfig['permissions'])) {
        return true;
    }

    return in_array($permission, $roleConfig['permissions']);
}

/**
 * Función para obtener el nombre del rol
 */
function getRoleName($role) {
    $roleConfig = getRoleConfig($role);
    return $roleConfig ? $roleConfig['name'] : 'Rol Desconocido';
}

/**
 * Función para obtener todos los permisos de un rol
 */
function getRolePermissions($role) {
    $roleConfig = getRoleConfig($role);
    return $roleConfig ? $roleConfig['permissions'] : [];
}

/**
 * Función para verificar si el modo debug está activo
 */
function isDebugMode() {
    return DEBUG_MODE;
}

/**
 * Función para obtener la URL base de la aplicación
 */
function base_url($path = '') {
    return APP_URL . '/' . ltrim($path, '/');
}

/**
 * Función para obtener la ruta absoluta de un archivo
 */
function app_path($path = '') {
    return __DIR__ . '/../' . ltrim($path, '/');
}

/**
 * Función para obtener la ruta pública
 */
function public_path($path = '') {
    return __DIR__ . '/../public/' . ltrim($path, '/');
}

/**
 * Función para redirigir
 */
function redirect($url) {
    header('Location: ' . $url);
    exit;
}

/**
 * Función para obtener el método de la petición HTTP
 */
function request_method() {
    return $_SERVER['REQUEST_METHOD'];
}

/**
 * Función para verificar si la petición es POST
 */
function is_post() {
    return request_method() === 'POST';
}

/**
 * Función para verificar si la petición es GET
 */
function is_get() {
    return request_method() === 'GET';
}

/**
 * Función para verificar si la petición es AJAX
 */
function is_ajax() {
    return isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * Función para obtener el path de la URL
 */
function request_uri() {
    $uri = $_SERVER['REQUEST_URI'];

    // Remover parámetros de query
    if (($pos = strpos($uri, '?')) !== false) {
        $uri = substr($uri, 0, $pos);
    }

    return $uri;
}

/**
 * Función para limpiar strings (seguridad XSS)
 */
function sanitize($string) {
    return htmlspecialchars(trim($string), ENT_QUOTES, 'UTF-8');
}

/**
 * Función para generar tokens CSRF (seguridad futura)
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Función para validar tokens CSRF (seguridad futura)
 */
function validate_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && $_SESSION['csrf_token'] === $token;
}