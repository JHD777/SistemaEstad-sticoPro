Sistema Estadístico Pro - Especificaciones Técnicas
1. Visión General y Propósito
Sistema Estadístico Pro es una plataforma web centralizada para la recolección, gestión y visualización de datos censales de flora y fauna. Su principal diferenciador es su capacidad para manejar formularios dinámicos y altamente específicos para cada especie, sin necesidad de modificar la estructura de la base de datos. El sistema está diseñado para ser escalable, seguro y adaptable a nuevas especies y tipos de datos en el futuro.

2. Arquitectura del Sistema
2.1. Stack Tecnológico
Frontend: HTML5, CSS3, JavaScript (Vanilla JS).
Backend: PHP 8+ (Programación Orientada a Objetos).
Base de Datos: MySQL 8+.
Servidor: Apache (con .htaccess para reescritura de URLs).
Entorno de Desarrollo: Laragon.
2.2. Patrón de Diseño
El sistema sigue una arquitectura MVC (Modelo-Vista-Controlador) con un Controlador Frontal.
Controlador Frontal (public/index.php): Todas las peticiones HTTP son enrutadas a través de este único archivo.
Router (app/core/Router.php): Interpreta la URL y dirige la petición al controlador y método correspondientes.
Modelos (app/models/): Representan la lógica de datos y la interacción con la base de datos (Ej: Usuario, Formulario).
Vistas (app/views/): Contienen el HTML presentado al usuario. Son "tontas" y solo muestran los datos que el controlador les proporciona.
Controladores (app/controllers/): Orquestan el flujo, reciben peticiones, interactúan con los modelos y cargan las vistas.
2.3. Organización de Archivos
La estructura de carpetas está diseñada para la seguridad y la mantenibilidad.

public/: Única carpeta accesible desde la web. Contiene el controlador frontal, assets (CSS, JS) y endpoints de API.
app/: Contiene toda la lógica de la aplicación (controladores, modelos, vistas) y es inaccesible desde el exterior.
config/: Archivos de configuración (BD, constantes de la app).
vendor/: Para dependencias externas (ej. Composer, si se usa en el futuro).
3. Lógica Central y Algoritmos
3.1. El Problema Central: Formularios Dinámicos
El núcleo del sistema es permitir que un administrador cree formularios con un número variable de preguntas, tipos de pregunta y lógica condicional (mostrar/ocultar preguntas basadas en respuestas anteriores). Crear una tabla en la BD para cada formulario es inviable.

3.2. La Solución: Modelo de Datos EAV (Entidad-Atributo-Valor)
La base de datos está diseñada usando un patrón EAV para almacenar las respuestas.

Entidad: Un RegistroCenso (la instancia de un censo para un individuo).
Atributo: Una Pregunta (definida en un formulario).
Valor: Una Respuesta (el valor de una pregunta para un registro de censo específico).
Esto permite que la tabla respuestas crezca infinitamente con cualquier tipo de respuesta sin necesidad de alterar su estructura.

3.3. Algoritmo de Visualización de Datos (Dashboard)
El dashboard no muestra datos en crudo, sino que los presenta de forma jerárquica e inteligente.
vista General (Ej; "flora"):
Identifica todas kas especies hijas (citricos, tuberculos, etc).
Encontrar la intersección de preguntas que existen en TODOS los formularios de esas especies.
Consultar y mostrar los datos SOLO para esas preguntas comunes.
Vista medio (Ej: "Cítricos"):
Identificar todas las especies hijas (Limón, Naranja).
Encontrar la intersección de preguntas que existen en TODOS los formularios de esas especies.
Consultar y mostrar los datos SOLO para esas preguntas comunes.
Vista Específica (Ej: "Limón"):
Identificar el formulario de la especie "Limón".
Consultar y mostrar los datos de TODAS las preguntas de ese formulario.
Esto permite al usuario "hacer zoom" desde lo general a lo específico, viendo solo la información relevante en cada nivel.========================================================================================================
                              BASE DE DATOS
                              =============
-- =================================================================
-- SCRIPT DE CREACIÓN DE BASE DE DATOS PARA SISTEMA ESTADÍSTICO PRO (Versión Optimizada)
-- =================================================================

-- Eliminar la base de datos si existe para una instalación limpia
DROP DATABASE IF EXISTS `sistema_estadistico_pro`;

-- Crear la base de datos con charset UTF8 para soporte completo de caracteres
CREATE DATABASE `sistema_estadistico_pro`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_spanish_ci;

-- Seleccionar la base de datos recién creada para usarla
USE `sistema_estadistico_pro`;

-- =================================================================
-- TABLA 1: usuarios
-- Almacena la información de los usuarios y sus roles de acceso.
-- =================================================================
CREATE TABLE `usuarios` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `rol` ENUM('basico', 'registrado', 'admin', 'supremo') NOT NULL DEFAULT 'basico',
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `activo` BOOLEAN DEFAULT TRUE,
    -- Índice para búsquedas rápidas por email (ya es único, pero es bueno recordarlo)
    INDEX `idx_email` (`email`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 2: especies
-- Define la jerarquía taxonómica: Reino -> Módulo -> Especie.
-- Es una tabla auto-referenciada para crear la estructura de árbol.
-- =================================================================
CREATE TABLE `especies` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(255) NOT NULL,
    `parent_id` INT NULL,
    `tipo` ENUM('reino', 'modulo', 'especie') NOT NULL,
    `descripcion` TEXT NULL,
    FOREIGN KEY (`parent_id`) REFERENCES `especies`(`id`) ON DELETE SET NULL,
    -- Índice para encontrar rápidamente los hijos de un padre
    INDEX `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 3: formularios
-- Cada formulario está asociado a una especie específica.
-- Contiene el flujo de aprobación (borrador, pendiente, aprobado).
-- =================================================================
CREATE TABLE `formularios` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `especie_id` INT NOT NULL,
    `nombre` VARCHAR(255) NOT NULL,
    `descripcion` TEXT NULL,
    `estado` ENUM('borrador', 'pendiente', 'aprobado', 'archivado') NOT NULL DEFAULT 'borrador',
    `creador_id` INT NOT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `fecha_aprobacion` TIMESTAMP NULL,
    `aprobador_id` INT NULL,
    FOREIGN KEY (`especie_id`) REFERENCES `especies`(`id`) ON DELETE CASCADE,
    -- ON DELETE RESTRICT: Protege la integridad. No se puede borrar un usuario que ha creado formularios.
    FOREIGN KEY (`creador_id`) REFERENCES `usuarios`(`id`) ON DELETE RESTRICT,
    -- ON DELETE SET NULL: Si el aprobador es borrado, el formulario sigue aprobado, pero pierde la referencia de quién lo aprobó.
    FOREIGN KEY (`aprobador_id`) REFERENCES `usuarios`(`id`) ON DELETE SET NULL,
    -- Índices para búsquedas comunes en el dashboard
    INDEX `idx_especie_estado` (`especie_id`, `estado`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 4: listas_maestras
-- Define listas de opciones reutilizables para preguntas condicionales
-- =================================================================
CREATE TABLE `listas_maestras` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nombre` VARCHAR(255) NOT NULL,
    `descripcion` TEXT NULL,
    `especie_id` INT NOT NULL, -- Especie/módulo/reino al que pertenece
    `tipo` ENUM('parásitos', 'enfermedades', 'hábitos', 'colores', 'texturas', 'otros') NOT NULL,
    `opciones` TEXT NOT NULL, -- JSON array de opciones: ["Opción 1", "Opción 2", ...]
    `creador_id` INT NOT NULL,
    `fecha_creacion` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `activa` BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (`especie_id`) REFERENCES `especies`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`creador_id`) REFERENCES `usuarios`(`id`) ON DELETE RESTRICT,
    INDEX `idx_especie_tipo` (`especie_id`, `tipo`),
    INDEX `idx_activa` (`activa`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 5: preguntas
-- Define cada pregunta de un formulario con soporte para herencia y listas maestras
-- =================================================================
CREATE TABLE `preguntas` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `formulario_id` INT NOT NULL,
    `texto_pregunta` TEXT NOT NULL,
    `tipo_pregunta` ENUM('texto', 'numero', 'booleano', 'opcion_multiple', 'fecha', 'lista_maestra') NOT NULL,
    `opciones` TEXT NULL, -- Para 'opcion_multiple', ej: "Sí,No,Tal vez"
    `lista_maestra_id` INT NULL, -- Para tipo 'lista_maestra'
    `orden` INT NOT NULL,
    `bloque` VARCHAR(100) NULL, -- Nombre del bloque visual (ej: "Datos Generales")
    `orden_bloque` INT DEFAULT 1, -- Orden dentro del bloque
    `obligatoria` BOOLEAN DEFAULT FALSE,
    `depende_de` INT NULL, -- ID de la pregunta "padre"
    `respuesta_requerida` TEXT NULL, -- Respuesta que activa esta pregunta
    `nivel_herencia` ENUM('base', 'modulo', 'especie') NOT NULL DEFAULT 'especie', -- Nivel jerárquico
    `es_heredada` BOOLEAN DEFAULT FALSE, -- Si la pregunta viene de un nivel superior
    `pregunta_original_id` INT NULL, -- ID de la pregunta original si es heredada
    FOREIGN KEY (`formulario_id`) REFERENCES `formularios`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`depende_de`) REFERENCES `preguntas`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`lista_maestra_id`) REFERENCES `listas_maestras`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`pregunta_original_id`) REFERENCES `preguntas`(`id`) ON DELETE SET NULL,
    -- Índices para obtener las preguntas de un formulario ordenadas
    INDEX `idx_formulario_orden` (`formulario_id`, `orden`),
    INDEX `idx_bloque_orden` (`formulario_id`, `bloque`, `orden_bloque`),
    INDEX `idx_nivel_herencia` (`nivel_herencia`),
    INDEX `idx_es_heredada` (`es_heredada`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 5: registros_censo
-- Representa una instancia única de un censo completado para un individuo.
-- =================================================================
CREATE TABLE `registros_censo` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `formulario_id` INT NOT NULL,
    `usuario_admin_id` INT NOT NULL,
    `fecha_censo` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `ubicacion_geo` VARCHAR(100) NULL, -- Ej: "-12.0464, -77.0428"
    `observaciones` TEXT NULL,
    FOREIGN KEY (`formulario_id`) REFERENCES `formularios`(`id`) ON DELETE CASCADE,
    -- ON DELETE RESTRICT: Protege la integridad. No se puede borrar un usuario que ha realizado censos.
    FOREIGN KEY (`usuario_admin_id`) REFERENCES `usuarios`(`id`) ON DELETE RESTRICT,
    -- Índice para filtrar censos por formulario o admin
    INDEX `idx_formulario_admin` (`formulario_id`, `usuario_admin_id`)
) ENGINE=InnoDB;

-- =================================================================
-- TABLA 6: respuestas
-- Almacena cada respuesta individual, conectando un registro de censo con una pregunta.
-- Esta es la tabla clave del modelo EAV (Entidad-Atributo-Valor).
-- =================================================================
CREATE TABLE `respuestas` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `registro_censo_id` INT NOT NULL,
    `pregunta_id` INT NOT NULL,
    `valor_respuesta` TEXT NOT NULL,
    FOREIGN KEY (`registro_censo_id`) REFERENCES `registros_censo`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`pregunta_id`) REFERENCES `preguntas`(`id`) ON DELETE CASCADE,
    -- Índices cruciales para el rendimiento al consultar datos del dashboard
    INDEX `idx_registro_censo` (`registro_censo_id`),
    INDEX `idx_pregunta` (`pregunta_id`)
) ENGINE=InnoDB;


-- =================================================================
-- INSERCIÓN DE DATOS DE EJEMPLO
-- =================================================================

-- NOTA: El hash de contraseña es para "password123". Generado con password_hash().
 $password_hash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';

-- Insertar usuarios de ejemplo para cada rol
INSERT INTO `usuarios` (`id`, `nombre`, `email`, `password_hash`, `rol`) VALUES
(1, 'Admin Supremo', 'supremo@censo.com', '$password_hash', 'supremo'),
(2, 'Administrador', 'admin@censo.com', '$password_hash', 'admin'),
(3, 'Usuario Registrado', 'registrado@censo.com', '$password_hash', 'registrado'),
(4, 'Usuario Básico', 'basico@censo.com', '$password_hash', 'basico');

-- Insertar la jerarquía de especies
INSERT INTO `especies` (`id`, `nombre`, `parent_id`, `tipo`) VALUES
(1, 'Flora', NULL, 'reino'),
(2, 'Fauna', NULL, 'reino'),
(3, 'Cítricos', 1, 'modulo'),
(4, 'Bovinos', 2, 'modulo'),
(5, 'Limón', 3, 'especie'),
(6, 'Naranja', 3, 'especie'),
(7, 'Vaca', 4, 'especie'),
(8, 'Toro', 4, 'especie');

-- Insertar formularios de ejemplo
INSERT INTO `formularios` (`especie_id`, `nombre`, `estado`, `creador_id`) VALUES
(5, 'Censo de Limón 2024', 'aprobado', 2), -- Creado por un admin, aprobado (simulado)
(7, 'Censo de Vaca Lechera', 'borrador', 2); -- Creado por un admin, pendiente de aprobación

-- Insertar listas maestras de ejemplo
INSERT INTO `listas_maestras` (`nombre`, `descripcion`, `especie_id`, `tipo`, `opciones`, `creador_id`) VALUES
('Parásitos en Cítricos', 'Lista de parásitos comunes en árboles cítricos', 3, 'parásitos', '["Minador de la hoja", "Mosca blanca", "Cochinilla", "Ácaro", "Otro (especificar en observaciones)"]', 1),
('Enfermedades en Cítricos', 'Enfermedades comunes en cítricos', 3, 'enfermedades', '["Oidio", "Cancro cítrico", "Tristeza", "Huanglongbing", "Otra (especificar)"]', 1),
('Colores de Frutos', 'Colores posibles para frutos', 3, 'colores', '["Verde", "Amarillo", "Naranja", "Rojo", "Otro"]', 1);

-- Insertar preguntas base para Flora (nivel base)
INSERT INTO `preguntas` (`formulario_id`, `texto_pregunta`, `tipo_pregunta`, `orden`, `bloque`, `orden_bloque`, `obligatoria`, `nivel_herencia`) VALUES
(1, '¿El organismo realiza fotosíntesis?', 'booleano', 1, 'Datos Básicos', 1, TRUE, 'base'),
(1, '¿Presencia de clorofila?', 'booleano', 2, 'Datos Básicos', 2, TRUE, 'base'),
(1, '¿Tipo de estructura principal?', 'opcion_multiple', 3, 'Datos Básicos', 3, TRUE, 'base'),
(1, 'Ubicación GPS (coordenadas)', 'texto', 4, 'Ubicación', 1, FALSE, 'base');

-- Configurar opciones para preguntas base
UPDATE `preguntas` SET `opciones` = 'Leñosa,Herbácea,Fungus' WHERE `id` = 3;

-- Insertar preguntas para Cítricos (nivel módulo - heredan de Flora)
INSERT INTO `preguntas` (`formulario_id`, `texto_pregunta`, `tipo_pregunta`, `orden`, `bloque`, `orden_bloque`, `obligatoria`, `nivel_herencia`, `es_heredada`, `pregunta_original_id`) VALUES
(2, '¿El organismo realiza fotosíntesis?', 'booleano', 1, 'Datos Básicos', 1, TRUE, 'base', TRUE, 1),
(2, '¿Presencia de clorofila?', 'booleano', 2, 'Datos Básicos', 2, TRUE, 'base', TRUE, 2),
(2, '¿Tipo de estructura principal?', 'opcion_multiple', 3, 'Datos Básicos', 3, TRUE, 'base', TRUE, 3),
(2, 'Ubicación GPS (coordenadas)', 'texto', 4, 'Ubicación', 1, FALSE, 'base', TRUE, 4),
(2, '¿Presencia de aceites esenciales en la piel?', 'booleano', 5, 'Características Físicas', 1, FALSE, 'modulo'),
(2, '¿Estructura del fruto?', 'opcion_multiple', 6, 'Características Físicas', 2, TRUE, 'modulo'),
(2, '¿Tipo de copa del árbol?', 'opcion_multiple', 7, 'Características Físicas', 3, FALSE, 'modulo');

-- Configurar opciones para preguntas de módulo
UPDATE `preguntas` SET `opciones` = 'Leñosa,Herbácea,Fungus' WHERE `id` = 7;
UPDATE `preguntas` SET `opciones` = 'Hesperidio,Baya,Drupa' WHERE `id` = 8;
UPDATE `preguntas` SET `opciones` = 'Redondeada,Columnar,Extendida' WHERE `id` = 9;

-- Insertar preguntas para Limón (nivel especie - heredan de Cítricos)
INSERT INTO `preguntas` (`formulario_id`, `texto_pregunta`, `tipo_pregunta`, `orden`, `bloque`, `orden_bloque`, `obligatoria`, `nivel_herencia`, `es_heredada`, `pregunta_original_id`) VALUES
(3, '¿El organismo realiza fotosíntesis?', 'booleano', 1, 'Datos Básicos', 1, TRUE, 'base', TRUE, 1),
(3, '¿Presencia de clorofila?', 'booleano', 2, 'Datos Básicos', 2, TRUE, 'base', TRUE, 2),
(3, '¿Tipo de estructura principal?', 'opcion_multiple', 3, 'Datos Básicos', 3, TRUE, 'base', TRUE, 3),
(3, 'Ubicación GPS (coordenadas)', 'texto', 4, 'Ubicación', 1, FALSE, 'base', TRUE, 4),
(3, '¿Presencia de aceites esenciales en la piel?', 'booleano', 5, 'Características Físicas', 1, FALSE, 'modulo', TRUE, 5),
(3, '¿Estructura del fruto?', 'opcion_multiple', 6, 'Características Físicas', 2, TRUE, 'modulo', TRUE, 6),
(3, '¿Tipo de copa del árbol?', 'opcion_multiple', 7, 'Características Físicas', 3, FALSE, 'modulo', TRUE, 7),
(3, '¿El árbol fue fumigado el último año?', 'booleano', 8, 'Manejo Agrícola', 1, TRUE, 'especie'),
(3, '¿Cuántos frutos estima que tiene?', 'numero', 9, 'Producción', 1, TRUE, 'especie'),
(3, '¿Presenta signos de alguna plaga?', 'booleano', 10, 'Evaluación de Plagas', 1, FALSE, 'especie'),
(3, '¿Cuál parásito específico?', 'lista_maestra', 11, 'Evaluación de Plagas', 2, FALSE, 'especie'),
(3, '¿Presenta signos de alguna enfermedad?', 'booleano', 12, 'Evaluación de Enfermedades', 1, FALSE, 'especie'),
(3, '¿Cuál enfermedad específica?', 'lista_maestra', 13, 'Evaluación de Enfermedades', 2, FALSE, 'especie'),
(3, 'Nivel de acidez del fruto (%)', 'numero', 14, 'Características del Fruto', 1, FALSE, 'especie'),
(3, 'Color predominante del fruto', 'lista_maestra', 15, 'Características del Fruto', 2, FALSE, 'especie'),
(3, 'Observaciones generales', 'texto', 16, 'Observaciones', 1, FALSE, 'especie');

-- Configurar opciones y lógica condicional para preguntas de especie
UPDATE `preguntas` SET `opciones` = 'Leñosa,Herbácea,Fungus' WHERE `id` = 11;
UPDATE `preguntas` SET `opciones` = 'Hesperidio,Baya,Drupa' WHERE `id` = 12;
UPDATE `preguntas` SET `opciones` = 'Redondeada,Columnar,Extendida' WHERE `id` = 13;
UPDATE `preguntas` SET `depende_de` = 18, `respuesta_requerida` = '1' WHERE `id` = 19; -- Parásito depende de "¿Presenta signos de alguna plaga?"
UPDATE `preguntas` SET `lista_maestra_id` = 1 WHERE `id` = 19; -- Lista de parásitos en cítricos
UPDATE `preguntas` SET `depende_de` = 20, `respuesta_requerida` = '1' WHERE `id` = 21; -- Enfermedad depende de "¿Presenta signos de alguna enfermedad?"
UPDATE `preguntas` SET `lista_maestra_id` = 2 WHERE `id` = 21; -- Lista de enfermedades en cítricos
UPDATE `preguntas` SET `lista_maestra_id` = 3 WHERE `id` = 23; -- Lista de colores

-- Insertar preguntas para el formulario de Vaca (ID 7)
INSERT INTO `preguntas` (`formulario_id`, `texto_pregunta`, `tipo_pregunta`, `orden`, `obligatoria`) VALUES
(2, '¿Está en producción de leche?', 'booleano', 1, TRUE),
(2, '¿Cuántos litros de leche produce al día?', 'numero', 2, FALSE),
(2, '¿Está vacunada contra la fiebre aftosa?', 'booleano', 3, TRUE),
(2, 'Número de partos', 'numero', 4, FALSE);

-- Configurar la lógica condicional para las preguntas de la Vaca
UPDATE `preguntas` SET `depende_de` = 5, `respuesta_requerida` = '1' WHERE `id` = 6; -- Solo muestra producción si está en producción (1 para 'Sí')

-- Insertar un registro de censo completado para un Limón
INSERT INTO `registros_censo` (`formulario_id`, `usuario_admin_id`, `ubicacion_geo`) VALUES (1, 2, '-12.0464, -77.0428');

-- Insertar las respuestas para ese registro de censo del Limón
INSERT INTO `respuestas` (`registro_censo_id`, `pregunta_id`, `valor_respuesta`) VALUES
(1, 1, '1'), -- 'Sí' para fumigado
(1, 2, '250'), -- 250 frutos
(1, 3, 'Sí'), -- Sí tiene plaga
(1, 4, 'Minador de la hoja'); -- Plaga específica

-- Insertar un registro de censo completado para una Vaca
INSERT INTO `registros_censo` (`formulario_id`, `usuario_admin_id`, `ubicacion_geo`) VALUES (2, 2, '-12.0500, -77.0400');

-- Insertar las respuestas para ese registro de censo de la Vaca
INSERT INTO `respuestas` (`registro_censo_id`, `pregunta_id`, `valor_respuesta`) VALUES
(2, 5, '1'), -- 'Sí' está en producción
(2, 6, '22'), -- 22 litros
(2, 7, '1'), -- 'Sí' está vacunada
(2, 8, '3'); -- 3 partos

-- =================================================================
-- FIN DEL SCRIPT
-- =================================================================
4. Base de Datos
4.1. Esquema General
La base de datos sistema_estadistico_pro consta de 6 tablas principales interconectadas:

usuarios: Gestiona los 4 roles del sistema.
especies: Tabla auto-referenciada para crear la jerarquía (Reino -> Módulo -> Especie).
formularios: Asocia un formulario a una especie y gestiona su estado de aprobación.
preguntas: Define cada pregunta de un formulario, incluyendo su tipo y lógica condicional.
registros_censo: Representa una única instancia de un censo completado.
respuestas: La tabla EAV que conecta un registro, una pregunta y su valor.
4.2. Tablas Clave
especies: Fundamental para la navegación y la lógica del dashboard.
preguntas: El corazón de la flexibilidad del sistema. La columna depende_de es crucial para la lógica condicional.
respuestas: La tabla EAV donde reside toda la información censo.
5. Gestión de Usuarios y Permisos (RBAC)
El sistema implementa un control de acceso basado en roles (Role-Based Access Control).

Rol
Permisos Clave
Básico	- Ver dashboard público (visualizaciones generales).
Registrado	- Permisos de Básico. - Descargar reportes públicos.
Admin	- Permisos de Registrado. - Realizar censos con formularios aprobados. - Ver sus propios datos cargados.
Supremo	- Todos los permisos. - Crear/Editar/Eliminar Módulos y Especies. - Aprobar o rechazar formularios creados por Admins. - Acceder a todos los datos y generar reportes globales. - Gestión completa de usuarios: Crear, desactivar/activar y modificar roles de cualquier usuario (excepto otros Supremos).

6. Especificaciones de Seguridad
6.1. Seguridad de la Aplicación
Inyección de Código (XSS): Toda salida de datos que se imprime en HTML debe ser escapada usando htmlspecialchars(). Las vistas deben tratar los datos como no confiables por defecto.
Falsificación de Petición en Sitios Cruzados (CSRF): En una versión futura, se deben implementar tokens CSRF en todos los formularios que modifican datos (POST, PUT, DELETE).
Validación de Entrada: Todos los datos provenientes del usuario ($_POST, $_GET) deben ser saneados y validados. Usar trim() para eliminar espacios en blanco es obligatorio.
6.2. Seguridad de la Base de Datos
Inyección SQL: ESTRICTAMENTE PROHIBIDO concatenar variables en consultas SQL. Todas las interacciones con la BD deben usar sentencias preparadas (prepared statements) con PDO y los métodos bindParam() o bindValue().
6.3. Seguridad de la Infraestructura
Estructura de Archivos: La carpeta public debe ser la única accesible vía web. El DocumentRoot de Apache debe apuntar a ella.
.htaccess: Se utiliza para asegurar que todas las peticiones pasen por index.php y para bloquear el acceso a archivos sensibles (ej. .env, .git).
Contraseñas: Las contraseñas de la base de datos nunca deben estar hardcodeadas en el repositorio. Usar variables de entorno o un archivo de configuración fuera del public.
6.4. Gestión de Contraseñas
Almacenamiento: Las contraseñas de los usuarios NUNCA se almacenan en texto plano. Se deben hashear exclusivamente con la función password_hash() de PHP.
Verificación: La verificación se debe hacer con password_verify().
7. Especificaciones de Estilo y Experiencia de Usuario (UX/UI)
7.1. Principios de Diseño
Funcionalidad sobre Estética: La prioridad es que el sistema sea claro, rápido y fácil de usar.
Diseño Limpio y Minimalista: Interfaz sin elementos innecesarios que distraigan.
Responsividad: El layout debe ser usable en dispositivos móviles y de escritorio.
7.2. Guía de Estilos (Base)
Paleta de Colores: Tonos grises y blancos para el fondo, con un color primario (ej: verde #5cb85c o azul #0275d8) para botones y elementos de acción.
Tipografía: Fuentes sans-serif legibles como Arial, Helvetica o Roboto.
Layout: Basado en cajas (.container) con espaciado consistente (margin, padding).
7.3. Comportamiento Dinámico
Formularios: La lógica de mostrar/ocultar preguntas condicionales debe manejarse con JavaScript en el frontend para una experiencia de usuario instantánea, sin recargas de página.
Feedback al Usuario: Se debe proporcionar feedback claro (mensajes de éxito, error, indicadores de carga) para todas las acciones.
8. Flujo de Trabajo Clave
8.1. Creación de un Nuevo Formulario (Admin)
El Admin selecciona una especie existente (ej: "Naranja").
Accede a una interfaz para "Crear/Editar Formulario".
Añade preguntas una por una, definiendo texto, tipo y orden.
Para preguntas condicionales, selecciona una pregunta "padre" y la respuesta que la activa.
Guarda el formulario con estado borrador o pendiente.
El Admin Supremo recibe una notificación (futuro), revisa el formulario y lo aprueba, cambiando su estado a aprobado.
8.2. Realización de un Censo (Admin en Campo)
El Admin selecciona la especie y el formulario aprobado a utilizar.
El sistema renderiza el formulario dinámicamente en su dispositivo.
El Admin responde las preguntas. JavaScript gestiona la lógica condicional.
Al enviar, los datos se guardan en registros_censo y respuestas.
8.3. Visualización de Datos (Usuario)
El usuario accede al dashboard.
Se le presentan los "Reinos" (Flora, Fauna).
Al hacer clic en uno, ve los "Módulos" (Cítricos, Bovinos) con gráficos basados en preguntas comunes.
Al hacer clic en un "Módulo", ve las "Especies" (Limón, Naranja).
Al hacer clic en una "Especie", ve gráficos detallados basados en todas las preguntas de su formulario.
8.4. Gestión de Usuarios (Admin Supremo)
El Admin Supremo inicia sesión y ve en la navegación un enlace exclusivo: "Gestión de Usuarios".
Al acceder, se le presenta una tabla con todos los usuarios del sistema, mostrando su nombre, email, rol y estado (Activo/Inactivo).
Crear Usuario: Puede hacer clic en un botón "Crear Nuevo Usuario", lo que le lleva a un formulario para introducir nombre, email, una contraseña temporal y asignar un rol (registrado o admin).
Desactivar Usuario: Junto a cada usuario (excepto otros Supremos), hay una acción "Desactivar". Al confirmar, el sistema cambia el campo activo a FALSE en la base de datos. Esto impide que el usuario inicie sesión, pero preserva todos los datos históricos (censos, formularios) que ha generado, manteniendo la integridad del sistema.
9. Hoja de Ruta (Roadmap) - Funcionalidades Futuras
Importación de Datos CSV/Excel: Permitir al Admin Supremo subir un archivo para poblar la base de datos.
Integración con Google Forms: Usar la API de Google Forms como creador de formularios externos.
Generación de Reportes (PDF/Excel): Crear reportes descargables y bien formateados desde el dashboard.
Autenticación Avanzada: Implementar tokens CSRF y, opcionalmente, autenticación de dos factores (2FA).
Autocargador con Composer: Migrar el sistema de require_once manuales a un autocargador estándar de PSR-4.
10. Notas para el Desarrollador / IA
La flexibilidad es la clave: Nunca asumas que el número o tipo de preguntas es fijo. Todo el código debe estar preparado para la variabilidad.
El modelo EAV es sagrado: La lógica de respuestas es el corazón del sistema. No intentes "optimizarlo" en una tabla plana o romperás el propósito del proyecto.
La seguridad no es opcional: Aplica estrictamente las reglas de password_hash, sentencias preparadas y htmlspecialchars.
Piensa en jerarquías: Tanto para las especies como para la visualización de datos, la lógica de "padre-hijo" y "general-específico" es fundamental.
Apéndice A: Deep Dive - Gestión del Ciclo de Vida de una Encuesta
Este capítulo detalla el flujo de trabajo completo de una encuesta, desde su conceptualización hasta la visualización de los datos recolectados.

Fase 1: Creación y Definición de la Encuesta (Admin / Admin Supremo)
Actor Principal: Admin (para especies existentes) o Admin Supremo (para nuevas especies/módulos).

Flujo de Trabajo:

Selección del Contexto:
El Admin accede a su panel y selecciona "Crear Nuevo Formulario".
Se le presenta un desplegable con las especies de tipo especie para las que ya existe un formulario aprobado. No puede crear un formulario para una especie que no ha sido definida.
El Admin Supremo tiene una opción adicional para "Crear Nueva Especie" dentro de un modulo existente, lo que a su vez crea una nueva entrada en la tabla especies.
Construcción del Formulario (Interfaz de "Form Builder"):
Se muestra una interfaz para construir el formulario pregunta por pregunta.
Por cada pregunta, el Admin debe definir:
texto_pregunta: El texto visible para el usuario.
tipo_pregunta: Selecciona de un desplegable ('texto', 'numero', 'booleano', 'opcion_multiple', 'fecha').
opciones: Si el tipo es 'opcion_multiple', aparece un campo de texto para introducir las opciones separadas por comas (ej: "Sí,No,Tal vez").
orden: Un campo numérico para ordenar las preguntas.
obligatoria: Un checkbox para marcar si la pregunta es requerida.
Lógica Condicional (Avanzado):
Un checkbox "Esta pregunta depende de otra".
Si se marca, aparecen dos desplegables:
"Mostrar si la respuesta a [lista de preguntas anteriores] es..."
"[lista de opciones de la pregunta seleccionada]".
Al guardar, esto se traduce en los campos depende_de y respuesta_requerida en la tabla preguntas.
Guardado y Flujo de Aprobación:
Al guardar, el sistema crea una nueva entrada en la tabla formularios con estado = 'borrador' y creador_id = ID del Admin.
El Admin puede luego cambiar el estado a pendiente.
Notificación (Futuro): El Admin Supremo recibe una notificación en su dashboard de que hay un formulario pendiente de revisión.
El Admin Supremo accede a una vista de "Revisión de Formularios", puede previsualizar el formulario y sus reglas, y luego tomar una acción:
Aprobar: Cambia estado a 'aprobado', registra fecha_aprobacion y aprobador_id. El formulario ya está disponible para que los Admins lo usen.
Rechazar: Cambia estado a 'borrador' y puede añadir un comentario para el Admin creador.
Impacto en la Base de Datos:

Creación: INSERT en formularios. Múltiples INSERT en preguntas.
Aprobación: UPDATE en formularios.
Fase 2: Recolección de Datos (Admin en Campo)
Actor Principal: Admin.

Flujo de Trabajo:

Selección del Formulario:
El Admin accede a su panel y selecciona "Realizar Nuevo Censo".
Se le muestra una lista de todos los formularios con estado = 'aprobado', agrupados por especie/módulo.
El Admin selecciona el formulario que va a utilizar (ej: "Censo de Limón 2024").
Renderizado Dinámico del Formulario:
El controlador (FormularioController@responder) consulta la BD:
SELECT * FROM preguntas WHERE formulario_id = ? ORDER BY orden ASC.
El backend pasa este array de preguntas a la vista.
JavaScript en el Frontend: Un script recorre el array de preguntas y genera el HTML del formulario (<input>, <select>, etc.) en tiempo real.
El script también lee las propiedades depende_de y respuesta_requerida y adjunta event listeners a los campos padre para mostrar/ocultar los campos hijos dinámicamente.
Envío de Datos:
El Admin rellena el formulario y pulsa "Enviar".
Los datos se envían por POST a una ruta (ej: formulario/guardar).
Transacción en la Base de Datos: Este es un paso crítico que debe ser atómico.
START TRANSACTION;
INSERT en registros_censo para crear el contenedor principal. Se obtiene el ultimo_id_insertado (registro_censo_id).
Iterar sobre el array $_POST['respuestas']. Por cada respuesta:
INSERT en respuestas con el registro_censo_id obtenido y el pregunta_id y valor_respuesta correspondientes.
Si todos los INSERT tienen éxito: COMMIT;
Si alguno falla: ROLLBACK;
Impacto en la Base de Datos:

Recolección: INSERT en registros_censo. Múltiples INSERT en respuestas.
Fase 3: Procesamiento y Visualización de Datos (Todos los Roles)
Actor Principal: Cualquier usuario (Básico, Registrado, Admin, Supremo), con diferentes niveles de detalle.

Flujo de Trabajo:

Navegación Jerárquica:
El usuario accede al DashboardController@general.
El controlador consulta la tabla especies para obtener los "Reinos" (tipo = 'reino') y los muestra como botones.
Al hacer clic en un "Reino" (ej: Flora, id=1), se hace una petición AJAX al backend para obtener sus "Módulos" hijos (SELECT * FROM especies WHERE parent_id = 1).
Este proceso se repite, permitiendo al usuario "drill-down" (profundizar) en la jerarquía.
Carga de Datos para Visualización:
Cuando el usuario selecciona un nivel (ej: el Módulo "Cítricos"), se activa el Algoritmo de Visualización.
Backend (DashboardController@obtenerDatos):
Recibe el especie_id del nivel seleccionado (ej: id=3 para Cítricos).
Encuentra todos los especie_id hijos (Limón, Naranja, etc.).
Encuentra todos los formulario_id aprobados para esas especies hijas.
Encuentra la intersección de pregunta_id comunes a todos esos formularios. (Esta es la consulta SQL más compleja).
Consulta la tabla respuestas para obtener todos los valores correspondientes a esas pregunta_id comunes y a los registros_censo de esas especies.
Agrupa y procesa los datos (ej: contar respuestas 'Sí'/'No', calcular promedios de números, etc.).
Devuelve un JSON limpio y estructurado al frontend.
Renderizado de Gráficos:
Frontend (JavaScript): Una librería como Chart.js o D3.js recibe el JSON del backend.
El JavaScript renderiza dinámicamente los gráficos (de tarta, de barras, etc.) en el dashboard.
Si el usuario hace clic en una especie específica (ej: "Limón"), el proceso se repite, pero esta vez el backend obtiene TODAS las preguntas de esa especie, no solo la intersección.
Impacto en la Base de Datos:

Visualización: Múltiples SELECT complejos con JOINs y subconsultas en especies, formularios, preguntas, registros_censo y respuestas.
Apéndice B: Contexto y Funcionamiento de la Base de Datos
1. Filosofía de Diseño: Flexibilidad Mediante el Modelo EAV
El mayor desafío técnico del proyecto es gestionar una cantidad infinita de formularios heterogéneos. Un enfoque tradicional (crear una tabla limones, otra vacas, etc.) es inviable, ya que no es escalable y rompería con cada nueva especie o pregunta añadida.

Para resolver esto, el núcleo de la base de datos se basa en el patrón de diseño EAV (Entidad-Atributo-Valor).

Entidad: Un individuo censado. En nuestra BD, esto es un registro_censo.
Atributo: Una característica que se mide. En nuestra BD, esto es una pregunta definida en un formulario.
Valor: El dato específico para esa entidad y ese atributo. En nuestra BD, esto es una respuesta.
Esta arquitectura desacopla la estructura de las preguntas de los datos recolectados. La tabla respuestas puede crecer infinitamente almacenando cualquier tipo de respuesta sin que nunca necesitemos modificar su estructura (ALTER TABLE).

Ejemplo Práctico:

Un censo de un Limón crea un registro_censo (ID 100) y varias respuestas (pregunta 1 -> "Sí", pregunta 2 -> "250").
Un censo de una Vaca crea otro registro_censo (ID 101) y otras respuestas (pregunta 5 -> "Sí", pregunta 6 -> "22").
Ambos conjuntos de datos viven felices en la misma tabla respuestas, cada uno asociado a su registro_censo y pregunta correspondiente.
2. Desglose del Esquema de Tablas
A continuación se detalla cada tabla, su propósito y su rol en el ecosistema del sistema.

usuarios
Propósito: Gestiona la identidad y los permisos de las personas que interactúan con el sistema.
Columnas Clave:
rol: Define el nivel de acceso (basico, registrado, admin, supremo). Es la base del sistema de permisos (RBAC).
password_hash: Almacena el hash de la contraseña. Nunca se almacena la contraseña en texto plano.
activo: Permite deshabilitar cuentas sin borrarlas, manteniendo la integridad de los datos que han creado. Este campo es clave para la gestión de usuarios. En lugar de borrar un usuario (lo que rompería la integridad histórica de sus datos), se le desactiva cambiando este campo a FALSE. Un usuario inactivo no puede iniciar sesión, pero todos los censos o formularios que creó permanecen en el sistema.
Relaciones y Lógica: Es la tabla "padre" para formularios.creador_id y registros_censo.usuario_admin_id. La restricción ON DELETE RESTRICT es crucial: impide borrar un usuario que ha creado formularios o realizado censos, protegiendo la integridad histórica de los datos. El Admin Supremo interactúa con esta tabla a través de un panel dedicado para crear nuevos usuarios o modificar el campo activo y rol de los existentes, centralizando así el control de acceso al sistema.
especies
Propósito: Define la taxonomía jerárquica del sistema (Reino -> Módulo -> Especie). Es el esqueleto sobre el que se construyen los formularios y se navegan los datos.
Columnas Clave:
parent_id: Es una clave foránea auto-referenciada. Un parent_id NULL indica un nivel superior (un "Reino"). El parent_id de "Limón" es el id de "Cítricos".
tipo: Clasifica el nodo (reino, modulo, especie), facilitando las consultas.
Relaciones y Lógica: Es la tabla "padre" de formularios.especie_id. ON DELETE SET NULL permite borrar un módulo (ej: "Cítricos") sin borrar las especies hijas ("Limón", "Naranja"), que simplemente quedarían huérfanas.
formularios
Propósito: Actúa como un contenedor que agrupa un conjunto de preguntas y lo asocia a una especie específica.
Columnas Clave:
estado: Es el pilar del flujo de aprobación (borrador, pendiente, aprobado, archivado). Solo los formularios aprobados son visibles para realizar censos.
creador_id / aprobador_id: Registra la responsabilidad y la trazabilidad de quién crea y quién aprueba cada formulario.
Relaciones y Lógica: Conecta especies con preguntas. ON DELETE CASCADE asegura que si se borra una especie, todos sus formularios asociados se borren también.
preguntas
Propósito: Define las preguntas individuales que componen un formulario. Aquí reside la flexibilidad del sistema.
Columnas Clave:
tipo_pregunta: Define el tipo de input en el frontend (texto, numero, etc.).
opciones: Almacena las opciones para preguntas de selección múltiple, como un string separado por comas.
depende_de / respuesta_requerida: Implementa la lógica condicional. Si la pregunta A depende de la pregunta B, y la respuesta a B es "Sí", entonces la pregunta A se muestra.
Relaciones y Lógica: Es la tabla "padre" de respuestas.pregunta_id. ON DELETE CASCADE borra todas las respuestas de una pregunta si esta es eliminada.
registros_censo
Propósito: Representa una instancia única y completa de un censo. Es la "caja" que contiene todas las respuestas de un individuo en un momento dado.
Columnas Clave:
usuario_admin_id: Registra quién realizó el censo.
fecha_censo: Marca de tiempo del censo.
ubicacion_geo: Permite análisis geoespaciales.
Relaciones y Lógica: Es la tabla "padre" de respuestas.registro_censo_id. ON DELETE CASCADE es fundamental: si se borra un registro de censo, todas sus respuestas deben desaparecer con él para evitar datos huérfanos.
respuestas
Propósito: Es la tabla EAV central. Almacena cada pieza individual de datos, conectando una pregunta con un registro de censo.
Columnas Clave:
valor_respuesta: Almacena el dato como texto (TEXT). Esto permite guardar números, fechas, booleanos ("1"/"0") o texto sin importar el tipo de pregunta original. La conversión de tipo se maneja en la capa de aplicación (PHP/JS).
Relaciones y Lógica: Es la tabla "hija" de registros_censo y preguntas. Las dos claves foráneas con ON DELETE CASCADE garantizan la limpieza y consistencia de los datos.
3. Flujo de Datos en la Base de Datos
Creación de Formulario:
especies (selecciona una) -> formularios (crea un nuevo registro) -> preguntas (crea múltiples registros asociados al nuevo formulario).
Recolección de Censo:
formularios (selecciona uno aprobado) -> registros_censo (crea un nuevo registro) -> respuestas (crea múltiples registros, uno por cada pregunta respondida, asociados al nuevo registro_censo).
Visualización de Datos (Dashboard):
Esta es la operación más compleja. Implica JOINs múltiples:
especies (para obtener la jerarquía) -> formularios (para encontrar los aprobados) -> preguntas (para encontrar las comunes o específicas) -> registros_censo (para filtrar por especie/módulo) -> respuestas (para obtener los valores finales).
Los índices en estas tablas son cruciales para que estas consultas complejas sean rápidas.
4. Rendimiento e Índices
El modelo EAV puede ser costoso en términos de consultas si no se optimiza. Por ello, se han añadido índices estratégicos en columnas que se usan frecuentemente en cláusulas WHERE, JOIN y ORDER BY (ej: preguntas.formulario_id, respuestas.pregunta_id, usuarios.email). Esto asegura que el rendimiento del sistema se mantenga a medida que la base de datos crece a millones de registros.

=============================IMPORTANTE----------------------------------------------
(Sección 8) Flujo de Trabajo Clave - Con Nueva Sección Añadida
...flujos existentes...

8.5. Registro Público de Usuario
Un usuario no autenticado accede al sitio y ve en la navegación los enlaces "Iniciar Sesión" y "Registrarse".
Al hacer clic en "Registrarse", se le presenta un formulario para introducir su nombre, email y contraseña.
El usuario rellena el formulario y lo envía.
El sistema valida que los campos no estén vacíos y que las contraseñas coincidan.
Creación Automática: El sistema crea una nueva entrada en la tabla usuarios con el rol 'registrado' por defecto. Se verifica que el email no esté ya en uso.
Feedback y Redirección: Si el registro es exitoso, el sistema muestra un mensaje de éxito y redirige al usuario a la página de login para que pueda iniciar sesión con su nueva cuenta.