# Sistema Estadístico Pro

## 🚀 Inicio Rápido

### **Acceso al Sistema**
- **URL Principal:** `https://sistema_estadistico_pro.test/`
- **Página de Inicio:** Dashboard principal con información del sistema

### **Credenciales de Demostración**
| Rol | Email | Contraseña | Acceso |
|-----|-------|------------|---------|
| **Usuario Básico** | `basico@censo.com` | `password123` | Dashboard público |
| **Usuario Registrado** | `registrado@censo.com` | `password123` | Reportes básicos |
| **Administrador** | `admin@censo.com` | `password123` | Gestión completa |
| **Admin Supremo** | `supremo@censo.com` | `password123` | Control total |

## 📋 Características Destacadas

### **Página Principal del Sistema**
- ✅ Diseño elegante y profesional con información del Sistema Estadístico Pro
- ✅ Secciones informativas sobre el sistema (características, funcionalidades)
- ✅ Demostraciones interactivas por nivel de usuario
- ✅ Navegación intuitiva con efectos visuales modernos
- ✅ Footer con enlaces a información legal y contacto

### **Funcionalidades Técnicas**
- ✅ **Arquitectura EAV** para formularios dinámicos
- ✅ **Jerarquía taxonómica** completa (Reino → Módulo → Especie)
- ✅ **Sistema RBAC** avanzado con 4 niveles de permisos
- ✅ **API REST** completa para integración externa
- ✅ **Seguridad** integral (XSS, SQL Injection, CSRF)

## 🛠 Configuración Técnica

### **Servidor Web**
- **Dominio personalizado:** `https://sistema_estadistico_pro.test/`
- **Redirecciones automáticas** desde localhost
- **SSL forzado** para seguridad
- **Headers de seguridad** configurados

### **Base de Datos**
- **Inicialización automática** en primera carga
- **Datos de ejemplo** incluidos
- **Modelo EAV** implementado
- **Relaciones jerárquicas** configuradas

## 🎨 Diseño y UX

### **Características Visuales**
- ✅ **Gradientes modernos** y colores corporativos
- ✅ **Tipografía profesional** (Inter font)
- ✅ **Animaciones suaves** y transiciones elegantes
- ✅ **Cards flotantes** con efectos hover
- ✅ **Navbar transparente** con efecto blur
- ✅ **Responsive design** para todos los dispositivos

### **Estructura de Página**
1. **Dashboard Principal** - Información general del sistema
2. **Estadísticas del Sistema** - Datos y métricas principales
3. **Características Técnicas** - EAV, Seguridad, RBAC destacadas
4. **Navegación por Roles** - Acceso según permisos de usuario
5. **Footer Informativo** - Enlaces legales y de contacto

## 🔧 Desarrollo

### **Arquitectura MVC**
```
app/
├── controllers/     # Controladores del sistema
├── models/         # Modelos de datos y lógica
├── views/          # Plantillas y páginas
└── core/           # Clases base y utilidades
```

### **Archivos Implementados**
- ✅ **API REST completa** (`public/api/v1/`)
- ✅ **Página principal corporativa** moderna
- ✅ **Sistema de autenticación** seguro
- ✅ **Dashboard jerárquico** funcional
- ✅ **Gestión de formularios** dinámica

## 🚀 Próximos Pasos

1. **Iniciar Laragon** y acceder a `https://sistema_estadistico_pro.test/`
2. **Iniciar sesión** con las credenciales de demostración
3. **Explorar el dashboard** según su nivel de permisos
4. **Crear formularios personalizados** (usuarios admin y supremos)
5. **Realizar censos** con lógica condicional avanzada

## 📞 Soporte

Para soporte técnico o consultas:
- **Email:** soporte@sistema-estadistico-pro.com
- **Teléfono:** +591 123 4567
- **Documentación:** Disponible en la plataforma
- **Información adicional:** Visite las páginas de Acerca de, Contacto y Documentación

---

**Sistema Estadístico Pro** | Plataforma avanzada para la gestión y análisis de datos estadísticos de especies biológicas.